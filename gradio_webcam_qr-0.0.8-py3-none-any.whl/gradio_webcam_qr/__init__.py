
from .webcam_qr import webcam_qr

__all__ = ['webcam_qr']
