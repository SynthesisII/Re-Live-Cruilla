const { setContext: ie, getContext: E } = window.__gradio__svelte__internal, R = "WORKER_PROXY_CONTEXT_KEY";
function C() {
  return E(R);
}
const k = "lite.local";
function O(n) {
  return n.host === window.location.host || n.host === "localhost:7860" || n.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  n.host === k;
}
function L(n, e) {
  const r = e.toLowerCase();
  for (const [t, l] of Object.entries(n))
    if (t.toLowerCase() === r)
      return l;
}
function T(n) {
  const e = typeof window < "u";
  if (n == null || !e)
    return !1;
  const r = new URL(n, window.location.href);
  return !(!O(r) || r.protocol !== "http:" && r.protocol !== "https:");
}
let _;
async function q(n) {
  const e = typeof window < "u";
  if (n == null || !e || !T(n))
    return n;
  if (_ == null)
    try {
      _ = C();
    } catch {
      return n;
    }
  if (_ == null)
    return n;
  const t = new URL(n, window.location.href).pathname;
  return _.httpRequest({
    method: "GET",
    path: t,
    headers: {},
    query_string: ""
  }).then((l) => {
    if (l.status !== 200)
      throw new Error(`Failed to get file ${t} from the Wasm worker.`);
    const o = new Blob([l.body], {
      type: L(l.headers, "content-type")
    });
    return URL.createObjectURL(o);
  });
}
const {
  SvelteComponent: K,
  assign: d,
  bubble: U,
  claim_element: P,
  compute_rest_props: h,
  detach: W,
  element: I,
  exclude_internal_props: S,
  get_spread_update: X,
  init: Y,
  insert_hydration: j,
  listen: F,
  noop: g,
  safe_not_equal: G,
  set_attributes: w,
  src_url_equal: H,
  toggle_class: b
} = window.__gradio__svelte__internal;
function N(n) {
  let e, r, t, l, o = [
    {
      src: r = /*resolved_src*/
      n[0]
    },
    /*$$restProps*/
    n[1]
  ], s = {};
  for (let i = 0; i < o.length; i += 1)
    s = d(s, o[i]);
  return {
    c() {
      e = I("img"), this.h();
    },
    l(i) {
      e = P(i, "IMG", { src: !0 }), this.h();
    },
    h() {
      w(e, s), b(e, "svelte-kxeri3", !0);
    },
    m(i, u) {
      j(i, e, u), t || (l = F(
        e,
        "load",
        /*load_handler*/
        n[4]
      ), t = !0);
    },
    p(i, [u]) {
      w(e, s = X(o, [
        u & /*resolved_src*/
        1 && !H(e.src, r = /*resolved_src*/
        i[0]) && { src: r },
        u & /*$$restProps*/
        2 && /*$$restProps*/
        i[1]
      ])), b(e, "svelte-kxeri3", !0);
    },
    i: g,
    o: g,
    d(i) {
      i && W(e), t = !1, l();
    }
  };
}
function V(n, e, r) {
  const t = ["src"];
  let l = h(e, t), { src: o = void 0 } = e, s, i;
  function u(a) {
    U.call(this, n, a);
  }
  return n.$$set = (a) => {
    e = d(d({}, e), S(a)), r(1, l = h(e, t)), "src" in a && r(2, o = a.src);
  }, n.$$.update = () => {
    if (n.$$.dirty & /*src, latest_src*/
    12) {
      r(0, s = o), r(3, i = o);
      const a = o;
      q(a).then((v) => {
        i === a && r(0, s = v);
      });
    }
  }, [s, l, o, i, u];
}
class A extends K {
  constructor(e) {
    super(), Y(this, e, V, N, G, { src: 2 });
  }
}
const {
  SvelteComponent: B,
  attr: D,
  check_outros: M,
  children: z,
  claim_component: J,
  claim_element: Q,
  create_component: Z,
  destroy_component: x,
  detach: y,
  element: $,
  group_outros: ee,
  init: te,
  insert_hydration: ne,
  mount_component: le,
  safe_not_equal: re,
  toggle_class: c,
  transition_in: f,
  transition_out: m
} = window.__gradio__svelte__internal;
function p(n) {
  let e, r;
  return e = new A({
    props: { src: (
      /*value*/
      n[0].url
    ), alt: "" }
  }), {
    c() {
      Z(e.$$.fragment);
    },
    l(t) {
      J(e.$$.fragment, t);
    },
    m(t, l) {
      le(e, t, l), r = !0;
    },
    p(t, l) {
      const o = {};
      l & /*value*/
      1 && (o.src = /*value*/
      t[0].url), e.$set(o);
    },
    i(t) {
      r || (f(e.$$.fragment, t), r = !0);
    },
    o(t) {
      m(e.$$.fragment, t), r = !1;
    },
    d(t) {
      x(e, t);
    }
  };
}
function oe(n) {
  let e, r, t = (
    /*value*/
    n[0] && p(n)
  );
  return {
    c() {
      e = $("div"), t && t.c(), this.h();
    },
    l(l) {
      e = Q(l, "DIV", { class: !0 });
      var o = z(e);
      t && t.l(o), o.forEach(y), this.h();
    },
    h() {
      D(e, "class", "container svelte-1sgcyba"), c(
        e,
        "table",
        /*type*/
        n[1] === "table"
      ), c(
        e,
        "gallery",
        /*type*/
        n[1] === "gallery"
      ), c(
        e,
        "selected",
        /*selected*/
        n[2]
      ), c(
        e,
        "border",
        /*value*/
        n[0]
      );
    },
    m(l, o) {
      ne(l, e, o), t && t.m(e, null), r = !0;
    },
    p(l, [o]) {
      /*value*/
      l[0] ? t ? (t.p(l, o), o & /*value*/
      1 && f(t, 1)) : (t = p(l), t.c(), f(t, 1), t.m(e, null)) : t && (ee(), m(t, 1, 1, () => {
        t = null;
      }), M()), (!r || o & /*type*/
      2) && c(
        e,
        "table",
        /*type*/
        l[1] === "table"
      ), (!r || o & /*type*/
      2) && c(
        e,
        "gallery",
        /*type*/
        l[1] === "gallery"
      ), (!r || o & /*selected*/
      4) && c(
        e,
        "selected",
        /*selected*/
        l[2]
      ), (!r || o & /*value*/
      1) && c(
        e,
        "border",
        /*value*/
        l[0]
      );
    },
    i(l) {
      r || (f(t), r = !0);
    },
    o(l) {
      m(t), r = !1;
    },
    d(l) {
      l && y(e), t && t.d();
    }
  };
}
function se(n, e, r) {
  let { value: t } = e, { type: l } = e, { selected: o = !1 } = e;
  return n.$$set = (s) => {
    "value" in s && r(0, t = s.value), "type" in s && r(1, l = s.type), "selected" in s && r(2, o = s.selected);
  }, [t, l, o];
}
class ae extends B {
  constructor(e) {
    super(), te(this, e, se, oe, re, { value: 0, type: 1, selected: 2 });
  }
}
export {
  ae as default
};
