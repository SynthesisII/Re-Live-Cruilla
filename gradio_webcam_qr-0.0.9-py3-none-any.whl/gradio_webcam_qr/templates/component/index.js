var v1 = Object.defineProperty;
var Qr = (r) => {
  throw TypeError(r);
};
var b1 = (r, e, t) => e in r ? v1(r, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : r[e] = t;
var C0 = (r, e, t) => b1(r, typeof e != "symbol" ? e + "" : e, t), k1 = (r, e, t) => e.has(r) || Qr("Cannot " + t);
var Zr = (r, e, t) => e.has(r) ? Qr("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(r) : e.set(r, t);
var wt = (r, e, t) => (k1(r, e, "access private method"), t);
const {
  SvelteComponent: w1,
  assign: y1,
  children: S1,
  claim_element: T1,
  create_slot: M1,
  detach: Kr,
  element: P1,
  get_all_dirty_from_scope: _1,
  get_slot_changes: z1,
  get_spread_update: R1,
  init: N1,
  insert_hydration: L1,
  safe_not_equal: I1,
  set_dynamic_element_data: Jr,
  set_style: z0,
  toggle_class: ne,
  transition_in: ln,
  transition_out: sn,
  update_slot_base: O1
} = window.__gradio__svelte__internal;
function q1(r) {
  let e, t, x;
  const a = (
    /*#slots*/
    r[22].default
  ), n = M1(
    a,
    r,
    /*$$scope*/
    r[21],
    null
  );
  let o = [
    { "data-testid": (
      /*test_id*/
      r[9]
    ) },
    { id: (
      /*elem_id*/
      r[4]
    ) },
    {
      class: t = "block " + /*elem_classes*/
      r[5].join(" ") + " svelte-1ezsyiy"
    }
  ], s = {};
  for (let i = 0; i < o.length; i += 1)
    s = y1(s, o[i]);
  return {
    c() {
      e = P1(
        /*tag*/
        r[18]
      ), n && n.c(), this.h();
    },
    l(i) {
      e = T1(
        i,
        /*tag*/
        (r[18] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0
        }
      );
      var m = S1(e);
      n && n.l(m), m.forEach(Kr), this.h();
    },
    h() {
      Jr(
        /*tag*/
        r[18]
      )(e, s), ne(
        e,
        "hidden",
        /*visible*/
        r[12] === !1
      ), ne(
        e,
        "padded",
        /*padding*/
        r[8]
      ), ne(
        e,
        "flex",
        /*flex*/
        r[17]
      ), ne(
        e,
        "border_focus",
        /*border_mode*/
        r[7] === "focus"
      ), ne(
        e,
        "border_contrast",
        /*border_mode*/
        r[7] === "contrast"
      ), ne(e, "hide-container", !/*explicit_call*/
      r[10] && !/*container*/
      r[11]), z0(
        e,
        "height",
        /*get_dimension*/
        r[19](
          /*height*/
          r[0]
        )
      ), z0(
        e,
        "min-height",
        /*get_dimension*/
        r[19](
          /*min_height*/
          r[1]
        )
      ), z0(
        e,
        "max-height",
        /*get_dimension*/
        r[19](
          /*max_height*/
          r[2]
        )
      ), z0(e, "width", typeof /*width*/
      r[3] == "number" ? `calc(min(${/*width*/
      r[3]}px, 100%))` : (
        /*get_dimension*/
        r[19](
          /*width*/
          r[3]
        )
      )), z0(
        e,
        "border-style",
        /*variant*/
        r[6]
      ), z0(
        e,
        "overflow",
        /*allow_overflow*/
        r[13] ? (
          /*overflow_behavior*/
          r[14]
        ) : "hidden"
      ), z0(
        e,
        "flex-grow",
        /*scale*/
        r[15]
      ), z0(e, "min-width", `calc(min(${/*min_width*/
      r[16]}px, 100%))`), z0(e, "border-width", "var(--block-border-width)");
    },
    m(i, m) {
      L1(i, e, m), n && n.m(e, null), x = !0;
    },
    p(i, m) {
      n && n.p && (!x || m & /*$$scope*/
      2097152) && O1(
        n,
        a,
        i,
        /*$$scope*/
        i[21],
        x ? z1(
          a,
          /*$$scope*/
          i[21],
          m,
          null
        ) : _1(
          /*$$scope*/
          i[21]
        ),
        null
      ), Jr(
        /*tag*/
        i[18]
      )(e, s = R1(o, [
        (!x || m & /*test_id*/
        512) && { "data-testid": (
          /*test_id*/
          i[9]
        ) },
        (!x || m & /*elem_id*/
        16) && { id: (
          /*elem_id*/
          i[4]
        ) },
        (!x || m & /*elem_classes*/
        32 && t !== (t = "block " + /*elem_classes*/
        i[5].join(" ") + " svelte-1ezsyiy")) && { class: t }
      ])), ne(
        e,
        "hidden",
        /*visible*/
        i[12] === !1
      ), ne(
        e,
        "padded",
        /*padding*/
        i[8]
      ), ne(
        e,
        "flex",
        /*flex*/
        i[17]
      ), ne(
        e,
        "border_focus",
        /*border_mode*/
        i[7] === "focus"
      ), ne(
        e,
        "border_contrast",
        /*border_mode*/
        i[7] === "contrast"
      ), ne(e, "hide-container", !/*explicit_call*/
      i[10] && !/*container*/
      i[11]), m & /*height*/
      1 && z0(
        e,
        "height",
        /*get_dimension*/
        i[19](
          /*height*/
          i[0]
        )
      ), m & /*min_height*/
      2 && z0(
        e,
        "min-height",
        /*get_dimension*/
        i[19](
          /*min_height*/
          i[1]
        )
      ), m & /*max_height*/
      4 && z0(
        e,
        "max-height",
        /*get_dimension*/
        i[19](
          /*max_height*/
          i[2]
        )
      ), m & /*width*/
      8 && z0(e, "width", typeof /*width*/
      i[3] == "number" ? `calc(min(${/*width*/
      i[3]}px, 100%))` : (
        /*get_dimension*/
        i[19](
          /*width*/
          i[3]
        )
      )), m & /*variant*/
      64 && z0(
        e,
        "border-style",
        /*variant*/
        i[6]
      ), m & /*allow_overflow, overflow_behavior*/
      24576 && z0(
        e,
        "overflow",
        /*allow_overflow*/
        i[13] ? (
          /*overflow_behavior*/
          i[14]
        ) : "hidden"
      ), m & /*scale*/
      32768 && z0(
        e,
        "flex-grow",
        /*scale*/
        i[15]
      ), m & /*min_width*/
      65536 && z0(e, "min-width", `calc(min(${/*min_width*/
      i[16]}px, 100%))`);
    },
    i(i) {
      x || (ln(n, i), x = !0);
    },
    o(i) {
      sn(n, i), x = !1;
    },
    d(i) {
      i && Kr(e), n && n.d(i);
    }
  };
}
function H1(r) {
  let e, t = (
    /*tag*/
    r[18] && q1(r)
  );
  return {
    c() {
      t && t.c();
    },
    l(x) {
      t && t.l(x);
    },
    m(x, a) {
      t && t.m(x, a), e = !0;
    },
    p(x, [a]) {
      /*tag*/
      x[18] && t.p(x, a);
    },
    i(x) {
      e || (ln(t, x), e = !0);
    },
    o(x) {
      sn(t, x), e = !1;
    },
    d(x) {
      t && t.d(x);
    }
  };
}
function U1(r, e, t) {
  let { $$slots: x = {}, $$scope: a } = e, { height: n = void 0 } = e, { min_height: o = void 0 } = e, { max_height: s = void 0 } = e, { width: i = void 0 } = e, { elem_id: m = "" } = e, { elem_classes: d = [] } = e, { variant: E = "solid" } = e, { border_mode: C = "base" } = e, { padding: A = !0 } = e, { type: b = "normal" } = e, { test_id: y = void 0 } = e, { explicit_call: w = !1 } = e, { container: P = !0 } = e, { visible: k = !0 } = e, { allow_overflow: f = !0 } = e, { overflow_behavior: B = "auto" } = e, { scale: D = null } = e, { min_width: p = 0 } = e, { flex: F = !1 } = e, _ = b === "fieldset" ? "fieldset" : "div";
  const M = (R) => {
    if (R !== void 0) {
      if (typeof R == "number")
        return R + "px";
      if (typeof R == "string")
        return R;
    }
  };
  return r.$$set = (R) => {
    "height" in R && t(0, n = R.height), "min_height" in R && t(1, o = R.min_height), "max_height" in R && t(2, s = R.max_height), "width" in R && t(3, i = R.width), "elem_id" in R && t(4, m = R.elem_id), "elem_classes" in R && t(5, d = R.elem_classes), "variant" in R && t(6, E = R.variant), "border_mode" in R && t(7, C = R.border_mode), "padding" in R && t(8, A = R.padding), "type" in R && t(20, b = R.type), "test_id" in R && t(9, y = R.test_id), "explicit_call" in R && t(10, w = R.explicit_call), "container" in R && t(11, P = R.container), "visible" in R && t(12, k = R.visible), "allow_overflow" in R && t(13, f = R.allow_overflow), "overflow_behavior" in R && t(14, B = R.overflow_behavior), "scale" in R && t(15, D = R.scale), "min_width" in R && t(16, p = R.min_width), "flex" in R && t(17, F = R.flex), "$$scope" in R && t(21, a = R.$$scope);
  }, [
    n,
    o,
    s,
    i,
    m,
    d,
    E,
    C,
    A,
    y,
    w,
    P,
    k,
    f,
    B,
    D,
    p,
    F,
    _,
    M,
    b,
    a,
    x
  ];
}
class G1 extends w1 {
  constructor(e) {
    super(), N1(this, e, U1, H1, I1, {
      height: 0,
      min_height: 1,
      max_height: 2,
      width: 3,
      elem_id: 4,
      elem_classes: 5,
      variant: 6,
      border_mode: 7,
      padding: 8,
      type: 20,
      test_id: 9,
      explicit_call: 10,
      container: 11,
      visible: 12,
      allow_overflow: 13,
      overflow_behavior: 14,
      scale: 15,
      min_width: 16,
      flex: 17
    });
  }
}
const V1 = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ea = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
V1.reduce(
  (r, { color: e, primary: t, secondary: x }) => ({
    ...r,
    [e]: {
      primary: ea[e][t],
      secondary: ea[e][x]
    }
  }),
  {}
);
class or {
  // The + prefix indicates that these fields aren't writeable
  // Lexer holding the input string.
  // Start offset, zero-based inclusive.
  // End offset, zero-based exclusive.
  constructor(e, t, x) {
    this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = x;
  }
  /**
   * Merges two `SourceLocation`s from location providers, given they are
   * provided in order of appearance.
   * - Returns the first one's location if only the first is provided.
   * - Returns a merged range of the first and the last if both are provided
   *   and their lexers match.
   * - Otherwise, returns null.
   */
  static range(e, t) {
    return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new or(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc;
  }
}
class lr {
  // don't expand the token
  // used in \noexpand
  constructor(e, t) {
    this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
  }
  /**
   * Given a pair of tokens (this and endToken), compute a `Token` encompassing
   * the whole input range enclosed by these two.
   */
  range(e, t) {
    return new lr(t, or.range(this, e));
  }
}
class J {
  // Error start position based on passed-in Token or ParseNode.
  // Length of affected text based on passed-in Token or ParseNode.
  // The underlying error message without any context added.
  constructor(e, t) {
    this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
    var x = "KaTeX parse error: " + e, a, n, o = t && t.loc;
    if (o && o.start <= o.end) {
      var s = o.lexer.input;
      a = o.start, n = o.end, a === s.length ? x += " at end of input: " : x += " at position " + (a + 1) + ": ";
      var i = s.slice(a, n).replace(/[^]/g, "$&̲"), m;
      a > 15 ? m = "…" + s.slice(a - 15, a) : m = s.slice(0, a);
      var d;
      n + 15 < s.length ? d = s.slice(n, n + 15) + "…" : d = s.slice(n), x += m + i + d;
    }
    var E = new Error(x);
    return E.name = "ParseError", E.__proto__ = J.prototype, E.position = a, a != null && n != null && (E.length = n - a), E.rawMessage = e, E;
  }
}
J.prototype.__proto__ = Error.prototype;
var X1 = function(e, t) {
  return e.indexOf(t) !== -1;
}, $1 = function(e, t) {
  return e === void 0 ? t : e;
}, W1 = /([A-Z])/g, j1 = function(e) {
  return e.replace(W1, "-$1").toLowerCase();
}, Y1 = {
  "&": "&amp;",
  ">": "&gt;",
  "<": "&lt;",
  '"': "&quot;",
  "'": "&#x27;"
}, Q1 = /[&><"']/g;
function Z1(r) {
  return String(r).replace(Q1, (e) => Y1[e]);
}
var un = function r(e) {
  return e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? r(e.body[0]) : e : e.type === "font" ? r(e.body) : e;
}, K1 = function(e) {
  var t = un(e);
  return t.type === "mathord" || t.type === "textord" || t.type === "atom";
}, J1 = function(e) {
  if (!e)
    throw new Error("Expected non-null, but got " + String(e));
  return e;
}, e9 = function(e) {
  var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
  return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
}, t0 = {
  contains: X1,
  deflt: $1,
  escape: Z1,
  hyphenate: j1,
  getBaseElem: un,
  isCharacterBox: K1,
  protocolFromUrl: e9
};
class Se {
  constructor(e, t, x) {
    this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = x;
  }
  /**
   * Get the style of a superscript given a base in the current style.
   */
  sup() {
    return me[t9[this.id]];
  }
  /**
   * Get the style of a subscript given a base in the current style.
   */
  sub() {
    return me[x9[this.id]];
  }
  /**
   * Get the style of a fraction numerator given the fraction in the current
   * style.
   */
  fracNum() {
    return me[r9[this.id]];
  }
  /**
   * Get the style of a fraction denominator given the fraction in the current
   * style.
   */
  fracDen() {
    return me[a9[this.id]];
  }
  /**
   * Get the cramped version of a style (in particular, cramping a cramped style
   * doesn't change the style).
   */
  cramp() {
    return me[n9[this.id]];
  }
  /**
   * Get a text or display version of this style.
   */
  text() {
    return me[o9[this.id]];
  }
  /**
   * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
   */
  isTight() {
    return this.size >= 2;
  }
}
var ir = 0, Wt = 1, Qe = 2, be = 3, ft = 4, oe = 5, Ze = 6, V0 = 7, me = [new Se(ir, 0, !1), new Se(Wt, 0, !0), new Se(Qe, 1, !1), new Se(be, 1, !0), new Se(ft, 2, !1), new Se(oe, 2, !0), new Se(Ze, 3, !1), new Se(V0, 3, !0)], t9 = [ft, oe, ft, oe, Ze, V0, Ze, V0], x9 = [oe, oe, oe, oe, V0, V0, V0, V0], r9 = [Qe, be, ft, oe, Ze, V0, Ze, V0], a9 = [be, be, oe, oe, V0, V0, V0, V0], n9 = [Wt, Wt, be, be, oe, oe, V0, V0], o9 = [ir, Wt, Qe, be, Qe, be, Qe, be], r0 = {
  DISPLAY: me[ir],
  TEXT: me[Qe],
  SCRIPT: me[ft],
  SCRIPTSCRIPT: me[Ze]
}, Qx = [{
  // Latin characters beyond the Latin-1 characters we have metrics for.
  // Needed for Czech, Hungarian and Turkish text, for example.
  name: "latin",
  blocks: [
    [256, 591],
    // Latin Extended-A and Latin Extended-B
    [768, 879]
    // Combining Diacritical marks
  ]
}, {
  // The Cyrillic script used by Russian and related languages.
  // A Cyrillic subset used to be supported as explicitly defined
  // symbols in symbols.js
  name: "cyrillic",
  blocks: [[1024, 1279]]
}, {
  // Armenian
  name: "armenian",
  blocks: [[1328, 1423]]
}, {
  // The Brahmic scripts of South and Southeast Asia
  // Devanagari (0900–097F)
  // Bengali (0980–09FF)
  // Gurmukhi (0A00–0A7F)
  // Gujarati (0A80–0AFF)
  // Oriya (0B00–0B7F)
  // Tamil (0B80–0BFF)
  // Telugu (0C00–0C7F)
  // Kannada (0C80–0CFF)
  // Malayalam (0D00–0D7F)
  // Sinhala (0D80–0DFF)
  // Thai (0E00–0E7F)
  // Lao (0E80–0EFF)
  // Tibetan (0F00–0FFF)
  // Myanmar (1000–109F)
  name: "brahmic",
  blocks: [[2304, 4255]]
}, {
  name: "georgian",
  blocks: [[4256, 4351]]
}, {
  // Chinese and Japanese.
  // The "k" in cjk is for Korean, but we've separated Korean out
  name: "cjk",
  blocks: [
    [12288, 12543],
    // CJK symbols and punctuation, Hiragana, Katakana
    [19968, 40879],
    // CJK ideograms
    [65280, 65376]
    // Fullwidth punctuation
    // TODO: add halfwidth Katakana and Romanji glyphs
  ]
}, {
  // Korean
  name: "hangul",
  blocks: [[44032, 55215]]
}];
function l9(r) {
  for (var e = 0; e < Qx.length; e++)
    for (var t = Qx[e], x = 0; x < t.blocks.length; x++) {
      var a = t.blocks[x];
      if (r >= a[0] && r <= a[1])
        return t.name;
    }
  return null;
}
var Xt = [];
Qx.forEach((r) => r.blocks.forEach((e) => Xt.push(...e)));
function i9(r) {
  for (var e = 0; e < Xt.length; e += 2)
    if (r >= Xt[e] && r <= Xt[e + 1])
      return !0;
  return !1;
}
var Ye = 80, s9 = function(e, t) {
  return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, u9 = function(e, t) {
  return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, c9 = function(e, t) {
  return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, E9 = function(e, t) {
  return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
}, d9 = function(e, t) {
  return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, m9 = function(e) {
  var t = e / 2;
  return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, h9 = function(e, t, x) {
  var a = x - 54 - t - e;
  return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + a + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
}, f9 = function(e, t, x) {
  t = 1e3 * t;
  var a = "";
  switch (e) {
    case "sqrtMain":
      a = s9(t, Ye);
      break;
    case "sqrtSize1":
      a = u9(t, Ye);
      break;
    case "sqrtSize2":
      a = c9(t, Ye);
      break;
    case "sqrtSize3":
      a = E9(t, Ye);
      break;
    case "sqrtSize4":
      a = d9(t, Ye);
      break;
    case "sqrtTall":
      a = h9(t, Ye, x);
  }
  return a;
}, B9 = function(e, t) {
  switch (e) {
    case "⎜":
      return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
    case "∣":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
    case "∥":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
    case "⎟":
      return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
    case "⎢":
      return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
    case "⎥":
      return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
    case "⎪":
      return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
    case "⏐":
      return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
    case "‖":
      return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
    default:
      return "";
  }
}, ta = {
  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
  doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
  doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
  // leftarrow is from glyph U+2190 in font KaTeX Main
  leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
  leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
  leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
  // overgroup is from the MnSymbol package (public domain)
  leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
  leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
  // Harpoons are from glyph U+21BD in font KaTeX Main
  leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
  leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
  leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
  leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
  // hook is from glyph U+21A9 in font KaTeX Main
  lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
  leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
  leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
  leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
  longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
  midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
  midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
  oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
  oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
  oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
  oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
  rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
  rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
  rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
  rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
  rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
  rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
  rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
  rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
  rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
  righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
  rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
  rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
  twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
  twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
  // tilde1 is a modified version of a glyph from the MnSymbol package
  tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
  // ditto tilde2, tilde3, & tilde4
  tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
  tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
  tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
  // vec is from glyph U+20D7 in font KaTeX Main
  vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
  // widehat1 is a modified version of a glyph from the MnSymbol package
  widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
  // ditto widehat2, widehat3, & widehat4
  widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  // widecheck paths are all inverted versions of widehat
  widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
  widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  // The next ten paths support reaction arrows from the mhchem package.
  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
  // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
  baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
  rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
  baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
  rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
  shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
  shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
}, C9 = function(e, t) {
  switch (e) {
    case "lbrack":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
    case "rbrack":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
    case "vert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
    case "doublevert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
    case "lfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "rfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "lceil":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
    case "rceil":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
    case "lparen":
      return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
    case "rparen":
      return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
    default:
      throw new Error("Unknown stretchy delimiter.");
  }
};
class Ct {
  // HtmlDomNode
  // Never used; needed for satisfying interface.
  constructor(e) {
    this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
  }
  hasClass(e) {
    return t0.contains(this.classes, e);
  }
  /** Convert the fragment into a node. */
  toNode() {
    for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
      e.appendChild(this.children[t].toNode());
    return e;
  }
  /** Convert the fragment into HTML markup. */
  toMarkup() {
    for (var e = "", t = 0; t < this.children.length; t++)
      e += this.children[t].toMarkup();
    return e;
  }
  /**
   * Converts the math node into a string, similar to innerText. Applies to
   * MathDomNode's only.
   */
  toText() {
    var e = (t) => t.toText();
    return this.children.map(e).join("");
  }
}
var ve = {
  "AMS-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68889, 0, 0, 0.72222],
    66: [0, 0.68889, 0, 0, 0.66667],
    67: [0, 0.68889, 0, 0, 0.72222],
    68: [0, 0.68889, 0, 0, 0.72222],
    69: [0, 0.68889, 0, 0, 0.66667],
    70: [0, 0.68889, 0, 0, 0.61111],
    71: [0, 0.68889, 0, 0, 0.77778],
    72: [0, 0.68889, 0, 0, 0.77778],
    73: [0, 0.68889, 0, 0, 0.38889],
    74: [0.16667, 0.68889, 0, 0, 0.5],
    75: [0, 0.68889, 0, 0, 0.77778],
    76: [0, 0.68889, 0, 0, 0.66667],
    77: [0, 0.68889, 0, 0, 0.94445],
    78: [0, 0.68889, 0, 0, 0.72222],
    79: [0.16667, 0.68889, 0, 0, 0.77778],
    80: [0, 0.68889, 0, 0, 0.61111],
    81: [0.16667, 0.68889, 0, 0, 0.77778],
    82: [0, 0.68889, 0, 0, 0.72222],
    83: [0, 0.68889, 0, 0, 0.55556],
    84: [0, 0.68889, 0, 0, 0.66667],
    85: [0, 0.68889, 0, 0, 0.72222],
    86: [0, 0.68889, 0, 0, 0.72222],
    87: [0, 0.68889, 0, 0, 1],
    88: [0, 0.68889, 0, 0, 0.72222],
    89: [0, 0.68889, 0, 0, 0.72222],
    90: [0, 0.68889, 0, 0, 0.66667],
    107: [0, 0.68889, 0, 0, 0.55556],
    160: [0, 0, 0, 0, 0.25],
    165: [0, 0.675, 0.025, 0, 0.75],
    174: [0.15559, 0.69224, 0, 0, 0.94666],
    240: [0, 0.68889, 0, 0, 0.55556],
    295: [0, 0.68889, 0, 0, 0.54028],
    710: [0, 0.825, 0, 0, 2.33334],
    732: [0, 0.9, 0, 0, 2.33334],
    770: [0, 0.825, 0, 0, 2.33334],
    771: [0, 0.9, 0, 0, 2.33334],
    989: [0.08167, 0.58167, 0, 0, 0.77778],
    1008: [0, 0.43056, 0.04028, 0, 0.66667],
    8245: [0, 0.54986, 0, 0, 0.275],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8487: [0, 0.68889, 0, 0, 0.72222],
    8498: [0, 0.68889, 0, 0, 0.55556],
    8502: [0, 0.68889, 0, 0, 0.66667],
    8503: [0, 0.68889, 0, 0, 0.44445],
    8504: [0, 0.68889, 0, 0, 0.66667],
    8513: [0, 0.68889, 0, 0, 0.63889],
    8592: [-0.03598, 0.46402, 0, 0, 0.5],
    8594: [-0.03598, 0.46402, 0, 0, 0.5],
    8602: [-0.13313, 0.36687, 0, 0, 1],
    8603: [-0.13313, 0.36687, 0, 0, 1],
    8606: [0.01354, 0.52239, 0, 0, 1],
    8608: [0.01354, 0.52239, 0, 0, 1],
    8610: [0.01354, 0.52239, 0, 0, 1.11111],
    8611: [0.01354, 0.52239, 0, 0, 1.11111],
    8619: [0, 0.54986, 0, 0, 1],
    8620: [0, 0.54986, 0, 0, 1],
    8621: [-0.13313, 0.37788, 0, 0, 1.38889],
    8622: [-0.13313, 0.36687, 0, 0, 1],
    8624: [0, 0.69224, 0, 0, 0.5],
    8625: [0, 0.69224, 0, 0, 0.5],
    8630: [0, 0.43056, 0, 0, 1],
    8631: [0, 0.43056, 0, 0, 1],
    8634: [0.08198, 0.58198, 0, 0, 0.77778],
    8635: [0.08198, 0.58198, 0, 0, 0.77778],
    8638: [0.19444, 0.69224, 0, 0, 0.41667],
    8639: [0.19444, 0.69224, 0, 0, 0.41667],
    8642: [0.19444, 0.69224, 0, 0, 0.41667],
    8643: [0.19444, 0.69224, 0, 0, 0.41667],
    8644: [0.1808, 0.675, 0, 0, 1],
    8646: [0.1808, 0.675, 0, 0, 1],
    8647: [0.1808, 0.675, 0, 0, 1],
    8648: [0.19444, 0.69224, 0, 0, 0.83334],
    8649: [0.1808, 0.675, 0, 0, 1],
    8650: [0.19444, 0.69224, 0, 0, 0.83334],
    8651: [0.01354, 0.52239, 0, 0, 1],
    8652: [0.01354, 0.52239, 0, 0, 1],
    8653: [-0.13313, 0.36687, 0, 0, 1],
    8654: [-0.13313, 0.36687, 0, 0, 1],
    8655: [-0.13313, 0.36687, 0, 0, 1],
    8666: [0.13667, 0.63667, 0, 0, 1],
    8667: [0.13667, 0.63667, 0, 0, 1],
    8669: [-0.13313, 0.37788, 0, 0, 1],
    8672: [-0.064, 0.437, 0, 0, 1.334],
    8674: [-0.064, 0.437, 0, 0, 1.334],
    8705: [0, 0.825, 0, 0, 0.5],
    8708: [0, 0.68889, 0, 0, 0.55556],
    8709: [0.08167, 0.58167, 0, 0, 0.77778],
    8717: [0, 0.43056, 0, 0, 0.42917],
    8722: [-0.03598, 0.46402, 0, 0, 0.5],
    8724: [0.08198, 0.69224, 0, 0, 0.77778],
    8726: [0.08167, 0.58167, 0, 0, 0.77778],
    8733: [0, 0.69224, 0, 0, 0.77778],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8737: [0, 0.69224, 0, 0, 0.72222],
    8738: [0.03517, 0.52239, 0, 0, 0.72222],
    8739: [0.08167, 0.58167, 0, 0, 0.22222],
    8740: [0.25142, 0.74111, 0, 0, 0.27778],
    8741: [0.08167, 0.58167, 0, 0, 0.38889],
    8742: [0.25142, 0.74111, 0, 0, 0.5],
    8756: [0, 0.69224, 0, 0, 0.66667],
    8757: [0, 0.69224, 0, 0, 0.66667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8765: [-0.13313, 0.37788, 0, 0, 0.77778],
    8769: [-0.13313, 0.36687, 0, 0, 0.77778],
    8770: [-0.03625, 0.46375, 0, 0, 0.77778],
    8774: [0.30274, 0.79383, 0, 0, 0.77778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8778: [0.08167, 0.58167, 0, 0, 0.77778],
    8782: [0.06062, 0.54986, 0, 0, 0.77778],
    8783: [0.06062, 0.54986, 0, 0, 0.77778],
    8785: [0.08198, 0.58198, 0, 0, 0.77778],
    8786: [0.08198, 0.58198, 0, 0, 0.77778],
    8787: [0.08198, 0.58198, 0, 0, 0.77778],
    8790: [0, 0.69224, 0, 0, 0.77778],
    8791: [0.22958, 0.72958, 0, 0, 0.77778],
    8796: [0.08198, 0.91667, 0, 0, 0.77778],
    8806: [0.25583, 0.75583, 0, 0, 0.77778],
    8807: [0.25583, 0.75583, 0, 0, 0.77778],
    8808: [0.25142, 0.75726, 0, 0, 0.77778],
    8809: [0.25142, 0.75726, 0, 0, 0.77778],
    8812: [0.25583, 0.75583, 0, 0, 0.5],
    8814: [0.20576, 0.70576, 0, 0, 0.77778],
    8815: [0.20576, 0.70576, 0, 0, 0.77778],
    8816: [0.30274, 0.79383, 0, 0, 0.77778],
    8817: [0.30274, 0.79383, 0, 0, 0.77778],
    8818: [0.22958, 0.72958, 0, 0, 0.77778],
    8819: [0.22958, 0.72958, 0, 0, 0.77778],
    8822: [0.1808, 0.675, 0, 0, 0.77778],
    8823: [0.1808, 0.675, 0, 0, 0.77778],
    8828: [0.13667, 0.63667, 0, 0, 0.77778],
    8829: [0.13667, 0.63667, 0, 0, 0.77778],
    8830: [0.22958, 0.72958, 0, 0, 0.77778],
    8831: [0.22958, 0.72958, 0, 0, 0.77778],
    8832: [0.20576, 0.70576, 0, 0, 0.77778],
    8833: [0.20576, 0.70576, 0, 0, 0.77778],
    8840: [0.30274, 0.79383, 0, 0, 0.77778],
    8841: [0.30274, 0.79383, 0, 0, 0.77778],
    8842: [0.13597, 0.63597, 0, 0, 0.77778],
    8843: [0.13597, 0.63597, 0, 0, 0.77778],
    8847: [0.03517, 0.54986, 0, 0, 0.77778],
    8848: [0.03517, 0.54986, 0, 0, 0.77778],
    8858: [0.08198, 0.58198, 0, 0, 0.77778],
    8859: [0.08198, 0.58198, 0, 0, 0.77778],
    8861: [0.08198, 0.58198, 0, 0, 0.77778],
    8862: [0, 0.675, 0, 0, 0.77778],
    8863: [0, 0.675, 0, 0, 0.77778],
    8864: [0, 0.675, 0, 0, 0.77778],
    8865: [0, 0.675, 0, 0, 0.77778],
    8872: [0, 0.69224, 0, 0, 0.61111],
    8873: [0, 0.69224, 0, 0, 0.72222],
    8874: [0, 0.69224, 0, 0, 0.88889],
    8876: [0, 0.68889, 0, 0, 0.61111],
    8877: [0, 0.68889, 0, 0, 0.61111],
    8878: [0, 0.68889, 0, 0, 0.72222],
    8879: [0, 0.68889, 0, 0, 0.72222],
    8882: [0.03517, 0.54986, 0, 0, 0.77778],
    8883: [0.03517, 0.54986, 0, 0, 0.77778],
    8884: [0.13667, 0.63667, 0, 0, 0.77778],
    8885: [0.13667, 0.63667, 0, 0, 0.77778],
    8888: [0, 0.54986, 0, 0, 1.11111],
    8890: [0.19444, 0.43056, 0, 0, 0.55556],
    8891: [0.19444, 0.69224, 0, 0, 0.61111],
    8892: [0.19444, 0.69224, 0, 0, 0.61111],
    8901: [0, 0.54986, 0, 0, 0.27778],
    8903: [0.08167, 0.58167, 0, 0, 0.77778],
    8905: [0.08167, 0.58167, 0, 0, 0.77778],
    8906: [0.08167, 0.58167, 0, 0, 0.77778],
    8907: [0, 0.69224, 0, 0, 0.77778],
    8908: [0, 0.69224, 0, 0, 0.77778],
    8909: [-0.03598, 0.46402, 0, 0, 0.77778],
    8910: [0, 0.54986, 0, 0, 0.76042],
    8911: [0, 0.54986, 0, 0, 0.76042],
    8912: [0.03517, 0.54986, 0, 0, 0.77778],
    8913: [0.03517, 0.54986, 0, 0, 0.77778],
    8914: [0, 0.54986, 0, 0, 0.66667],
    8915: [0, 0.54986, 0, 0, 0.66667],
    8916: [0, 0.69224, 0, 0, 0.66667],
    8918: [0.0391, 0.5391, 0, 0, 0.77778],
    8919: [0.0391, 0.5391, 0, 0, 0.77778],
    8920: [0.03517, 0.54986, 0, 0, 1.33334],
    8921: [0.03517, 0.54986, 0, 0, 1.33334],
    8922: [0.38569, 0.88569, 0, 0, 0.77778],
    8923: [0.38569, 0.88569, 0, 0, 0.77778],
    8926: [0.13667, 0.63667, 0, 0, 0.77778],
    8927: [0.13667, 0.63667, 0, 0, 0.77778],
    8928: [0.30274, 0.79383, 0, 0, 0.77778],
    8929: [0.30274, 0.79383, 0, 0, 0.77778],
    8934: [0.23222, 0.74111, 0, 0, 0.77778],
    8935: [0.23222, 0.74111, 0, 0, 0.77778],
    8936: [0.23222, 0.74111, 0, 0, 0.77778],
    8937: [0.23222, 0.74111, 0, 0, 0.77778],
    8938: [0.20576, 0.70576, 0, 0, 0.77778],
    8939: [0.20576, 0.70576, 0, 0, 0.77778],
    8940: [0.30274, 0.79383, 0, 0, 0.77778],
    8941: [0.30274, 0.79383, 0, 0, 0.77778],
    8994: [0.19444, 0.69224, 0, 0, 0.77778],
    8995: [0.19444, 0.69224, 0, 0, 0.77778],
    9416: [0.15559, 0.69224, 0, 0, 0.90222],
    9484: [0, 0.69224, 0, 0, 0.5],
    9488: [0, 0.69224, 0, 0, 0.5],
    9492: [0, 0.37788, 0, 0, 0.5],
    9496: [0, 0.37788, 0, 0, 0.5],
    9585: [0.19444, 0.68889, 0, 0, 0.88889],
    9586: [0.19444, 0.74111, 0, 0, 0.88889],
    9632: [0, 0.675, 0, 0, 0.77778],
    9633: [0, 0.675, 0, 0, 0.77778],
    9650: [0, 0.54986, 0, 0, 0.72222],
    9651: [0, 0.54986, 0, 0, 0.72222],
    9654: [0.03517, 0.54986, 0, 0, 0.77778],
    9660: [0, 0.54986, 0, 0, 0.72222],
    9661: [0, 0.54986, 0, 0, 0.72222],
    9664: [0.03517, 0.54986, 0, 0, 0.77778],
    9674: [0.11111, 0.69224, 0, 0, 0.66667],
    9733: [0.19444, 0.69224, 0, 0, 0.94445],
    10003: [0, 0.69224, 0, 0, 0.83334],
    10016: [0, 0.69224, 0, 0, 0.83334],
    10731: [0.11111, 0.69224, 0, 0, 0.66667],
    10846: [0.19444, 0.75583, 0, 0, 0.61111],
    10877: [0.13667, 0.63667, 0, 0, 0.77778],
    10878: [0.13667, 0.63667, 0, 0, 0.77778],
    10885: [0.25583, 0.75583, 0, 0, 0.77778],
    10886: [0.25583, 0.75583, 0, 0, 0.77778],
    10887: [0.13597, 0.63597, 0, 0, 0.77778],
    10888: [0.13597, 0.63597, 0, 0, 0.77778],
    10889: [0.26167, 0.75726, 0, 0, 0.77778],
    10890: [0.26167, 0.75726, 0, 0, 0.77778],
    10891: [0.48256, 0.98256, 0, 0, 0.77778],
    10892: [0.48256, 0.98256, 0, 0, 0.77778],
    10901: [0.13667, 0.63667, 0, 0, 0.77778],
    10902: [0.13667, 0.63667, 0, 0, 0.77778],
    10933: [0.25142, 0.75726, 0, 0, 0.77778],
    10934: [0.25142, 0.75726, 0, 0, 0.77778],
    10935: [0.26167, 0.75726, 0, 0, 0.77778],
    10936: [0.26167, 0.75726, 0, 0, 0.77778],
    10937: [0.26167, 0.75726, 0, 0, 0.77778],
    10938: [0.26167, 0.75726, 0, 0, 0.77778],
    10949: [0.25583, 0.75583, 0, 0, 0.77778],
    10950: [0.25583, 0.75583, 0, 0, 0.77778],
    10955: [0.28481, 0.79383, 0, 0, 0.77778],
    10956: [0.28481, 0.79383, 0, 0, 0.77778],
    57350: [0.08167, 0.58167, 0, 0, 0.22222],
    57351: [0.08167, 0.58167, 0, 0, 0.38889],
    57352: [0.08167, 0.58167, 0, 0, 0.77778],
    57353: [0, 0.43056, 0.04028, 0, 0.66667],
    57356: [0.25142, 0.75726, 0, 0, 0.77778],
    57357: [0.25142, 0.75726, 0, 0, 0.77778],
    57358: [0.41951, 0.91951, 0, 0, 0.77778],
    57359: [0.30274, 0.79383, 0, 0, 0.77778],
    57360: [0.30274, 0.79383, 0, 0, 0.77778],
    57361: [0.41951, 0.91951, 0, 0, 0.77778],
    57366: [0.25142, 0.75726, 0, 0, 0.77778],
    57367: [0.25142, 0.75726, 0, 0, 0.77778],
    57368: [0.25142, 0.75726, 0, 0, 0.77778],
    57369: [0.25142, 0.75726, 0, 0, 0.77778],
    57370: [0.13597, 0.63597, 0, 0, 0.77778],
    57371: [0.13597, 0.63597, 0, 0, 0.77778]
  },
  "Caligraphic-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68333, 0, 0.19445, 0.79847],
    66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
    67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
    68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
    69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
    70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
    71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
    72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
    73: [0, 0.68333, 0.07382, 0, 0.54452],
    74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
    75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
    76: [0, 0.68333, 0, 0.13889, 0.68972],
    77: [0, 0.68333, 0, 0.13889, 1.2009],
    78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
    79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
    80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
    81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
    82: [0, 0.68333, 0, 0.08334, 0.8475],
    83: [0, 0.68333, 0.075, 0.13889, 0.60556],
    84: [0, 0.68333, 0.25417, 0, 0.54464],
    85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
    86: [0, 0.68333, 0.08222, 0, 0.61278],
    87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
    88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
    89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
    90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
    160: [0, 0, 0, 0, 0.25]
  },
  "Fraktur-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69141, 0, 0, 0.29574],
    34: [0, 0.69141, 0, 0, 0.21471],
    38: [0, 0.69141, 0, 0, 0.73786],
    39: [0, 0.69141, 0, 0, 0.21201],
    40: [0.24982, 0.74947, 0, 0, 0.38865],
    41: [0.24982, 0.74947, 0, 0, 0.38865],
    42: [0, 0.62119, 0, 0, 0.27764],
    43: [0.08319, 0.58283, 0, 0, 0.75623],
    44: [0, 0.10803, 0, 0, 0.27764],
    45: [0.08319, 0.58283, 0, 0, 0.75623],
    46: [0, 0.10803, 0, 0, 0.27764],
    47: [0.24982, 0.74947, 0, 0, 0.50181],
    48: [0, 0.47534, 0, 0, 0.50181],
    49: [0, 0.47534, 0, 0, 0.50181],
    50: [0, 0.47534, 0, 0, 0.50181],
    51: [0.18906, 0.47534, 0, 0, 0.50181],
    52: [0.18906, 0.47534, 0, 0, 0.50181],
    53: [0.18906, 0.47534, 0, 0, 0.50181],
    54: [0, 0.69141, 0, 0, 0.50181],
    55: [0.18906, 0.47534, 0, 0, 0.50181],
    56: [0, 0.69141, 0, 0, 0.50181],
    57: [0.18906, 0.47534, 0, 0, 0.50181],
    58: [0, 0.47534, 0, 0, 0.21606],
    59: [0.12604, 0.47534, 0, 0, 0.21606],
    61: [-0.13099, 0.36866, 0, 0, 0.75623],
    63: [0, 0.69141, 0, 0, 0.36245],
    65: [0, 0.69141, 0, 0, 0.7176],
    66: [0, 0.69141, 0, 0, 0.88397],
    67: [0, 0.69141, 0, 0, 0.61254],
    68: [0, 0.69141, 0, 0, 0.83158],
    69: [0, 0.69141, 0, 0, 0.66278],
    70: [0.12604, 0.69141, 0, 0, 0.61119],
    71: [0, 0.69141, 0, 0, 0.78539],
    72: [0.06302, 0.69141, 0, 0, 0.7203],
    73: [0, 0.69141, 0, 0, 0.55448],
    74: [0.12604, 0.69141, 0, 0, 0.55231],
    75: [0, 0.69141, 0, 0, 0.66845],
    76: [0, 0.69141, 0, 0, 0.66602],
    77: [0, 0.69141, 0, 0, 1.04953],
    78: [0, 0.69141, 0, 0, 0.83212],
    79: [0, 0.69141, 0, 0, 0.82699],
    80: [0.18906, 0.69141, 0, 0, 0.82753],
    81: [0.03781, 0.69141, 0, 0, 0.82699],
    82: [0, 0.69141, 0, 0, 0.82807],
    83: [0, 0.69141, 0, 0, 0.82861],
    84: [0, 0.69141, 0, 0, 0.66899],
    85: [0, 0.69141, 0, 0, 0.64576],
    86: [0, 0.69141, 0, 0, 0.83131],
    87: [0, 0.69141, 0, 0, 1.04602],
    88: [0, 0.69141, 0, 0, 0.71922],
    89: [0.18906, 0.69141, 0, 0, 0.83293],
    90: [0.12604, 0.69141, 0, 0, 0.60201],
    91: [0.24982, 0.74947, 0, 0, 0.27764],
    93: [0.24982, 0.74947, 0, 0, 0.27764],
    94: [0, 0.69141, 0, 0, 0.49965],
    97: [0, 0.47534, 0, 0, 0.50046],
    98: [0, 0.69141, 0, 0, 0.51315],
    99: [0, 0.47534, 0, 0, 0.38946],
    100: [0, 0.62119, 0, 0, 0.49857],
    101: [0, 0.47534, 0, 0, 0.40053],
    102: [0.18906, 0.69141, 0, 0, 0.32626],
    103: [0.18906, 0.47534, 0, 0, 0.5037],
    104: [0.18906, 0.69141, 0, 0, 0.52126],
    105: [0, 0.69141, 0, 0, 0.27899],
    106: [0, 0.69141, 0, 0, 0.28088],
    107: [0, 0.69141, 0, 0, 0.38946],
    108: [0, 0.69141, 0, 0, 0.27953],
    109: [0, 0.47534, 0, 0, 0.76676],
    110: [0, 0.47534, 0, 0, 0.52666],
    111: [0, 0.47534, 0, 0, 0.48885],
    112: [0.18906, 0.52396, 0, 0, 0.50046],
    113: [0.18906, 0.47534, 0, 0, 0.48912],
    114: [0, 0.47534, 0, 0, 0.38919],
    115: [0, 0.47534, 0, 0, 0.44266],
    116: [0, 0.62119, 0, 0, 0.33301],
    117: [0, 0.47534, 0, 0, 0.5172],
    118: [0, 0.52396, 0, 0, 0.5118],
    119: [0, 0.52396, 0, 0, 0.77351],
    120: [0.18906, 0.47534, 0, 0, 0.38865],
    121: [0.18906, 0.47534, 0, 0, 0.49884],
    122: [0.18906, 0.47534, 0, 0, 0.39054],
    160: [0, 0, 0, 0, 0.25],
    8216: [0, 0.69141, 0, 0, 0.21471],
    8217: [0, 0.69141, 0, 0, 0.21471],
    58112: [0, 0.62119, 0, 0, 0.49749],
    58113: [0, 0.62119, 0, 0, 0.4983],
    58114: [0.18906, 0.69141, 0, 0, 0.33328],
    58115: [0.18906, 0.69141, 0, 0, 0.32923],
    58116: [0.18906, 0.47534, 0, 0, 0.50343],
    58117: [0, 0.69141, 0, 0, 0.33301],
    58118: [0, 0.62119, 0, 0, 0.33409],
    58119: [0, 0.47534, 0, 0, 0.50073]
  },
  "Main-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.35],
    34: [0, 0.69444, 0, 0, 0.60278],
    35: [0.19444, 0.69444, 0, 0, 0.95833],
    36: [0.05556, 0.75, 0, 0, 0.575],
    37: [0.05556, 0.75, 0, 0, 0.95833],
    38: [0, 0.69444, 0, 0, 0.89444],
    39: [0, 0.69444, 0, 0, 0.31944],
    40: [0.25, 0.75, 0, 0, 0.44722],
    41: [0.25, 0.75, 0, 0, 0.44722],
    42: [0, 0.75, 0, 0, 0.575],
    43: [0.13333, 0.63333, 0, 0, 0.89444],
    44: [0.19444, 0.15556, 0, 0, 0.31944],
    45: [0, 0.44444, 0, 0, 0.38333],
    46: [0, 0.15556, 0, 0, 0.31944],
    47: [0.25, 0.75, 0, 0, 0.575],
    48: [0, 0.64444, 0, 0, 0.575],
    49: [0, 0.64444, 0, 0, 0.575],
    50: [0, 0.64444, 0, 0, 0.575],
    51: [0, 0.64444, 0, 0, 0.575],
    52: [0, 0.64444, 0, 0, 0.575],
    53: [0, 0.64444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0, 0.64444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0, 0.64444, 0, 0, 0.575],
    58: [0, 0.44444, 0, 0, 0.31944],
    59: [0.19444, 0.44444, 0, 0, 0.31944],
    60: [0.08556, 0.58556, 0, 0, 0.89444],
    61: [-0.10889, 0.39111, 0, 0, 0.89444],
    62: [0.08556, 0.58556, 0, 0, 0.89444],
    63: [0, 0.69444, 0, 0, 0.54305],
    64: [0, 0.69444, 0, 0, 0.89444],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0, 0, 0.81805],
    67: [0, 0.68611, 0, 0, 0.83055],
    68: [0, 0.68611, 0, 0, 0.88194],
    69: [0, 0.68611, 0, 0, 0.75555],
    70: [0, 0.68611, 0, 0, 0.72361],
    71: [0, 0.68611, 0, 0, 0.90416],
    72: [0, 0.68611, 0, 0, 0.9],
    73: [0, 0.68611, 0, 0, 0.43611],
    74: [0, 0.68611, 0, 0, 0.59444],
    75: [0, 0.68611, 0, 0, 0.90138],
    76: [0, 0.68611, 0, 0, 0.69166],
    77: [0, 0.68611, 0, 0, 1.09166],
    78: [0, 0.68611, 0, 0, 0.9],
    79: [0, 0.68611, 0, 0, 0.86388],
    80: [0, 0.68611, 0, 0, 0.78611],
    81: [0.19444, 0.68611, 0, 0, 0.86388],
    82: [0, 0.68611, 0, 0, 0.8625],
    83: [0, 0.68611, 0, 0, 0.63889],
    84: [0, 0.68611, 0, 0, 0.8],
    85: [0, 0.68611, 0, 0, 0.88472],
    86: [0, 0.68611, 0.01597, 0, 0.86944],
    87: [0, 0.68611, 0.01597, 0, 1.18888],
    88: [0, 0.68611, 0, 0, 0.86944],
    89: [0, 0.68611, 0.02875, 0, 0.86944],
    90: [0, 0.68611, 0, 0, 0.70277],
    91: [0.25, 0.75, 0, 0, 0.31944],
    92: [0.25, 0.75, 0, 0, 0.575],
    93: [0.25, 0.75, 0, 0, 0.31944],
    94: [0, 0.69444, 0, 0, 0.575],
    95: [0.31, 0.13444, 0.03194, 0, 0.575],
    97: [0, 0.44444, 0, 0, 0.55902],
    98: [0, 0.69444, 0, 0, 0.63889],
    99: [0, 0.44444, 0, 0, 0.51111],
    100: [0, 0.69444, 0, 0, 0.63889],
    101: [0, 0.44444, 0, 0, 0.52708],
    102: [0, 0.69444, 0.10903, 0, 0.35139],
    103: [0.19444, 0.44444, 0.01597, 0, 0.575],
    104: [0, 0.69444, 0, 0, 0.63889],
    105: [0, 0.69444, 0, 0, 0.31944],
    106: [0.19444, 0.69444, 0, 0, 0.35139],
    107: [0, 0.69444, 0, 0, 0.60694],
    108: [0, 0.69444, 0, 0, 0.31944],
    109: [0, 0.44444, 0, 0, 0.95833],
    110: [0, 0.44444, 0, 0, 0.63889],
    111: [0, 0.44444, 0, 0, 0.575],
    112: [0.19444, 0.44444, 0, 0, 0.63889],
    113: [0.19444, 0.44444, 0, 0, 0.60694],
    114: [0, 0.44444, 0, 0, 0.47361],
    115: [0, 0.44444, 0, 0, 0.45361],
    116: [0, 0.63492, 0, 0, 0.44722],
    117: [0, 0.44444, 0, 0, 0.63889],
    118: [0, 0.44444, 0.01597, 0, 0.60694],
    119: [0, 0.44444, 0.01597, 0, 0.83055],
    120: [0, 0.44444, 0, 0, 0.60694],
    121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
    122: [0, 0.44444, 0, 0, 0.51111],
    123: [0.25, 0.75, 0, 0, 0.575],
    124: [0.25, 0.75, 0, 0, 0.31944],
    125: [0.25, 0.75, 0, 0, 0.575],
    126: [0.35, 0.34444, 0, 0, 0.575],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.86853],
    168: [0, 0.69444, 0, 0, 0.575],
    172: [0, 0.44444, 0, 0, 0.76666],
    176: [0, 0.69444, 0, 0, 0.86944],
    177: [0.13333, 0.63333, 0, 0, 0.89444],
    184: [0.17014, 0, 0, 0, 0.51111],
    198: [0, 0.68611, 0, 0, 1.04166],
    215: [0.13333, 0.63333, 0, 0, 0.89444],
    216: [0.04861, 0.73472, 0, 0, 0.89444],
    223: [0, 0.69444, 0, 0, 0.59722],
    230: [0, 0.44444, 0, 0, 0.83055],
    247: [0.13333, 0.63333, 0, 0, 0.89444],
    248: [0.09722, 0.54167, 0, 0, 0.575],
    305: [0, 0.44444, 0, 0, 0.31944],
    338: [0, 0.68611, 0, 0, 1.16944],
    339: [0, 0.44444, 0, 0, 0.89444],
    567: [0.19444, 0.44444, 0, 0, 0.35139],
    710: [0, 0.69444, 0, 0, 0.575],
    711: [0, 0.63194, 0, 0, 0.575],
    713: [0, 0.59611, 0, 0, 0.575],
    714: [0, 0.69444, 0, 0, 0.575],
    715: [0, 0.69444, 0, 0, 0.575],
    728: [0, 0.69444, 0, 0, 0.575],
    729: [0, 0.69444, 0, 0, 0.31944],
    730: [0, 0.69444, 0, 0, 0.86944],
    732: [0, 0.69444, 0, 0, 0.575],
    733: [0, 0.69444, 0, 0, 0.575],
    915: [0, 0.68611, 0, 0, 0.69166],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0, 0, 0.89444],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0, 0, 0.76666],
    928: [0, 0.68611, 0, 0, 0.9],
    931: [0, 0.68611, 0, 0, 0.83055],
    933: [0, 0.68611, 0, 0, 0.89444],
    934: [0, 0.68611, 0, 0, 0.83055],
    936: [0, 0.68611, 0, 0, 0.89444],
    937: [0, 0.68611, 0, 0, 0.83055],
    8211: [0, 0.44444, 0.03194, 0, 0.575],
    8212: [0, 0.44444, 0.03194, 0, 1.14999],
    8216: [0, 0.69444, 0, 0, 0.31944],
    8217: [0, 0.69444, 0, 0, 0.31944],
    8220: [0, 0.69444, 0, 0, 0.60278],
    8221: [0, 0.69444, 0, 0, 0.60278],
    8224: [0.19444, 0.69444, 0, 0, 0.51111],
    8225: [0.19444, 0.69444, 0, 0, 0.51111],
    8242: [0, 0.55556, 0, 0, 0.34444],
    8407: [0, 0.72444, 0.15486, 0, 0.575],
    8463: [0, 0.69444, 0, 0, 0.66759],
    8465: [0, 0.69444, 0, 0, 0.83055],
    8467: [0, 0.69444, 0, 0, 0.47361],
    8472: [0.19444, 0.44444, 0, 0, 0.74027],
    8476: [0, 0.69444, 0, 0, 0.83055],
    8501: [0, 0.69444, 0, 0, 0.70277],
    8592: [-0.10889, 0.39111, 0, 0, 1.14999],
    8593: [0.19444, 0.69444, 0, 0, 0.575],
    8594: [-0.10889, 0.39111, 0, 0, 1.14999],
    8595: [0.19444, 0.69444, 0, 0, 0.575],
    8596: [-0.10889, 0.39111, 0, 0, 1.14999],
    8597: [0.25, 0.75, 0, 0, 0.575],
    8598: [0.19444, 0.69444, 0, 0, 1.14999],
    8599: [0.19444, 0.69444, 0, 0, 1.14999],
    8600: [0.19444, 0.69444, 0, 0, 1.14999],
    8601: [0.19444, 0.69444, 0, 0, 1.14999],
    8636: [-0.10889, 0.39111, 0, 0, 1.14999],
    8637: [-0.10889, 0.39111, 0, 0, 1.14999],
    8640: [-0.10889, 0.39111, 0, 0, 1.14999],
    8641: [-0.10889, 0.39111, 0, 0, 1.14999],
    8656: [-0.10889, 0.39111, 0, 0, 1.14999],
    8657: [0.19444, 0.69444, 0, 0, 0.70277],
    8658: [-0.10889, 0.39111, 0, 0, 1.14999],
    8659: [0.19444, 0.69444, 0, 0, 0.70277],
    8660: [-0.10889, 0.39111, 0, 0, 1.14999],
    8661: [0.25, 0.75, 0, 0, 0.70277],
    8704: [0, 0.69444, 0, 0, 0.63889],
    8706: [0, 0.69444, 0.06389, 0, 0.62847],
    8707: [0, 0.69444, 0, 0, 0.63889],
    8709: [0.05556, 0.75, 0, 0, 0.575],
    8711: [0, 0.68611, 0, 0, 0.95833],
    8712: [0.08556, 0.58556, 0, 0, 0.76666],
    8715: [0.08556, 0.58556, 0, 0, 0.76666],
    8722: [0.13333, 0.63333, 0, 0, 0.89444],
    8723: [0.13333, 0.63333, 0, 0, 0.89444],
    8725: [0.25, 0.75, 0, 0, 0.575],
    8726: [0.25, 0.75, 0, 0, 0.575],
    8727: [-0.02778, 0.47222, 0, 0, 0.575],
    8728: [-0.02639, 0.47361, 0, 0, 0.575],
    8729: [-0.02639, 0.47361, 0, 0, 0.575],
    8730: [0.18, 0.82, 0, 0, 0.95833],
    8733: [0, 0.44444, 0, 0, 0.89444],
    8734: [0, 0.44444, 0, 0, 1.14999],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.31944],
    8741: [0.25, 0.75, 0, 0, 0.575],
    8743: [0, 0.55556, 0, 0, 0.76666],
    8744: [0, 0.55556, 0, 0, 0.76666],
    8745: [0, 0.55556, 0, 0, 0.76666],
    8746: [0, 0.55556, 0, 0, 0.76666],
    8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
    8764: [-0.10889, 0.39111, 0, 0, 0.89444],
    8768: [0.19444, 0.69444, 0, 0, 0.31944],
    8771: [222e-5, 0.50222, 0, 0, 0.89444],
    8773: [0.027, 0.638, 0, 0, 0.894],
    8776: [0.02444, 0.52444, 0, 0, 0.89444],
    8781: [222e-5, 0.50222, 0, 0, 0.89444],
    8801: [222e-5, 0.50222, 0, 0, 0.89444],
    8804: [0.19667, 0.69667, 0, 0, 0.89444],
    8805: [0.19667, 0.69667, 0, 0, 0.89444],
    8810: [0.08556, 0.58556, 0, 0, 1.14999],
    8811: [0.08556, 0.58556, 0, 0, 1.14999],
    8826: [0.08556, 0.58556, 0, 0, 0.89444],
    8827: [0.08556, 0.58556, 0, 0, 0.89444],
    8834: [0.08556, 0.58556, 0, 0, 0.89444],
    8835: [0.08556, 0.58556, 0, 0, 0.89444],
    8838: [0.19667, 0.69667, 0, 0, 0.89444],
    8839: [0.19667, 0.69667, 0, 0, 0.89444],
    8846: [0, 0.55556, 0, 0, 0.76666],
    8849: [0.19667, 0.69667, 0, 0, 0.89444],
    8850: [0.19667, 0.69667, 0, 0, 0.89444],
    8851: [0, 0.55556, 0, 0, 0.76666],
    8852: [0, 0.55556, 0, 0, 0.76666],
    8853: [0.13333, 0.63333, 0, 0, 0.89444],
    8854: [0.13333, 0.63333, 0, 0, 0.89444],
    8855: [0.13333, 0.63333, 0, 0, 0.89444],
    8856: [0.13333, 0.63333, 0, 0, 0.89444],
    8857: [0.13333, 0.63333, 0, 0, 0.89444],
    8866: [0, 0.69444, 0, 0, 0.70277],
    8867: [0, 0.69444, 0, 0, 0.70277],
    8868: [0, 0.69444, 0, 0, 0.89444],
    8869: [0, 0.69444, 0, 0, 0.89444],
    8900: [-0.02639, 0.47361, 0, 0, 0.575],
    8901: [-0.02639, 0.47361, 0, 0, 0.31944],
    8902: [-0.02778, 0.47222, 0, 0, 0.575],
    8968: [0.25, 0.75, 0, 0, 0.51111],
    8969: [0.25, 0.75, 0, 0, 0.51111],
    8970: [0.25, 0.75, 0, 0, 0.51111],
    8971: [0.25, 0.75, 0, 0, 0.51111],
    8994: [-0.13889, 0.36111, 0, 0, 1.14999],
    8995: [-0.13889, 0.36111, 0, 0, 1.14999],
    9651: [0.19444, 0.69444, 0, 0, 1.02222],
    9657: [-0.02778, 0.47222, 0, 0, 0.575],
    9661: [0.19444, 0.69444, 0, 0, 1.02222],
    9667: [-0.02778, 0.47222, 0, 0, 0.575],
    9711: [0.19444, 0.69444, 0, 0, 1.14999],
    9824: [0.12963, 0.69444, 0, 0, 0.89444],
    9825: [0.12963, 0.69444, 0, 0, 0.89444],
    9826: [0.12963, 0.69444, 0, 0, 0.89444],
    9827: [0.12963, 0.69444, 0, 0, 0.89444],
    9837: [0, 0.75, 0, 0, 0.44722],
    9838: [0.19444, 0.69444, 0, 0, 0.44722],
    9839: [0.19444, 0.69444, 0, 0, 0.44722],
    10216: [0.25, 0.75, 0, 0, 0.44722],
    10217: [0.25, 0.75, 0, 0, 0.44722],
    10815: [0, 0.68611, 0, 0, 0.9],
    10927: [0.19667, 0.69667, 0, 0, 0.89444],
    10928: [0.19667, 0.69667, 0, 0, 0.89444],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Main-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.11417, 0, 0.38611],
    34: [0, 0.69444, 0.07939, 0, 0.62055],
    35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
    37: [0.05556, 0.75, 0.12861, 0, 0.94444],
    38: [0, 0.69444, 0.08528, 0, 0.88555],
    39: [0, 0.69444, 0.12945, 0, 0.35555],
    40: [0.25, 0.75, 0.15806, 0, 0.47333],
    41: [0.25, 0.75, 0.03306, 0, 0.47333],
    42: [0, 0.75, 0.14333, 0, 0.59111],
    43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
    44: [0.19444, 0.14722, 0, 0, 0.35555],
    45: [0, 0.44444, 0.02611, 0, 0.41444],
    46: [0, 0.14722, 0, 0, 0.35555],
    47: [0.25, 0.75, 0.15806, 0, 0.59111],
    48: [0, 0.64444, 0.13167, 0, 0.59111],
    49: [0, 0.64444, 0.13167, 0, 0.59111],
    50: [0, 0.64444, 0.13167, 0, 0.59111],
    51: [0, 0.64444, 0.13167, 0, 0.59111],
    52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    53: [0, 0.64444, 0.13167, 0, 0.59111],
    54: [0, 0.64444, 0.13167, 0, 0.59111],
    55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    56: [0, 0.64444, 0.13167, 0, 0.59111],
    57: [0, 0.64444, 0.13167, 0, 0.59111],
    58: [0, 0.44444, 0.06695, 0, 0.35555],
    59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
    61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
    63: [0, 0.69444, 0.11472, 0, 0.59111],
    64: [0, 0.69444, 0.09208, 0, 0.88555],
    65: [0, 0.68611, 0, 0, 0.86555],
    66: [0, 0.68611, 0.0992, 0, 0.81666],
    67: [0, 0.68611, 0.14208, 0, 0.82666],
    68: [0, 0.68611, 0.09062, 0, 0.87555],
    69: [0, 0.68611, 0.11431, 0, 0.75666],
    70: [0, 0.68611, 0.12903, 0, 0.72722],
    71: [0, 0.68611, 0.07347, 0, 0.89527],
    72: [0, 0.68611, 0.17208, 0, 0.8961],
    73: [0, 0.68611, 0.15681, 0, 0.47166],
    74: [0, 0.68611, 0.145, 0, 0.61055],
    75: [0, 0.68611, 0.14208, 0, 0.89499],
    76: [0, 0.68611, 0, 0, 0.69777],
    77: [0, 0.68611, 0.17208, 0, 1.07277],
    78: [0, 0.68611, 0.17208, 0, 0.8961],
    79: [0, 0.68611, 0.09062, 0, 0.85499],
    80: [0, 0.68611, 0.0992, 0, 0.78721],
    81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
    82: [0, 0.68611, 0.02559, 0, 0.85944],
    83: [0, 0.68611, 0.11264, 0, 0.64999],
    84: [0, 0.68611, 0.12903, 0, 0.7961],
    85: [0, 0.68611, 0.17208, 0, 0.88083],
    86: [0, 0.68611, 0.18625, 0, 0.86555],
    87: [0, 0.68611, 0.18625, 0, 1.15999],
    88: [0, 0.68611, 0.15681, 0, 0.86555],
    89: [0, 0.68611, 0.19803, 0, 0.86555],
    90: [0, 0.68611, 0.14208, 0, 0.70888],
    91: [0.25, 0.75, 0.1875, 0, 0.35611],
    93: [0.25, 0.75, 0.09972, 0, 0.35611],
    94: [0, 0.69444, 0.06709, 0, 0.59111],
    95: [0.31, 0.13444, 0.09811, 0, 0.59111],
    97: [0, 0.44444, 0.09426, 0, 0.59111],
    98: [0, 0.69444, 0.07861, 0, 0.53222],
    99: [0, 0.44444, 0.05222, 0, 0.53222],
    100: [0, 0.69444, 0.10861, 0, 0.59111],
    101: [0, 0.44444, 0.085, 0, 0.53222],
    102: [0.19444, 0.69444, 0.21778, 0, 0.4],
    103: [0.19444, 0.44444, 0.105, 0, 0.53222],
    104: [0, 0.69444, 0.09426, 0, 0.59111],
    105: [0, 0.69326, 0.11387, 0, 0.35555],
    106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
    107: [0, 0.69444, 0.11111, 0, 0.53222],
    108: [0, 0.69444, 0.10861, 0, 0.29666],
    109: [0, 0.44444, 0.09426, 0, 0.94444],
    110: [0, 0.44444, 0.09426, 0, 0.64999],
    111: [0, 0.44444, 0.07861, 0, 0.59111],
    112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
    113: [0.19444, 0.44444, 0.105, 0, 0.53222],
    114: [0, 0.44444, 0.11111, 0, 0.50167],
    115: [0, 0.44444, 0.08167, 0, 0.48694],
    116: [0, 0.63492, 0.09639, 0, 0.385],
    117: [0, 0.44444, 0.09426, 0, 0.62055],
    118: [0, 0.44444, 0.11111, 0, 0.53222],
    119: [0, 0.44444, 0.11111, 0, 0.76777],
    120: [0, 0.44444, 0.12583, 0, 0.56055],
    121: [0.19444, 0.44444, 0.105, 0, 0.56166],
    122: [0, 0.44444, 0.13889, 0, 0.49055],
    126: [0.35, 0.34444, 0.11472, 0, 0.59111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0.11473, 0, 0.59111],
    176: [0, 0.69444, 0, 0, 0.94888],
    184: [0.17014, 0, 0, 0, 0.53222],
    198: [0, 0.68611, 0.11431, 0, 1.02277],
    216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
    223: [0.19444, 0.69444, 0.09736, 0, 0.665],
    230: [0, 0.44444, 0.085, 0, 0.82666],
    248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
    305: [0, 0.44444, 0.09426, 0, 0.35555],
    338: [0, 0.68611, 0.11431, 0, 1.14054],
    339: [0, 0.44444, 0.085, 0, 0.82666],
    567: [0.19444, 0.44444, 0.04611, 0, 0.385],
    710: [0, 0.69444, 0.06709, 0, 0.59111],
    711: [0, 0.63194, 0.08271, 0, 0.59111],
    713: [0, 0.59444, 0.10444, 0, 0.59111],
    714: [0, 0.69444, 0.08528, 0, 0.59111],
    715: [0, 0.69444, 0, 0, 0.59111],
    728: [0, 0.69444, 0.10333, 0, 0.59111],
    729: [0, 0.69444, 0.12945, 0, 0.35555],
    730: [0, 0.69444, 0, 0, 0.94888],
    732: [0, 0.69444, 0.11472, 0, 0.59111],
    733: [0, 0.69444, 0.11472, 0, 0.59111],
    915: [0, 0.68611, 0.12903, 0, 0.69777],
    916: [0, 0.68611, 0, 0, 0.94444],
    920: [0, 0.68611, 0.09062, 0, 0.88555],
    923: [0, 0.68611, 0, 0, 0.80666],
    926: [0, 0.68611, 0.15092, 0, 0.76777],
    928: [0, 0.68611, 0.17208, 0, 0.8961],
    931: [0, 0.68611, 0.11431, 0, 0.82666],
    933: [0, 0.68611, 0.10778, 0, 0.88555],
    934: [0, 0.68611, 0.05632, 0, 0.82666],
    936: [0, 0.68611, 0.10778, 0, 0.88555],
    937: [0, 0.68611, 0.0992, 0, 0.82666],
    8211: [0, 0.44444, 0.09811, 0, 0.59111],
    8212: [0, 0.44444, 0.09811, 0, 1.18221],
    8216: [0, 0.69444, 0.12945, 0, 0.35555],
    8217: [0, 0.69444, 0.12945, 0, 0.35555],
    8220: [0, 0.69444, 0.16772, 0, 0.62055],
    8221: [0, 0.69444, 0.07939, 0, 0.62055]
  },
  "Main-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.12417, 0, 0.30667],
    34: [0, 0.69444, 0.06961, 0, 0.51444],
    35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
    37: [0.05556, 0.75, 0.13639, 0, 0.81777],
    38: [0, 0.69444, 0.09694, 0, 0.76666],
    39: [0, 0.69444, 0.12417, 0, 0.30667],
    40: [0.25, 0.75, 0.16194, 0, 0.40889],
    41: [0.25, 0.75, 0.03694, 0, 0.40889],
    42: [0, 0.75, 0.14917, 0, 0.51111],
    43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
    44: [0.19444, 0.10556, 0, 0, 0.30667],
    45: [0, 0.43056, 0.02826, 0, 0.35778],
    46: [0, 0.10556, 0, 0, 0.30667],
    47: [0.25, 0.75, 0.16194, 0, 0.51111],
    48: [0, 0.64444, 0.13556, 0, 0.51111],
    49: [0, 0.64444, 0.13556, 0, 0.51111],
    50: [0, 0.64444, 0.13556, 0, 0.51111],
    51: [0, 0.64444, 0.13556, 0, 0.51111],
    52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    53: [0, 0.64444, 0.13556, 0, 0.51111],
    54: [0, 0.64444, 0.13556, 0, 0.51111],
    55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    56: [0, 0.64444, 0.13556, 0, 0.51111],
    57: [0, 0.64444, 0.13556, 0, 0.51111],
    58: [0, 0.43056, 0.0582, 0, 0.30667],
    59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
    61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
    63: [0, 0.69444, 0.1225, 0, 0.51111],
    64: [0, 0.69444, 0.09597, 0, 0.76666],
    65: [0, 0.68333, 0, 0, 0.74333],
    66: [0, 0.68333, 0.10257, 0, 0.70389],
    67: [0, 0.68333, 0.14528, 0, 0.71555],
    68: [0, 0.68333, 0.09403, 0, 0.755],
    69: [0, 0.68333, 0.12028, 0, 0.67833],
    70: [0, 0.68333, 0.13305, 0, 0.65277],
    71: [0, 0.68333, 0.08722, 0, 0.77361],
    72: [0, 0.68333, 0.16389, 0, 0.74333],
    73: [0, 0.68333, 0.15806, 0, 0.38555],
    74: [0, 0.68333, 0.14028, 0, 0.525],
    75: [0, 0.68333, 0.14528, 0, 0.76888],
    76: [0, 0.68333, 0, 0, 0.62722],
    77: [0, 0.68333, 0.16389, 0, 0.89666],
    78: [0, 0.68333, 0.16389, 0, 0.74333],
    79: [0, 0.68333, 0.09403, 0, 0.76666],
    80: [0, 0.68333, 0.10257, 0, 0.67833],
    81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
    82: [0, 0.68333, 0.03868, 0, 0.72944],
    83: [0, 0.68333, 0.11972, 0, 0.56222],
    84: [0, 0.68333, 0.13305, 0, 0.71555],
    85: [0, 0.68333, 0.16389, 0, 0.74333],
    86: [0, 0.68333, 0.18361, 0, 0.74333],
    87: [0, 0.68333, 0.18361, 0, 0.99888],
    88: [0, 0.68333, 0.15806, 0, 0.74333],
    89: [0, 0.68333, 0.19383, 0, 0.74333],
    90: [0, 0.68333, 0.14528, 0, 0.61333],
    91: [0.25, 0.75, 0.1875, 0, 0.30667],
    93: [0.25, 0.75, 0.10528, 0, 0.30667],
    94: [0, 0.69444, 0.06646, 0, 0.51111],
    95: [0.31, 0.12056, 0.09208, 0, 0.51111],
    97: [0, 0.43056, 0.07671, 0, 0.51111],
    98: [0, 0.69444, 0.06312, 0, 0.46],
    99: [0, 0.43056, 0.05653, 0, 0.46],
    100: [0, 0.69444, 0.10333, 0, 0.51111],
    101: [0, 0.43056, 0.07514, 0, 0.46],
    102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
    103: [0.19444, 0.43056, 0.08847, 0, 0.46],
    104: [0, 0.69444, 0.07671, 0, 0.51111],
    105: [0, 0.65536, 0.1019, 0, 0.30667],
    106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
    107: [0, 0.69444, 0.10764, 0, 0.46],
    108: [0, 0.69444, 0.10333, 0, 0.25555],
    109: [0, 0.43056, 0.07671, 0, 0.81777],
    110: [0, 0.43056, 0.07671, 0, 0.56222],
    111: [0, 0.43056, 0.06312, 0, 0.51111],
    112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
    113: [0.19444, 0.43056, 0.08847, 0, 0.46],
    114: [0, 0.43056, 0.10764, 0, 0.42166],
    115: [0, 0.43056, 0.08208, 0, 0.40889],
    116: [0, 0.61508, 0.09486, 0, 0.33222],
    117: [0, 0.43056, 0.07671, 0, 0.53666],
    118: [0, 0.43056, 0.10764, 0, 0.46],
    119: [0, 0.43056, 0.10764, 0, 0.66444],
    120: [0, 0.43056, 0.12042, 0, 0.46389],
    121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
    122: [0, 0.43056, 0.12292, 0, 0.40889],
    126: [0.35, 0.31786, 0.11585, 0, 0.51111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.66786, 0.10474, 0, 0.51111],
    176: [0, 0.69444, 0, 0, 0.83129],
    184: [0.17014, 0, 0, 0, 0.46],
    198: [0, 0.68333, 0.12028, 0, 0.88277],
    216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
    223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
    230: [0, 0.43056, 0.07514, 0, 0.71555],
    248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
    338: [0, 0.68333, 0.12028, 0, 0.98499],
    339: [0, 0.43056, 0.07514, 0, 0.71555],
    710: [0, 0.69444, 0.06646, 0, 0.51111],
    711: [0, 0.62847, 0.08295, 0, 0.51111],
    713: [0, 0.56167, 0.10333, 0, 0.51111],
    714: [0, 0.69444, 0.09694, 0, 0.51111],
    715: [0, 0.69444, 0, 0, 0.51111],
    728: [0, 0.69444, 0.10806, 0, 0.51111],
    729: [0, 0.66786, 0.11752, 0, 0.30667],
    730: [0, 0.69444, 0, 0, 0.83129],
    732: [0, 0.66786, 0.11585, 0, 0.51111],
    733: [0, 0.69444, 0.1225, 0, 0.51111],
    915: [0, 0.68333, 0.13305, 0, 0.62722],
    916: [0, 0.68333, 0, 0, 0.81777],
    920: [0, 0.68333, 0.09403, 0, 0.76666],
    923: [0, 0.68333, 0, 0, 0.69222],
    926: [0, 0.68333, 0.15294, 0, 0.66444],
    928: [0, 0.68333, 0.16389, 0, 0.74333],
    931: [0, 0.68333, 0.12028, 0, 0.71555],
    933: [0, 0.68333, 0.11111, 0, 0.76666],
    934: [0, 0.68333, 0.05986, 0, 0.71555],
    936: [0, 0.68333, 0.11111, 0, 0.76666],
    937: [0, 0.68333, 0.10257, 0, 0.71555],
    8211: [0, 0.43056, 0.09208, 0, 0.51111],
    8212: [0, 0.43056, 0.09208, 0, 1.02222],
    8216: [0, 0.69444, 0.12417, 0, 0.30667],
    8217: [0, 0.69444, 0.12417, 0, 0.30667],
    8220: [0, 0.69444, 0.1685, 0, 0.51444],
    8221: [0, 0.69444, 0.06961, 0, 0.51444],
    8463: [0, 0.68889, 0, 0, 0.54028]
  },
  "Main-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.27778],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.77778],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.19444, 0.10556, 0, 0, 0.27778],
    45: [0, 0.43056, 0, 0, 0.33333],
    46: [0, 0.10556, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.64444, 0, 0, 0.5],
    49: [0, 0.64444, 0, 0, 0.5],
    50: [0, 0.64444, 0, 0, 0.5],
    51: [0, 0.64444, 0, 0, 0.5],
    52: [0, 0.64444, 0, 0, 0.5],
    53: [0, 0.64444, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0, 0.64444, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0, 0.64444, 0, 0, 0.5],
    58: [0, 0.43056, 0, 0, 0.27778],
    59: [0.19444, 0.43056, 0, 0, 0.27778],
    60: [0.0391, 0.5391, 0, 0, 0.77778],
    61: [-0.13313, 0.36687, 0, 0, 0.77778],
    62: [0.0391, 0.5391, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.77778],
    65: [0, 0.68333, 0, 0, 0.75],
    66: [0, 0.68333, 0, 0, 0.70834],
    67: [0, 0.68333, 0, 0, 0.72222],
    68: [0, 0.68333, 0, 0, 0.76389],
    69: [0, 0.68333, 0, 0, 0.68056],
    70: [0, 0.68333, 0, 0, 0.65278],
    71: [0, 0.68333, 0, 0, 0.78472],
    72: [0, 0.68333, 0, 0, 0.75],
    73: [0, 0.68333, 0, 0, 0.36111],
    74: [0, 0.68333, 0, 0, 0.51389],
    75: [0, 0.68333, 0, 0, 0.77778],
    76: [0, 0.68333, 0, 0, 0.625],
    77: [0, 0.68333, 0, 0, 0.91667],
    78: [0, 0.68333, 0, 0, 0.75],
    79: [0, 0.68333, 0, 0, 0.77778],
    80: [0, 0.68333, 0, 0, 0.68056],
    81: [0.19444, 0.68333, 0, 0, 0.77778],
    82: [0, 0.68333, 0, 0, 0.73611],
    83: [0, 0.68333, 0, 0, 0.55556],
    84: [0, 0.68333, 0, 0, 0.72222],
    85: [0, 0.68333, 0, 0, 0.75],
    86: [0, 0.68333, 0.01389, 0, 0.75],
    87: [0, 0.68333, 0.01389, 0, 1.02778],
    88: [0, 0.68333, 0, 0, 0.75],
    89: [0, 0.68333, 0.025, 0, 0.75],
    90: [0, 0.68333, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.27778],
    92: [0.25, 0.75, 0, 0, 0.5],
    93: [0.25, 0.75, 0, 0, 0.27778],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.31, 0.12056, 0.02778, 0, 0.5],
    97: [0, 0.43056, 0, 0, 0.5],
    98: [0, 0.69444, 0, 0, 0.55556],
    99: [0, 0.43056, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.55556],
    101: [0, 0.43056, 0, 0, 0.44445],
    102: [0, 0.69444, 0.07778, 0, 0.30556],
    103: [0.19444, 0.43056, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.55556],
    105: [0, 0.66786, 0, 0, 0.27778],
    106: [0.19444, 0.66786, 0, 0, 0.30556],
    107: [0, 0.69444, 0, 0, 0.52778],
    108: [0, 0.69444, 0, 0, 0.27778],
    109: [0, 0.43056, 0, 0, 0.83334],
    110: [0, 0.43056, 0, 0, 0.55556],
    111: [0, 0.43056, 0, 0, 0.5],
    112: [0.19444, 0.43056, 0, 0, 0.55556],
    113: [0.19444, 0.43056, 0, 0, 0.52778],
    114: [0, 0.43056, 0, 0, 0.39167],
    115: [0, 0.43056, 0, 0, 0.39445],
    116: [0, 0.61508, 0, 0, 0.38889],
    117: [0, 0.43056, 0, 0, 0.55556],
    118: [0, 0.43056, 0.01389, 0, 0.52778],
    119: [0, 0.43056, 0.01389, 0, 0.72222],
    120: [0, 0.43056, 0, 0, 0.52778],
    121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
    122: [0, 0.43056, 0, 0, 0.44445],
    123: [0.25, 0.75, 0, 0, 0.5],
    124: [0.25, 0.75, 0, 0, 0.27778],
    125: [0.25, 0.75, 0, 0, 0.5],
    126: [0.35, 0.31786, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.76909],
    167: [0.19444, 0.69444, 0, 0, 0.44445],
    168: [0, 0.66786, 0, 0, 0.5],
    172: [0, 0.43056, 0, 0, 0.66667],
    176: [0, 0.69444, 0, 0, 0.75],
    177: [0.08333, 0.58333, 0, 0, 0.77778],
    182: [0.19444, 0.69444, 0, 0, 0.61111],
    184: [0.17014, 0, 0, 0, 0.44445],
    198: [0, 0.68333, 0, 0, 0.90278],
    215: [0.08333, 0.58333, 0, 0, 0.77778],
    216: [0.04861, 0.73194, 0, 0, 0.77778],
    223: [0, 0.69444, 0, 0, 0.5],
    230: [0, 0.43056, 0, 0, 0.72222],
    247: [0.08333, 0.58333, 0, 0, 0.77778],
    248: [0.09722, 0.52778, 0, 0, 0.5],
    305: [0, 0.43056, 0, 0, 0.27778],
    338: [0, 0.68333, 0, 0, 1.01389],
    339: [0, 0.43056, 0, 0, 0.77778],
    567: [0.19444, 0.43056, 0, 0, 0.30556],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.62847, 0, 0, 0.5],
    713: [0, 0.56778, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.66786, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.75],
    732: [0, 0.66786, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.68333, 0, 0, 0.625],
    916: [0, 0.68333, 0, 0, 0.83334],
    920: [0, 0.68333, 0, 0, 0.77778],
    923: [0, 0.68333, 0, 0, 0.69445],
    926: [0, 0.68333, 0, 0, 0.66667],
    928: [0, 0.68333, 0, 0, 0.75],
    931: [0, 0.68333, 0, 0, 0.72222],
    933: [0, 0.68333, 0, 0, 0.77778],
    934: [0, 0.68333, 0, 0, 0.72222],
    936: [0, 0.68333, 0, 0, 0.77778],
    937: [0, 0.68333, 0, 0, 0.72222],
    8211: [0, 0.43056, 0.02778, 0, 0.5],
    8212: [0, 0.43056, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5],
    8224: [0.19444, 0.69444, 0, 0, 0.44445],
    8225: [0.19444, 0.69444, 0, 0, 0.44445],
    8230: [0, 0.123, 0, 0, 1.172],
    8242: [0, 0.55556, 0, 0, 0.275],
    8407: [0, 0.71444, 0.15382, 0, 0.5],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8465: [0, 0.69444, 0, 0, 0.72222],
    8467: [0, 0.69444, 0, 0.11111, 0.41667],
    8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
    8476: [0, 0.69444, 0, 0, 0.72222],
    8501: [0, 0.69444, 0, 0, 0.61111],
    8592: [-0.13313, 0.36687, 0, 0, 1],
    8593: [0.19444, 0.69444, 0, 0, 0.5],
    8594: [-0.13313, 0.36687, 0, 0, 1],
    8595: [0.19444, 0.69444, 0, 0, 0.5],
    8596: [-0.13313, 0.36687, 0, 0, 1],
    8597: [0.25, 0.75, 0, 0, 0.5],
    8598: [0.19444, 0.69444, 0, 0, 1],
    8599: [0.19444, 0.69444, 0, 0, 1],
    8600: [0.19444, 0.69444, 0, 0, 1],
    8601: [0.19444, 0.69444, 0, 0, 1],
    8614: [0.011, 0.511, 0, 0, 1],
    8617: [0.011, 0.511, 0, 0, 1.126],
    8618: [0.011, 0.511, 0, 0, 1.126],
    8636: [-0.13313, 0.36687, 0, 0, 1],
    8637: [-0.13313, 0.36687, 0, 0, 1],
    8640: [-0.13313, 0.36687, 0, 0, 1],
    8641: [-0.13313, 0.36687, 0, 0, 1],
    8652: [0.011, 0.671, 0, 0, 1],
    8656: [-0.13313, 0.36687, 0, 0, 1],
    8657: [0.19444, 0.69444, 0, 0, 0.61111],
    8658: [-0.13313, 0.36687, 0, 0, 1],
    8659: [0.19444, 0.69444, 0, 0, 0.61111],
    8660: [-0.13313, 0.36687, 0, 0, 1],
    8661: [0.25, 0.75, 0, 0, 0.61111],
    8704: [0, 0.69444, 0, 0, 0.55556],
    8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
    8707: [0, 0.69444, 0, 0, 0.55556],
    8709: [0.05556, 0.75, 0, 0, 0.5],
    8711: [0, 0.68333, 0, 0, 0.83334],
    8712: [0.0391, 0.5391, 0, 0, 0.66667],
    8715: [0.0391, 0.5391, 0, 0, 0.66667],
    8722: [0.08333, 0.58333, 0, 0, 0.77778],
    8723: [0.08333, 0.58333, 0, 0, 0.77778],
    8725: [0.25, 0.75, 0, 0, 0.5],
    8726: [0.25, 0.75, 0, 0, 0.5],
    8727: [-0.03472, 0.46528, 0, 0, 0.5],
    8728: [-0.05555, 0.44445, 0, 0, 0.5],
    8729: [-0.05555, 0.44445, 0, 0, 0.5],
    8730: [0.2, 0.8, 0, 0, 0.83334],
    8733: [0, 0.43056, 0, 0, 0.77778],
    8734: [0, 0.43056, 0, 0, 1],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.27778],
    8741: [0.25, 0.75, 0, 0, 0.5],
    8743: [0, 0.55556, 0, 0, 0.66667],
    8744: [0, 0.55556, 0, 0, 0.66667],
    8745: [0, 0.55556, 0, 0, 0.66667],
    8746: [0, 0.55556, 0, 0, 0.66667],
    8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8768: [0.19444, 0.69444, 0, 0, 0.27778],
    8771: [-0.03625, 0.46375, 0, 0, 0.77778],
    8773: [-0.022, 0.589, 0, 0, 0.778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8781: [-0.03625, 0.46375, 0, 0, 0.77778],
    8784: [-0.133, 0.673, 0, 0, 0.778],
    8801: [-0.03625, 0.46375, 0, 0, 0.77778],
    8804: [0.13597, 0.63597, 0, 0, 0.77778],
    8805: [0.13597, 0.63597, 0, 0, 0.77778],
    8810: [0.0391, 0.5391, 0, 0, 1],
    8811: [0.0391, 0.5391, 0, 0, 1],
    8826: [0.0391, 0.5391, 0, 0, 0.77778],
    8827: [0.0391, 0.5391, 0, 0, 0.77778],
    8834: [0.0391, 0.5391, 0, 0, 0.77778],
    8835: [0.0391, 0.5391, 0, 0, 0.77778],
    8838: [0.13597, 0.63597, 0, 0, 0.77778],
    8839: [0.13597, 0.63597, 0, 0, 0.77778],
    8846: [0, 0.55556, 0, 0, 0.66667],
    8849: [0.13597, 0.63597, 0, 0, 0.77778],
    8850: [0.13597, 0.63597, 0, 0, 0.77778],
    8851: [0, 0.55556, 0, 0, 0.66667],
    8852: [0, 0.55556, 0, 0, 0.66667],
    8853: [0.08333, 0.58333, 0, 0, 0.77778],
    8854: [0.08333, 0.58333, 0, 0, 0.77778],
    8855: [0.08333, 0.58333, 0, 0, 0.77778],
    8856: [0.08333, 0.58333, 0, 0, 0.77778],
    8857: [0.08333, 0.58333, 0, 0, 0.77778],
    8866: [0, 0.69444, 0, 0, 0.61111],
    8867: [0, 0.69444, 0, 0, 0.61111],
    8868: [0, 0.69444, 0, 0, 0.77778],
    8869: [0, 0.69444, 0, 0, 0.77778],
    8872: [0.249, 0.75, 0, 0, 0.867],
    8900: [-0.05555, 0.44445, 0, 0, 0.5],
    8901: [-0.05555, 0.44445, 0, 0, 0.27778],
    8902: [-0.03472, 0.46528, 0, 0, 0.5],
    8904: [5e-3, 0.505, 0, 0, 0.9],
    8942: [0.03, 0.903, 0, 0, 0.278],
    8943: [-0.19, 0.313, 0, 0, 1.172],
    8945: [-0.1, 0.823, 0, 0, 1.282],
    8968: [0.25, 0.75, 0, 0, 0.44445],
    8969: [0.25, 0.75, 0, 0, 0.44445],
    8970: [0.25, 0.75, 0, 0, 0.44445],
    8971: [0.25, 0.75, 0, 0, 0.44445],
    8994: [-0.14236, 0.35764, 0, 0, 1],
    8995: [-0.14236, 0.35764, 0, 0, 1],
    9136: [0.244, 0.744, 0, 0, 0.412],
    9137: [0.244, 0.745, 0, 0, 0.412],
    9651: [0.19444, 0.69444, 0, 0, 0.88889],
    9657: [-0.03472, 0.46528, 0, 0, 0.5],
    9661: [0.19444, 0.69444, 0, 0, 0.88889],
    9667: [-0.03472, 0.46528, 0, 0, 0.5],
    9711: [0.19444, 0.69444, 0, 0, 1],
    9824: [0.12963, 0.69444, 0, 0, 0.77778],
    9825: [0.12963, 0.69444, 0, 0, 0.77778],
    9826: [0.12963, 0.69444, 0, 0, 0.77778],
    9827: [0.12963, 0.69444, 0, 0, 0.77778],
    9837: [0, 0.75, 0, 0, 0.38889],
    9838: [0.19444, 0.69444, 0, 0, 0.38889],
    9839: [0.19444, 0.69444, 0, 0, 0.38889],
    10216: [0.25, 0.75, 0, 0, 0.38889],
    10217: [0.25, 0.75, 0, 0, 0.38889],
    10222: [0.244, 0.744, 0, 0, 0.412],
    10223: [0.244, 0.745, 0, 0, 0.412],
    10229: [0.011, 0.511, 0, 0, 1.609],
    10230: [0.011, 0.511, 0, 0, 1.638],
    10231: [0.011, 0.511, 0, 0, 1.859],
    10232: [0.024, 0.525, 0, 0, 1.609],
    10233: [0.024, 0.525, 0, 0, 1.638],
    10234: [0.024, 0.525, 0, 0, 1.858],
    10236: [0.011, 0.511, 0, 0, 1.638],
    10815: [0, 0.68333, 0, 0, 0.75],
    10927: [0.13597, 0.63597, 0, 0, 0.77778],
    10928: [0.13597, 0.63597, 0, 0, 0.77778],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Math-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.44444, 0, 0, 0.575],
    49: [0, 0.44444, 0, 0, 0.575],
    50: [0, 0.44444, 0, 0, 0.575],
    51: [0.19444, 0.44444, 0, 0, 0.575],
    52: [0.19444, 0.44444, 0, 0, 0.575],
    53: [0.19444, 0.44444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0.19444, 0.44444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0.19444, 0.44444, 0, 0, 0.575],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0.04835, 0, 0.8664],
    67: [0, 0.68611, 0.06979, 0, 0.81694],
    68: [0, 0.68611, 0.03194, 0, 0.93812],
    69: [0, 0.68611, 0.05451, 0, 0.81007],
    70: [0, 0.68611, 0.15972, 0, 0.68889],
    71: [0, 0.68611, 0, 0, 0.88673],
    72: [0, 0.68611, 0.08229, 0, 0.98229],
    73: [0, 0.68611, 0.07778, 0, 0.51111],
    74: [0, 0.68611, 0.10069, 0, 0.63125],
    75: [0, 0.68611, 0.06979, 0, 0.97118],
    76: [0, 0.68611, 0, 0, 0.75555],
    77: [0, 0.68611, 0.11424, 0, 1.14201],
    78: [0, 0.68611, 0.11424, 0, 0.95034],
    79: [0, 0.68611, 0.03194, 0, 0.83666],
    80: [0, 0.68611, 0.15972, 0, 0.72309],
    81: [0.19444, 0.68611, 0, 0, 0.86861],
    82: [0, 0.68611, 421e-5, 0, 0.87235],
    83: [0, 0.68611, 0.05382, 0, 0.69271],
    84: [0, 0.68611, 0.15972, 0, 0.63663],
    85: [0, 0.68611, 0.11424, 0, 0.80027],
    86: [0, 0.68611, 0.25555, 0, 0.67778],
    87: [0, 0.68611, 0.15972, 0, 1.09305],
    88: [0, 0.68611, 0.07778, 0, 0.94722],
    89: [0, 0.68611, 0.25555, 0, 0.67458],
    90: [0, 0.68611, 0.06979, 0, 0.77257],
    97: [0, 0.44444, 0, 0, 0.63287],
    98: [0, 0.69444, 0, 0, 0.52083],
    99: [0, 0.44444, 0, 0, 0.51342],
    100: [0, 0.69444, 0, 0, 0.60972],
    101: [0, 0.44444, 0, 0, 0.55361],
    102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
    103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
    104: [0, 0.69444, 0, 0, 0.66759],
    105: [0, 0.69326, 0, 0, 0.4048],
    106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
    107: [0, 0.69444, 0.01852, 0, 0.6037],
    108: [0, 0.69444, 88e-4, 0, 0.34815],
    109: [0, 0.44444, 0, 0, 1.0324],
    110: [0, 0.44444, 0, 0, 0.71296],
    111: [0, 0.44444, 0, 0, 0.58472],
    112: [0.19444, 0.44444, 0, 0, 0.60092],
    113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
    114: [0, 0.44444, 0.03194, 0, 0.5287],
    115: [0, 0.44444, 0, 0, 0.53125],
    116: [0, 0.63492, 0, 0, 0.41528],
    117: [0, 0.44444, 0, 0, 0.68102],
    118: [0, 0.44444, 0.03704, 0, 0.56666],
    119: [0, 0.44444, 0.02778, 0, 0.83148],
    120: [0, 0.44444, 0, 0, 0.65903],
    121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
    122: [0, 0.44444, 0.04213, 0, 0.55509],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68611, 0.15972, 0, 0.65694],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0.03194, 0, 0.86722],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0.07458, 0, 0.84125],
    928: [0, 0.68611, 0.08229, 0, 0.98229],
    931: [0, 0.68611, 0.05451, 0, 0.88507],
    933: [0, 0.68611, 0.15972, 0, 0.67083],
    934: [0, 0.68611, 0, 0, 0.76666],
    936: [0, 0.68611, 0.11653, 0, 0.71402],
    937: [0, 0.68611, 0.04835, 0, 0.8789],
    945: [0, 0.44444, 0, 0, 0.76064],
    946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
    947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
    948: [0, 0.69444, 0.03819, 0, 0.52222],
    949: [0, 0.44444, 0, 0, 0.52882],
    950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
    951: [0.19444, 0.44444, 0.03704, 0, 0.6],
    952: [0, 0.69444, 0.03194, 0, 0.5618],
    953: [0, 0.44444, 0, 0, 0.41204],
    954: [0, 0.44444, 0, 0, 0.66759],
    955: [0, 0.69444, 0, 0, 0.67083],
    956: [0.19444, 0.44444, 0, 0, 0.70787],
    957: [0, 0.44444, 0.06898, 0, 0.57685],
    958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
    959: [0, 0.44444, 0, 0, 0.58472],
    960: [0, 0.44444, 0.03704, 0, 0.68241],
    961: [0.19444, 0.44444, 0, 0, 0.6118],
    962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
    963: [0, 0.44444, 0.03704, 0, 0.68588],
    964: [0, 0.44444, 0.13472, 0, 0.52083],
    965: [0, 0.44444, 0.03704, 0, 0.63055],
    966: [0.19444, 0.44444, 0, 0, 0.74722],
    967: [0.19444, 0.44444, 0, 0, 0.71805],
    968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
    969: [0, 0.44444, 0.03704, 0, 0.71782],
    977: [0, 0.69444, 0, 0, 0.69155],
    981: [0.19444, 0.69444, 0, 0, 0.7125],
    982: [0, 0.44444, 0.03194, 0, 0.975],
    1009: [0.19444, 0.44444, 0, 0, 0.6118],
    1013: [0, 0.44444, 0, 0, 0.48333],
    57649: [0, 0.44444, 0, 0, 0.39352],
    57911: [0.19444, 0.44444, 0, 0, 0.43889]
  },
  "Math-Italic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.43056, 0, 0, 0.5],
    49: [0, 0.43056, 0, 0, 0.5],
    50: [0, 0.43056, 0, 0, 0.5],
    51: [0.19444, 0.43056, 0, 0, 0.5],
    52: [0.19444, 0.43056, 0, 0, 0.5],
    53: [0.19444, 0.43056, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0.19444, 0.43056, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0.19444, 0.43056, 0, 0, 0.5],
    65: [0, 0.68333, 0, 0.13889, 0.75],
    66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
    67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
    68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
    69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
    70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
    71: [0, 0.68333, 0, 0.08334, 0.78625],
    72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
    74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
    75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
    76: [0, 0.68333, 0, 0.02778, 0.68056],
    77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
    78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
    79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
    81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
    82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
    83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
    84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
    85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
    86: [0, 0.68333, 0.22222, 0, 0.58333],
    87: [0, 0.68333, 0.13889, 0, 0.94445],
    88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
    89: [0, 0.68333, 0.22222, 0, 0.58056],
    90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
    97: [0, 0.43056, 0, 0, 0.52859],
    98: [0, 0.69444, 0, 0, 0.42917],
    99: [0, 0.43056, 0, 0.05556, 0.43276],
    100: [0, 0.69444, 0, 0.16667, 0.52049],
    101: [0, 0.43056, 0, 0.05556, 0.46563],
    102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
    103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
    104: [0, 0.69444, 0, 0, 0.57616],
    105: [0, 0.65952, 0, 0, 0.34451],
    106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
    107: [0, 0.69444, 0.03148, 0, 0.5206],
    108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
    109: [0, 0.43056, 0, 0, 0.87801],
    110: [0, 0.43056, 0, 0, 0.60023],
    111: [0, 0.43056, 0, 0.05556, 0.48472],
    112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
    113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
    114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
    115: [0, 0.43056, 0, 0.05556, 0.46875],
    116: [0, 0.61508, 0, 0.08334, 0.36111],
    117: [0, 0.43056, 0, 0.02778, 0.57246],
    118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
    119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
    120: [0, 0.43056, 0, 0.02778, 0.57153],
    121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
    122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
    916: [0, 0.68333, 0, 0.16667, 0.83334],
    920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    923: [0, 0.68333, 0, 0.16667, 0.69445],
    926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
    928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
    933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
    934: [0, 0.68333, 0, 0.08334, 0.66667],
    936: [0, 0.68333, 0.11, 0.05556, 0.61222],
    937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
    945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
    946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
    947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
    948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
    949: [0, 0.43056, 0, 0.08334, 0.46632],
    950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
    951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
    952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
    953: [0, 0.43056, 0, 0.05556, 0.35394],
    954: [0, 0.43056, 0, 0, 0.57616],
    955: [0, 0.69444, 0, 0, 0.58334],
    956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
    957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
    958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
    959: [0, 0.43056, 0, 0.05556, 0.48472],
    960: [0, 0.43056, 0.03588, 0, 0.57003],
    961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
    963: [0, 0.43056, 0.03588, 0, 0.57141],
    964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
    965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
    966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
    967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
    968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
    969: [0, 0.43056, 0.03588, 0, 0.62245],
    977: [0, 0.69444, 0, 0.08334, 0.59144],
    981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
    982: [0, 0.43056, 0.02778, 0, 0.82813],
    1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    1013: [0, 0.43056, 0, 0.05556, 0.4059],
    57649: [0, 0.43056, 0, 0.02778, 0.32246],
    57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
  },
  "SansSerif-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.36667],
    34: [0, 0.69444, 0, 0, 0.55834],
    35: [0.19444, 0.69444, 0, 0, 0.91667],
    36: [0.05556, 0.75, 0, 0, 0.55],
    37: [0.05556, 0.75, 0, 0, 1.02912],
    38: [0, 0.69444, 0, 0, 0.83056],
    39: [0, 0.69444, 0, 0, 0.30556],
    40: [0.25, 0.75, 0, 0, 0.42778],
    41: [0.25, 0.75, 0, 0, 0.42778],
    42: [0, 0.75, 0, 0, 0.55],
    43: [0.11667, 0.61667, 0, 0, 0.85556],
    44: [0.10556, 0.13056, 0, 0, 0.30556],
    45: [0, 0.45833, 0, 0, 0.36667],
    46: [0, 0.13056, 0, 0, 0.30556],
    47: [0.25, 0.75, 0, 0, 0.55],
    48: [0, 0.69444, 0, 0, 0.55],
    49: [0, 0.69444, 0, 0, 0.55],
    50: [0, 0.69444, 0, 0, 0.55],
    51: [0, 0.69444, 0, 0, 0.55],
    52: [0, 0.69444, 0, 0, 0.55],
    53: [0, 0.69444, 0, 0, 0.55],
    54: [0, 0.69444, 0, 0, 0.55],
    55: [0, 0.69444, 0, 0, 0.55],
    56: [0, 0.69444, 0, 0, 0.55],
    57: [0, 0.69444, 0, 0, 0.55],
    58: [0, 0.45833, 0, 0, 0.30556],
    59: [0.10556, 0.45833, 0, 0, 0.30556],
    61: [-0.09375, 0.40625, 0, 0, 0.85556],
    63: [0, 0.69444, 0, 0, 0.51945],
    64: [0, 0.69444, 0, 0, 0.73334],
    65: [0, 0.69444, 0, 0, 0.73334],
    66: [0, 0.69444, 0, 0, 0.73334],
    67: [0, 0.69444, 0, 0, 0.70278],
    68: [0, 0.69444, 0, 0, 0.79445],
    69: [0, 0.69444, 0, 0, 0.64167],
    70: [0, 0.69444, 0, 0, 0.61111],
    71: [0, 0.69444, 0, 0, 0.73334],
    72: [0, 0.69444, 0, 0, 0.79445],
    73: [0, 0.69444, 0, 0, 0.33056],
    74: [0, 0.69444, 0, 0, 0.51945],
    75: [0, 0.69444, 0, 0, 0.76389],
    76: [0, 0.69444, 0, 0, 0.58056],
    77: [0, 0.69444, 0, 0, 0.97778],
    78: [0, 0.69444, 0, 0, 0.79445],
    79: [0, 0.69444, 0, 0, 0.79445],
    80: [0, 0.69444, 0, 0, 0.70278],
    81: [0.10556, 0.69444, 0, 0, 0.79445],
    82: [0, 0.69444, 0, 0, 0.70278],
    83: [0, 0.69444, 0, 0, 0.61111],
    84: [0, 0.69444, 0, 0, 0.73334],
    85: [0, 0.69444, 0, 0, 0.76389],
    86: [0, 0.69444, 0.01528, 0, 0.73334],
    87: [0, 0.69444, 0.01528, 0, 1.03889],
    88: [0, 0.69444, 0, 0, 0.73334],
    89: [0, 0.69444, 0.0275, 0, 0.73334],
    90: [0, 0.69444, 0, 0, 0.67223],
    91: [0.25, 0.75, 0, 0, 0.34306],
    93: [0.25, 0.75, 0, 0, 0.34306],
    94: [0, 0.69444, 0, 0, 0.55],
    95: [0.35, 0.10833, 0.03056, 0, 0.55],
    97: [0, 0.45833, 0, 0, 0.525],
    98: [0, 0.69444, 0, 0, 0.56111],
    99: [0, 0.45833, 0, 0, 0.48889],
    100: [0, 0.69444, 0, 0, 0.56111],
    101: [0, 0.45833, 0, 0, 0.51111],
    102: [0, 0.69444, 0.07639, 0, 0.33611],
    103: [0.19444, 0.45833, 0.01528, 0, 0.55],
    104: [0, 0.69444, 0, 0, 0.56111],
    105: [0, 0.69444, 0, 0, 0.25556],
    106: [0.19444, 0.69444, 0, 0, 0.28611],
    107: [0, 0.69444, 0, 0, 0.53056],
    108: [0, 0.69444, 0, 0, 0.25556],
    109: [0, 0.45833, 0, 0, 0.86667],
    110: [0, 0.45833, 0, 0, 0.56111],
    111: [0, 0.45833, 0, 0, 0.55],
    112: [0.19444, 0.45833, 0, 0, 0.56111],
    113: [0.19444, 0.45833, 0, 0, 0.56111],
    114: [0, 0.45833, 0.01528, 0, 0.37222],
    115: [0, 0.45833, 0, 0, 0.42167],
    116: [0, 0.58929, 0, 0, 0.40417],
    117: [0, 0.45833, 0, 0, 0.56111],
    118: [0, 0.45833, 0.01528, 0, 0.5],
    119: [0, 0.45833, 0.01528, 0, 0.74445],
    120: [0, 0.45833, 0, 0, 0.5],
    121: [0.19444, 0.45833, 0.01528, 0, 0.5],
    122: [0, 0.45833, 0, 0, 0.47639],
    126: [0.35, 0.34444, 0, 0, 0.55],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0, 0, 0.55],
    176: [0, 0.69444, 0, 0, 0.73334],
    180: [0, 0.69444, 0, 0, 0.55],
    184: [0.17014, 0, 0, 0, 0.48889],
    305: [0, 0.45833, 0, 0, 0.25556],
    567: [0.19444, 0.45833, 0, 0, 0.28611],
    710: [0, 0.69444, 0, 0, 0.55],
    711: [0, 0.63542, 0, 0, 0.55],
    713: [0, 0.63778, 0, 0, 0.55],
    728: [0, 0.69444, 0, 0, 0.55],
    729: [0, 0.69444, 0, 0, 0.30556],
    730: [0, 0.69444, 0, 0, 0.73334],
    732: [0, 0.69444, 0, 0, 0.55],
    733: [0, 0.69444, 0, 0, 0.55],
    915: [0, 0.69444, 0, 0, 0.58056],
    916: [0, 0.69444, 0, 0, 0.91667],
    920: [0, 0.69444, 0, 0, 0.85556],
    923: [0, 0.69444, 0, 0, 0.67223],
    926: [0, 0.69444, 0, 0, 0.73334],
    928: [0, 0.69444, 0, 0, 0.79445],
    931: [0, 0.69444, 0, 0, 0.79445],
    933: [0, 0.69444, 0, 0, 0.85556],
    934: [0, 0.69444, 0, 0, 0.79445],
    936: [0, 0.69444, 0, 0, 0.85556],
    937: [0, 0.69444, 0, 0, 0.79445],
    8211: [0, 0.45833, 0.03056, 0, 0.55],
    8212: [0, 0.45833, 0.03056, 0, 1.10001],
    8216: [0, 0.69444, 0, 0, 0.30556],
    8217: [0, 0.69444, 0, 0, 0.30556],
    8220: [0, 0.69444, 0, 0, 0.55834],
    8221: [0, 0.69444, 0, 0, 0.55834]
  },
  "SansSerif-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.05733, 0, 0.31945],
    34: [0, 0.69444, 316e-5, 0, 0.5],
    35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
    36: [0.05556, 0.75, 0.11156, 0, 0.5],
    37: [0.05556, 0.75, 0.03126, 0, 0.83334],
    38: [0, 0.69444, 0.03058, 0, 0.75834],
    39: [0, 0.69444, 0.07816, 0, 0.27778],
    40: [0.25, 0.75, 0.13164, 0, 0.38889],
    41: [0.25, 0.75, 0.02536, 0, 0.38889],
    42: [0, 0.75, 0.11775, 0, 0.5],
    43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0.01946, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0.13164, 0, 0.5],
    48: [0, 0.65556, 0.11156, 0, 0.5],
    49: [0, 0.65556, 0.11156, 0, 0.5],
    50: [0, 0.65556, 0.11156, 0, 0.5],
    51: [0, 0.65556, 0.11156, 0, 0.5],
    52: [0, 0.65556, 0.11156, 0, 0.5],
    53: [0, 0.65556, 0.11156, 0, 0.5],
    54: [0, 0.65556, 0.11156, 0, 0.5],
    55: [0, 0.65556, 0.11156, 0, 0.5],
    56: [0, 0.65556, 0.11156, 0, 0.5],
    57: [0, 0.65556, 0.11156, 0, 0.5],
    58: [0, 0.44444, 0.02502, 0, 0.27778],
    59: [0.125, 0.44444, 0.02502, 0, 0.27778],
    61: [-0.13, 0.37, 0.05087, 0, 0.77778],
    63: [0, 0.69444, 0.11809, 0, 0.47222],
    64: [0, 0.69444, 0.07555, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0.08293, 0, 0.66667],
    67: [0, 0.69444, 0.11983, 0, 0.63889],
    68: [0, 0.69444, 0.07555, 0, 0.72223],
    69: [0, 0.69444, 0.11983, 0, 0.59722],
    70: [0, 0.69444, 0.13372, 0, 0.56945],
    71: [0, 0.69444, 0.11983, 0, 0.66667],
    72: [0, 0.69444, 0.08094, 0, 0.70834],
    73: [0, 0.69444, 0.13372, 0, 0.27778],
    74: [0, 0.69444, 0.08094, 0, 0.47222],
    75: [0, 0.69444, 0.11983, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0.08094, 0, 0.875],
    78: [0, 0.69444, 0.08094, 0, 0.70834],
    79: [0, 0.69444, 0.07555, 0, 0.73611],
    80: [0, 0.69444, 0.08293, 0, 0.63889],
    81: [0.125, 0.69444, 0.07555, 0, 0.73611],
    82: [0, 0.69444, 0.08293, 0, 0.64584],
    83: [0, 0.69444, 0.09205, 0, 0.55556],
    84: [0, 0.69444, 0.13372, 0, 0.68056],
    85: [0, 0.69444, 0.08094, 0, 0.6875],
    86: [0, 0.69444, 0.1615, 0, 0.66667],
    87: [0, 0.69444, 0.1615, 0, 0.94445],
    88: [0, 0.69444, 0.13372, 0, 0.66667],
    89: [0, 0.69444, 0.17261, 0, 0.66667],
    90: [0, 0.69444, 0.11983, 0, 0.61111],
    91: [0.25, 0.75, 0.15942, 0, 0.28889],
    93: [0.25, 0.75, 0.08719, 0, 0.28889],
    94: [0, 0.69444, 0.0799, 0, 0.5],
    95: [0.35, 0.09444, 0.08616, 0, 0.5],
    97: [0, 0.44444, 981e-5, 0, 0.48056],
    98: [0, 0.69444, 0.03057, 0, 0.51667],
    99: [0, 0.44444, 0.08336, 0, 0.44445],
    100: [0, 0.69444, 0.09483, 0, 0.51667],
    101: [0, 0.44444, 0.06778, 0, 0.44445],
    102: [0, 0.69444, 0.21705, 0, 0.30556],
    103: [0.19444, 0.44444, 0.10836, 0, 0.5],
    104: [0, 0.69444, 0.01778, 0, 0.51667],
    105: [0, 0.67937, 0.09718, 0, 0.23889],
    106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
    107: [0, 0.69444, 0.08336, 0, 0.48889],
    108: [0, 0.69444, 0.09483, 0, 0.23889],
    109: [0, 0.44444, 0.01778, 0, 0.79445],
    110: [0, 0.44444, 0.01778, 0, 0.51667],
    111: [0, 0.44444, 0.06613, 0, 0.5],
    112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
    113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
    114: [0, 0.44444, 0.10836, 0, 0.34167],
    115: [0, 0.44444, 0.0778, 0, 0.38333],
    116: [0, 0.57143, 0.07225, 0, 0.36111],
    117: [0, 0.44444, 0.04169, 0, 0.51667],
    118: [0, 0.44444, 0.10836, 0, 0.46111],
    119: [0, 0.44444, 0.10836, 0, 0.68334],
    120: [0, 0.44444, 0.09169, 0, 0.46111],
    121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
    122: [0, 0.44444, 0.08752, 0, 0.43472],
    126: [0.35, 0.32659, 0.08826, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0.06385, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.73752],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0.04169, 0, 0.23889],
    567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
    710: [0, 0.69444, 0.0799, 0, 0.5],
    711: [0, 0.63194, 0.08432, 0, 0.5],
    713: [0, 0.60889, 0.08776, 0, 0.5],
    714: [0, 0.69444, 0.09205, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0.09483, 0, 0.5],
    729: [0, 0.67937, 0.07774, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.73752],
    732: [0, 0.67659, 0.08826, 0, 0.5],
    733: [0, 0.69444, 0.09205, 0, 0.5],
    915: [0, 0.69444, 0.13372, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0.07555, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0.12816, 0, 0.66667],
    928: [0, 0.69444, 0.08094, 0, 0.70834],
    931: [0, 0.69444, 0.11983, 0, 0.72222],
    933: [0, 0.69444, 0.09031, 0, 0.77778],
    934: [0, 0.69444, 0.04603, 0, 0.72222],
    936: [0, 0.69444, 0.09031, 0, 0.77778],
    937: [0, 0.69444, 0.08293, 0, 0.72222],
    8211: [0, 0.44444, 0.08616, 0, 0.5],
    8212: [0, 0.44444, 0.08616, 0, 1],
    8216: [0, 0.69444, 0.07816, 0, 0.27778],
    8217: [0, 0.69444, 0.07816, 0, 0.27778],
    8220: [0, 0.69444, 0.14205, 0, 0.5],
    8221: [0, 0.69444, 316e-5, 0, 0.5]
  },
  "SansSerif-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.31945],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.75834],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.65556, 0, 0, 0.5],
    49: [0, 0.65556, 0, 0, 0.5],
    50: [0, 0.65556, 0, 0, 0.5],
    51: [0, 0.65556, 0, 0, 0.5],
    52: [0, 0.65556, 0, 0, 0.5],
    53: [0, 0.65556, 0, 0, 0.5],
    54: [0, 0.65556, 0, 0, 0.5],
    55: [0, 0.65556, 0, 0, 0.5],
    56: [0, 0.65556, 0, 0, 0.5],
    57: [0, 0.65556, 0, 0, 0.5],
    58: [0, 0.44444, 0, 0, 0.27778],
    59: [0.125, 0.44444, 0, 0, 0.27778],
    61: [-0.13, 0.37, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0, 0, 0.66667],
    67: [0, 0.69444, 0, 0, 0.63889],
    68: [0, 0.69444, 0, 0, 0.72223],
    69: [0, 0.69444, 0, 0, 0.59722],
    70: [0, 0.69444, 0, 0, 0.56945],
    71: [0, 0.69444, 0, 0, 0.66667],
    72: [0, 0.69444, 0, 0, 0.70834],
    73: [0, 0.69444, 0, 0, 0.27778],
    74: [0, 0.69444, 0, 0, 0.47222],
    75: [0, 0.69444, 0, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0, 0, 0.875],
    78: [0, 0.69444, 0, 0, 0.70834],
    79: [0, 0.69444, 0, 0, 0.73611],
    80: [0, 0.69444, 0, 0, 0.63889],
    81: [0.125, 0.69444, 0, 0, 0.73611],
    82: [0, 0.69444, 0, 0, 0.64584],
    83: [0, 0.69444, 0, 0, 0.55556],
    84: [0, 0.69444, 0, 0, 0.68056],
    85: [0, 0.69444, 0, 0, 0.6875],
    86: [0, 0.69444, 0.01389, 0, 0.66667],
    87: [0, 0.69444, 0.01389, 0, 0.94445],
    88: [0, 0.69444, 0, 0, 0.66667],
    89: [0, 0.69444, 0.025, 0, 0.66667],
    90: [0, 0.69444, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.28889],
    93: [0.25, 0.75, 0, 0, 0.28889],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.35, 0.09444, 0.02778, 0, 0.5],
    97: [0, 0.44444, 0, 0, 0.48056],
    98: [0, 0.69444, 0, 0, 0.51667],
    99: [0, 0.44444, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.51667],
    101: [0, 0.44444, 0, 0, 0.44445],
    102: [0, 0.69444, 0.06944, 0, 0.30556],
    103: [0.19444, 0.44444, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.51667],
    105: [0, 0.67937, 0, 0, 0.23889],
    106: [0.19444, 0.67937, 0, 0, 0.26667],
    107: [0, 0.69444, 0, 0, 0.48889],
    108: [0, 0.69444, 0, 0, 0.23889],
    109: [0, 0.44444, 0, 0, 0.79445],
    110: [0, 0.44444, 0, 0, 0.51667],
    111: [0, 0.44444, 0, 0, 0.5],
    112: [0.19444, 0.44444, 0, 0, 0.51667],
    113: [0.19444, 0.44444, 0, 0, 0.51667],
    114: [0, 0.44444, 0.01389, 0, 0.34167],
    115: [0, 0.44444, 0, 0, 0.38333],
    116: [0, 0.57143, 0, 0, 0.36111],
    117: [0, 0.44444, 0, 0, 0.51667],
    118: [0, 0.44444, 0.01389, 0, 0.46111],
    119: [0, 0.44444, 0.01389, 0, 0.68334],
    120: [0, 0.44444, 0, 0, 0.46111],
    121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
    122: [0, 0.44444, 0, 0, 0.43472],
    126: [0.35, 0.32659, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.66667],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0, 0, 0.23889],
    567: [0.19444, 0.44444, 0, 0, 0.26667],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.63194, 0, 0, 0.5],
    713: [0, 0.60889, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.67937, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.66667],
    732: [0, 0.67659, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.69444, 0, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0, 0, 0.66667],
    928: [0, 0.69444, 0, 0, 0.70834],
    931: [0, 0.69444, 0, 0, 0.72222],
    933: [0, 0.69444, 0, 0, 0.77778],
    934: [0, 0.69444, 0, 0, 0.72222],
    936: [0, 0.69444, 0, 0, 0.77778],
    937: [0, 0.69444, 0, 0, 0.72222],
    8211: [0, 0.44444, 0.02778, 0, 0.5],
    8212: [0, 0.44444, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5]
  },
  "Script-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.7, 0.22925, 0, 0.80253],
    66: [0, 0.7, 0.04087, 0, 0.90757],
    67: [0, 0.7, 0.1689, 0, 0.66619],
    68: [0, 0.7, 0.09371, 0, 0.77443],
    69: [0, 0.7, 0.18583, 0, 0.56162],
    70: [0, 0.7, 0.13634, 0, 0.89544],
    71: [0, 0.7, 0.17322, 0, 0.60961],
    72: [0, 0.7, 0.29694, 0, 0.96919],
    73: [0, 0.7, 0.19189, 0, 0.80907],
    74: [0.27778, 0.7, 0.19189, 0, 1.05159],
    75: [0, 0.7, 0.31259, 0, 0.91364],
    76: [0, 0.7, 0.19189, 0, 0.87373],
    77: [0, 0.7, 0.15981, 0, 1.08031],
    78: [0, 0.7, 0.3525, 0, 0.9015],
    79: [0, 0.7, 0.08078, 0, 0.73787],
    80: [0, 0.7, 0.08078, 0, 1.01262],
    81: [0, 0.7, 0.03305, 0, 0.88282],
    82: [0, 0.7, 0.06259, 0, 0.85],
    83: [0, 0.7, 0.19189, 0, 0.86767],
    84: [0, 0.7, 0.29087, 0, 0.74697],
    85: [0, 0.7, 0.25815, 0, 0.79996],
    86: [0, 0.7, 0.27523, 0, 0.62204],
    87: [0, 0.7, 0.27523, 0, 0.80532],
    88: [0, 0.7, 0.26006, 0, 0.94445],
    89: [0, 0.7, 0.2939, 0, 0.70961],
    90: [0, 0.7, 0.24037, 0, 0.8212],
    160: [0, 0, 0, 0, 0.25]
  },
  "Size1-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.35001, 0.85, 0, 0, 0.45834],
    41: [0.35001, 0.85, 0, 0, 0.45834],
    47: [0.35001, 0.85, 0, 0, 0.57778],
    91: [0.35001, 0.85, 0, 0, 0.41667],
    92: [0.35001, 0.85, 0, 0, 0.57778],
    93: [0.35001, 0.85, 0, 0, 0.41667],
    123: [0.35001, 0.85, 0, 0, 0.58334],
    125: [0.35001, 0.85, 0, 0, 0.58334],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.72222, 0, 0, 0.55556],
    732: [0, 0.72222, 0, 0, 0.55556],
    770: [0, 0.72222, 0, 0, 0.55556],
    771: [0, 0.72222, 0, 0, 0.55556],
    8214: [-99e-5, 0.601, 0, 0, 0.77778],
    8593: [1e-5, 0.6, 0, 0, 0.66667],
    8595: [1e-5, 0.6, 0, 0, 0.66667],
    8657: [1e-5, 0.6, 0, 0, 0.77778],
    8659: [1e-5, 0.6, 0, 0, 0.77778],
    8719: [0.25001, 0.75, 0, 0, 0.94445],
    8720: [0.25001, 0.75, 0, 0, 0.94445],
    8721: [0.25001, 0.75, 0, 0, 1.05556],
    8730: [0.35001, 0.85, 0, 0, 1],
    8739: [-599e-5, 0.606, 0, 0, 0.33333],
    8741: [-599e-5, 0.606, 0, 0, 0.55556],
    8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8748: [0.306, 0.805, 0.19445, 0, 0.47222],
    8749: [0.306, 0.805, 0.19445, 0, 0.47222],
    8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8896: [0.25001, 0.75, 0, 0, 0.83334],
    8897: [0.25001, 0.75, 0, 0, 0.83334],
    8898: [0.25001, 0.75, 0, 0, 0.83334],
    8899: [0.25001, 0.75, 0, 0, 0.83334],
    8968: [0.35001, 0.85, 0, 0, 0.47222],
    8969: [0.35001, 0.85, 0, 0, 0.47222],
    8970: [0.35001, 0.85, 0, 0, 0.47222],
    8971: [0.35001, 0.85, 0, 0, 0.47222],
    9168: [-99e-5, 0.601, 0, 0, 0.66667],
    10216: [0.35001, 0.85, 0, 0, 0.47222],
    10217: [0.35001, 0.85, 0, 0, 0.47222],
    10752: [0.25001, 0.75, 0, 0, 1.11111],
    10753: [0.25001, 0.75, 0, 0, 1.11111],
    10754: [0.25001, 0.75, 0, 0, 1.11111],
    10756: [0.25001, 0.75, 0, 0, 0.83334],
    10758: [0.25001, 0.75, 0, 0, 0.83334]
  },
  "Size2-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.65002, 1.15, 0, 0, 0.59722],
    41: [0.65002, 1.15, 0, 0, 0.59722],
    47: [0.65002, 1.15, 0, 0, 0.81111],
    91: [0.65002, 1.15, 0, 0, 0.47222],
    92: [0.65002, 1.15, 0, 0, 0.81111],
    93: [0.65002, 1.15, 0, 0, 0.47222],
    123: [0.65002, 1.15, 0, 0, 0.66667],
    125: [0.65002, 1.15, 0, 0, 0.66667],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1],
    732: [0, 0.75, 0, 0, 1],
    770: [0, 0.75, 0, 0, 1],
    771: [0, 0.75, 0, 0, 1],
    8719: [0.55001, 1.05, 0, 0, 1.27778],
    8720: [0.55001, 1.05, 0, 0, 1.27778],
    8721: [0.55001, 1.05, 0, 0, 1.44445],
    8730: [0.65002, 1.15, 0, 0, 1],
    8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8748: [0.862, 1.36, 0.44445, 0, 0.55556],
    8749: [0.862, 1.36, 0.44445, 0, 0.55556],
    8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8896: [0.55001, 1.05, 0, 0, 1.11111],
    8897: [0.55001, 1.05, 0, 0, 1.11111],
    8898: [0.55001, 1.05, 0, 0, 1.11111],
    8899: [0.55001, 1.05, 0, 0, 1.11111],
    8968: [0.65002, 1.15, 0, 0, 0.52778],
    8969: [0.65002, 1.15, 0, 0, 0.52778],
    8970: [0.65002, 1.15, 0, 0, 0.52778],
    8971: [0.65002, 1.15, 0, 0, 0.52778],
    10216: [0.65002, 1.15, 0, 0, 0.61111],
    10217: [0.65002, 1.15, 0, 0, 0.61111],
    10752: [0.55001, 1.05, 0, 0, 1.51112],
    10753: [0.55001, 1.05, 0, 0, 1.51112],
    10754: [0.55001, 1.05, 0, 0, 1.51112],
    10756: [0.55001, 1.05, 0, 0, 1.11111],
    10758: [0.55001, 1.05, 0, 0, 1.11111]
  },
  "Size3-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.95003, 1.45, 0, 0, 0.73611],
    41: [0.95003, 1.45, 0, 0, 0.73611],
    47: [0.95003, 1.45, 0, 0, 1.04445],
    91: [0.95003, 1.45, 0, 0, 0.52778],
    92: [0.95003, 1.45, 0, 0, 1.04445],
    93: [0.95003, 1.45, 0, 0, 0.52778],
    123: [0.95003, 1.45, 0, 0, 0.75],
    125: [0.95003, 1.45, 0, 0, 0.75],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1.44445],
    732: [0, 0.75, 0, 0, 1.44445],
    770: [0, 0.75, 0, 0, 1.44445],
    771: [0, 0.75, 0, 0, 1.44445],
    8730: [0.95003, 1.45, 0, 0, 1],
    8968: [0.95003, 1.45, 0, 0, 0.58334],
    8969: [0.95003, 1.45, 0, 0, 0.58334],
    8970: [0.95003, 1.45, 0, 0, 0.58334],
    8971: [0.95003, 1.45, 0, 0, 0.58334],
    10216: [0.95003, 1.45, 0, 0, 0.75],
    10217: [0.95003, 1.45, 0, 0, 0.75]
  },
  "Size4-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [1.25003, 1.75, 0, 0, 0.79167],
    41: [1.25003, 1.75, 0, 0, 0.79167],
    47: [1.25003, 1.75, 0, 0, 1.27778],
    91: [1.25003, 1.75, 0, 0, 0.58334],
    92: [1.25003, 1.75, 0, 0, 1.27778],
    93: [1.25003, 1.75, 0, 0, 0.58334],
    123: [1.25003, 1.75, 0, 0, 0.80556],
    125: [1.25003, 1.75, 0, 0, 0.80556],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.825, 0, 0, 1.8889],
    732: [0, 0.825, 0, 0, 1.8889],
    770: [0, 0.825, 0, 0, 1.8889],
    771: [0, 0.825, 0, 0, 1.8889],
    8730: [1.25003, 1.75, 0, 0, 1],
    8968: [1.25003, 1.75, 0, 0, 0.63889],
    8969: [1.25003, 1.75, 0, 0, 0.63889],
    8970: [1.25003, 1.75, 0, 0, 0.63889],
    8971: [1.25003, 1.75, 0, 0, 0.63889],
    9115: [0.64502, 1.155, 0, 0, 0.875],
    9116: [1e-5, 0.6, 0, 0, 0.875],
    9117: [0.64502, 1.155, 0, 0, 0.875],
    9118: [0.64502, 1.155, 0, 0, 0.875],
    9119: [1e-5, 0.6, 0, 0, 0.875],
    9120: [0.64502, 1.155, 0, 0, 0.875],
    9121: [0.64502, 1.155, 0, 0, 0.66667],
    9122: [-99e-5, 0.601, 0, 0, 0.66667],
    9123: [0.64502, 1.155, 0, 0, 0.66667],
    9124: [0.64502, 1.155, 0, 0, 0.66667],
    9125: [-99e-5, 0.601, 0, 0, 0.66667],
    9126: [0.64502, 1.155, 0, 0, 0.66667],
    9127: [1e-5, 0.9, 0, 0, 0.88889],
    9128: [0.65002, 1.15, 0, 0, 0.88889],
    9129: [0.90001, 0, 0, 0, 0.88889],
    9130: [0, 0.3, 0, 0, 0.88889],
    9131: [1e-5, 0.9, 0, 0, 0.88889],
    9132: [0.65002, 1.15, 0, 0, 0.88889],
    9133: [0.90001, 0, 0, 0, 0.88889],
    9143: [0.88502, 0.915, 0, 0, 1.05556],
    10216: [1.25003, 1.75, 0, 0, 0.80556],
    10217: [1.25003, 1.75, 0, 0, 0.80556],
    57344: [-499e-5, 0.605, 0, 0, 1.05556],
    57345: [-499e-5, 0.605, 0, 0, 1.05556],
    57680: [0, 0.12, 0, 0, 0.45],
    57681: [0, 0.12, 0, 0, 0.45],
    57682: [0, 0.12, 0, 0, 0.45],
    57683: [0, 0.12, 0, 0, 0.45]
  },
  "Typewriter-Regular": {
    32: [0, 0, 0, 0, 0.525],
    33: [0, 0.61111, 0, 0, 0.525],
    34: [0, 0.61111, 0, 0, 0.525],
    35: [0, 0.61111, 0, 0, 0.525],
    36: [0.08333, 0.69444, 0, 0, 0.525],
    37: [0.08333, 0.69444, 0, 0, 0.525],
    38: [0, 0.61111, 0, 0, 0.525],
    39: [0, 0.61111, 0, 0, 0.525],
    40: [0.08333, 0.69444, 0, 0, 0.525],
    41: [0.08333, 0.69444, 0, 0, 0.525],
    42: [0, 0.52083, 0, 0, 0.525],
    43: [-0.08056, 0.53055, 0, 0, 0.525],
    44: [0.13889, 0.125, 0, 0, 0.525],
    45: [-0.08056, 0.53055, 0, 0, 0.525],
    46: [0, 0.125, 0, 0, 0.525],
    47: [0.08333, 0.69444, 0, 0, 0.525],
    48: [0, 0.61111, 0, 0, 0.525],
    49: [0, 0.61111, 0, 0, 0.525],
    50: [0, 0.61111, 0, 0, 0.525],
    51: [0, 0.61111, 0, 0, 0.525],
    52: [0, 0.61111, 0, 0, 0.525],
    53: [0, 0.61111, 0, 0, 0.525],
    54: [0, 0.61111, 0, 0, 0.525],
    55: [0, 0.61111, 0, 0, 0.525],
    56: [0, 0.61111, 0, 0, 0.525],
    57: [0, 0.61111, 0, 0, 0.525],
    58: [0, 0.43056, 0, 0, 0.525],
    59: [0.13889, 0.43056, 0, 0, 0.525],
    60: [-0.05556, 0.55556, 0, 0, 0.525],
    61: [-0.19549, 0.41562, 0, 0, 0.525],
    62: [-0.05556, 0.55556, 0, 0, 0.525],
    63: [0, 0.61111, 0, 0, 0.525],
    64: [0, 0.61111, 0, 0, 0.525],
    65: [0, 0.61111, 0, 0, 0.525],
    66: [0, 0.61111, 0, 0, 0.525],
    67: [0, 0.61111, 0, 0, 0.525],
    68: [0, 0.61111, 0, 0, 0.525],
    69: [0, 0.61111, 0, 0, 0.525],
    70: [0, 0.61111, 0, 0, 0.525],
    71: [0, 0.61111, 0, 0, 0.525],
    72: [0, 0.61111, 0, 0, 0.525],
    73: [0, 0.61111, 0, 0, 0.525],
    74: [0, 0.61111, 0, 0, 0.525],
    75: [0, 0.61111, 0, 0, 0.525],
    76: [0, 0.61111, 0, 0, 0.525],
    77: [0, 0.61111, 0, 0, 0.525],
    78: [0, 0.61111, 0, 0, 0.525],
    79: [0, 0.61111, 0, 0, 0.525],
    80: [0, 0.61111, 0, 0, 0.525],
    81: [0.13889, 0.61111, 0, 0, 0.525],
    82: [0, 0.61111, 0, 0, 0.525],
    83: [0, 0.61111, 0, 0, 0.525],
    84: [0, 0.61111, 0, 0, 0.525],
    85: [0, 0.61111, 0, 0, 0.525],
    86: [0, 0.61111, 0, 0, 0.525],
    87: [0, 0.61111, 0, 0, 0.525],
    88: [0, 0.61111, 0, 0, 0.525],
    89: [0, 0.61111, 0, 0, 0.525],
    90: [0, 0.61111, 0, 0, 0.525],
    91: [0.08333, 0.69444, 0, 0, 0.525],
    92: [0.08333, 0.69444, 0, 0, 0.525],
    93: [0.08333, 0.69444, 0, 0, 0.525],
    94: [0, 0.61111, 0, 0, 0.525],
    95: [0.09514, 0, 0, 0, 0.525],
    96: [0, 0.61111, 0, 0, 0.525],
    97: [0, 0.43056, 0, 0, 0.525],
    98: [0, 0.61111, 0, 0, 0.525],
    99: [0, 0.43056, 0, 0, 0.525],
    100: [0, 0.61111, 0, 0, 0.525],
    101: [0, 0.43056, 0, 0, 0.525],
    102: [0, 0.61111, 0, 0, 0.525],
    103: [0.22222, 0.43056, 0, 0, 0.525],
    104: [0, 0.61111, 0, 0, 0.525],
    105: [0, 0.61111, 0, 0, 0.525],
    106: [0.22222, 0.61111, 0, 0, 0.525],
    107: [0, 0.61111, 0, 0, 0.525],
    108: [0, 0.61111, 0, 0, 0.525],
    109: [0, 0.43056, 0, 0, 0.525],
    110: [0, 0.43056, 0, 0, 0.525],
    111: [0, 0.43056, 0, 0, 0.525],
    112: [0.22222, 0.43056, 0, 0, 0.525],
    113: [0.22222, 0.43056, 0, 0, 0.525],
    114: [0, 0.43056, 0, 0, 0.525],
    115: [0, 0.43056, 0, 0, 0.525],
    116: [0, 0.55358, 0, 0, 0.525],
    117: [0, 0.43056, 0, 0, 0.525],
    118: [0, 0.43056, 0, 0, 0.525],
    119: [0, 0.43056, 0, 0, 0.525],
    120: [0, 0.43056, 0, 0, 0.525],
    121: [0.22222, 0.43056, 0, 0, 0.525],
    122: [0, 0.43056, 0, 0, 0.525],
    123: [0.08333, 0.69444, 0, 0, 0.525],
    124: [0.08333, 0.69444, 0, 0, 0.525],
    125: [0.08333, 0.69444, 0, 0, 0.525],
    126: [0, 0.61111, 0, 0, 0.525],
    127: [0, 0.61111, 0, 0, 0.525],
    160: [0, 0, 0, 0, 0.525],
    176: [0, 0.61111, 0, 0, 0.525],
    184: [0.19445, 0, 0, 0, 0.525],
    305: [0, 0.43056, 0, 0, 0.525],
    567: [0.22222, 0.43056, 0, 0, 0.525],
    711: [0, 0.56597, 0, 0, 0.525],
    713: [0, 0.56555, 0, 0, 0.525],
    714: [0, 0.61111, 0, 0, 0.525],
    715: [0, 0.61111, 0, 0, 0.525],
    728: [0, 0.61111, 0, 0, 0.525],
    730: [0, 0.61111, 0, 0, 0.525],
    770: [0, 0.61111, 0, 0, 0.525],
    771: [0, 0.61111, 0, 0, 0.525],
    776: [0, 0.61111, 0, 0, 0.525],
    915: [0, 0.61111, 0, 0, 0.525],
    916: [0, 0.61111, 0, 0, 0.525],
    920: [0, 0.61111, 0, 0, 0.525],
    923: [0, 0.61111, 0, 0, 0.525],
    926: [0, 0.61111, 0, 0, 0.525],
    928: [0, 0.61111, 0, 0, 0.525],
    931: [0, 0.61111, 0, 0, 0.525],
    933: [0, 0.61111, 0, 0, 0.525],
    934: [0, 0.61111, 0, 0, 0.525],
    936: [0, 0.61111, 0, 0, 0.525],
    937: [0, 0.61111, 0, 0, 0.525],
    8216: [0, 0.61111, 0, 0, 0.525],
    8217: [0, 0.61111, 0, 0, 0.525],
    8242: [0, 0.61111, 0, 0, 0.525],
    9251: [0.11111, 0.21944, 0, 0, 0.525]
  }
}, xa = {
  // Latin-1
  Å: "A",
  Ð: "D",
  Þ: "o",
  å: "a",
  ð: "d",
  þ: "o",
  // Cyrillic
  А: "A",
  Б: "B",
  В: "B",
  Г: "F",
  Д: "A",
  Е: "E",
  Ж: "K",
  З: "3",
  И: "N",
  Й: "N",
  К: "K",
  Л: "N",
  М: "M",
  Н: "H",
  О: "O",
  П: "N",
  Р: "P",
  С: "C",
  Т: "T",
  У: "y",
  Ф: "O",
  Х: "X",
  Ц: "U",
  Ч: "h",
  Ш: "W",
  Щ: "W",
  Ъ: "B",
  Ы: "X",
  Ь: "B",
  Э: "3",
  Ю: "X",
  Я: "R",
  а: "a",
  б: "b",
  в: "a",
  г: "r",
  д: "y",
  е: "e",
  ж: "m",
  з: "e",
  и: "n",
  й: "n",
  к: "n",
  л: "n",
  м: "m",
  н: "n",
  о: "o",
  п: "n",
  р: "p",
  с: "c",
  т: "o",
  у: "y",
  ф: "b",
  х: "x",
  ц: "n",
  ч: "n",
  ш: "w",
  щ: "w",
  ъ: "a",
  ы: "m",
  ь: "a",
  э: "e",
  ю: "m",
  я: "r"
};
function sr(r, e, t) {
  if (!ve[e])
    throw new Error("Font metrics not found for font: " + e + ".");
  var x = r.charCodeAt(0), a = ve[e][x];
  if (!a && r[0] in xa && (x = xa[r[0]].charCodeAt(0), a = ve[e][x]), !a && t === "text" && i9(x) && (a = ve[e][77]), a)
    return {
      depth: a[0],
      height: a[1],
      italic: a[2],
      skew: a[3],
      width: a[4]
    };
}
var Zx = {
  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
  // https://tex.stackexchange.com/a/8263
  pt: 1,
  // TeX point
  mm: 7227 / 2540,
  // millimeter
  cm: 7227 / 254,
  // centimeter
  in: 72.27,
  // inch
  bp: 803 / 800,
  // big (PostScript) points
  pc: 12,
  // pica
  dd: 1238 / 1157,
  // didot
  cc: 14856 / 1157,
  // cicero (12 didot)
  nd: 685 / 642,
  // new didot
  nc: 1370 / 107,
  // new cicero (12 new didot)
  sp: 1 / 65536,
  // scaled point (TeX's internal smallest unit)
  // https://tex.stackexchange.com/a/41371
  px: 803 / 800
  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
}, A9 = {
  ex: !0,
  em: !0,
  mu: !0
}, D9 = function(e) {
  return typeof e != "string" && (e = e.unit), e in Zx || e in A9 || e === "ex";
}, p0 = function(e, t) {
  var x;
  if (e.unit in Zx)
    x = Zx[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
  else if (e.unit === "mu")
    x = t.fontMetrics().cssEmPerMu;
  else {
    var a;
    if (t.style.isTight() ? a = t.havingStyle(t.style.text()) : a = t, e.unit === "ex")
      x = a.fontMetrics().xHeight;
    else if (e.unit === "em")
      x = a.fontMetrics().quad;
    else
      throw new J("Invalid unit: '" + e.unit + "'");
    a !== t && (x *= a.sizeMultiplier / t.sizeMultiplier);
  }
  return Math.min(e.number * x, t.maxSize);
}, U = function(e) {
  return +e.toFixed(4) + "em";
}, _e = function(e) {
  return e.filter((t) => t).join(" ");
}, cn = function(e, t, x) {
  if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = x || {}, t) {
    t.style.isTight() && this.classes.push("mtight");
    var a = t.getColor();
    a && (this.style.color = a);
  }
}, En = function(e) {
  var t = document.createElement(e);
  t.className = _e(this.classes);
  for (var x in this.style)
    this.style.hasOwnProperty(x) && (t.style[x] = this.style[x]);
  for (var a in this.attributes)
    this.attributes.hasOwnProperty(a) && t.setAttribute(a, this.attributes[a]);
  for (var n = 0; n < this.children.length; n++)
    t.appendChild(this.children[n].toNode());
  return t;
}, dn = function(e) {
  var t = "<" + e;
  this.classes.length && (t += ' class="' + t0.escape(_e(this.classes)) + '"');
  var x = "";
  for (var a in this.style)
    this.style.hasOwnProperty(a) && (x += t0.hyphenate(a) + ":" + this.style[a] + ";");
  x && (t += ' style="' + t0.escape(x) + '"');
  for (var n in this.attributes)
    this.attributes.hasOwnProperty(n) && (t += " " + n + '="' + t0.escape(this.attributes[n]) + '"');
  t += ">";
  for (var o = 0; o < this.children.length; o++)
    t += this.children[o].toMarkup();
  return t += "</" + e + ">", t;
};
class tx {
  constructor(e, t, x, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, cn.call(this, e, x, a), this.children = t || [];
  }
  /**
   * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
   * all browsers support attributes the same, and having too many custom
   * attributes is probably bad.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return t0.contains(this.classes, e);
  }
  toNode() {
    return En.call(this, "span");
  }
  toMarkup() {
    return dn.call(this, "span");
  }
}
class mn {
  constructor(e, t, x, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, cn.call(this, t, a), this.children = x || [], this.setAttribute("href", e);
  }
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return t0.contains(this.classes, e);
  }
  toNode() {
    return En.call(this, "a");
  }
  toMarkup() {
    return dn.call(this, "a");
  }
}
class F9 {
  constructor(e, t, x) {
    this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.style = x;
  }
  hasClass(e) {
    return t0.contains(this.classes, e);
  }
  toNode() {
    var e = document.createElement("img");
    e.src = this.src, e.alt = this.alt, e.className = "mord";
    for (var t in this.style)
      this.style.hasOwnProperty(t) && (e.style[t] = this.style[t]);
    return e;
  }
  toMarkup() {
    var e = '<img src="' + t0.escape(this.src) + '"' + (' alt="' + t0.escape(this.alt) + '"'), t = "";
    for (var x in this.style)
      this.style.hasOwnProperty(x) && (t += t0.hyphenate(x) + ":" + this.style[x] + ";");
    return t && (e += ' style="' + t0.escape(t) + '"'), e += "'/>", e;
  }
}
var p9 = {
  î: "ı̂",
  ï: "ı̈",
  í: "ı́",
  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
  ì: "ı̀"
};
class Be {
  constructor(e, t, x, a, n, o, s, i) {
    this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = x || 0, this.italic = a || 0, this.skew = n || 0, this.width = o || 0, this.classes = s || [], this.style = i || {}, this.maxFontSize = 0;
    var m = l9(this.text.charCodeAt(0));
    m && this.classes.push(m + "_fallback"), /[îïíì]/.test(this.text) && (this.text = p9[this.text]);
  }
  hasClass(e) {
    return t0.contains(this.classes, e);
  }
  /**
   * Creates a text node or span from a symbol node. Note that a span is only
   * created if it is needed.
   */
  toNode() {
    var e = document.createTextNode(this.text), t = null;
    this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = U(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = _e(this.classes));
    for (var x in this.style)
      this.style.hasOwnProperty(x) && (t = t || document.createElement("span"), t.style[x] = this.style[x]);
    return t ? (t.appendChild(e), t) : e;
  }
  /**
   * Creates markup for a symbol node.
   */
  toMarkup() {
    var e = !1, t = "<span";
    this.classes.length && (e = !0, t += ' class="', t += t0.escape(_e(this.classes)), t += '"');
    var x = "";
    this.italic > 0 && (x += "margin-right:" + this.italic + "em;");
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (x += t0.hyphenate(a) + ":" + this.style[a] + ";");
    x && (e = !0, t += ' style="' + t0.escape(x) + '"');
    var n = t0.escape(this.text);
    return e ? (t += ">", t += n, t += "</span>", t) : n;
  }
}
class ze {
  constructor(e, t) {
    this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg");
    for (var x in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, x) && t.setAttribute(x, this.attributes[x]);
    for (var a = 0; a < this.children.length; a++)
      t.appendChild(this.children[a].toNode());
    return t;
  }
  toMarkup() {
    var e = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + t0.escape(this.attributes[t]) + '"');
    e += ">";
    for (var x = 0; x < this.children.length; x++)
      e += this.children[x].toMarkup();
    return e += "</svg>", e;
  }
}
class qe {
  constructor(e, t) {
    this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path");
    return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", ta[this.pathName]), t;
  }
  toMarkup() {
    return this.alternate ? '<path d="' + t0.escape(this.alternate) + '"/>' : '<path d="' + t0.escape(ta[this.pathName]) + '"/>';
  }
}
class ra {
  constructor(e) {
    this.attributes = void 0, this.attributes = e || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line");
    for (var x in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, x) && t.setAttribute(x, this.attributes[x]);
    return t;
  }
  toMarkup() {
    var e = "<line";
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + t0.escape(this.attributes[t]) + '"');
    return e += "/>", e;
  }
}
function aa(r) {
  if (r instanceof Be)
    return r;
  throw new Error("Expected symbolNode but got " + String(r) + ".");
}
function g9(r) {
  if (r instanceof tx)
    return r;
  throw new Error("Expected span<HtmlDomNode> but got " + String(r) + ".");
}
var v9 = {
  "accent-token": 1,
  mathord: 1,
  "op-token": 1,
  spacing: 1,
  textord: 1
}, k0 = {
  math: {},
  text: {}
};
function l(r, e, t, x, a, n) {
  k0[r][a] = {
    font: e,
    group: t,
    replace: x
  }, n && x && (k0[r][x] = k0[r][a]);
}
var u = "math", L = "text", c = "main", g = "ams", D0 = "accent-token", X = "bin", $0 = "close", Je = "inner", e0 = "mathord", S0 = "op-token", te = "open", xx = "punct", v = "rel", ye = "spacing", S = "textord";
l(u, c, v, "≡", "\\equiv", !0);
l(u, c, v, "≺", "\\prec", !0);
l(u, c, v, "≻", "\\succ", !0);
l(u, c, v, "∼", "\\sim", !0);
l(u, c, v, "⊥", "\\perp");
l(u, c, v, "⪯", "\\preceq", !0);
l(u, c, v, "⪰", "\\succeq", !0);
l(u, c, v, "≃", "\\simeq", !0);
l(u, c, v, "∣", "\\mid", !0);
l(u, c, v, "≪", "\\ll", !0);
l(u, c, v, "≫", "\\gg", !0);
l(u, c, v, "≍", "\\asymp", !0);
l(u, c, v, "∥", "\\parallel");
l(u, c, v, "⋈", "\\bowtie", !0);
l(u, c, v, "⌣", "\\smile", !0);
l(u, c, v, "⊑", "\\sqsubseteq", !0);
l(u, c, v, "⊒", "\\sqsupseteq", !0);
l(u, c, v, "≐", "\\doteq", !0);
l(u, c, v, "⌢", "\\frown", !0);
l(u, c, v, "∋", "\\ni", !0);
l(u, c, v, "∝", "\\propto", !0);
l(u, c, v, "⊢", "\\vdash", !0);
l(u, c, v, "⊣", "\\dashv", !0);
l(u, c, v, "∋", "\\owns");
l(u, c, xx, ".", "\\ldotp");
l(u, c, xx, "⋅", "\\cdotp");
l(u, c, S, "#", "\\#");
l(L, c, S, "#", "\\#");
l(u, c, S, "&", "\\&");
l(L, c, S, "&", "\\&");
l(u, c, S, "ℵ", "\\aleph", !0);
l(u, c, S, "∀", "\\forall", !0);
l(u, c, S, "ℏ", "\\hbar", !0);
l(u, c, S, "∃", "\\exists", !0);
l(u, c, S, "∇", "\\nabla", !0);
l(u, c, S, "♭", "\\flat", !0);
l(u, c, S, "ℓ", "\\ell", !0);
l(u, c, S, "♮", "\\natural", !0);
l(u, c, S, "♣", "\\clubsuit", !0);
l(u, c, S, "℘", "\\wp", !0);
l(u, c, S, "♯", "\\sharp", !0);
l(u, c, S, "♢", "\\diamondsuit", !0);
l(u, c, S, "ℜ", "\\Re", !0);
l(u, c, S, "♡", "\\heartsuit", !0);
l(u, c, S, "ℑ", "\\Im", !0);
l(u, c, S, "♠", "\\spadesuit", !0);
l(u, c, S, "§", "\\S", !0);
l(L, c, S, "§", "\\S");
l(u, c, S, "¶", "\\P", !0);
l(L, c, S, "¶", "\\P");
l(u, c, S, "†", "\\dag");
l(L, c, S, "†", "\\dag");
l(L, c, S, "†", "\\textdagger");
l(u, c, S, "‡", "\\ddag");
l(L, c, S, "‡", "\\ddag");
l(L, c, S, "‡", "\\textdaggerdbl");
l(u, c, $0, "⎱", "\\rmoustache", !0);
l(u, c, te, "⎰", "\\lmoustache", !0);
l(u, c, $0, "⟯", "\\rgroup", !0);
l(u, c, te, "⟮", "\\lgroup", !0);
l(u, c, X, "∓", "\\mp", !0);
l(u, c, X, "⊖", "\\ominus", !0);
l(u, c, X, "⊎", "\\uplus", !0);
l(u, c, X, "⊓", "\\sqcap", !0);
l(u, c, X, "∗", "\\ast");
l(u, c, X, "⊔", "\\sqcup", !0);
l(u, c, X, "◯", "\\bigcirc", !0);
l(u, c, X, "∙", "\\bullet", !0);
l(u, c, X, "‡", "\\ddagger");
l(u, c, X, "≀", "\\wr", !0);
l(u, c, X, "⨿", "\\amalg");
l(u, c, X, "&", "\\And");
l(u, c, v, "⟵", "\\longleftarrow", !0);
l(u, c, v, "⇐", "\\Leftarrow", !0);
l(u, c, v, "⟸", "\\Longleftarrow", !0);
l(u, c, v, "⟶", "\\longrightarrow", !0);
l(u, c, v, "⇒", "\\Rightarrow", !0);
l(u, c, v, "⟹", "\\Longrightarrow", !0);
l(u, c, v, "↔", "\\leftrightarrow", !0);
l(u, c, v, "⟷", "\\longleftrightarrow", !0);
l(u, c, v, "⇔", "\\Leftrightarrow", !0);
l(u, c, v, "⟺", "\\Longleftrightarrow", !0);
l(u, c, v, "↦", "\\mapsto", !0);
l(u, c, v, "⟼", "\\longmapsto", !0);
l(u, c, v, "↗", "\\nearrow", !0);
l(u, c, v, "↩", "\\hookleftarrow", !0);
l(u, c, v, "↪", "\\hookrightarrow", !0);
l(u, c, v, "↘", "\\searrow", !0);
l(u, c, v, "↼", "\\leftharpoonup", !0);
l(u, c, v, "⇀", "\\rightharpoonup", !0);
l(u, c, v, "↙", "\\swarrow", !0);
l(u, c, v, "↽", "\\leftharpoondown", !0);
l(u, c, v, "⇁", "\\rightharpoondown", !0);
l(u, c, v, "↖", "\\nwarrow", !0);
l(u, c, v, "⇌", "\\rightleftharpoons", !0);
l(u, g, v, "≮", "\\nless", !0);
l(u, g, v, "", "\\@nleqslant");
l(u, g, v, "", "\\@nleqq");
l(u, g, v, "⪇", "\\lneq", !0);
l(u, g, v, "≨", "\\lneqq", !0);
l(u, g, v, "", "\\@lvertneqq");
l(u, g, v, "⋦", "\\lnsim", !0);
l(u, g, v, "⪉", "\\lnapprox", !0);
l(u, g, v, "⊀", "\\nprec", !0);
l(u, g, v, "⋠", "\\npreceq", !0);
l(u, g, v, "⋨", "\\precnsim", !0);
l(u, g, v, "⪹", "\\precnapprox", !0);
l(u, g, v, "≁", "\\nsim", !0);
l(u, g, v, "", "\\@nshortmid");
l(u, g, v, "∤", "\\nmid", !0);
l(u, g, v, "⊬", "\\nvdash", !0);
l(u, g, v, "⊭", "\\nvDash", !0);
l(u, g, v, "⋪", "\\ntriangleleft");
l(u, g, v, "⋬", "\\ntrianglelefteq", !0);
l(u, g, v, "⊊", "\\subsetneq", !0);
l(u, g, v, "", "\\@varsubsetneq");
l(u, g, v, "⫋", "\\subsetneqq", !0);
l(u, g, v, "", "\\@varsubsetneqq");
l(u, g, v, "≯", "\\ngtr", !0);
l(u, g, v, "", "\\@ngeqslant");
l(u, g, v, "", "\\@ngeqq");
l(u, g, v, "⪈", "\\gneq", !0);
l(u, g, v, "≩", "\\gneqq", !0);
l(u, g, v, "", "\\@gvertneqq");
l(u, g, v, "⋧", "\\gnsim", !0);
l(u, g, v, "⪊", "\\gnapprox", !0);
l(u, g, v, "⊁", "\\nsucc", !0);
l(u, g, v, "⋡", "\\nsucceq", !0);
l(u, g, v, "⋩", "\\succnsim", !0);
l(u, g, v, "⪺", "\\succnapprox", !0);
l(u, g, v, "≆", "\\ncong", !0);
l(u, g, v, "", "\\@nshortparallel");
l(u, g, v, "∦", "\\nparallel", !0);
l(u, g, v, "⊯", "\\nVDash", !0);
l(u, g, v, "⋫", "\\ntriangleright");
l(u, g, v, "⋭", "\\ntrianglerighteq", !0);
l(u, g, v, "", "\\@nsupseteqq");
l(u, g, v, "⊋", "\\supsetneq", !0);
l(u, g, v, "", "\\@varsupsetneq");
l(u, g, v, "⫌", "\\supsetneqq", !0);
l(u, g, v, "", "\\@varsupsetneqq");
l(u, g, v, "⊮", "\\nVdash", !0);
l(u, g, v, "⪵", "\\precneqq", !0);
l(u, g, v, "⪶", "\\succneqq", !0);
l(u, g, v, "", "\\@nsubseteqq");
l(u, g, X, "⊴", "\\unlhd");
l(u, g, X, "⊵", "\\unrhd");
l(u, g, v, "↚", "\\nleftarrow", !0);
l(u, g, v, "↛", "\\nrightarrow", !0);
l(u, g, v, "⇍", "\\nLeftarrow", !0);
l(u, g, v, "⇏", "\\nRightarrow", !0);
l(u, g, v, "↮", "\\nleftrightarrow", !0);
l(u, g, v, "⇎", "\\nLeftrightarrow", !0);
l(u, g, v, "△", "\\vartriangle");
l(u, g, S, "ℏ", "\\hslash");
l(u, g, S, "▽", "\\triangledown");
l(u, g, S, "◊", "\\lozenge");
l(u, g, S, "Ⓢ", "\\circledS");
l(u, g, S, "®", "\\circledR");
l(L, g, S, "®", "\\circledR");
l(u, g, S, "∡", "\\measuredangle", !0);
l(u, g, S, "∄", "\\nexists");
l(u, g, S, "℧", "\\mho");
l(u, g, S, "Ⅎ", "\\Finv", !0);
l(u, g, S, "⅁", "\\Game", !0);
l(u, g, S, "‵", "\\backprime");
l(u, g, S, "▲", "\\blacktriangle");
l(u, g, S, "▼", "\\blacktriangledown");
l(u, g, S, "■", "\\blacksquare");
l(u, g, S, "⧫", "\\blacklozenge");
l(u, g, S, "★", "\\bigstar");
l(u, g, S, "∢", "\\sphericalangle", !0);
l(u, g, S, "∁", "\\complement", !0);
l(u, g, S, "ð", "\\eth", !0);
l(L, c, S, "ð", "ð");
l(u, g, S, "╱", "\\diagup");
l(u, g, S, "╲", "\\diagdown");
l(u, g, S, "□", "\\square");
l(u, g, S, "□", "\\Box");
l(u, g, S, "◊", "\\Diamond");
l(u, g, S, "¥", "\\yen", !0);
l(L, g, S, "¥", "\\yen", !0);
l(u, g, S, "✓", "\\checkmark", !0);
l(L, g, S, "✓", "\\checkmark");
l(u, g, S, "ℶ", "\\beth", !0);
l(u, g, S, "ℸ", "\\daleth", !0);
l(u, g, S, "ℷ", "\\gimel", !0);
l(u, g, S, "ϝ", "\\digamma", !0);
l(u, g, S, "ϰ", "\\varkappa");
l(u, g, te, "┌", "\\@ulcorner", !0);
l(u, g, $0, "┐", "\\@urcorner", !0);
l(u, g, te, "└", "\\@llcorner", !0);
l(u, g, $0, "┘", "\\@lrcorner", !0);
l(u, g, v, "≦", "\\leqq", !0);
l(u, g, v, "⩽", "\\leqslant", !0);
l(u, g, v, "⪕", "\\eqslantless", !0);
l(u, g, v, "≲", "\\lesssim", !0);
l(u, g, v, "⪅", "\\lessapprox", !0);
l(u, g, v, "≊", "\\approxeq", !0);
l(u, g, X, "⋖", "\\lessdot");
l(u, g, v, "⋘", "\\lll", !0);
l(u, g, v, "≶", "\\lessgtr", !0);
l(u, g, v, "⋚", "\\lesseqgtr", !0);
l(u, g, v, "⪋", "\\lesseqqgtr", !0);
l(u, g, v, "≑", "\\doteqdot");
l(u, g, v, "≓", "\\risingdotseq", !0);
l(u, g, v, "≒", "\\fallingdotseq", !0);
l(u, g, v, "∽", "\\backsim", !0);
l(u, g, v, "⋍", "\\backsimeq", !0);
l(u, g, v, "⫅", "\\subseteqq", !0);
l(u, g, v, "⋐", "\\Subset", !0);
l(u, g, v, "⊏", "\\sqsubset", !0);
l(u, g, v, "≼", "\\preccurlyeq", !0);
l(u, g, v, "⋞", "\\curlyeqprec", !0);
l(u, g, v, "≾", "\\precsim", !0);
l(u, g, v, "⪷", "\\precapprox", !0);
l(u, g, v, "⊲", "\\vartriangleleft");
l(u, g, v, "⊴", "\\trianglelefteq");
l(u, g, v, "⊨", "\\vDash", !0);
l(u, g, v, "⊪", "\\Vvdash", !0);
l(u, g, v, "⌣", "\\smallsmile");
l(u, g, v, "⌢", "\\smallfrown");
l(u, g, v, "≏", "\\bumpeq", !0);
l(u, g, v, "≎", "\\Bumpeq", !0);
l(u, g, v, "≧", "\\geqq", !0);
l(u, g, v, "⩾", "\\geqslant", !0);
l(u, g, v, "⪖", "\\eqslantgtr", !0);
l(u, g, v, "≳", "\\gtrsim", !0);
l(u, g, v, "⪆", "\\gtrapprox", !0);
l(u, g, X, "⋗", "\\gtrdot");
l(u, g, v, "⋙", "\\ggg", !0);
l(u, g, v, "≷", "\\gtrless", !0);
l(u, g, v, "⋛", "\\gtreqless", !0);
l(u, g, v, "⪌", "\\gtreqqless", !0);
l(u, g, v, "≖", "\\eqcirc", !0);
l(u, g, v, "≗", "\\circeq", !0);
l(u, g, v, "≜", "\\triangleq", !0);
l(u, g, v, "∼", "\\thicksim");
l(u, g, v, "≈", "\\thickapprox");
l(u, g, v, "⫆", "\\supseteqq", !0);
l(u, g, v, "⋑", "\\Supset", !0);
l(u, g, v, "⊐", "\\sqsupset", !0);
l(u, g, v, "≽", "\\succcurlyeq", !0);
l(u, g, v, "⋟", "\\curlyeqsucc", !0);
l(u, g, v, "≿", "\\succsim", !0);
l(u, g, v, "⪸", "\\succapprox", !0);
l(u, g, v, "⊳", "\\vartriangleright");
l(u, g, v, "⊵", "\\trianglerighteq");
l(u, g, v, "⊩", "\\Vdash", !0);
l(u, g, v, "∣", "\\shortmid");
l(u, g, v, "∥", "\\shortparallel");
l(u, g, v, "≬", "\\between", !0);
l(u, g, v, "⋔", "\\pitchfork", !0);
l(u, g, v, "∝", "\\varpropto");
l(u, g, v, "◀", "\\blacktriangleleft");
l(u, g, v, "∴", "\\therefore", !0);
l(u, g, v, "∍", "\\backepsilon");
l(u, g, v, "▶", "\\blacktriangleright");
l(u, g, v, "∵", "\\because", !0);
l(u, g, v, "⋘", "\\llless");
l(u, g, v, "⋙", "\\gggtr");
l(u, g, X, "⊲", "\\lhd");
l(u, g, X, "⊳", "\\rhd");
l(u, g, v, "≂", "\\eqsim", !0);
l(u, c, v, "⋈", "\\Join");
l(u, g, v, "≑", "\\Doteq", !0);
l(u, g, X, "∔", "\\dotplus", !0);
l(u, g, X, "∖", "\\smallsetminus");
l(u, g, X, "⋒", "\\Cap", !0);
l(u, g, X, "⋓", "\\Cup", !0);
l(u, g, X, "⩞", "\\doublebarwedge", !0);
l(u, g, X, "⊟", "\\boxminus", !0);
l(u, g, X, "⊞", "\\boxplus", !0);
l(u, g, X, "⋇", "\\divideontimes", !0);
l(u, g, X, "⋉", "\\ltimes", !0);
l(u, g, X, "⋊", "\\rtimes", !0);
l(u, g, X, "⋋", "\\leftthreetimes", !0);
l(u, g, X, "⋌", "\\rightthreetimes", !0);
l(u, g, X, "⋏", "\\curlywedge", !0);
l(u, g, X, "⋎", "\\curlyvee", !0);
l(u, g, X, "⊝", "\\circleddash", !0);
l(u, g, X, "⊛", "\\circledast", !0);
l(u, g, X, "⋅", "\\centerdot");
l(u, g, X, "⊺", "\\intercal", !0);
l(u, g, X, "⋒", "\\doublecap");
l(u, g, X, "⋓", "\\doublecup");
l(u, g, X, "⊠", "\\boxtimes", !0);
l(u, g, v, "⇢", "\\dashrightarrow", !0);
l(u, g, v, "⇠", "\\dashleftarrow", !0);
l(u, g, v, "⇇", "\\leftleftarrows", !0);
l(u, g, v, "⇆", "\\leftrightarrows", !0);
l(u, g, v, "⇚", "\\Lleftarrow", !0);
l(u, g, v, "↞", "\\twoheadleftarrow", !0);
l(u, g, v, "↢", "\\leftarrowtail", !0);
l(u, g, v, "↫", "\\looparrowleft", !0);
l(u, g, v, "⇋", "\\leftrightharpoons", !0);
l(u, g, v, "↶", "\\curvearrowleft", !0);
l(u, g, v, "↺", "\\circlearrowleft", !0);
l(u, g, v, "↰", "\\Lsh", !0);
l(u, g, v, "⇈", "\\upuparrows", !0);
l(u, g, v, "↿", "\\upharpoonleft", !0);
l(u, g, v, "⇃", "\\downharpoonleft", !0);
l(u, c, v, "⊶", "\\origof", !0);
l(u, c, v, "⊷", "\\imageof", !0);
l(u, g, v, "⊸", "\\multimap", !0);
l(u, g, v, "↭", "\\leftrightsquigarrow", !0);
l(u, g, v, "⇉", "\\rightrightarrows", !0);
l(u, g, v, "⇄", "\\rightleftarrows", !0);
l(u, g, v, "↠", "\\twoheadrightarrow", !0);
l(u, g, v, "↣", "\\rightarrowtail", !0);
l(u, g, v, "↬", "\\looparrowright", !0);
l(u, g, v, "↷", "\\curvearrowright", !0);
l(u, g, v, "↻", "\\circlearrowright", !0);
l(u, g, v, "↱", "\\Rsh", !0);
l(u, g, v, "⇊", "\\downdownarrows", !0);
l(u, g, v, "↾", "\\upharpoonright", !0);
l(u, g, v, "⇂", "\\downharpoonright", !0);
l(u, g, v, "⇝", "\\rightsquigarrow", !0);
l(u, g, v, "⇝", "\\leadsto");
l(u, g, v, "⇛", "\\Rrightarrow", !0);
l(u, g, v, "↾", "\\restriction");
l(u, c, S, "‘", "`");
l(u, c, S, "$", "\\$");
l(L, c, S, "$", "\\$");
l(L, c, S, "$", "\\textdollar");
l(u, c, S, "%", "\\%");
l(L, c, S, "%", "\\%");
l(u, c, S, "_", "\\_");
l(L, c, S, "_", "\\_");
l(L, c, S, "_", "\\textunderscore");
l(u, c, S, "∠", "\\angle", !0);
l(u, c, S, "∞", "\\infty", !0);
l(u, c, S, "′", "\\prime");
l(u, c, S, "△", "\\triangle");
l(u, c, S, "Γ", "\\Gamma", !0);
l(u, c, S, "Δ", "\\Delta", !0);
l(u, c, S, "Θ", "\\Theta", !0);
l(u, c, S, "Λ", "\\Lambda", !0);
l(u, c, S, "Ξ", "\\Xi", !0);
l(u, c, S, "Π", "\\Pi", !0);
l(u, c, S, "Σ", "\\Sigma", !0);
l(u, c, S, "Υ", "\\Upsilon", !0);
l(u, c, S, "Φ", "\\Phi", !0);
l(u, c, S, "Ψ", "\\Psi", !0);
l(u, c, S, "Ω", "\\Omega", !0);
l(u, c, S, "A", "Α");
l(u, c, S, "B", "Β");
l(u, c, S, "E", "Ε");
l(u, c, S, "Z", "Ζ");
l(u, c, S, "H", "Η");
l(u, c, S, "I", "Ι");
l(u, c, S, "K", "Κ");
l(u, c, S, "M", "Μ");
l(u, c, S, "N", "Ν");
l(u, c, S, "O", "Ο");
l(u, c, S, "P", "Ρ");
l(u, c, S, "T", "Τ");
l(u, c, S, "X", "Χ");
l(u, c, S, "¬", "\\neg", !0);
l(u, c, S, "¬", "\\lnot");
l(u, c, S, "⊤", "\\top");
l(u, c, S, "⊥", "\\bot");
l(u, c, S, "∅", "\\emptyset");
l(u, g, S, "∅", "\\varnothing");
l(u, c, e0, "α", "\\alpha", !0);
l(u, c, e0, "β", "\\beta", !0);
l(u, c, e0, "γ", "\\gamma", !0);
l(u, c, e0, "δ", "\\delta", !0);
l(u, c, e0, "ϵ", "\\epsilon", !0);
l(u, c, e0, "ζ", "\\zeta", !0);
l(u, c, e0, "η", "\\eta", !0);
l(u, c, e0, "θ", "\\theta", !0);
l(u, c, e0, "ι", "\\iota", !0);
l(u, c, e0, "κ", "\\kappa", !0);
l(u, c, e0, "λ", "\\lambda", !0);
l(u, c, e0, "μ", "\\mu", !0);
l(u, c, e0, "ν", "\\nu", !0);
l(u, c, e0, "ξ", "\\xi", !0);
l(u, c, e0, "ο", "\\omicron", !0);
l(u, c, e0, "π", "\\pi", !0);
l(u, c, e0, "ρ", "\\rho", !0);
l(u, c, e0, "σ", "\\sigma", !0);
l(u, c, e0, "τ", "\\tau", !0);
l(u, c, e0, "υ", "\\upsilon", !0);
l(u, c, e0, "ϕ", "\\phi", !0);
l(u, c, e0, "χ", "\\chi", !0);
l(u, c, e0, "ψ", "\\psi", !0);
l(u, c, e0, "ω", "\\omega", !0);
l(u, c, e0, "ε", "\\varepsilon", !0);
l(u, c, e0, "ϑ", "\\vartheta", !0);
l(u, c, e0, "ϖ", "\\varpi", !0);
l(u, c, e0, "ϱ", "\\varrho", !0);
l(u, c, e0, "ς", "\\varsigma", !0);
l(u, c, e0, "φ", "\\varphi", !0);
l(u, c, X, "∗", "*", !0);
l(u, c, X, "+", "+");
l(u, c, X, "−", "-", !0);
l(u, c, X, "⋅", "\\cdot", !0);
l(u, c, X, "∘", "\\circ", !0);
l(u, c, X, "÷", "\\div", !0);
l(u, c, X, "±", "\\pm", !0);
l(u, c, X, "×", "\\times", !0);
l(u, c, X, "∩", "\\cap", !0);
l(u, c, X, "∪", "\\cup", !0);
l(u, c, X, "∖", "\\setminus", !0);
l(u, c, X, "∧", "\\land");
l(u, c, X, "∨", "\\lor");
l(u, c, X, "∧", "\\wedge", !0);
l(u, c, X, "∨", "\\vee", !0);
l(u, c, S, "√", "\\surd");
l(u, c, te, "⟨", "\\langle", !0);
l(u, c, te, "∣", "\\lvert");
l(u, c, te, "∥", "\\lVert");
l(u, c, $0, "?", "?");
l(u, c, $0, "!", "!");
l(u, c, $0, "⟩", "\\rangle", !0);
l(u, c, $0, "∣", "\\rvert");
l(u, c, $0, "∥", "\\rVert");
l(u, c, v, "=", "=");
l(u, c, v, ":", ":");
l(u, c, v, "≈", "\\approx", !0);
l(u, c, v, "≅", "\\cong", !0);
l(u, c, v, "≥", "\\ge");
l(u, c, v, "≥", "\\geq", !0);
l(u, c, v, "←", "\\gets");
l(u, c, v, ">", "\\gt", !0);
l(u, c, v, "∈", "\\in", !0);
l(u, c, v, "", "\\@not");
l(u, c, v, "⊂", "\\subset", !0);
l(u, c, v, "⊃", "\\supset", !0);
l(u, c, v, "⊆", "\\subseteq", !0);
l(u, c, v, "⊇", "\\supseteq", !0);
l(u, g, v, "⊈", "\\nsubseteq", !0);
l(u, g, v, "⊉", "\\nsupseteq", !0);
l(u, c, v, "⊨", "\\models");
l(u, c, v, "←", "\\leftarrow", !0);
l(u, c, v, "≤", "\\le");
l(u, c, v, "≤", "\\leq", !0);
l(u, c, v, "<", "\\lt", !0);
l(u, c, v, "→", "\\rightarrow", !0);
l(u, c, v, "→", "\\to");
l(u, g, v, "≱", "\\ngeq", !0);
l(u, g, v, "≰", "\\nleq", !0);
l(u, c, ye, " ", "\\ ");
l(u, c, ye, " ", "\\space");
l(u, c, ye, " ", "\\nobreakspace");
l(L, c, ye, " ", "\\ ");
l(L, c, ye, " ", " ");
l(L, c, ye, " ", "\\space");
l(L, c, ye, " ", "\\nobreakspace");
l(u, c, ye, null, "\\nobreak");
l(u, c, ye, null, "\\allowbreak");
l(u, c, xx, ",", ",");
l(u, c, xx, ";", ";");
l(u, g, X, "⊼", "\\barwedge", !0);
l(u, g, X, "⊻", "\\veebar", !0);
l(u, c, X, "⊙", "\\odot", !0);
l(u, c, X, "⊕", "\\oplus", !0);
l(u, c, X, "⊗", "\\otimes", !0);
l(u, c, S, "∂", "\\partial", !0);
l(u, c, X, "⊘", "\\oslash", !0);
l(u, g, X, "⊚", "\\circledcirc", !0);
l(u, g, X, "⊡", "\\boxdot", !0);
l(u, c, X, "△", "\\bigtriangleup");
l(u, c, X, "▽", "\\bigtriangledown");
l(u, c, X, "†", "\\dagger");
l(u, c, X, "⋄", "\\diamond");
l(u, c, X, "⋆", "\\star");
l(u, c, X, "◃", "\\triangleleft");
l(u, c, X, "▹", "\\triangleright");
l(u, c, te, "{", "\\{");
l(L, c, S, "{", "\\{");
l(L, c, S, "{", "\\textbraceleft");
l(u, c, $0, "}", "\\}");
l(L, c, S, "}", "\\}");
l(L, c, S, "}", "\\textbraceright");
l(u, c, te, "{", "\\lbrace");
l(u, c, $0, "}", "\\rbrace");
l(u, c, te, "[", "\\lbrack", !0);
l(L, c, S, "[", "\\lbrack", !0);
l(u, c, $0, "]", "\\rbrack", !0);
l(L, c, S, "]", "\\rbrack", !0);
l(u, c, te, "(", "\\lparen", !0);
l(u, c, $0, ")", "\\rparen", !0);
l(L, c, S, "<", "\\textless", !0);
l(L, c, S, ">", "\\textgreater", !0);
l(u, c, te, "⌊", "\\lfloor", !0);
l(u, c, $0, "⌋", "\\rfloor", !0);
l(u, c, te, "⌈", "\\lceil", !0);
l(u, c, $0, "⌉", "\\rceil", !0);
l(u, c, S, "\\", "\\backslash");
l(u, c, S, "∣", "|");
l(u, c, S, "∣", "\\vert");
l(L, c, S, "|", "\\textbar", !0);
l(u, c, S, "∥", "\\|");
l(u, c, S, "∥", "\\Vert");
l(L, c, S, "∥", "\\textbardbl");
l(L, c, S, "~", "\\textasciitilde");
l(L, c, S, "\\", "\\textbackslash");
l(L, c, S, "^", "\\textasciicircum");
l(u, c, v, "↑", "\\uparrow", !0);
l(u, c, v, "⇑", "\\Uparrow", !0);
l(u, c, v, "↓", "\\downarrow", !0);
l(u, c, v, "⇓", "\\Downarrow", !0);
l(u, c, v, "↕", "\\updownarrow", !0);
l(u, c, v, "⇕", "\\Updownarrow", !0);
l(u, c, S0, "∐", "\\coprod");
l(u, c, S0, "⋁", "\\bigvee");
l(u, c, S0, "⋀", "\\bigwedge");
l(u, c, S0, "⨄", "\\biguplus");
l(u, c, S0, "⋂", "\\bigcap");
l(u, c, S0, "⋃", "\\bigcup");
l(u, c, S0, "∫", "\\int");
l(u, c, S0, "∫", "\\intop");
l(u, c, S0, "∬", "\\iint");
l(u, c, S0, "∭", "\\iiint");
l(u, c, S0, "∏", "\\prod");
l(u, c, S0, "∑", "\\sum");
l(u, c, S0, "⨂", "\\bigotimes");
l(u, c, S0, "⨁", "\\bigoplus");
l(u, c, S0, "⨀", "\\bigodot");
l(u, c, S0, "∮", "\\oint");
l(u, c, S0, "∯", "\\oiint");
l(u, c, S0, "∰", "\\oiiint");
l(u, c, S0, "⨆", "\\bigsqcup");
l(u, c, S0, "∫", "\\smallint");
l(L, c, Je, "…", "\\textellipsis");
l(u, c, Je, "…", "\\mathellipsis");
l(L, c, Je, "…", "\\ldots", !0);
l(u, c, Je, "…", "\\ldots", !0);
l(u, c, Je, "⋯", "\\@cdots", !0);
l(u, c, Je, "⋱", "\\ddots", !0);
l(u, c, S, "⋮", "\\varvdots");
l(u, c, D0, "ˊ", "\\acute");
l(u, c, D0, "ˋ", "\\grave");
l(u, c, D0, "¨", "\\ddot");
l(u, c, D0, "~", "\\tilde");
l(u, c, D0, "ˉ", "\\bar");
l(u, c, D0, "˘", "\\breve");
l(u, c, D0, "ˇ", "\\check");
l(u, c, D0, "^", "\\hat");
l(u, c, D0, "⃗", "\\vec");
l(u, c, D0, "˙", "\\dot");
l(u, c, D0, "˚", "\\mathring");
l(u, c, e0, "", "\\@imath");
l(u, c, e0, "", "\\@jmath");
l(u, c, S, "ı", "ı");
l(u, c, S, "ȷ", "ȷ");
l(L, c, S, "ı", "\\i", !0);
l(L, c, S, "ȷ", "\\j", !0);
l(L, c, S, "ß", "\\ss", !0);
l(L, c, S, "æ", "\\ae", !0);
l(L, c, S, "œ", "\\oe", !0);
l(L, c, S, "ø", "\\o", !0);
l(L, c, S, "Æ", "\\AE", !0);
l(L, c, S, "Œ", "\\OE", !0);
l(L, c, S, "Ø", "\\O", !0);
l(L, c, D0, "ˊ", "\\'");
l(L, c, D0, "ˋ", "\\`");
l(L, c, D0, "ˆ", "\\^");
l(L, c, D0, "˜", "\\~");
l(L, c, D0, "ˉ", "\\=");
l(L, c, D0, "˘", "\\u");
l(L, c, D0, "˙", "\\.");
l(L, c, D0, "¸", "\\c");
l(L, c, D0, "˚", "\\r");
l(L, c, D0, "ˇ", "\\v");
l(L, c, D0, "¨", '\\"');
l(L, c, D0, "˝", "\\H");
l(L, c, D0, "◯", "\\textcircled");
var hn = {
  "--": !0,
  "---": !0,
  "``": !0,
  "''": !0
};
l(L, c, S, "–", "--", !0);
l(L, c, S, "–", "\\textendash");
l(L, c, S, "—", "---", !0);
l(L, c, S, "—", "\\textemdash");
l(L, c, S, "‘", "`", !0);
l(L, c, S, "‘", "\\textquoteleft");
l(L, c, S, "’", "'", !0);
l(L, c, S, "’", "\\textquoteright");
l(L, c, S, "“", "``", !0);
l(L, c, S, "“", "\\textquotedblleft");
l(L, c, S, "”", "''", !0);
l(L, c, S, "”", "\\textquotedblright");
l(u, c, S, "°", "\\degree", !0);
l(L, c, S, "°", "\\degree");
l(L, c, S, "°", "\\textdegree", !0);
l(u, c, S, "£", "\\pounds");
l(u, c, S, "£", "\\mathsterling", !0);
l(L, c, S, "£", "\\pounds");
l(L, c, S, "£", "\\textsterling", !0);
l(u, g, S, "✠", "\\maltese");
l(L, g, S, "✠", "\\maltese");
var na = '0123456789/@."';
for (var Dx = 0; Dx < na.length; Dx++) {
  var oa = na.charAt(Dx);
  l(u, c, S, oa, oa);
}
var la = '0123456789!@*()-=+";:?/.,';
for (var Fx = 0; Fx < la.length; Fx++) {
  var ia = la.charAt(Fx);
  l(L, c, S, ia, ia);
}
var jt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var px = 0; px < jt.length; px++) {
  var yt = jt.charAt(px);
  l(u, c, e0, yt, yt), l(L, c, S, yt, yt);
}
l(u, g, S, "C", "ℂ");
l(L, g, S, "C", "ℂ");
l(u, g, S, "H", "ℍ");
l(L, g, S, "H", "ℍ");
l(u, g, S, "N", "ℕ");
l(L, g, S, "N", "ℕ");
l(u, g, S, "P", "ℙ");
l(L, g, S, "P", "ℙ");
l(u, g, S, "Q", "ℚ");
l(L, g, S, "Q", "ℚ");
l(u, g, S, "R", "ℝ");
l(L, g, S, "R", "ℝ");
l(u, g, S, "Z", "ℤ");
l(L, g, S, "Z", "ℤ");
l(u, c, e0, "h", "ℎ");
l(L, c, e0, "h", "ℎ");
var n0 = "";
for (var H0 = 0; H0 < jt.length; H0++) {
  var v0 = jt.charAt(H0);
  n0 = String.fromCharCode(55349, 56320 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0), n0 = String.fromCharCode(55349, 56372 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0), n0 = String.fromCharCode(55349, 56424 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0), n0 = String.fromCharCode(55349, 56580 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0), n0 = String.fromCharCode(55349, 56684 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0), n0 = String.fromCharCode(55349, 56736 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0), n0 = String.fromCharCode(55349, 56788 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0), n0 = String.fromCharCode(55349, 56840 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0), n0 = String.fromCharCode(55349, 56944 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0), H0 < 26 && (n0 = String.fromCharCode(55349, 56632 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0), n0 = String.fromCharCode(55349, 56476 + H0), l(u, c, e0, v0, n0), l(L, c, S, v0, n0));
}
n0 = "𝕜";
l(u, c, e0, "k", n0);
l(L, c, S, "k", n0);
for (var Le = 0; Le < 10; Le++) {
  var Te = Le.toString();
  n0 = String.fromCharCode(55349, 57294 + Le), l(u, c, e0, Te, n0), l(L, c, S, Te, n0), n0 = String.fromCharCode(55349, 57314 + Le), l(u, c, e0, Te, n0), l(L, c, S, Te, n0), n0 = String.fromCharCode(55349, 57324 + Le), l(u, c, e0, Te, n0), l(L, c, S, Te, n0), n0 = String.fromCharCode(55349, 57334 + Le), l(u, c, e0, Te, n0), l(L, c, S, Te, n0);
}
var sa = "ÐÞþ";
for (var gx = 0; gx < sa.length; gx++) {
  var St = sa.charAt(gx);
  l(u, c, e0, St, St), l(L, c, S, St, St);
}
var Tt = [
  ["mathbf", "textbf", "Main-Bold"],
  // A-Z bold upright
  ["mathbf", "textbf", "Main-Bold"],
  // a-z bold upright
  ["mathnormal", "textit", "Math-Italic"],
  // A-Z italic
  ["mathnormal", "textit", "Math-Italic"],
  // a-z italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // A-Z bold italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // a-z bold italic
  // Map fancy A-Z letters to script, not calligraphic.
  // This aligns with unicode-math and math fonts (except Cambria Math).
  ["mathscr", "textscr", "Script-Regular"],
  // A-Z script
  ["", "", ""],
  // a-z script.  No font
  ["", "", ""],
  // A-Z bold script. No font
  ["", "", ""],
  // a-z bold script. No font
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // A-Z Fraktur
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // a-z Fraktur
  ["mathbb", "textbb", "AMS-Regular"],
  // A-Z double-struck
  ["mathbb", "textbb", "AMS-Regular"],
  // k double-struck
  // Note that we are using a bold font, but font metrics for regular Fraktur.
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // A-Z bold Fraktur
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // a-z bold Fraktur
  ["mathsf", "textsf", "SansSerif-Regular"],
  // A-Z sans-serif
  ["mathsf", "textsf", "SansSerif-Regular"],
  // a-z sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // A-Z bold sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // a-z bold sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // A-Z italic sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // a-z italic sans-serif
  ["", "", ""],
  // A-Z bold italic sans. No font
  ["", "", ""],
  // a-z bold italic sans. No font
  ["mathtt", "texttt", "Typewriter-Regular"],
  // A-Z monospace
  ["mathtt", "texttt", "Typewriter-Regular"]
  // a-z monospace
], ua = [
  ["mathbf", "textbf", "Main-Bold"],
  // 0-9 bold
  ["", "", ""],
  // 0-9 double-struck. No KaTeX font.
  ["mathsf", "textsf", "SansSerif-Regular"],
  // 0-9 sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // 0-9 bold sans-serif
  ["mathtt", "texttt", "Typewriter-Regular"]
  // 0-9 monospace
], b9 = function(e, t) {
  var x = e.charCodeAt(0), a = e.charCodeAt(1), n = (x - 55296) * 1024 + (a - 56320) + 65536, o = t === "math" ? 0 : 1;
  if (119808 <= n && n < 120484) {
    var s = Math.floor((n - 119808) / 26);
    return [Tt[s][2], Tt[s][o]];
  } else if (120782 <= n && n <= 120831) {
    var i = Math.floor((n - 120782) / 10);
    return [ua[i][2], ua[i][o]];
  } else {
    if (n === 120485 || n === 120486)
      return [Tt[0][2], Tt[0][o]];
    if (120486 < n && n < 120782)
      return ["", ""];
    throw new J("Unsupported character: " + e);
  }
}, rx = function(e, t, x) {
  return k0[x][e] && k0[x][e].replace && (e = k0[x][e].replace), {
    value: e,
    metrics: sr(e, t, x)
  };
}, ue = function(e, t, x, a, n) {
  var o = rx(e, t, x), s = o.metrics;
  e = o.value;
  var i;
  if (s) {
    var m = s.italic;
    (x === "text" || a && a.font === "mathit") && (m = 0), i = new Be(e, s.height, s.depth, m, s.skew, s.width, n);
  } else
    typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + x + "'")), i = new Be(e, 0, 0, 0, 0, 0, n);
  if (a) {
    i.maxFontSize = a.sizeMultiplier, a.style.isTight() && i.classes.push("mtight");
    var d = a.getColor();
    d && (i.style.color = d);
  }
  return i;
}, k9 = function(e, t, x, a) {
  return a === void 0 && (a = []), x.font === "boldsymbol" && rx(e, "Main-Bold", t).metrics ? ue(e, "Main-Bold", t, x, a.concat(["mathbf"])) : e === "\\" || k0[t][e].font === "main" ? ue(e, "Main-Regular", t, x, a) : ue(e, "AMS-Regular", t, x, a.concat(["amsrm"]));
}, w9 = function(e, t, x, a, n) {
  return n !== "textord" && rx(e, "Math-BoldItalic", t).metrics ? {
    fontName: "Math-BoldItalic",
    fontClass: "boldsymbol"
  } : {
    fontName: "Main-Bold",
    fontClass: "mathbf"
  };
}, y9 = function(e, t, x) {
  var a = e.mode, n = e.text, o = ["mord"], s = a === "math" || a === "text" && t.font, i = s ? t.font : t.fontFamily, m = "", d = "";
  if (n.charCodeAt(0) === 55349 && ([m, d] = b9(n, a)), m.length > 0)
    return ue(n, m, a, t, o.concat(d));
  if (i) {
    var E, C;
    if (i === "boldsymbol") {
      var A = w9(n, a, t, o, x);
      E = A.fontName, C = [A.fontClass];
    } else s ? (E = Cn[i].fontName, C = [i]) : (E = Mt(i, t.fontWeight, t.fontShape), C = [i, t.fontWeight, t.fontShape]);
    if (rx(n, E, a).metrics)
      return ue(n, E, a, t, o.concat(C));
    if (hn.hasOwnProperty(n) && E.slice(0, 10) === "Typewriter") {
      for (var b = [], y = 0; y < n.length; y++)
        b.push(ue(n[y], E, a, t, o.concat(C)));
      return Bn(b);
    }
  }
  if (x === "mathord")
    return ue(n, "Math-Italic", a, t, o.concat(["mathnormal"]));
  if (x === "textord") {
    var w = k0[a][n] && k0[a][n].font;
    if (w === "ams") {
      var P = Mt("amsrm", t.fontWeight, t.fontShape);
      return ue(n, P, a, t, o.concat("amsrm", t.fontWeight, t.fontShape));
    } else if (w === "main" || !w) {
      var k = Mt("textrm", t.fontWeight, t.fontShape);
      return ue(n, k, a, t, o.concat(t.fontWeight, t.fontShape));
    } else {
      var f = Mt(w, t.fontWeight, t.fontShape);
      return ue(n, f, a, t, o.concat(f, t.fontWeight, t.fontShape));
    }
  } else
    throw new Error("unexpected type: " + x + " in makeOrd");
}, S9 = (r, e) => {
  if (_e(r.classes) !== _e(e.classes) || r.skew !== e.skew || r.maxFontSize !== e.maxFontSize)
    return !1;
  if (r.classes.length === 1) {
    var t = r.classes[0];
    if (t === "mbin" || t === "mord")
      return !1;
  }
  for (var x in r.style)
    if (r.style.hasOwnProperty(x) && r.style[x] !== e.style[x])
      return !1;
  for (var a in e.style)
    if (e.style.hasOwnProperty(a) && r.style[a] !== e.style[a])
      return !1;
  return !0;
}, T9 = (r) => {
  for (var e = 0; e < r.length - 1; e++) {
    var t = r[e], x = r[e + 1];
    t instanceof Be && x instanceof Be && S9(t, x) && (t.text += x.text, t.height = Math.max(t.height, x.height), t.depth = Math.max(t.depth, x.depth), t.italic = x.italic, r.splice(e + 1, 1), e--);
  }
  return r;
}, ur = function(e) {
  for (var t = 0, x = 0, a = 0, n = 0; n < e.children.length; n++) {
    var o = e.children[n];
    o.height > t && (t = o.height), o.depth > x && (x = o.depth), o.maxFontSize > a && (a = o.maxFontSize);
  }
  e.height = t, e.depth = x, e.maxFontSize = a;
}, Q0 = function(e, t, x, a) {
  var n = new tx(e, t, x, a);
  return ur(n), n;
}, fn = (r, e, t, x) => new tx(r, e, t, x), M9 = function(e, t, x) {
  var a = Q0([e], [], t);
  return a.height = Math.max(x || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), a.style.borderBottomWidth = U(a.height), a.maxFontSize = 1, a;
}, P9 = function(e, t, x, a) {
  var n = new mn(e, t, x, a);
  return ur(n), n;
}, Bn = function(e) {
  var t = new Ct(e);
  return ur(t), t;
}, _9 = function(e, t) {
  return e instanceof Ct ? Q0([], [e], t) : e;
}, z9 = function(e) {
  if (e.positionType === "individualShift") {
    for (var t = e.children, x = [t[0]], a = -t[0].shift - t[0].elem.depth, n = a, o = 1; o < t.length; o++) {
      var s = -t[o].shift - n - t[o].elem.depth, i = s - (t[o - 1].elem.height + t[o - 1].elem.depth);
      n = n + s, x.push({
        type: "kern",
        size: i
      }), x.push(t[o]);
    }
    return {
      children: x,
      depth: a
    };
  }
  var m;
  if (e.positionType === "top") {
    for (var d = e.positionData, E = 0; E < e.children.length; E++) {
      var C = e.children[E];
      d -= C.type === "kern" ? C.size : C.elem.height + C.elem.depth;
    }
    m = d;
  } else if (e.positionType === "bottom")
    m = -e.positionData;
  else {
    var A = e.children[0];
    if (A.type !== "elem")
      throw new Error('First child must have type "elem".');
    if (e.positionType === "shift")
      m = -A.elem.depth - e.positionData;
    else if (e.positionType === "firstBaseline")
      m = -A.elem.depth;
    else
      throw new Error("Invalid positionType " + e.positionType + ".");
  }
  return {
    children: e.children,
    depth: m
  };
}, R9 = function(e, t) {
  for (var {
    children: x,
    depth: a
  } = z9(e), n = 0, o = 0; o < x.length; o++) {
    var s = x[o];
    if (s.type === "elem") {
      var i = s.elem;
      n = Math.max(n, i.maxFontSize, i.height);
    }
  }
  n += 2;
  var m = Q0(["pstrut"], []);
  m.style.height = U(n);
  for (var d = [], E = a, C = a, A = a, b = 0; b < x.length; b++) {
    var y = x[b];
    if (y.type === "kern")
      A += y.size;
    else {
      var w = y.elem, P = y.wrapperClasses || [], k = y.wrapperStyle || {}, f = Q0(P, [m, w], void 0, k);
      f.style.top = U(-n - A - w.depth), y.marginLeft && (f.style.marginLeft = y.marginLeft), y.marginRight && (f.style.marginRight = y.marginRight), d.push(f), A += w.height + w.depth;
    }
    E = Math.min(E, A), C = Math.max(C, A);
  }
  var B = Q0(["vlist"], d);
  B.style.height = U(C);
  var D;
  if (E < 0) {
    var p = Q0([], []), F = Q0(["vlist"], [p]);
    F.style.height = U(-E);
    var _ = Q0(["vlist-s"], [new Be("​")]);
    D = [Q0(["vlist-r"], [B, _]), Q0(["vlist-r"], [F])];
  } else
    D = [Q0(["vlist-r"], [B])];
  var M = Q0(["vlist-t"], D);
  return D.length === 2 && M.classes.push("vlist-t2"), M.height = C, M.depth = -E, M;
}, N9 = (r, e) => {
  var t = Q0(["mspace"], [], e), x = p0(r, e);
  return t.style.marginRight = U(x), t;
}, Mt = function(e, t, x) {
  var a = "";
  switch (e) {
    case "amsrm":
      a = "AMS";
      break;
    case "textrm":
      a = "Main";
      break;
    case "textsf":
      a = "SansSerif";
      break;
    case "texttt":
      a = "Typewriter";
      break;
    default:
      a = e;
  }
  var n;
  return t === "textbf" && x === "textit" ? n = "BoldItalic" : t === "textbf" ? n = "Bold" : t === "textit" ? n = "Italic" : n = "Regular", a + "-" + n;
}, Cn = {
  // styles
  mathbf: {
    variant: "bold",
    fontName: "Main-Bold"
  },
  mathrm: {
    variant: "normal",
    fontName: "Main-Regular"
  },
  textit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathnormal: {
    variant: "italic",
    fontName: "Math-Italic"
  },
  // "boldsymbol" is missing because they require the use of multiple fonts:
  // Math-BoldItalic and Main-Bold.  This is handled by a special case in
  // makeOrd which ends up calling boldsymbol.
  // families
  mathbb: {
    variant: "double-struck",
    fontName: "AMS-Regular"
  },
  mathcal: {
    variant: "script",
    fontName: "Caligraphic-Regular"
  },
  mathfrak: {
    variant: "fraktur",
    fontName: "Fraktur-Regular"
  },
  mathscr: {
    variant: "script",
    fontName: "Script-Regular"
  },
  mathsf: {
    variant: "sans-serif",
    fontName: "SansSerif-Regular"
  },
  mathtt: {
    variant: "monospace",
    fontName: "Typewriter-Regular"
  }
}, An = {
  //   path, width, height
  vec: ["vec", 0.471, 0.714],
  // values from the font glyph
  oiintSize1: ["oiintSize1", 0.957, 0.499],
  // oval to overlay the integrand
  oiintSize2: ["oiintSize2", 1.472, 0.659],
  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
}, L9 = function(e, t) {
  var [x, a, n] = An[e], o = new qe(x), s = new ze([o], {
    width: U(a),
    height: U(n),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + U(a),
    viewBox: "0 0 " + 1e3 * a + " " + 1e3 * n,
    preserveAspectRatio: "xMinYMin"
  }), i = fn(["overlay"], [s], t);
  return i.height = n, i.style.height = U(n), i.style.width = U(a), i;
}, z = {
  fontMap: Cn,
  makeSymbol: ue,
  mathsym: k9,
  makeSpan: Q0,
  makeSvgSpan: fn,
  makeLineSpan: M9,
  makeAnchor: P9,
  makeFragment: Bn,
  wrapFragment: _9,
  makeVList: R9,
  makeOrd: y9,
  makeGlue: N9,
  staticSvg: L9,
  svgData: An,
  tryCombineChars: T9
}, F0 = {
  number: 3,
  unit: "mu"
}, Ie = {
  number: 4,
  unit: "mu"
}, ge = {
  number: 5,
  unit: "mu"
}, I9 = {
  mord: {
    mop: F0,
    mbin: Ie,
    mrel: ge,
    minner: F0
  },
  mop: {
    mord: F0,
    mop: F0,
    mrel: ge,
    minner: F0
  },
  mbin: {
    mord: Ie,
    mop: Ie,
    mopen: Ie,
    minner: Ie
  },
  mrel: {
    mord: ge,
    mop: ge,
    mopen: ge,
    minner: ge
  },
  mopen: {},
  mclose: {
    mop: F0,
    mbin: Ie,
    mrel: ge,
    minner: F0
  },
  mpunct: {
    mord: F0,
    mop: F0,
    mrel: ge,
    mopen: F0,
    mclose: F0,
    mpunct: F0,
    minner: F0
  },
  minner: {
    mord: F0,
    mop: F0,
    mbin: Ie,
    mrel: ge,
    mopen: F0,
    mpunct: F0,
    minner: F0
  }
}, O9 = {
  mord: {
    mop: F0
  },
  mop: {
    mord: F0,
    mop: F0
  },
  mbin: {},
  mrel: {},
  mopen: {},
  mclose: {
    mop: F0
  },
  mpunct: {},
  minner: {
    mop: F0
  }
}, Dn = {}, Yt = {}, Qt = {};
function V(r) {
  for (var {
    type: e,
    names: t,
    props: x,
    handler: a,
    htmlBuilder: n,
    mathmlBuilder: o
  } = r, s = {
    type: e,
    numArgs: x.numArgs,
    argTypes: x.argTypes,
    allowedInArgument: !!x.allowedInArgument,
    allowedInText: !!x.allowedInText,
    allowedInMath: x.allowedInMath === void 0 ? !0 : x.allowedInMath,
    numOptionalArgs: x.numOptionalArgs || 0,
    infix: !!x.infix,
    primitive: !!x.primitive,
    handler: a
  }, i = 0; i < t.length; ++i)
    Dn[t[i]] = s;
  e && (n && (Yt[e] = n), o && (Qt[e] = o));
}
function Ge(r) {
  var {
    type: e,
    htmlBuilder: t,
    mathmlBuilder: x
  } = r;
  V({
    type: e,
    names: [],
    props: {
      numArgs: 0
    },
    handler() {
      throw new Error("Should never be called.");
    },
    htmlBuilder: t,
    mathmlBuilder: x
  });
}
var Zt = function(e) {
  return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, b0 = function(e) {
  return e.type === "ordgroup" ? e.body : [e];
}, Ke = z.makeSpan, q9 = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"], H9 = ["rightmost", "mrel", "mclose", "mpunct"], U9 = {
  display: r0.DISPLAY,
  text: r0.TEXT,
  script: r0.SCRIPT,
  scriptscript: r0.SCRIPTSCRIPT
}, G9 = {
  mord: "mord",
  mop: "mop",
  mbin: "mbin",
  mrel: "mrel",
  mopen: "mopen",
  mclose: "mclose",
  mpunct: "mpunct",
  minner: "minner"
}, R0 = function(e, t, x, a) {
  a === void 0 && (a = [null, null]);
  for (var n = [], o = 0; o < e.length; o++) {
    var s = d0(e[o], t);
    if (s instanceof Ct) {
      var i = s.children;
      n.push(...i);
    } else
      n.push(s);
  }
  if (z.tryCombineChars(n), !x)
    return n;
  var m = t;
  if (e.length === 1) {
    var d = e[0];
    d.type === "sizing" ? m = t.havingSize(d.size) : d.type === "styling" && (m = t.havingStyle(U9[d.style]));
  }
  var E = Ke([a[0] || "leftmost"], [], t), C = Ke([a[1] || "rightmost"], [], t), A = x === "root";
  return ca(n, (b, y) => {
    var w = y.classes[0], P = b.classes[0];
    w === "mbin" && t0.contains(H9, P) ? y.classes[0] = "mord" : P === "mbin" && t0.contains(q9, w) && (b.classes[0] = "mord");
  }, {
    node: E
  }, C, A), ca(n, (b, y) => {
    var w = Kx(y), P = Kx(b), k = w && P ? b.hasClass("mtight") ? O9[w][P] : I9[w][P] : null;
    if (k)
      return z.makeGlue(k, m);
  }, {
    node: E
  }, C, A), n;
}, ca = function r(e, t, x, a, n) {
  a && e.push(a);
  for (var o = 0; o < e.length; o++) {
    var s = e[o], i = Fn(s);
    if (i) {
      r(i.children, t, x, null, n);
      continue;
    }
    var m = !s.hasClass("mspace");
    if (m) {
      var d = t(s, x.node);
      d && (x.insertAfter ? x.insertAfter(d) : (e.unshift(d), o++));
    }
    m ? x.node = s : n && s.hasClass("newline") && (x.node = Ke(["leftmost"])), x.insertAfter = /* @__PURE__ */ ((E) => (C) => {
      e.splice(E + 1, 0, C), o++;
    })(o);
  }
  a && e.pop();
}, Fn = function(e) {
  return e instanceof Ct || e instanceof mn || e instanceof tx && e.hasClass("enclosing") ? e : null;
}, V9 = function r(e, t) {
  var x = Fn(e);
  if (x) {
    var a = x.children;
    if (a.length) {
      if (t === "right")
        return r(a[a.length - 1], "right");
      if (t === "left")
        return r(a[0], "left");
    }
  }
  return e;
}, Kx = function(e, t) {
  return e ? (t && (e = V9(e, t)), G9[e.classes[0]] || null) : null;
}, Bt = function(e, t) {
  var x = ["nulldelimiter"].concat(e.baseSizingClasses());
  return Ke(t.concat(x));
}, d0 = function(e, t, x) {
  if (!e)
    return Ke();
  if (Yt[e.type]) {
    var a = Yt[e.type](e, t);
    if (x && t.size !== x.size) {
      a = Ke(t.sizingClasses(x), [a], t);
      var n = t.sizeMultiplier / x.sizeMultiplier;
      a.height *= n, a.depth *= n;
    }
    return a;
  } else
    throw new J("Got group of unknown type: '" + e.type + "'");
};
function pn(r) {
  return new Ct(r);
}
class ce {
  constructor(e, t, x) {
    this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = x || [];
  }
  /**
   * Sets an attribute on a MathML node. MathML depends on attributes to convey a
   * semantic content, so this is used heavily.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  /**
   * Gets an attribute on a MathML node.
   */
  getAttribute(e) {
    return this.attributes[e];
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
    this.classes.length > 0 && (e.className = _e(this.classes));
    for (var x = 0; x < this.children.length; x++)
      e.appendChild(this.children[x].toNode());
    return e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    var e = "<" + this.type;
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += t0.escape(this.attributes[t]), e += '"');
    this.classes.length > 0 && (e += ' class ="' + t0.escape(_e(this.classes)) + '"'), e += ">";
    for (var x = 0; x < this.children.length; x++)
      e += this.children[x].toMarkup();
    return e += "</" + this.type + ">", e;
  }
  /**
   * Converts the math node into a string, similar to innerText, but escaped.
   */
  toText() {
    return this.children.map((e) => e.toText()).join("");
  }
}
class Et {
  constructor(e) {
    this.text = void 0, this.text = e;
  }
  /**
   * Converts the text node into a DOM text node.
   */
  toNode() {
    return document.createTextNode(this.text);
  }
  /**
   * Converts the text node into escaped HTML markup
   * (representing the text itself).
   */
  toMarkup() {
    return t0.escape(this.toText());
  }
  /**
   * Converts the text node into a string
   * (representing the text itself).
   */
  toText() {
    return this.text;
  }
}
class X9 {
  /**
   * Create a Space node with width given in CSS ems.
   */
  constructor(e) {
    this.width = void 0, this.character = void 0, this.width = e, e >= 0.05555 && e <= 0.05556 ? this.character = " " : e >= 0.1666 && e <= 0.1667 ? this.character = " " : e >= 0.2222 && e <= 0.2223 ? this.character = " " : e >= 0.2777 && e <= 0.2778 ? this.character = "  " : e >= -0.05556 && e <= -0.05555 ? this.character = " ⁣" : e >= -0.1667 && e <= -0.1666 ? this.character = " ⁣" : e >= -0.2223 && e <= -0.2222 ? this.character = " ⁣" : e >= -0.2778 && e <= -0.2777 ? this.character = " ⁣" : this.character = null;
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    if (this.character)
      return document.createTextNode(this.character);
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
    return e.setAttribute("width", U(this.width)), e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + U(this.width) + '"/>';
  }
  /**
   * Converts the math node into a string, similar to innerText.
   */
  toText() {
    return this.character ? this.character : " ";
  }
}
var O = {
  MathNode: ce,
  TextNode: Et,
  SpaceNode: X9,
  newDocumentFragment: pn
}, le = function(e, t, x) {
  return k0[t][e] && k0[t][e].replace && e.charCodeAt(0) !== 55349 && !(hn.hasOwnProperty(e) && x && (x.fontFamily && x.fontFamily.slice(4, 6) === "tt" || x.font && x.font.slice(4, 6) === "tt")) && (e = k0[t][e].replace), new O.TextNode(e);
}, cr = function(e) {
  return e.length === 1 ? e[0] : new O.MathNode("mrow", e);
}, Er = function(e, t) {
  if (t.fontFamily === "texttt")
    return "monospace";
  if (t.fontFamily === "textsf")
    return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
  if (t.fontShape === "textit" && t.fontWeight === "textbf")
    return "bold-italic";
  if (t.fontShape === "textit")
    return "italic";
  if (t.fontWeight === "textbf")
    return "bold";
  var x = t.font;
  if (!x || x === "mathnormal")
    return null;
  var a = e.mode;
  if (x === "mathit")
    return "italic";
  if (x === "boldsymbol")
    return e.type === "textord" ? "bold" : "bold-italic";
  if (x === "mathbf")
    return "bold";
  if (x === "mathbb")
    return "double-struck";
  if (x === "mathfrak")
    return "fraktur";
  if (x === "mathscr" || x === "mathcal")
    return "script";
  if (x === "mathsf")
    return "sans-serif";
  if (x === "mathtt")
    return "monospace";
  var n = e.text;
  if (t0.contains(["\\imath", "\\jmath"], n))
    return null;
  k0[a][n] && k0[a][n].replace && (n = k0[a][n].replace);
  var o = z.fontMap[x].fontName;
  return sr(n, o, a) ? z.fontMap[x].variant : null;
}, xe = function(e, t, x) {
  if (e.length === 1) {
    var a = B0(e[0], t);
    return x && a instanceof ce && a.type === "mo" && (a.setAttribute("lspace", "0em"), a.setAttribute("rspace", "0em")), [a];
  }
  for (var n = [], o, s = 0; s < e.length; s++) {
    var i = B0(e[s], t);
    if (i instanceof ce && o instanceof ce) {
      if (i.type === "mtext" && o.type === "mtext" && i.getAttribute("mathvariant") === o.getAttribute("mathvariant")) {
        o.children.push(...i.children);
        continue;
      } else if (i.type === "mn" && o.type === "mn") {
        o.children.push(...i.children);
        continue;
      } else if (i.type === "mi" && i.children.length === 1 && o.type === "mn") {
        var m = i.children[0];
        if (m instanceof Et && m.text === ".") {
          o.children.push(...i.children);
          continue;
        }
      } else if (o.type === "mi" && o.children.length === 1) {
        var d = o.children[0];
        if (d instanceof Et && d.text === "̸" && (i.type === "mo" || i.type === "mi" || i.type === "mn")) {
          var E = i.children[0];
          E instanceof Et && E.text.length > 0 && (E.text = E.text.slice(0, 1) + "̸" + E.text.slice(1), n.pop());
        }
      }
    }
    n.push(i), o = i;
  }
  return n;
}, Re = function(e, t, x) {
  return cr(xe(e, t, x));
}, B0 = function(e, t) {
  if (!e)
    return new O.MathNode("mrow");
  if (Qt[e.type]) {
    var x = Qt[e.type](e, t);
    return x;
  } else
    throw new J("Got group of unknown type: '" + e.type + "'");
}, $9 = {
  widehat: "^",
  widecheck: "ˇ",
  widetilde: "~",
  utilde: "~",
  overleftarrow: "←",
  underleftarrow: "←",
  xleftarrow: "←",
  overrightarrow: "→",
  underrightarrow: "→",
  xrightarrow: "→",
  underbrace: "⏟",
  overbrace: "⏞",
  overgroup: "⏠",
  undergroup: "⏡",
  overleftrightarrow: "↔",
  underleftrightarrow: "↔",
  xleftrightarrow: "↔",
  Overrightarrow: "⇒",
  xRightarrow: "⇒",
  overleftharpoon: "↼",
  xleftharpoonup: "↼",
  overrightharpoon: "⇀",
  xrightharpoonup: "⇀",
  xLeftarrow: "⇐",
  xLeftrightarrow: "⇔",
  xhookleftarrow: "↩",
  xhookrightarrow: "↪",
  xmapsto: "↦",
  xrightharpoondown: "⇁",
  xleftharpoondown: "↽",
  xrightleftharpoons: "⇌",
  xleftrightharpoons: "⇋",
  xtwoheadleftarrow: "↞",
  xtwoheadrightarrow: "↠",
  xlongequal: "=",
  xtofrom: "⇄",
  xrightleftarrows: "⇄",
  xrightequilibrium: "⇌",
  // Not a perfect match.
  xleftequilibrium: "⇋",
  // None better available.
  "\\cdrightarrow": "→",
  "\\cdleftarrow": "←",
  "\\cdlongequal": "="
}, W9 = function(e) {
  var t = new O.MathNode("mo", [new O.TextNode($9[e.replace(/^\\/, "")])]);
  return t.setAttribute("stretchy", "true"), t;
}, j9 = {
  //   path(s), minWidth, height, align
  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
  "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
  // CD minwwidth2.5pc
  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
  "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
  "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
  // The next three arrows are from the mhchem package.
  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
  // document as \xrightarrow or \xrightleftharpoons. Those have
  // min-length = 1.75em, so we set min-length on these next three to match.
  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
}, Y9 = function(e) {
  return e.type === "ordgroup" ? e.body.length : 1;
}, Q9 = function(e, t) {
  function x() {
    var s = 4e5, i = e.label.slice(1);
    if (t0.contains(["widehat", "widecheck", "widetilde", "utilde"], i)) {
      var m = e, d = Y9(m.base), E, C, A;
      if (d > 5)
        i === "widehat" || i === "widecheck" ? (E = 420, s = 2364, A = 0.42, C = i + "4") : (E = 312, s = 2340, A = 0.34, C = "tilde4");
      else {
        var b = [1, 1, 2, 2, 3, 3][d];
        i === "widehat" || i === "widecheck" ? (s = [0, 1062, 2364, 2364, 2364][b], E = [0, 239, 300, 360, 420][b], A = [0, 0.24, 0.3, 0.3, 0.36, 0.42][b], C = i + b) : (s = [0, 600, 1033, 2339, 2340][b], E = [0, 260, 286, 306, 312][b], A = [0, 0.26, 0.286, 0.3, 0.306, 0.34][b], C = "tilde" + b);
      }
      var y = new qe(C), w = new ze([y], {
        width: "100%",
        height: U(A),
        viewBox: "0 0 " + s + " " + E,
        preserveAspectRatio: "none"
      });
      return {
        span: z.makeSvgSpan([], [w], t),
        minWidth: 0,
        height: A
      };
    } else {
      var P = [], k = j9[i], [f, B, D] = k, p = D / 1e3, F = f.length, _, M;
      if (F === 1) {
        var R = k[3];
        _ = ["hide-tail"], M = [R];
      } else if (F === 2)
        _ = ["halfarrow-left", "halfarrow-right"], M = ["xMinYMin", "xMaxYMin"];
      else if (F === 3)
        _ = ["brace-left", "brace-center", "brace-right"], M = ["xMinYMin", "xMidYMin", "xMaxYMin"];
      else
        throw new Error(`Correct katexImagesData or update code here to support
                    ` + F + " children.");
      for (var N = 0; N < F; N++) {
        var I = new qe(f[N]), $ = new ze([I], {
          width: "400em",
          height: U(p),
          viewBox: "0 0 " + s + " " + D,
          preserveAspectRatio: M[N] + " slice"
        }), G = z.makeSvgSpan([_[N]], [$], t);
        if (F === 1)
          return {
            span: G,
            minWidth: B,
            height: p
          };
        G.style.height = U(p), P.push(G);
      }
      return {
        span: z.makeSpan(["stretchy"], P, t),
        minWidth: B,
        height: p
      };
    }
  }
  var {
    span: a,
    minWidth: n,
    height: o
  } = x();
  return a.height = o, a.style.height = U(o), n > 0 && (a.style.minWidth = U(n)), a;
}, Z9 = function(e, t, x, a, n) {
  var o, s = e.height + e.depth + x + a;
  if (/fbox|color|angl/.test(t)) {
    if (o = z.makeSpan(["stretchy", t], [], n), t === "fbox") {
      var i = n.color && n.getColor();
      i && (o.style.borderColor = i);
    }
  } else {
    var m = [];
    /^[bx]cancel$/.test(t) && m.push(new ra({
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%",
      "stroke-width": "0.046em"
    })), /^x?cancel$/.test(t) && m.push(new ra({
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0",
      "stroke-width": "0.046em"
    }));
    var d = new ze(m, {
      width: "100%",
      height: U(s)
    });
    o = z.makeSvgSpan([], [d], n);
  }
  return o.height = s, o.style.height = U(s), o;
}, we = {
  encloseSpan: Z9,
  mathMLnode: W9,
  svgSpan: Q9
};
function s0(r, e) {
  if (!r || r.type !== e)
    throw new Error("Expected node of type " + e + ", but got " + (r ? "node of type " + r.type : String(r)));
  return r;
}
function dr(r) {
  var e = ax(r);
  if (!e)
    throw new Error("Expected node of symbol group type, but got " + (r ? "node of type " + r.type : String(r)));
  return e;
}
function ax(r) {
  return r && (r.type === "atom" || v9.hasOwnProperty(r.type)) ? r : null;
}
var mr = (r, e) => {
  var t, x, a;
  r && r.type === "supsub" ? (x = s0(r.base, "accent"), t = x.base, r.base = t, a = g9(d0(r, e)), r.base = x) : (x = s0(r, "accent"), t = x.base);
  var n = d0(t, e.havingCrampedStyle()), o = x.isShifty && t0.isCharacterBox(t), s = 0;
  if (o) {
    var i = t0.getBaseElem(t), m = d0(i, e.havingCrampedStyle());
    s = aa(m).skew;
  }
  var d = x.label === "\\c", E = d ? n.height + n.depth : Math.min(n.height, e.fontMetrics().xHeight), C;
  if (x.isStretchy)
    C = we.svgSpan(x, e), C = z.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: n
      }, {
        type: "elem",
        elem: C,
        wrapperClasses: ["svg-align"],
        wrapperStyle: s > 0 ? {
          width: "calc(100% - " + U(2 * s) + ")",
          marginLeft: U(2 * s)
        } : void 0
      }]
    }, e);
  else {
    var A, b;
    x.label === "\\vec" ? (A = z.staticSvg("vec", e), b = z.svgData.vec[1]) : (A = z.makeOrd({
      mode: x.mode,
      text: x.label
    }, e, "textord"), A = aa(A), A.italic = 0, b = A.width, d && (E += A.depth)), C = z.makeSpan(["accent-body"], [A]);
    var y = x.label === "\\textcircled";
    y && (C.classes.push("accent-full"), E = n.height);
    var w = s;
    y || (w -= b / 2), C.style.left = U(w), x.label === "\\textcircled" && (C.style.top = ".2em"), C = z.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: -E
      }, {
        type: "elem",
        elem: C
      }]
    }, e);
  }
  var P = z.makeSpan(["mord", "accent"], [C], e);
  return a ? (a.children[0] = P, a.height = Math.max(P.height, a.height), a.classes[0] = "mord", a) : P;
}, gn = (r, e) => {
  var t = r.isStretchy ? we.mathMLnode(r.label) : new O.MathNode("mo", [le(r.label, r.mode)]), x = new O.MathNode("mover", [B0(r.base, e), t]);
  return x.setAttribute("accent", "true"), x;
}, K9 = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((r) => "\\" + r).join("|"));
V({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var t = Zt(e[0]), x = !K9.test(r.funcName), a = !x || r.funcName === "\\widehat" || r.funcName === "\\widetilde" || r.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: r.parser.mode,
      label: r.funcName,
      isStretchy: x,
      isShifty: a,
      base: t
    };
  },
  htmlBuilder: mr,
  mathmlBuilder: gn
});
V({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    // unless in strict mode
    argTypes: ["primitive"]
  },
  handler: (r, e) => {
    var t = e[0], x = r.parser.mode;
    return x === "math" && (r.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + r.funcName + " works only in text mode"), x = "text"), {
      type: "accent",
      mode: x,
      label: r.funcName,
      isStretchy: !1,
      isShifty: !0,
      base: t
    };
  },
  htmlBuilder: mr,
  mathmlBuilder: gn
});
V({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: x
    } = r, a = e[0];
    return {
      type: "accentUnder",
      mode: t.mode,
      label: x,
      base: a
    };
  },
  htmlBuilder: (r, e) => {
    var t = d0(r.base, e), x = we.svgSpan(r, e), a = r.label === "\\utilde" ? 0.12 : 0, n = z.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "elem",
        elem: x,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return z.makeSpan(["mord", "accentunder"], [n], e);
  },
  mathmlBuilder: (r, e) => {
    var t = we.mathMLnode(r.label), x = new O.MathNode("munder", [B0(r.base, e), t]);
    return x.setAttribute("accentunder", "true"), x;
  }
});
var Pt = (r) => {
  var e = new O.MathNode("mpadded", r ? [r] : []);
  return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e;
};
V({
  type: "xArrow",
  names: [
    "\\xleftarrow",
    "\\xrightarrow",
    "\\xLeftarrow",
    "\\xRightarrow",
    "\\xleftrightarrow",
    "\\xLeftrightarrow",
    "\\xhookleftarrow",
    "\\xhookrightarrow",
    "\\xmapsto",
    "\\xrightharpoondown",
    "\\xrightharpoonup",
    "\\xleftharpoondown",
    "\\xleftharpoonup",
    "\\xrightleftharpoons",
    "\\xleftrightharpoons",
    "\\xlongequal",
    "\\xtwoheadrightarrow",
    "\\xtwoheadleftarrow",
    "\\xtofrom",
    // The next 3 functions are here to support the mhchem extension.
    // Direct use of these functions is discouraged and may break someday.
    "\\xrightleftarrows",
    "\\xrightequilibrium",
    "\\xleftequilibrium",
    // The next 3 functions are here only to support the {CD} environment.
    "\\\\cdrightarrow",
    "\\\\cdleftarrow",
    "\\\\cdlongequal"
  ],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(r, e, t) {
    var {
      parser: x,
      funcName: a
    } = r;
    return {
      type: "xArrow",
      mode: x.mode,
      label: a,
      body: e[0],
      below: t[0]
    };
  },
  // Flow is unable to correctly infer the type of `group`, even though it's
  // unambiguously determined from the passed-in `type` above.
  htmlBuilder(r, e) {
    var t = e.style, x = e.havingStyle(t.sup()), a = z.wrapFragment(d0(r.body, x, e), e), n = r.label.slice(0, 2) === "\\x" ? "x" : "cd";
    a.classes.push(n + "-arrow-pad");
    var o;
    r.below && (x = e.havingStyle(t.sub()), o = z.wrapFragment(d0(r.below, x, e), e), o.classes.push(n + "-arrow-pad"));
    var s = we.svgSpan(r, e), i = -e.fontMetrics().axisHeight + 0.5 * s.height, m = -e.fontMetrics().axisHeight - 0.5 * s.height - 0.111;
    (a.depth > 0.25 || r.label === "\\xleftequilibrium") && (m -= a.depth);
    var d;
    if (o) {
      var E = -e.fontMetrics().axisHeight + o.height + 0.5 * s.height + 0.111;
      d = z.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: m
        }, {
          type: "elem",
          elem: s,
          shift: i
        }, {
          type: "elem",
          elem: o,
          shift: E
        }]
      }, e);
    } else
      d = z.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: m
        }, {
          type: "elem",
          elem: s,
          shift: i
        }]
      }, e);
    return d.children[0].children[0].children[1].classes.push("svg-align"), z.makeSpan(["mrel", "x-arrow"], [d], e);
  },
  mathmlBuilder(r, e) {
    var t = we.mathMLnode(r.label);
    t.setAttribute("minsize", r.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var x;
    if (r.body) {
      var a = Pt(B0(r.body, e));
      if (r.below) {
        var n = Pt(B0(r.below, e));
        x = new O.MathNode("munderover", [t, n, a]);
      } else
        x = new O.MathNode("mover", [t, a]);
    } else if (r.below) {
      var o = Pt(B0(r.below, e));
      x = new O.MathNode("munder", [t, o]);
    } else
      x = Pt(), x = new O.MathNode("mover", [t, x]);
    return x;
  }
});
var J9 = z.makeSpan;
function vn(r, e) {
  var t = R0(r.body, e, !0);
  return J9([r.mclass], t, e);
}
function bn(r, e) {
  var t, x = xe(r.body, e);
  return r.mclass === "minner" ? t = new O.MathNode("mpadded", x) : r.mclass === "mord" ? r.isCharacterBox ? (t = x[0], t.type = "mi") : t = new O.MathNode("mi", x) : (r.isCharacterBox ? (t = x[0], t.type = "mo") : t = new O.MathNode("mo", x), r.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : r.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : r.mclass === "mopen" || r.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : r.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
}
V({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: x
    } = r, a = e[0];
    return {
      type: "mclass",
      mode: t.mode,
      mclass: "m" + x.slice(5),
      // TODO(kevinb): don't prefix with 'm'
      body: b0(a),
      isCharacterBox: t0.isCharacterBox(a)
    };
  },
  htmlBuilder: vn,
  mathmlBuilder: bn
});
var nx = (r) => {
  var e = r.type === "ordgroup" && r.body.length ? r.body[0] : r;
  return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord";
};
V({
  type: "mclass",
  names: ["\\@binrel"],
  props: {
    numArgs: 2
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "mclass",
      mode: t.mode,
      mclass: nx(e[0]),
      body: b0(e[1]),
      isCharacterBox: t0.isCharacterBox(e[1])
    };
  }
});
V({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  props: {
    numArgs: 2
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: x
    } = r, a = e[1], n = e[0], o;
    x !== "\\stackrel" ? o = nx(a) : o = "mrel";
    var s = {
      type: "op",
      mode: a.mode,
      limits: !0,
      alwaysHandleSupSub: !0,
      parentIsSupSub: !1,
      symbol: !1,
      suppressBaseShift: x !== "\\stackrel",
      body: b0(a)
    }, i = {
      type: "supsub",
      mode: n.mode,
      base: s,
      sup: x === "\\underset" ? null : n,
      sub: x === "\\underset" ? n : null
    };
    return {
      type: "mclass",
      mode: t.mode,
      mclass: o,
      body: [i],
      isCharacterBox: t0.isCharacterBox(i)
    };
  },
  htmlBuilder: vn,
  mathmlBuilder: bn
});
V({
  type: "pmb",
  names: ["\\pmb"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "pmb",
      mode: t.mode,
      mclass: nx(e[0]),
      body: b0(e[0])
    };
  },
  htmlBuilder(r, e) {
    var t = R0(r.body, e, !0), x = z.makeSpan([r.mclass], t, e);
    return x.style.textShadow = "0.02em 0.01em 0.04px", x;
  },
  mathmlBuilder(r, e) {
    var t = xe(r.body, e), x = new O.MathNode("mstyle", t);
    return x.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), x;
  }
});
var e8 = {
  ">": "\\\\cdrightarrow",
  "<": "\\\\cdleftarrow",
  "=": "\\\\cdlongequal",
  A: "\\uparrow",
  V: "\\downarrow",
  "|": "\\Vert",
  ".": "no arrow"
}, Ea = () => ({
  type: "styling",
  body: [],
  mode: "math",
  style: "display"
}), da = (r) => r.type === "textord" && r.text === "@", t8 = (r, e) => (r.type === "mathord" || r.type === "atom") && r.text === e;
function x8(r, e, t) {
  var x = e8[r];
  switch (x) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return t.callFunction(x, [e[0]], [e[1]]);
    case "\\uparrow":
    case "\\downarrow": {
      var a = t.callFunction("\\\\cdleft", [e[0]], []), n = {
        type: "atom",
        text: x,
        mode: "math",
        family: "rel"
      }, o = t.callFunction("\\Big", [n], []), s = t.callFunction("\\\\cdright", [e[1]], []), i = {
        type: "ordgroup",
        mode: "math",
        body: [a, o, s]
      };
      return t.callFunction("\\\\cdparent", [i], []);
    }
    case "\\\\cdlongequal":
      return t.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
      var m = {
        type: "textord",
        text: "\\Vert",
        mode: "math"
      };
      return t.callFunction("\\Big", [m], []);
    }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function r8(r) {
  var e = [];
  for (r.gullet.beginGroup(), r.gullet.macros.set("\\cr", "\\\\\\relax"), r.gullet.beginGroup(); ; ) {
    e.push(r.parseExpression(!1, "\\\\")), r.gullet.endGroup(), r.gullet.beginGroup();
    var t = r.fetch().text;
    if (t === "&" || t === "\\\\")
      r.consume();
    else if (t === "\\end") {
      e[e.length - 1].length === 0 && e.pop();
      break;
    } else
      throw new J("Expected \\\\ or \\cr or \\end", r.nextToken);
  }
  for (var x = [], a = [x], n = 0; n < e.length; n++) {
    for (var o = e[n], s = Ea(), i = 0; i < o.length; i++)
      if (!da(o[i]))
        s.body.push(o[i]);
      else {
        x.push(s), i += 1;
        var m = dr(o[i]).text, d = new Array(2);
        if (d[0] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, d[1] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, !("=|.".indexOf(m) > -1)) if ("<>AV".indexOf(m) > -1)
          for (var E = 0; E < 2; E++) {
            for (var C = !0, A = i + 1; A < o.length; A++) {
              if (t8(o[A], m)) {
                C = !1, i = A;
                break;
              }
              if (da(o[A]))
                throw new J("Missing a " + m + " character to complete a CD arrow.", o[A]);
              d[E].body.push(o[A]);
            }
            if (C)
              throw new J("Missing a " + m + " character to complete a CD arrow.", o[i]);
          }
        else
          throw new J('Expected one of "<>AV=|." after @', o[i]);
        var b = x8(m, d, r), y = {
          type: "styling",
          body: [b],
          mode: "math",
          style: "display"
          // CD is always displaystyle.
        };
        x.push(y), s = Ea();
      }
    n % 2 === 0 ? x.push(s) : x.shift(), x = [], a.push(x);
  }
  r.gullet.endGroup(), r.gullet.endGroup();
  var w = new Array(a[0].length).fill({
    type: "align",
    align: "c",
    pregap: 0.25,
    // CD package sets \enskip between columns.
    postgap: 0.25
    // So pre and post each get half an \enskip, i.e. 0.25em.
  });
  return {
    type: "array",
    mode: "math",
    body: a,
    arraystretch: 1,
    addJot: !0,
    rowGaps: [null],
    cols: w,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(a.length + 1).fill([])
  };
}
V({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: x
    } = r;
    return {
      type: "cdlabel",
      mode: t.mode,
      side: x.slice(4),
      label: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = e.havingStyle(e.style.sup()), x = z.wrapFragment(d0(r.label, t, e), e);
    return x.classes.push("cd-label-" + r.side), x.style.bottom = U(0.8 - x.depth), x.height = 0, x.depth = 0, x;
  },
  mathmlBuilder(r, e) {
    var t = new O.MathNode("mrow", [B0(r.label, e)]);
    return t = new O.MathNode("mpadded", [t]), t.setAttribute("width", "0"), r.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new O.MathNode("mstyle", [t]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t;
  }
});
V({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "cdlabelparent",
      mode: t.mode,
      fragment: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = z.wrapFragment(d0(r.fragment, e), e);
    return t.classes.push("cd-vert-arrow"), t;
  },
  mathmlBuilder(r, e) {
    return new O.MathNode("mrow", [B0(r.fragment, e)]);
  }
});
V({
  type: "textord",
  names: ["\\@char"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    for (var {
      parser: t
    } = r, x = s0(e[0], "ordgroup"), a = x.body, n = "", o = 0; o < a.length; o++) {
      var s = s0(a[o], "textord");
      n += s.text;
    }
    var i = parseInt(n), m;
    if (isNaN(i))
      throw new J("\\@char has non-numeric argument " + n);
    if (i < 0 || i >= 1114111)
      throw new J("\\@char with invalid code point " + n);
    return i <= 65535 ? m = String.fromCharCode(i) : (i -= 65536, m = String.fromCharCode((i >> 10) + 55296, (i & 1023) + 56320)), {
      type: "textord",
      mode: t.mode,
      text: m
    };
  }
});
var kn = (r, e) => {
  var t = R0(r.body, e.withColor(r.color), !1);
  return z.makeFragment(t);
}, wn = (r, e) => {
  var t = xe(r.body, e.withColor(r.color)), x = new O.MathNode("mstyle", t);
  return x.setAttribute("mathcolor", r.color), x;
};
V({
  type: "color",
  names: ["\\textcolor"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "original"]
  },
  handler(r, e) {
    var {
      parser: t
    } = r, x = s0(e[0], "color-token").color, a = e[1];
    return {
      type: "color",
      mode: t.mode,
      color: x,
      body: b0(a)
    };
  },
  htmlBuilder: kn,
  mathmlBuilder: wn
});
V({
  type: "color",
  names: ["\\color"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    argTypes: ["color"]
  },
  handler(r, e) {
    var {
      parser: t,
      breakOnTokenText: x
    } = r, a = s0(e[0], "color-token").color;
    t.gullet.macros.set("\\current@color", a);
    var n = t.parseExpression(!0, x);
    return {
      type: "color",
      mode: t.mode,
      color: a,
      body: n
    };
  },
  htmlBuilder: kn,
  mathmlBuilder: wn
});
V({
  type: "cr",
  names: ["\\\\"],
  props: {
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: !0
  },
  handler(r, e, t) {
    var {
      parser: x
    } = r, a = x.gullet.future().text === "[" ? x.parseSizeGroup(!0) : null, n = !x.settings.displayMode || !x.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: x.mode,
      newLine: n,
      size: a && s0(a, "size").value
    };
  },
  // The following builders are called only at the top level,
  // not within tabular/array environments.
  htmlBuilder(r, e) {
    var t = z.makeSpan(["mspace"], [], e);
    return r.newLine && (t.classes.push("newline"), r.size && (t.style.marginTop = U(p0(r.size, e)))), t;
  },
  mathmlBuilder(r, e) {
    var t = new O.MathNode("mspace");
    return r.newLine && (t.setAttribute("linebreak", "newline"), r.size && t.setAttribute("height", U(p0(r.size, e)))), t;
  }
});
var Jx = {
  "\\global": "\\global",
  "\\long": "\\\\globallong",
  "\\\\globallong": "\\\\globallong",
  "\\def": "\\gdef",
  "\\gdef": "\\gdef",
  "\\edef": "\\xdef",
  "\\xdef": "\\xdef",
  "\\let": "\\\\globallet",
  "\\futurelet": "\\\\globalfuture"
}, yn = (r) => {
  var e = r.text;
  if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
    throw new J("Expected a control sequence", r);
  return e;
}, a8 = (r) => {
  var e = r.gullet.popToken();
  return e.text === "=" && (e = r.gullet.popToken(), e.text === " " && (e = r.gullet.popToken())), e;
}, Sn = (r, e, t, x) => {
  var a = r.gullet.macros.get(t.text);
  a == null && (t.noexpand = !0, a = {
    tokens: [t],
    numArgs: 0,
    // reproduce the same behavior in expansion
    unexpandable: !r.gullet.isExpandable(t.text)
  }), r.gullet.macros.set(e, a, x);
};
V({
  type: "internal",
  names: [
    "\\global",
    "\\long",
    "\\\\globallong"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    e.consumeSpaces();
    var x = e.fetch();
    if (Jx[x.text])
      return (t === "\\global" || t === "\\\\globallong") && (x.text = Jx[x.text]), s0(e.parseFunction(), "internal");
    throw new J("Invalid token after macro prefix", x);
  }
});
V({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, x = e.gullet.popToken(), a = x.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(a))
      throw new J("Expected a control sequence", x);
    for (var n = 0, o, s = [[]]; e.gullet.future().text !== "{"; )
      if (x = e.gullet.popToken(), x.text === "#") {
        if (e.gullet.future().text === "{") {
          o = e.gullet.future(), s[n].push("{");
          break;
        }
        if (x = e.gullet.popToken(), !/^[1-9]$/.test(x.text))
          throw new J('Invalid argument number "' + x.text + '"');
        if (parseInt(x.text) !== n + 1)
          throw new J('Argument number "' + x.text + '" out of order');
        n++, s.push([]);
      } else {
        if (x.text === "EOF")
          throw new J("Expected a macro definition");
        s[n].push(x.text);
      }
    var {
      tokens: i
    } = e.gullet.consumeArg();
    return o && i.unshift(o), (t === "\\edef" || t === "\\xdef") && (i = e.gullet.expandTokens(i), i.reverse()), e.gullet.macros.set(a, {
      tokens: i,
      numArgs: n,
      delimiters: s
    }, t === Jx[t]), {
      type: "internal",
      mode: e.mode
    };
  }
});
V({
  type: "internal",
  names: [
    "\\let",
    "\\\\globallet"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, x = yn(e.gullet.popToken());
    e.gullet.consumeSpaces();
    var a = a8(e);
    return Sn(e, x, a, t === "\\\\globallet"), {
      type: "internal",
      mode: e.mode
    };
  }
});
V({
  type: "internal",
  names: [
    "\\futurelet",
    "\\\\globalfuture"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, x = yn(e.gullet.popToken()), a = e.gullet.popToken(), n = e.gullet.popToken();
    return Sn(e, x, n, t === "\\\\globalfuture"), e.gullet.pushToken(n), e.gullet.pushToken(a), {
      type: "internal",
      mode: e.mode
    };
  }
});
var ct = function(e, t, x) {
  var a = k0.math[e] && k0.math[e].replace, n = sr(a || e, t, x);
  if (!n)
    throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
  return n;
}, hr = function(e, t, x, a) {
  var n = x.havingBaseStyle(t), o = z.makeSpan(a.concat(n.sizingClasses(x)), [e], x), s = n.sizeMultiplier / x.sizeMultiplier;
  return o.height *= s, o.depth *= s, o.maxFontSize = n.sizeMultiplier, o;
}, Tn = function(e, t, x) {
  var a = t.havingBaseStyle(x), n = (1 - t.sizeMultiplier / a.sizeMultiplier) * t.fontMetrics().axisHeight;
  e.classes.push("delimcenter"), e.style.top = U(n), e.height -= n, e.depth += n;
}, n8 = function(e, t, x, a, n, o) {
  var s = z.makeSymbol(e, "Main-Regular", n, a), i = hr(s, t, a, o);
  return x && Tn(i, a, t), i;
}, o8 = function(e, t, x, a) {
  return z.makeSymbol(e, "Size" + t + "-Regular", x, a);
}, Mn = function(e, t, x, a, n, o) {
  var s = o8(e, t, n, a), i = hr(z.makeSpan(["delimsizing", "size" + t], [s], a), r0.TEXT, a, o);
  return x && Tn(i, a, r0.TEXT), i;
}, vx = function(e, t, x) {
  var a;
  t === "Size1-Regular" ? a = "delim-size1" : a = "delim-size4";
  var n = z.makeSpan(["delimsizinginner", a], [z.makeSpan([], [z.makeSymbol(e, t, x)])]);
  return {
    type: "elem",
    elem: n
  };
}, bx = function(e, t, x) {
  var a = ve["Size4-Regular"][e.charCodeAt(0)] ? ve["Size4-Regular"][e.charCodeAt(0)][4] : ve["Size1-Regular"][e.charCodeAt(0)][4], n = new qe("inner", B9(e, Math.round(1e3 * t))), o = new ze([n], {
    width: U(a),
    height: U(t),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + U(a),
    viewBox: "0 0 " + 1e3 * a + " " + Math.round(1e3 * t),
    preserveAspectRatio: "xMinYMin"
  }), s = z.makeSvgSpan([], [o], x);
  return s.height = t, s.style.height = U(t), s.style.width = U(a), {
    type: "elem",
    elem: s
  };
}, er = 8e-3, _t = {
  type: "kern",
  size: -1 * er
}, l8 = ["|", "\\lvert", "\\rvert", "\\vert"], i8 = ["\\|", "\\lVert", "\\rVert", "\\Vert"], Pn = function(e, t, x, a, n, o) {
  var s, i, m, d, E = "", C = 0;
  s = m = d = e, i = null;
  var A = "Size1-Regular";
  e === "\\uparrow" ? m = d = "⏐" : e === "\\Uparrow" ? m = d = "‖" : e === "\\downarrow" ? s = m = "⏐" : e === "\\Downarrow" ? s = m = "‖" : e === "\\updownarrow" ? (s = "\\uparrow", m = "⏐", d = "\\downarrow") : e === "\\Updownarrow" ? (s = "\\Uparrow", m = "‖", d = "\\Downarrow") : t0.contains(l8, e) ? (m = "∣", E = "vert", C = 333) : t0.contains(i8, e) ? (m = "∥", E = "doublevert", C = 556) : e === "[" || e === "\\lbrack" ? (s = "⎡", m = "⎢", d = "⎣", A = "Size4-Regular", E = "lbrack", C = 667) : e === "]" || e === "\\rbrack" ? (s = "⎤", m = "⎥", d = "⎦", A = "Size4-Regular", E = "rbrack", C = 667) : e === "\\lfloor" || e === "⌊" ? (m = s = "⎢", d = "⎣", A = "Size4-Regular", E = "lfloor", C = 667) : e === "\\lceil" || e === "⌈" ? (s = "⎡", m = d = "⎢", A = "Size4-Regular", E = "lceil", C = 667) : e === "\\rfloor" || e === "⌋" ? (m = s = "⎥", d = "⎦", A = "Size4-Regular", E = "rfloor", C = 667) : e === "\\rceil" || e === "⌉" ? (s = "⎤", m = d = "⎥", A = "Size4-Regular", E = "rceil", C = 667) : e === "(" || e === "\\lparen" ? (s = "⎛", m = "⎜", d = "⎝", A = "Size4-Regular", E = "lparen", C = 875) : e === ")" || e === "\\rparen" ? (s = "⎞", m = "⎟", d = "⎠", A = "Size4-Regular", E = "rparen", C = 875) : e === "\\{" || e === "\\lbrace" ? (s = "⎧", i = "⎨", d = "⎩", m = "⎪", A = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (s = "⎫", i = "⎬", d = "⎭", m = "⎪", A = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (s = "⎧", d = "⎩", m = "⎪", A = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (s = "⎫", d = "⎭", m = "⎪", A = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (s = "⎧", d = "⎭", m = "⎪", A = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (s = "⎫", d = "⎩", m = "⎪", A = "Size4-Regular");
  var b = ct(s, A, n), y = b.height + b.depth, w = ct(m, A, n), P = w.height + w.depth, k = ct(d, A, n), f = k.height + k.depth, B = 0, D = 1;
  if (i !== null) {
    var p = ct(i, A, n);
    B = p.height + p.depth, D = 2;
  }
  var F = y + f + B, _ = Math.max(0, Math.ceil((t - F) / (D * P))), M = F + _ * D * P, R = a.fontMetrics().axisHeight;
  x && (R *= a.sizeMultiplier);
  var N = M / 2 - R, I = [];
  if (E.length > 0) {
    var $ = M - y - f, G = Math.round(M * 1e3), W = C9(E, Math.round($ * 1e3)), a0 = new qe(E, W), j = (C / 1e3).toFixed(3) + "em", K = (G / 1e3).toFixed(3) + "em", i0 = new ze([a0], {
      width: j,
      height: K,
      viewBox: "0 0 " + C + " " + G
    }), o0 = z.makeSvgSpan([], [i0], a);
    o0.height = G / 1e3, o0.style.width = j, o0.style.height = K, I.push({
      type: "elem",
      elem: o0
    });
  } else {
    if (I.push(vx(d, A, n)), I.push(_t), i === null) {
      var H = M - y - f + 2 * er;
      I.push(bx(m, H, a));
    } else {
      var x0 = (M - y - f - B) / 2 + 2 * er;
      I.push(bx(m, x0, a)), I.push(_t), I.push(vx(i, A, n)), I.push(_t), I.push(bx(m, x0, a));
    }
    I.push(_t), I.push(vx(s, A, n));
  }
  var l0 = a.havingBaseStyle(r0.TEXT), Z = z.makeVList({
    positionType: "bottom",
    positionData: N,
    children: I
  }, l0);
  return hr(z.makeSpan(["delimsizing", "mult"], [Z], l0), r0.TEXT, a, o);
}, kx = 80, wx = 0.08, yx = function(e, t, x, a, n) {
  var o = f9(e, a, x), s = new qe(e, o), i = new ze([s], {
    // Note: 1000:1 ratio of viewBox to document em width.
    width: "400em",
    height: U(t),
    viewBox: "0 0 400000 " + x,
    preserveAspectRatio: "xMinYMin slice"
  });
  return z.makeSvgSpan(["hide-tail"], [i], n);
}, s8 = function(e, t) {
  var x = t.havingBaseSizing(), a = Nn("\\surd", e * x.sizeMultiplier, Rn, x), n = x.sizeMultiplier, o = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), s, i = 0, m = 0, d = 0, E;
  return a.type === "small" ? (d = 1e3 + 1e3 * o + kx, e < 1 ? n = 1 : e < 1.4 && (n = 0.7), i = (1 + o + wx) / n, m = (1 + o) / n, s = yx("sqrtMain", i, d, o, t), s.style.minWidth = "0.853em", E = 0.833 / n) : a.type === "large" ? (d = (1e3 + kx) * dt[a.size], m = (dt[a.size] + o) / n, i = (dt[a.size] + o + wx) / n, s = yx("sqrtSize" + a.size, i, d, o, t), s.style.minWidth = "1.02em", E = 1 / n) : (i = e + o + wx, m = e + o, d = Math.floor(1e3 * e + o) + kx, s = yx("sqrtTall", i, d, o, t), s.style.minWidth = "0.742em", E = 1.056), s.height = m, s.style.height = U(i), {
    span: s,
    advanceWidth: E,
    // Calculate the actual line width.
    // This actually should depend on the chosen font -- e.g. \boldmath
    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
    // have thicker rules.
    ruleWidth: (t.fontMetrics().sqrtRuleThickness + o) * n
  };
}, _n = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"], u8 = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"], zn = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"], dt = [0, 1.2, 1.8, 2.4, 3], c8 = function(e, t, x, a, n) {
  if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), t0.contains(_n, e) || t0.contains(zn, e))
    return Mn(e, t, !1, x, a, n);
  if (t0.contains(u8, e))
    return Pn(e, dt[t], !1, x, a, n);
  throw new J("Illegal delimiter: '" + e + "'");
}, E8 = [{
  type: "small",
  style: r0.SCRIPTSCRIPT
}, {
  type: "small",
  style: r0.SCRIPT
}, {
  type: "small",
  style: r0.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}], d8 = [{
  type: "small",
  style: r0.SCRIPTSCRIPT
}, {
  type: "small",
  style: r0.SCRIPT
}, {
  type: "small",
  style: r0.TEXT
}, {
  type: "stack"
}], Rn = [{
  type: "small",
  style: r0.SCRIPTSCRIPT
}, {
  type: "small",
  style: r0.SCRIPT
}, {
  type: "small",
  style: r0.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}, {
  type: "stack"
}], m8 = function(e) {
  if (e.type === "small")
    return "Main-Regular";
  if (e.type === "large")
    return "Size" + e.size + "-Regular";
  if (e.type === "stack")
    return "Size4-Regular";
  throw new Error("Add support for delim type '" + e.type + "' here.");
}, Nn = function(e, t, x, a) {
  for (var n = Math.min(2, 3 - a.style.size), o = n; o < x.length && x[o].type !== "stack"; o++) {
    var s = ct(e, m8(x[o]), "math"), i = s.height + s.depth;
    if (x[o].type === "small") {
      var m = a.havingBaseStyle(x[o].style);
      i *= m.sizeMultiplier;
    }
    if (i > t)
      return x[o];
  }
  return x[x.length - 1];
}, Ln = function(e, t, x, a, n, o) {
  e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
  var s;
  t0.contains(zn, e) ? s = E8 : t0.contains(_n, e) ? s = Rn : s = d8;
  var i = Nn(e, t, s, a);
  return i.type === "small" ? n8(e, i.style, x, a, n, o) : i.type === "large" ? Mn(e, i.size, x, a, n, o) : Pn(e, t, x, a, n, o);
}, h8 = function(e, t, x, a, n, o) {
  var s = a.fontMetrics().axisHeight * a.sizeMultiplier, i = 901, m = 5 / a.fontMetrics().ptPerEm, d = Math.max(t - s, x + s), E = Math.max(
    // In real TeX, calculations are done using integral values which are
    // 65536 per pt, or 655360 per em. So, the division here truncates in
    // TeX but doesn't here, producing different results. If we wanted to
    // exactly match TeX's calculation, we could do
    //   Math.floor(655360 * maxDistFromAxis / 500) *
    //    delimiterFactor / 655360
    // (To see the difference, compare
    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
    // in TeX and KaTeX)
    d / 500 * i,
    2 * d - m
  );
  return Ln(e, E, !0, a, n, o);
}, ke = {
  sqrtImage: s8,
  sizedDelim: c8,
  sizeToMaxHeight: dt,
  customSizedDelim: Ln,
  leftRightDelim: h8
}, ma = {
  "\\bigl": {
    mclass: "mopen",
    size: 1
  },
  "\\Bigl": {
    mclass: "mopen",
    size: 2
  },
  "\\biggl": {
    mclass: "mopen",
    size: 3
  },
  "\\Biggl": {
    mclass: "mopen",
    size: 4
  },
  "\\bigr": {
    mclass: "mclose",
    size: 1
  },
  "\\Bigr": {
    mclass: "mclose",
    size: 2
  },
  "\\biggr": {
    mclass: "mclose",
    size: 3
  },
  "\\Biggr": {
    mclass: "mclose",
    size: 4
  },
  "\\bigm": {
    mclass: "mrel",
    size: 1
  },
  "\\Bigm": {
    mclass: "mrel",
    size: 2
  },
  "\\biggm": {
    mclass: "mrel",
    size: 3
  },
  "\\Biggm": {
    mclass: "mrel",
    size: 4
  },
  "\\big": {
    mclass: "mord",
    size: 1
  },
  "\\Big": {
    mclass: "mord",
    size: 2
  },
  "\\bigg": {
    mclass: "mord",
    size: 3
  },
  "\\Bigg": {
    mclass: "mord",
    size: 4
  }
}, f8 = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
function ox(r, e) {
  var t = ax(r);
  if (t && t0.contains(f8, t.text))
    return t;
  throw t ? new J("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", r) : new J("Invalid delimiter type '" + r.type + "'", r);
}
V({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  props: {
    numArgs: 1,
    argTypes: ["primitive"]
  },
  handler: (r, e) => {
    var t = ox(e[0], r);
    return {
      type: "delimsizing",
      mode: r.parser.mode,
      size: ma[r.funcName].size,
      mclass: ma[r.funcName].mclass,
      delim: t.text
    };
  },
  htmlBuilder: (r, e) => r.delim === "." ? z.makeSpan([r.mclass]) : ke.sizedDelim(r.delim, r.size, e, r.mode, [r.mclass]),
  mathmlBuilder: (r) => {
    var e = [];
    r.delim !== "." && e.push(le(r.delim, r.mode));
    var t = new O.MathNode("mo", e);
    r.mclass === "mopen" || r.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true");
    var x = U(ke.sizeToMaxHeight[r.size]);
    return t.setAttribute("minsize", x), t.setAttribute("maxsize", x), t;
  }
});
function ha(r) {
  if (!r.body)
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
V({
  type: "leftright-right",
  names: ["\\right"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = r.parser.gullet.macros.get("\\current@color");
    if (t && typeof t != "string")
      throw new J("\\current@color set to non-string in \\right");
    return {
      type: "leftright-right",
      mode: r.parser.mode,
      delim: ox(e[0], r).text,
      color: t
      // undefined if not set via \color
    };
  }
});
V({
  type: "leftright",
  names: ["\\left"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = ox(e[0], r), x = r.parser;
    ++x.leftrightDepth;
    var a = x.parseExpression(!1);
    --x.leftrightDepth, x.expect("\\right", !1);
    var n = s0(x.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: x.mode,
      body: a,
      left: t.text,
      right: n.delim,
      rightColor: n.color
    };
  },
  htmlBuilder: (r, e) => {
    ha(r);
    for (var t = R0(r.body, e, !0, ["mopen", "mclose"]), x = 0, a = 0, n = !1, o = 0; o < t.length; o++)
      t[o].isMiddle ? n = !0 : (x = Math.max(t[o].height, x), a = Math.max(t[o].depth, a));
    x *= e.sizeMultiplier, a *= e.sizeMultiplier;
    var s;
    if (r.left === "." ? s = Bt(e, ["mopen"]) : s = ke.leftRightDelim(r.left, x, a, e, r.mode, ["mopen"]), t.unshift(s), n)
      for (var i = 1; i < t.length; i++) {
        var m = t[i], d = m.isMiddle;
        d && (t[i] = ke.leftRightDelim(d.delim, x, a, d.options, r.mode, []));
      }
    var E;
    if (r.right === ".")
      E = Bt(e, ["mclose"]);
    else {
      var C = r.rightColor ? e.withColor(r.rightColor) : e;
      E = ke.leftRightDelim(r.right, x, a, C, r.mode, ["mclose"]);
    }
    return t.push(E), z.makeSpan(["minner"], t, e);
  },
  mathmlBuilder: (r, e) => {
    ha(r);
    var t = xe(r.body, e);
    if (r.left !== ".") {
      var x = new O.MathNode("mo", [le(r.left, r.mode)]);
      x.setAttribute("fence", "true"), t.unshift(x);
    }
    if (r.right !== ".") {
      var a = new O.MathNode("mo", [le(r.right, r.mode)]);
      a.setAttribute("fence", "true"), r.rightColor && a.setAttribute("mathcolor", r.rightColor), t.push(a);
    }
    return cr(t);
  }
});
V({
  type: "middle",
  names: ["\\middle"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = ox(e[0], r);
    if (!r.parser.leftrightDepth)
      throw new J("\\middle without preceding \\left", t);
    return {
      type: "middle",
      mode: r.parser.mode,
      delim: t.text
    };
  },
  htmlBuilder: (r, e) => {
    var t;
    if (r.delim === ".")
      t = Bt(e, []);
    else {
      t = ke.sizedDelim(r.delim, 1, e, r.mode, []);
      var x = {
        delim: r.delim,
        options: e
      };
      t.isMiddle = x;
    }
    return t;
  },
  mathmlBuilder: (r, e) => {
    var t = r.delim === "\\vert" || r.delim === "|" ? le("|", "text") : le(r.delim, r.mode), x = new O.MathNode("mo", [t]);
    return x.setAttribute("fence", "true"), x.setAttribute("lspace", "0.05em"), x.setAttribute("rspace", "0.05em"), x;
  }
});
var fr = (r, e) => {
  var t = z.wrapFragment(d0(r.body, e), e), x = r.label.slice(1), a = e.sizeMultiplier, n, o = 0, s = t0.isCharacterBox(r.body);
  if (x === "sout")
    n = z.makeSpan(["stretchy", "sout"]), n.height = e.fontMetrics().defaultRuleThickness / a, o = -0.5 * e.fontMetrics().xHeight;
  else if (x === "phase") {
    var i = p0({
      number: 0.6,
      unit: "pt"
    }, e), m = p0({
      number: 0.35,
      unit: "ex"
    }, e), d = e.havingBaseSizing();
    a = a / d.sizeMultiplier;
    var E = t.height + t.depth + i + m;
    t.style.paddingLeft = U(E / 2 + i);
    var C = Math.floor(1e3 * E * a), A = m9(C), b = new ze([new qe("phase", A)], {
      width: "400em",
      height: U(C / 1e3),
      viewBox: "0 0 400000 " + C,
      preserveAspectRatio: "xMinYMin slice"
    });
    n = z.makeSvgSpan(["hide-tail"], [b], e), n.style.height = U(E), o = t.depth + i + m;
  } else {
    /cancel/.test(x) ? s || t.classes.push("cancel-pad") : x === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
    var y = 0, w = 0, P = 0;
    /box/.test(x) ? (P = Math.max(
      e.fontMetrics().fboxrule,
      // default
      e.minRuleThickness
      // User override.
    ), y = e.fontMetrics().fboxsep + (x === "colorbox" ? 0 : P), w = y) : x === "angl" ? (P = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), y = 4 * P, w = Math.max(0, 0.25 - t.depth)) : (y = s ? 0.2 : 0, w = y), n = we.encloseSpan(t, x, y, w, e), /fbox|boxed|fcolorbox/.test(x) ? (n.style.borderStyle = "solid", n.style.borderWidth = U(P)) : x === "angl" && P !== 0.049 && (n.style.borderTopWidth = U(P), n.style.borderRightWidth = U(P)), o = t.depth + w, r.backgroundColor && (n.style.backgroundColor = r.backgroundColor, r.borderColor && (n.style.borderColor = r.borderColor));
  }
  var k;
  if (r.backgroundColor)
    k = z.makeVList({
      positionType: "individualShift",
      children: [
        // Put the color background behind inner;
        {
          type: "elem",
          elem: n,
          shift: o
        },
        {
          type: "elem",
          elem: t,
          shift: 0
        }
      ]
    }, e);
  else {
    var f = /cancel|phase/.test(x) ? ["svg-align"] : [];
    k = z.makeVList({
      positionType: "individualShift",
      children: [
        // Write the \cancel stroke on top of inner.
        {
          type: "elem",
          elem: t,
          shift: 0
        },
        {
          type: "elem",
          elem: n,
          shift: o,
          wrapperClasses: f
        }
      ]
    }, e);
  }
  return /cancel/.test(x) && (k.height = t.height, k.depth = t.depth), /cancel/.test(x) && !s ? z.makeSpan(["mord", "cancel-lap"], [k], e) : z.makeSpan(["mord"], [k], e);
}, Br = (r, e) => {
  var t = 0, x = new O.MathNode(r.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [B0(r.body, e)]);
  switch (r.label) {
    case "\\cancel":
      x.setAttribute("notation", "updiagonalstrike");
      break;
    case "\\bcancel":
      x.setAttribute("notation", "downdiagonalstrike");
      break;
    case "\\phase":
      x.setAttribute("notation", "phasorangle");
      break;
    case "\\sout":
      x.setAttribute("notation", "horizontalstrike");
      break;
    case "\\fbox":
      x.setAttribute("notation", "box");
      break;
    case "\\angl":
      x.setAttribute("notation", "actuarial");
      break;
    case "\\fcolorbox":
    case "\\colorbox":
      if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, x.setAttribute("width", "+" + 2 * t + "pt"), x.setAttribute("height", "+" + 2 * t + "pt"), x.setAttribute("lspace", t + "pt"), x.setAttribute("voffset", t + "pt"), r.label === "\\fcolorbox") {
        var a = Math.max(
          e.fontMetrics().fboxrule,
          // default
          e.minRuleThickness
          // user override
        );
        x.setAttribute("style", "border: " + a + "em solid " + String(r.borderColor));
      }
      break;
    case "\\xcancel":
      x.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
      break;
  }
  return r.backgroundColor && x.setAttribute("mathbackground", r.backgroundColor), x;
};
V({
  type: "enclose",
  names: ["\\colorbox"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "text"]
  },
  handler(r, e, t) {
    var {
      parser: x,
      funcName: a
    } = r, n = s0(e[0], "color-token").color, o = e[1];
    return {
      type: "enclose",
      mode: x.mode,
      label: a,
      backgroundColor: n,
      body: o
    };
  },
  htmlBuilder: fr,
  mathmlBuilder: Br
});
V({
  type: "enclose",
  names: ["\\fcolorbox"],
  props: {
    numArgs: 3,
    allowedInText: !0,
    argTypes: ["color", "color", "text"]
  },
  handler(r, e, t) {
    var {
      parser: x,
      funcName: a
    } = r, n = s0(e[0], "color-token").color, o = s0(e[1], "color-token").color, s = e[2];
    return {
      type: "enclose",
      mode: x.mode,
      label: a,
      backgroundColor: o,
      borderColor: n,
      body: s
    };
  },
  htmlBuilder: fr,
  mathmlBuilder: Br
});
V({
  type: "enclose",
  names: ["\\fbox"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\fbox",
      body: e[0]
    };
  }
});
V({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: x
    } = r, a = e[0];
    return {
      type: "enclose",
      mode: t.mode,
      label: x,
      body: a
    };
  },
  htmlBuilder: fr,
  mathmlBuilder: Br
});
V({
  type: "enclose",
  names: ["\\angl"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\angl",
      body: e[0]
    };
  }
});
var In = {};
function Ce(r) {
  for (var {
    type: e,
    names: t,
    props: x,
    handler: a,
    htmlBuilder: n,
    mathmlBuilder: o
  } = r, s = {
    type: e,
    numArgs: x.numArgs || 0,
    allowedInText: !1,
    numOptionalArgs: 0,
    handler: a
  }, i = 0; i < t.length; ++i)
    In[t[i]] = s;
  n && (Yt[e] = n), o && (Qt[e] = o);
}
var B8 = {};
function h(r, e) {
  B8[r] = e;
}
function fa(r) {
  var e = [];
  r.consumeSpaces();
  var t = r.fetch().text;
  for (t === "\\relax" && (r.consume(), r.consumeSpaces(), t = r.fetch().text); t === "\\hline" || t === "\\hdashline"; )
    r.consume(), e.push(t === "\\hdashline"), r.consumeSpaces(), t = r.fetch().text;
  return e;
}
var lx = (r) => {
  var e = r.parser.settings;
  if (!e.displayMode)
    throw new J("{" + r.envName + "} can be used only in display mode.");
};
function Cr(r) {
  if (r.indexOf("ed") === -1)
    return r.indexOf("*") === -1;
}
function Ne(r, e, t) {
  var {
    hskipBeforeAndAfter: x,
    addJot: a,
    cols: n,
    arraystretch: o,
    colSeparationType: s,
    autoTag: i,
    singleRow: m,
    emptySingleRow: d,
    maxNumCols: E,
    leqno: C
  } = e;
  if (r.gullet.beginGroup(), m || r.gullet.macros.set("\\cr", "\\\\\\relax"), !o) {
    var A = r.gullet.expandMacroAsText("\\arraystretch");
    if (A == null)
      o = 1;
    else if (o = parseFloat(A), !o || o < 0)
      throw new J("Invalid \\arraystretch: " + A);
  }
  r.gullet.beginGroup();
  var b = [], y = [b], w = [], P = [], k = i != null ? [] : void 0;
  function f() {
    i && r.gullet.macros.set("\\@eqnsw", "1", !0);
  }
  function B() {
    k && (r.gullet.macros.get("\\df@tag") ? (k.push(r.subparse([new lr("\\df@tag")])), r.gullet.macros.set("\\df@tag", void 0, !0)) : k.push(!!i && r.gullet.macros.get("\\@eqnsw") === "1"));
  }
  for (f(), P.push(fa(r)); ; ) {
    var D = r.parseExpression(!1, m ? "\\end" : "\\\\");
    r.gullet.endGroup(), r.gullet.beginGroup(), D = {
      type: "ordgroup",
      mode: r.mode,
      body: D
    }, t && (D = {
      type: "styling",
      mode: r.mode,
      style: t,
      body: [D]
    }), b.push(D);
    var p = r.fetch().text;
    if (p === "&") {
      if (E && b.length === E) {
        if (m || s)
          throw new J("Too many tab characters: &", r.nextToken);
        r.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
      }
      r.consume();
    } else if (p === "\\end") {
      B(), b.length === 1 && D.type === "styling" && D.body[0].body.length === 0 && (y.length > 1 || !d) && y.pop(), P.length < y.length + 1 && P.push([]);
      break;
    } else if (p === "\\\\") {
      r.consume();
      var F = void 0;
      r.gullet.future().text !== " " && (F = r.parseSizeGroup(!0)), w.push(F ? F.value : null), B(), P.push(fa(r)), b = [], y.push(b), f();
    } else
      throw new J("Expected & or \\\\ or \\cr or \\end", r.nextToken);
  }
  return r.gullet.endGroup(), r.gullet.endGroup(), {
    type: "array",
    mode: r.mode,
    addJot: a,
    arraystretch: o,
    body: y,
    cols: n,
    rowGaps: w,
    hskipBeforeAndAfter: x,
    hLinesBeforeRow: P,
    colSeparationType: s,
    tags: k,
    leqno: C
  };
}
function Ar(r) {
  return r.slice(0, 1) === "d" ? "display" : "text";
}
var Ae = function(e, t) {
  var x, a, n = e.body.length, o = e.hLinesBeforeRow, s = 0, i = new Array(n), m = [], d = Math.max(
    // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
    t.fontMetrics().arrayRuleWidth,
    t.minRuleThickness
    // User override.
  ), E = 1 / t.fontMetrics().ptPerEm, C = 5 * E;
  if (e.colSeparationType && e.colSeparationType === "small") {
    var A = t.havingStyle(r0.SCRIPT).sizeMultiplier;
    C = 0.2778 * (A / t.sizeMultiplier);
  }
  var b = e.colSeparationType === "CD" ? p0({
    number: 3,
    unit: "ex"
  }, t) : 12 * E, y = 3 * E, w = e.arraystretch * b, P = 0.7 * w, k = 0.3 * w, f = 0;
  function B(O0) {
    for (var w0 = 0; w0 < O0.length; ++w0)
      w0 > 0 && (f += 0.25), m.push({
        pos: f,
        isDashed: O0[w0]
      });
  }
  for (B(o[0]), x = 0; x < e.body.length; ++x) {
    var D = e.body[x], p = P, F = k;
    s < D.length && (s = D.length);
    var _ = new Array(D.length);
    for (a = 0; a < D.length; ++a) {
      var M = d0(D[a], t);
      F < M.depth && (F = M.depth), p < M.height && (p = M.height), _[a] = M;
    }
    var R = e.rowGaps[x], N = 0;
    R && (N = p0(R, t), N > 0 && (N += k, F < N && (F = N), N = 0)), e.addJot && (F += y), _.height = p, _.depth = F, f += p, _.pos = f, f += F + N, i[x] = _, B(o[x + 1]);
  }
  var I = f / 2 + t.fontMetrics().axisHeight, $ = e.cols || [], G = [], W, a0, j = [];
  if (e.tags && e.tags.some((O0) => O0))
    for (x = 0; x < n; ++x) {
      var K = i[x], i0 = K.pos - I, o0 = e.tags[x], H = void 0;
      o0 === !0 ? H = z.makeSpan(["eqn-num"], [], t) : o0 === !1 ? H = z.makeSpan([], [], t) : H = z.makeSpan([], R0(o0, t, !0), t), H.depth = K.depth, H.height = K.height, j.push({
        type: "elem",
        elem: H,
        shift: i0
      });
    }
  for (
    a = 0, a0 = 0;
    // Continue while either there are more columns or more column
    // descriptions, so trailing separators don't get lost.
    a < s || a0 < $.length;
    ++a, ++a0
  ) {
    for (var x0 = $[a0] || {}, l0 = !0; x0.type === "separator"; ) {
      if (l0 || (W = z.makeSpan(["arraycolsep"], []), W.style.width = U(t.fontMetrics().doubleRuleSep), G.push(W)), x0.separator === "|" || x0.separator === ":") {
        var Z = x0.separator === "|" ? "solid" : "dashed", u0 = z.makeSpan(["vertical-separator"], [], t);
        u0.style.height = U(f), u0.style.borderRightWidth = U(d), u0.style.borderRightStyle = Z, u0.style.margin = "0 " + U(-d / 2);
        var m0 = f - I;
        m0 && (u0.style.verticalAlign = U(-m0)), G.push(u0);
      } else
        throw new J("Invalid separator type: " + x0.separator);
      a0++, x0 = $[a0] || {}, l0 = !1;
    }
    if (!(a >= s)) {
      var E0 = void 0;
      (a > 0 || e.hskipBeforeAndAfter) && (E0 = t0.deflt(x0.pregap, C), E0 !== 0 && (W = z.makeSpan(["arraycolsep"], []), W.style.width = U(E0), G.push(W)));
      var T0 = [];
      for (x = 0; x < n; ++x) {
        var g0 = i[x], Z0 = g0[a];
        if (Z0) {
          var N0 = g0.pos - I;
          Z0.depth = g0.depth, Z0.height = g0.height, T0.push({
            type: "elem",
            elem: Z0,
            shift: N0
          });
        }
      }
      T0 = z.makeVList({
        positionType: "individualShift",
        children: T0
      }, t), T0 = z.makeSpan(["col-align-" + (x0.align || "c")], [T0]), G.push(T0), (a < s - 1 || e.hskipBeforeAndAfter) && (E0 = t0.deflt(x0.postgap, C), E0 !== 0 && (W = z.makeSpan(["arraycolsep"], []), W.style.width = U(E0), G.push(W)));
    }
  }
  if (i = z.makeSpan(["mtable"], G), m.length > 0) {
    for (var re = z.makeLineSpan("hline", t, d), W0 = z.makeLineSpan("hdashline", t, d), P0 = [{
      type: "elem",
      elem: i,
      shift: 0
    }]; m.length > 0; ) {
      var j0 = m.pop(), ae = j0.pos - I;
      j0.isDashed ? P0.push({
        type: "elem",
        elem: W0,
        shift: ae
      }) : P0.push({
        type: "elem",
        elem: re,
        shift: ae
      });
    }
    i = z.makeVList({
      positionType: "individualShift",
      children: P0
    }, t);
  }
  if (j.length === 0)
    return z.makeSpan(["mord"], [i], t);
  var I0 = z.makeVList({
    positionType: "individualShift",
    children: j
  }, t);
  return I0 = z.makeSpan(["tag"], [I0], t), z.makeFragment([i, I0]);
}, C8 = {
  c: "center ",
  l: "left ",
  r: "right "
}, De = function(e, t) {
  for (var x = [], a = new O.MathNode("mtd", [], ["mtr-glue"]), n = new O.MathNode("mtd", [], ["mml-eqn-num"]), o = 0; o < e.body.length; o++) {
    for (var s = e.body[o], i = [], m = 0; m < s.length; m++)
      i.push(new O.MathNode("mtd", [B0(s[m], t)]));
    e.tags && e.tags[o] && (i.unshift(a), i.push(a), e.leqno ? i.unshift(n) : i.push(n)), x.push(new O.MathNode("mtr", i));
  }
  var d = new O.MathNode("mtable", x), E = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
  d.setAttribute("rowspacing", U(E));
  var C = "", A = "";
  if (e.cols && e.cols.length > 0) {
    var b = e.cols, y = "", w = !1, P = 0, k = b.length;
    b[0].type === "separator" && (C += "top ", P = 1), b[b.length - 1].type === "separator" && (C += "bottom ", k -= 1);
    for (var f = P; f < k; f++)
      b[f].type === "align" ? (A += C8[b[f].align], w && (y += "none "), w = !0) : b[f].type === "separator" && w && (y += b[f].separator === "|" ? "solid " : "dashed ", w = !1);
    d.setAttribute("columnalign", A.trim()), /[sd]/.test(y) && d.setAttribute("columnlines", y.trim());
  }
  if (e.colSeparationType === "align") {
    for (var B = e.cols || [], D = "", p = 1; p < B.length; p++)
      D += p % 2 ? "0em " : "1em ";
    d.setAttribute("columnspacing", D.trim());
  } else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? d.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? d.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? d.setAttribute("columnspacing", "0.5em") : d.setAttribute("columnspacing", "1em");
  var F = "", _ = e.hLinesBeforeRow;
  C += _[0].length > 0 ? "left " : "", C += _[_.length - 1].length > 0 ? "right " : "";
  for (var M = 1; M < _.length - 1; M++)
    F += _[M].length === 0 ? "none " : _[M][0] ? "dashed " : "solid ";
  return /[sd]/.test(F) && d.setAttribute("rowlines", F.trim()), C !== "" && (d = new O.MathNode("menclose", [d]), d.setAttribute("notation", C.trim())), e.arraystretch && e.arraystretch < 1 && (d = new O.MathNode("mstyle", [d]), d.setAttribute("scriptlevel", "1")), d;
}, On = function(e, t) {
  e.envName.indexOf("ed") === -1 && lx(e);
  var x = [], a = e.envName.indexOf("at") > -1 ? "alignat" : "align", n = e.envName === "split", o = Ne(e.parser, {
    cols: x,
    addJot: !0,
    autoTag: n ? void 0 : Cr(e.envName),
    emptySingleRow: !0,
    colSeparationType: a,
    maxNumCols: n ? 2 : void 0,
    leqno: e.parser.settings.leqno
  }, "display"), s, i = 0, m = {
    type: "ordgroup",
    mode: e.mode,
    body: []
  };
  if (t[0] && t[0].type === "ordgroup") {
    for (var d = "", E = 0; E < t[0].body.length; E++) {
      var C = s0(t[0].body[E], "textord");
      d += C.text;
    }
    s = Number(d), i = s * 2;
  }
  var A = !i;
  o.body.forEach(function(P) {
    for (var k = 1; k < P.length; k += 2) {
      var f = s0(P[k], "styling"), B = s0(f.body[0], "ordgroup");
      B.body.unshift(m);
    }
    if (A)
      i < P.length && (i = P.length);
    else {
      var D = P.length / 2;
      if (s < D)
        throw new J("Too many math in a row: " + ("expected " + s + ", but got " + D), P[0]);
    }
  });
  for (var b = 0; b < i; ++b) {
    var y = "r", w = 0;
    b % 2 === 1 ? y = "l" : b > 0 && A && (w = 1), x[b] = {
      type: "align",
      align: y,
      pregap: w,
      postgap: 0
    };
  }
  return o.colSeparationType = A ? "align" : "alignat", o;
};
Ce({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var t = ax(e[0]), x = t ? [e[0]] : s0(e[0], "ordgroup").body, a = x.map(function(o) {
      var s = dr(o), i = s.text;
      if ("lcr".indexOf(i) !== -1)
        return {
          type: "align",
          align: i
        };
      if (i === "|")
        return {
          type: "separator",
          separator: "|"
        };
      if (i === ":")
        return {
          type: "separator",
          separator: ":"
        };
      throw new J("Unknown column alignment: " + i, o);
    }), n = {
      cols: a,
      hskipBeforeAndAfter: !0,
      // \@preamble in lttab.dtx
      maxNumCols: a.length
    };
    return Ne(r.parser, n, Ar(r.envName));
  },
  htmlBuilder: Ae,
  mathmlBuilder: De
});
Ce({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      matrix: null,
      pmatrix: ["(", ")"],
      bmatrix: ["[", "]"],
      Bmatrix: ["\\{", "\\}"],
      vmatrix: ["|", "|"],
      Vmatrix: ["\\Vert", "\\Vert"]
    }[r.envName.replace("*", "")], t = "c", x = {
      hskipBeforeAndAfter: !1,
      cols: [{
        type: "align",
        align: t
      }]
    };
    if (r.envName.charAt(r.envName.length - 1) === "*") {
      var a = r.parser;
      if (a.consumeSpaces(), a.fetch().text === "[") {
        if (a.consume(), a.consumeSpaces(), t = a.fetch().text, "lcr".indexOf(t) === -1)
          throw new J("Expected l or c or r", a.nextToken);
        a.consume(), a.consumeSpaces(), a.expect("]"), a.consume(), x.cols = [{
          type: "align",
          align: t
        }];
      }
    }
    var n = Ne(r.parser, x, Ar(r.envName)), o = Math.max(0, ...n.body.map((s) => s.length));
    return n.cols = new Array(o).fill({
      type: "align",
      align: t
    }), e ? {
      type: "leftright",
      mode: r.mode,
      body: [n],
      left: e[0],
      right: e[1],
      rightColor: void 0
      // \right uninfluenced by \color in array
    } : n;
  },
  htmlBuilder: Ae,
  mathmlBuilder: De
});
Ce({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      arraystretch: 0.5
    }, t = Ne(r.parser, e, "script");
    return t.colSeparationType = "small", t;
  },
  htmlBuilder: Ae,
  mathmlBuilder: De
});
Ce({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var t = ax(e[0]), x = t ? [e[0]] : s0(e[0], "ordgroup").body, a = x.map(function(o) {
      var s = dr(o), i = s.text;
      if ("lc".indexOf(i) !== -1)
        return {
          type: "align",
          align: i
        };
      throw new J("Unknown column alignment: " + i, o);
    });
    if (a.length > 1)
      throw new J("{subarray} can contain only one column");
    var n = {
      cols: a,
      hskipBeforeAndAfter: !1,
      arraystretch: 0.5
    };
    if (n = Ne(r.parser, n, "script"), n.body.length > 0 && n.body[0].length > 1)
      throw new J("{subarray} can contain only one column");
    return n;
  },
  htmlBuilder: Ae,
  mathmlBuilder: De
});
Ce({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      arraystretch: 1.2,
      cols: [{
        type: "align",
        align: "l",
        pregap: 0,
        // TODO(kevinb) get the current style.
        // For now we use the metrics for TEXT style which is what we were
        // doing before.  Before attempting to get the current style we
        // should look at TeX's behavior especially for \over and matrices.
        postgap: 1
        /* 1em quad */
      }, {
        type: "align",
        align: "l",
        pregap: 0,
        postgap: 0
      }]
    }, t = Ne(r.parser, e, Ar(r.envName));
    return {
      type: "leftright",
      mode: r.mode,
      body: [t],
      left: r.envName.indexOf("r") > -1 ? "." : "\\{",
      right: r.envName.indexOf("r") > -1 ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: Ae,
  mathmlBuilder: De
});
Ce({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: On,
  htmlBuilder: Ae,
  mathmlBuilder: De
});
Ce({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    t0.contains(["gather", "gather*"], r.envName) && lx(r);
    var e = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: !0,
      colSeparationType: "gather",
      autoTag: Cr(r.envName),
      emptySingleRow: !0,
      leqno: r.parser.settings.leqno
    };
    return Ne(r.parser, e, "display");
  },
  htmlBuilder: Ae,
  mathmlBuilder: De
});
Ce({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: On,
  htmlBuilder: Ae,
  mathmlBuilder: De
});
Ce({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    lx(r);
    var e = {
      autoTag: Cr(r.envName),
      emptySingleRow: !0,
      singleRow: !0,
      maxNumCols: 1,
      leqno: r.parser.settings.leqno
    };
    return Ne(r.parser, e, "display");
  },
  htmlBuilder: Ae,
  mathmlBuilder: De
});
Ce({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(r) {
    return lx(r), r8(r.parser);
  },
  htmlBuilder: Ae,
  mathmlBuilder: De
});
h("\\nonumber", "\\gdef\\@eqnsw{0}");
h("\\notag", "\\nonumber");
V({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\hline", "\\hdashline"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !0
  },
  handler(r, e) {
    throw new J(r.funcName + " valid only within array environment");
  }
});
var Ba = In;
V({
  type: "environment",
  names: ["\\begin", "\\end"],
  props: {
    numArgs: 1,
    argTypes: ["text"]
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: x
    } = r, a = e[0];
    if (a.type !== "ordgroup")
      throw new J("Invalid environment name", a);
    for (var n = "", o = 0; o < a.body.length; ++o)
      n += s0(a.body[o], "textord").text;
    if (x === "\\begin") {
      if (!Ba.hasOwnProperty(n))
        throw new J("No such environment: " + n, a);
      var s = Ba[n], {
        args: i,
        optArgs: m
      } = t.parseArguments("\\begin{" + n + "}", s), d = {
        mode: t.mode,
        envName: n,
        parser: t
      }, E = s.handler(d, i, m);
      t.expect("\\end", !1);
      var C = t.nextToken, A = s0(t.parseFunction(), "environment");
      if (A.name !== n)
        throw new J("Mismatch: \\begin{" + n + "} matched by \\end{" + A.name + "}", C);
      return E;
    }
    return {
      type: "environment",
      mode: t.mode,
      name: n,
      nameGroup: a
    };
  }
});
var qn = (r, e) => {
  var t = r.font, x = e.withFont(t);
  return d0(r.body, x);
}, Hn = (r, e) => {
  var t = r.font, x = e.withFont(t);
  return B0(r.body, x);
}, Ca = {
  "\\Bbb": "\\mathbb",
  "\\bold": "\\mathbf",
  "\\frak": "\\mathfrak",
  "\\bm": "\\boldsymbol"
};
V({
  type: "font",
  names: [
    // styles, except \boldsymbol defined below
    "\\mathrm",
    "\\mathit",
    "\\mathbf",
    "\\mathnormal",
    // families
    "\\mathbb",
    "\\mathcal",
    "\\mathfrak",
    "\\mathscr",
    "\\mathsf",
    "\\mathtt",
    // aliases, except \bm defined below
    "\\Bbb",
    "\\bold",
    "\\frak"
  ],
  props: {
    numArgs: 1,
    allowedInArgument: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: x
    } = r, a = Zt(e[0]), n = x;
    return n in Ca && (n = Ca[n]), {
      type: "font",
      mode: t.mode,
      font: n.slice(1),
      body: a
    };
  },
  htmlBuilder: qn,
  mathmlBuilder: Hn
});
V({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, x = e[0], a = t0.isCharacterBox(x);
    return {
      type: "mclass",
      mode: t.mode,
      mclass: nx(x),
      body: [{
        type: "font",
        mode: t.mode,
        font: "boldsymbol",
        body: x
      }],
      isCharacterBox: a
    };
  }
});
V({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: x,
      breakOnTokenText: a
    } = r, {
      mode: n
    } = t, o = t.parseExpression(!0, a), s = "math" + x.slice(1);
    return {
      type: "font",
      mode: n,
      font: s,
      body: {
        type: "ordgroup",
        mode: t.mode,
        body: o
      }
    };
  },
  htmlBuilder: qn,
  mathmlBuilder: Hn
});
var Un = (r, e) => {
  var t = e;
  return r === "display" ? t = t.id >= r0.SCRIPT.id ? t.text() : r0.DISPLAY : r === "text" && t.size === r0.DISPLAY.size ? t = r0.TEXT : r === "script" ? t = r0.SCRIPT : r === "scriptscript" && (t = r0.SCRIPTSCRIPT), t;
}, Dr = (r, e) => {
  var t = Un(r.size, e.style), x = t.fracNum(), a = t.fracDen(), n;
  n = e.havingStyle(x);
  var o = d0(r.numer, n, e);
  if (r.continued) {
    var s = 8.5 / e.fontMetrics().ptPerEm, i = 3.5 / e.fontMetrics().ptPerEm;
    o.height = o.height < s ? s : o.height, o.depth = o.depth < i ? i : o.depth;
  }
  n = e.havingStyle(a);
  var m = d0(r.denom, n, e), d, E, C;
  r.hasBarLine ? (r.barSize ? (E = p0(r.barSize, e), d = z.makeLineSpan("frac-line", e, E)) : d = z.makeLineSpan("frac-line", e), E = d.height, C = d.height) : (d = null, E = 0, C = e.fontMetrics().defaultRuleThickness);
  var A, b, y;
  t.size === r0.DISPLAY.size || r.size === "display" ? (A = e.fontMetrics().num1, E > 0 ? b = 3 * C : b = 7 * C, y = e.fontMetrics().denom1) : (E > 0 ? (A = e.fontMetrics().num2, b = C) : (A = e.fontMetrics().num3, b = 3 * C), y = e.fontMetrics().denom2);
  var w;
  if (d) {
    var k = e.fontMetrics().axisHeight;
    A - o.depth - (k + 0.5 * E) < b && (A += b - (A - o.depth - (k + 0.5 * E))), k - 0.5 * E - (m.height - y) < b && (y += b - (k - 0.5 * E - (m.height - y)));
    var f = -(k - 0.5 * E);
    w = z.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: m,
        shift: y
      }, {
        type: "elem",
        elem: d,
        shift: f
      }, {
        type: "elem",
        elem: o,
        shift: -A
      }]
    }, e);
  } else {
    var P = A - o.depth - (m.height - y);
    P < b && (A += 0.5 * (b - P), y += 0.5 * (b - P)), w = z.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: m,
        shift: y
      }, {
        type: "elem",
        elem: o,
        shift: -A
      }]
    }, e);
  }
  n = e.havingStyle(t), w.height *= n.sizeMultiplier / e.sizeMultiplier, w.depth *= n.sizeMultiplier / e.sizeMultiplier;
  var B;
  t.size === r0.DISPLAY.size ? B = e.fontMetrics().delim1 : t.size === r0.SCRIPTSCRIPT.size ? B = e.havingStyle(r0.SCRIPT).fontMetrics().delim2 : B = e.fontMetrics().delim2;
  var D, p;
  return r.leftDelim == null ? D = Bt(e, ["mopen"]) : D = ke.customSizedDelim(r.leftDelim, B, !0, e.havingStyle(t), r.mode, ["mopen"]), r.continued ? p = z.makeSpan([]) : r.rightDelim == null ? p = Bt(e, ["mclose"]) : p = ke.customSizedDelim(r.rightDelim, B, !0, e.havingStyle(t), r.mode, ["mclose"]), z.makeSpan(["mord"].concat(n.sizingClasses(e)), [D, z.makeSpan(["mfrac"], [w]), p], e);
}, Fr = (r, e) => {
  var t = new O.MathNode("mfrac", [B0(r.numer, e), B0(r.denom, e)]);
  if (!r.hasBarLine)
    t.setAttribute("linethickness", "0px");
  else if (r.barSize) {
    var x = p0(r.barSize, e);
    t.setAttribute("linethickness", U(x));
  }
  var a = Un(r.size, e.style);
  if (a.size !== e.style.size) {
    t = new O.MathNode("mstyle", [t]);
    var n = a.size === r0.DISPLAY.size ? "true" : "false";
    t.setAttribute("displaystyle", n), t.setAttribute("scriptlevel", "0");
  }
  if (r.leftDelim != null || r.rightDelim != null) {
    var o = [];
    if (r.leftDelim != null) {
      var s = new O.MathNode("mo", [new O.TextNode(r.leftDelim.replace("\\", ""))]);
      s.setAttribute("fence", "true"), o.push(s);
    }
    if (o.push(t), r.rightDelim != null) {
      var i = new O.MathNode("mo", [new O.TextNode(r.rightDelim.replace("\\", ""))]);
      i.setAttribute("fence", "true"), o.push(i);
    }
    return cr(o);
  }
  return t;
};
V({
  type: "genfrac",
  names: [
    "\\dfrac",
    "\\frac",
    "\\tfrac",
    "\\dbinom",
    "\\binom",
    "\\tbinom",
    "\\\\atopfrac",
    // can’t be entered directly
    "\\\\bracefrac",
    "\\\\brackfrac"
    // ditto
  ],
  props: {
    numArgs: 2,
    allowedInArgument: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: x
    } = r, a = e[0], n = e[1], o, s = null, i = null, m = "auto";
    switch (x) {
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        o = !0;
        break;
      case "\\\\atopfrac":
        o = !1;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        o = !1, s = "(", i = ")";
        break;
      case "\\\\bracefrac":
        o = !1, s = "\\{", i = "\\}";
        break;
      case "\\\\brackfrac":
        o = !1, s = "[", i = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    switch (x) {
      case "\\dfrac":
      case "\\dbinom":
        m = "display";
        break;
      case "\\tfrac":
      case "\\tbinom":
        m = "text";
        break;
    }
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !1,
      numer: a,
      denom: n,
      hasBarLine: o,
      leftDelim: s,
      rightDelim: i,
      size: m,
      barSize: null
    };
  },
  htmlBuilder: Dr,
  mathmlBuilder: Fr
});
V({
  type: "genfrac",
  names: ["\\cfrac"],
  props: {
    numArgs: 2
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: x
    } = r, a = e[0], n = e[1];
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !0,
      numer: a,
      denom: n,
      hasBarLine: !0,
      leftDelim: null,
      rightDelim: null,
      size: "display",
      barSize: null
    };
  }
});
V({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  props: {
    numArgs: 0,
    infix: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t,
      token: x
    } = r, a;
    switch (t) {
      case "\\over":
        a = "\\frac";
        break;
      case "\\choose":
        a = "\\binom";
        break;
      case "\\atop":
        a = "\\\\atopfrac";
        break;
      case "\\brace":
        a = "\\\\bracefrac";
        break;
      case "\\brack":
        a = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: e.mode,
      replaceWith: a,
      token: x
    };
  }
});
var Aa = ["display", "text", "script", "scriptscript"], Da = function(e) {
  var t = null;
  return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
V({
  type: "genfrac",
  names: ["\\genfrac"],
  props: {
    numArgs: 6,
    allowedInArgument: !0,
    argTypes: ["math", "math", "size", "text", "math", "math"]
  },
  handler(r, e) {
    var {
      parser: t
    } = r, x = e[4], a = e[5], n = Zt(e[0]), o = n.type === "atom" && n.family === "open" ? Da(n.text) : null, s = Zt(e[1]), i = s.type === "atom" && s.family === "close" ? Da(s.text) : null, m = s0(e[2], "size"), d, E = null;
    m.isBlank ? d = !0 : (E = m.value, d = E.number > 0);
    var C = "auto", A = e[3];
    if (A.type === "ordgroup") {
      if (A.body.length > 0) {
        var b = s0(A.body[0], "textord");
        C = Aa[Number(b.text)];
      }
    } else
      A = s0(A, "textord"), C = Aa[Number(A.text)];
    return {
      type: "genfrac",
      mode: t.mode,
      numer: x,
      denom: a,
      continued: !1,
      hasBarLine: d,
      barSize: E,
      leftDelim: o,
      rightDelim: i,
      size: C
    };
  },
  htmlBuilder: Dr,
  mathmlBuilder: Fr
});
V({
  type: "infix",
  names: ["\\above"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    infix: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: x,
      token: a
    } = r;
    return {
      type: "infix",
      mode: t.mode,
      replaceWith: "\\\\abovefrac",
      size: s0(e[0], "size").value,
      token: a
    };
  }
});
V({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  props: {
    numArgs: 3,
    argTypes: ["math", "size", "math"]
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: x
    } = r, a = e[0], n = J1(s0(e[1], "infix").size), o = e[2], s = n.number > 0;
    return {
      type: "genfrac",
      mode: t.mode,
      numer: a,
      denom: o,
      continued: !1,
      hasBarLine: s,
      barSize: n,
      leftDelim: null,
      rightDelim: null,
      size: "auto"
    };
  },
  htmlBuilder: Dr,
  mathmlBuilder: Fr
});
var Gn = (r, e) => {
  var t = e.style, x, a;
  r.type === "supsub" ? (x = r.sup ? d0(r.sup, e.havingStyle(t.sup()), e) : d0(r.sub, e.havingStyle(t.sub()), e), a = s0(r.base, "horizBrace")) : a = s0(r, "horizBrace");
  var n = d0(a.base, e.havingBaseStyle(r0.DISPLAY)), o = we.svgSpan(a, e), s;
  if (a.isOver ? (s = z.makeVList({
    positionType: "firstBaseline",
    children: [{
      type: "elem",
      elem: n
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: o
    }]
  }, e), s.children[0].children[0].children[1].classes.push("svg-align")) : (s = z.makeVList({
    positionType: "bottom",
    positionData: n.depth + 0.1 + o.height,
    children: [{
      type: "elem",
      elem: o
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: n
    }]
  }, e), s.children[0].children[0].children[0].classes.push("svg-align")), x) {
    var i = z.makeSpan(["mord", a.isOver ? "mover" : "munder"], [s], e);
    a.isOver ? s = z.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: x
      }]
    }, e) : s = z.makeVList({
      positionType: "bottom",
      positionData: i.depth + 0.2 + x.height + x.depth,
      children: [{
        type: "elem",
        elem: x
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: i
      }]
    }, e);
  }
  return z.makeSpan(["mord", a.isOver ? "mover" : "munder"], [s], e);
}, A8 = (r, e) => {
  var t = we.mathMLnode(r.label);
  return new O.MathNode(r.isOver ? "mover" : "munder", [B0(r.base, e), t]);
};
V({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: x
    } = r;
    return {
      type: "horizBrace",
      mode: t.mode,
      label: x,
      isOver: /^\\over/.test(x),
      base: e[0]
    };
  },
  htmlBuilder: Gn,
  mathmlBuilder: A8
});
V({
  type: "href",
  names: ["\\href"],
  props: {
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, x = e[1], a = s0(e[0], "url").url;
    return t.settings.isTrusted({
      command: "\\href",
      url: a
    }) ? {
      type: "href",
      mode: t.mode,
      href: a,
      body: b0(x)
    } : t.formatUnsupportedCmd("\\href");
  },
  htmlBuilder: (r, e) => {
    var t = R0(r.body, e, !1);
    return z.makeAnchor(r.href, [], t, e);
  },
  mathmlBuilder: (r, e) => {
    var t = Re(r.body, e);
    return t instanceof ce || (t = new ce("mrow", [t])), t.setAttribute("href", r.href), t;
  }
});
V({
  type: "href",
  names: ["\\url"],
  props: {
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, x = s0(e[0], "url").url;
    if (!t.settings.isTrusted({
      command: "\\url",
      url: x
    }))
      return t.formatUnsupportedCmd("\\url");
    for (var a = [], n = 0; n < x.length; n++) {
      var o = x[n];
      o === "~" && (o = "\\textasciitilde"), a.push({
        type: "textord",
        mode: "text",
        text: o
      });
    }
    var s = {
      type: "text",
      mode: t.mode,
      font: "\\texttt",
      body: a
    };
    return {
      type: "href",
      mode: t.mode,
      href: x,
      body: b0(s)
    };
  }
});
V({
  type: "hbox",
  names: ["\\hbox"],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: !0,
    primitive: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "hbox",
      mode: t.mode,
      body: b0(e[0])
    };
  },
  htmlBuilder(r, e) {
    var t = R0(r.body, e, !1);
    return z.makeFragment(t);
  },
  mathmlBuilder(r, e) {
    return new O.MathNode("mrow", xe(r.body, e));
  }
});
V({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  props: {
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: x,
      token: a
    } = r, n = s0(e[0], "raw").string, o = e[1];
    t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    var s, i = {};
    switch (x) {
      case "\\htmlClass":
        i.class = n, s = {
          command: "\\htmlClass",
          class: n
        };
        break;
      case "\\htmlId":
        i.id = n, s = {
          command: "\\htmlId",
          id: n
        };
        break;
      case "\\htmlStyle":
        i.style = n, s = {
          command: "\\htmlStyle",
          style: n
        };
        break;
      case "\\htmlData": {
        for (var m = n.split(","), d = 0; d < m.length; d++) {
          var E = m[d].split("=");
          if (E.length !== 2)
            throw new J("Error parsing key-value for \\htmlData");
          i["data-" + E[0].trim()] = E[1].trim();
        }
        s = {
          command: "\\htmlData",
          attributes: i
        };
        break;
      }
      default:
        throw new Error("Unrecognized html command");
    }
    return t.settings.isTrusted(s) ? {
      type: "html",
      mode: t.mode,
      attributes: i,
      body: b0(o)
    } : t.formatUnsupportedCmd(x);
  },
  htmlBuilder: (r, e) => {
    var t = R0(r.body, e, !1), x = ["enclosing"];
    r.attributes.class && x.push(...r.attributes.class.trim().split(/\s+/));
    var a = z.makeSpan(x, t, e);
    for (var n in r.attributes)
      n !== "class" && r.attributes.hasOwnProperty(n) && a.setAttribute(n, r.attributes[n]);
    return a;
  },
  mathmlBuilder: (r, e) => Re(r.body, e)
});
V({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  props: {
    numArgs: 2,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r;
    return {
      type: "htmlmathml",
      mode: t.mode,
      html: b0(e[0]),
      mathml: b0(e[1])
    };
  },
  htmlBuilder: (r, e) => {
    var t = R0(r.html, e, !1);
    return z.makeFragment(t);
  },
  mathmlBuilder: (r, e) => Re(r.mathml, e)
});
var Sx = function(e) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
    return {
      number: +e,
      unit: "bp"
    };
  var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
  if (!t)
    throw new J("Invalid size: '" + e + "' in \\includegraphics");
  var x = {
    number: +(t[1] + t[2]),
    // sign + magnitude, cast to number
    unit: t[3]
  };
  if (!D9(x))
    throw new J("Invalid unit: '" + x.unit + "' in \\includegraphics.");
  return x;
};
V({
  type: "includegraphics",
  names: ["\\includegraphics"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: !1
  },
  handler: (r, e, t) => {
    var {
      parser: x
    } = r, a = {
      number: 0,
      unit: "em"
    }, n = {
      number: 0.9,
      unit: "em"
    }, o = {
      number: 0,
      unit: "em"
    }, s = "";
    if (t[0])
      for (var i = s0(t[0], "raw").string, m = i.split(","), d = 0; d < m.length; d++) {
        var E = m[d].split("=");
        if (E.length === 2) {
          var C = E[1].trim();
          switch (E[0].trim()) {
            case "alt":
              s = C;
              break;
            case "width":
              a = Sx(C);
              break;
            case "height":
              n = Sx(C);
              break;
            case "totalheight":
              o = Sx(C);
              break;
            default:
              throw new J("Invalid key: '" + E[0] + "' in \\includegraphics.");
          }
        }
      }
    var A = s0(e[0], "url").url;
    return s === "" && (s = A, s = s.replace(/^.*[\\/]/, ""), s = s.substring(0, s.lastIndexOf("."))), x.settings.isTrusted({
      command: "\\includegraphics",
      url: A
    }) ? {
      type: "includegraphics",
      mode: x.mode,
      alt: s,
      width: a,
      height: n,
      totalheight: o,
      src: A
    } : x.formatUnsupportedCmd("\\includegraphics");
  },
  htmlBuilder: (r, e) => {
    var t = p0(r.height, e), x = 0;
    r.totalheight.number > 0 && (x = p0(r.totalheight, e) - t);
    var a = 0;
    r.width.number > 0 && (a = p0(r.width, e));
    var n = {
      height: U(t + x)
    };
    a > 0 && (n.width = U(a)), x > 0 && (n.verticalAlign = U(-x));
    var o = new F9(r.src, r.alt, n);
    return o.height = t, o.depth = x, o;
  },
  mathmlBuilder: (r, e) => {
    var t = new O.MathNode("mglyph", []);
    t.setAttribute("alt", r.alt);
    var x = p0(r.height, e), a = 0;
    if (r.totalheight.number > 0 && (a = p0(r.totalheight, e) - x, t.setAttribute("valign", U(-a))), t.setAttribute("height", U(x + a)), r.width.number > 0) {
      var n = p0(r.width, e);
      t.setAttribute("width", U(n));
    }
    return t.setAttribute("src", r.src), t;
  }
});
V({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    primitive: !0,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: x
    } = r, a = s0(e[0], "size");
    if (t.settings.strict) {
      var n = x[1] === "m", o = a.value.unit === "mu";
      n ? (o || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + x + " supports only mu units, " + ("not " + a.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + x + " works only in math mode")) : o && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + x + " doesn't support mu units");
    }
    return {
      type: "kern",
      mode: t.mode,
      dimension: a.value
    };
  },
  htmlBuilder(r, e) {
    return z.makeGlue(r.dimension, e);
  },
  mathmlBuilder(r, e) {
    var t = p0(r.dimension, e);
    return new O.SpaceNode(t);
  }
});
V({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: x
    } = r, a = e[0];
    return {
      type: "lap",
      mode: t.mode,
      alignment: x.slice(5),
      body: a
    };
  },
  htmlBuilder: (r, e) => {
    var t;
    r.alignment === "clap" ? (t = z.makeSpan([], [d0(r.body, e)]), t = z.makeSpan(["inner"], [t], e)) : t = z.makeSpan(["inner"], [d0(r.body, e)]);
    var x = z.makeSpan(["fix"], []), a = z.makeSpan([r.alignment], [t, x], e), n = z.makeSpan(["strut"]);
    return n.style.height = U(a.height + a.depth), a.depth && (n.style.verticalAlign = U(-a.depth)), a.children.unshift(n), a = z.makeSpan(["thinbox"], [a], e), z.makeSpan(["mord", "vbox"], [a], e);
  },
  mathmlBuilder: (r, e) => {
    var t = new O.MathNode("mpadded", [B0(r.body, e)]);
    if (r.alignment !== "rlap") {
      var x = r.alignment === "llap" ? "-1" : "-0.5";
      t.setAttribute("lspace", x + "width");
    }
    return t.setAttribute("width", "0px"), t;
  }
});
V({
  type: "styling",
  names: ["\\(", "$"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(r, e) {
    var {
      funcName: t,
      parser: x
    } = r, a = x.mode;
    x.switchMode("math");
    var n = t === "\\(" ? "\\)" : "$", o = x.parseExpression(!1, n);
    return x.expect(n), x.switchMode(a), {
      type: "styling",
      mode: x.mode,
      style: "text",
      body: o
    };
  }
});
V({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\)", "\\]"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(r, e) {
    throw new J("Mismatched " + r.funcName);
  }
});
var Fa = (r, e) => {
  switch (e.style.size) {
    case r0.DISPLAY.size:
      return r.display;
    case r0.TEXT.size:
      return r.text;
    case r0.SCRIPT.size:
      return r.script;
    case r0.SCRIPTSCRIPT.size:
      return r.scriptscript;
    default:
      return r.text;
  }
};
V({
  type: "mathchoice",
  names: ["\\mathchoice"],
  props: {
    numArgs: 4,
    primitive: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r;
    return {
      type: "mathchoice",
      mode: t.mode,
      display: b0(e[0]),
      text: b0(e[1]),
      script: b0(e[2]),
      scriptscript: b0(e[3])
    };
  },
  htmlBuilder: (r, e) => {
    var t = Fa(r, e), x = R0(t, e, !1);
    return z.makeFragment(x);
  },
  mathmlBuilder: (r, e) => {
    var t = Fa(r, e);
    return Re(t, e);
  }
});
var Vn = (r, e, t, x, a, n, o) => {
  r = z.makeSpan([], [r]);
  var s = t && t0.isCharacterBox(t), i, m;
  if (e) {
    var d = d0(e, x.havingStyle(a.sup()), x);
    m = {
      elem: d,
      kern: Math.max(x.fontMetrics().bigOpSpacing1, x.fontMetrics().bigOpSpacing3 - d.depth)
    };
  }
  if (t) {
    var E = d0(t, x.havingStyle(a.sub()), x);
    i = {
      elem: E,
      kern: Math.max(x.fontMetrics().bigOpSpacing2, x.fontMetrics().bigOpSpacing4 - E.height)
    };
  }
  var C;
  if (m && i) {
    var A = x.fontMetrics().bigOpSpacing5 + i.elem.height + i.elem.depth + i.kern + r.depth + o;
    C = z.makeVList({
      positionType: "bottom",
      positionData: A,
      children: [{
        type: "kern",
        size: x.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: i.elem,
        marginLeft: U(-n)
      }, {
        type: "kern",
        size: i.kern
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: m.kern
      }, {
        type: "elem",
        elem: m.elem,
        marginLeft: U(n)
      }, {
        type: "kern",
        size: x.fontMetrics().bigOpSpacing5
      }]
    }, x);
  } else if (i) {
    var b = r.height - o;
    C = z.makeVList({
      positionType: "top",
      positionData: b,
      children: [{
        type: "kern",
        size: x.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: i.elem,
        marginLeft: U(-n)
      }, {
        type: "kern",
        size: i.kern
      }, {
        type: "elem",
        elem: r
      }]
    }, x);
  } else if (m) {
    var y = r.depth + o;
    C = z.makeVList({
      positionType: "bottom",
      positionData: y,
      children: [{
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: m.kern
      }, {
        type: "elem",
        elem: m.elem,
        marginLeft: U(n)
      }, {
        type: "kern",
        size: x.fontMetrics().bigOpSpacing5
      }]
    }, x);
  } else
    return r;
  var w = [C];
  if (i && n !== 0 && !s) {
    var P = z.makeSpan(["mspace"], [], x);
    P.style.marginRight = U(n), w.unshift(P);
  }
  return z.makeSpan(["mop", "op-limits"], w, x);
}, Xn = ["\\smallint"], et = (r, e) => {
  var t, x, a = !1, n;
  r.type === "supsub" ? (t = r.sup, x = r.sub, n = s0(r.base, "op"), a = !0) : n = s0(r, "op");
  var o = e.style, s = !1;
  o.size === r0.DISPLAY.size && n.symbol && !t0.contains(Xn, n.name) && (s = !0);
  var i;
  if (n.symbol) {
    var m = s ? "Size2-Regular" : "Size1-Regular", d = "";
    if ((n.name === "\\oiint" || n.name === "\\oiiint") && (d = n.name.slice(1), n.name = d === "oiint" ? "\\iint" : "\\iiint"), i = z.makeSymbol(n.name, m, "math", e, ["mop", "op-symbol", s ? "large-op" : "small-op"]), d.length > 0) {
      var E = i.italic, C = z.staticSvg(d + "Size" + (s ? "2" : "1"), e);
      i = z.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: i,
          shift: 0
        }, {
          type: "elem",
          elem: C,
          shift: s ? 0.08 : 0
        }]
      }, e), n.name = "\\" + d, i.classes.unshift("mop"), i.italic = E;
    }
  } else if (n.body) {
    var A = R0(n.body, e, !0);
    A.length === 1 && A[0] instanceof Be ? (i = A[0], i.classes[0] = "mop") : i = z.makeSpan(["mop"], A, e);
  } else {
    for (var b = [], y = 1; y < n.name.length; y++)
      b.push(z.mathsym(n.name[y], n.mode, e));
    i = z.makeSpan(["mop"], b, e);
  }
  var w = 0, P = 0;
  return (i instanceof Be || n.name === "\\oiint" || n.name === "\\oiiint") && !n.suppressBaseShift && (w = (i.height - i.depth) / 2 - e.fontMetrics().axisHeight, P = i.italic), a ? Vn(i, t, x, e, o, P, w) : (w && (i.style.position = "relative", i.style.top = U(w)), i);
}, At = (r, e) => {
  var t;
  if (r.symbol)
    t = new ce("mo", [le(r.name, r.mode)]), t0.contains(Xn, r.name) && t.setAttribute("largeop", "false");
  else if (r.body)
    t = new ce("mo", xe(r.body, e));
  else {
    t = new ce("mi", [new Et(r.name.slice(1))]);
    var x = new ce("mo", [le("⁡", "text")]);
    r.parentIsSupSub ? t = new ce("mrow", [t, x]) : t = pn([t, x]);
  }
  return t;
}, D8 = {
  "∏": "\\prod",
  "∐": "\\coprod",
  "∑": "\\sum",
  "⋀": "\\bigwedge",
  "⋁": "\\bigvee",
  "⋂": "\\bigcap",
  "⋃": "\\bigcup",
  "⨀": "\\bigodot",
  "⨁": "\\bigoplus",
  "⨂": "\\bigotimes",
  "⨄": "\\biguplus",
  "⨆": "\\bigsqcup"
};
V({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
  props: {
    numArgs: 0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: x
    } = r, a = x;
    return a.length === 1 && (a = D8[a]), {
      type: "op",
      mode: t.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !0,
      name: a
    };
  },
  htmlBuilder: et,
  mathmlBuilder: At
});
V({
  type: "op",
  names: ["\\mathop"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, x = e[0];
    return {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      body: b0(x)
    };
  },
  htmlBuilder: et,
  mathmlBuilder: At
});
var F8 = {
  "∫": "\\int",
  "∬": "\\iint",
  "∭": "\\iiint",
  "∮": "\\oint",
  "∯": "\\oiint",
  "∰": "\\oiiint"
};
V({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    return {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: et,
  mathmlBuilder: At
});
V({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    return {
      type: "op",
      mode: e.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: et,
  mathmlBuilder: At
});
V({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, x = t;
    return x.length === 1 && (x = F8[x]), {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !0,
      name: x
    };
  },
  htmlBuilder: et,
  mathmlBuilder: At
});
var $n = (r, e) => {
  var t, x, a = !1, n;
  r.type === "supsub" ? (t = r.sup, x = r.sub, n = s0(r.base, "operatorname"), a = !0) : n = s0(r, "operatorname");
  var o;
  if (n.body.length > 0) {
    for (var s = n.body.map((E) => {
      var C = E.text;
      return typeof C == "string" ? {
        type: "textord",
        mode: E.mode,
        text: C
      } : E;
    }), i = R0(s, e.withFont("mathrm"), !0), m = 0; m < i.length; m++) {
      var d = i[m];
      d instanceof Be && (d.text = d.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
    }
    o = z.makeSpan(["mop"], i, e);
  } else
    o = z.makeSpan(["mop"], [], e);
  return a ? Vn(o, t, x, e, e.style, 0, 0) : o;
}, p8 = (r, e) => {
  for (var t = xe(r.body, e.withFont("mathrm")), x = !0, a = 0; a < t.length; a++) {
    var n = t[a];
    if (!(n instanceof O.SpaceNode)) if (n instanceof O.MathNode)
      switch (n.type) {
        case "mi":
        case "mn":
        case "ms":
        case "mspace":
        case "mtext":
          break;
        case "mo": {
          var o = n.children[0];
          n.children.length === 1 && o instanceof O.TextNode ? o.text = o.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : x = !1;
          break;
        }
        default:
          x = !1;
      }
    else
      x = !1;
  }
  if (x) {
    var s = t.map((d) => d.toText()).join("");
    t = [new O.TextNode(s)];
  }
  var i = new O.MathNode("mi", t);
  i.setAttribute("mathvariant", "normal");
  var m = new O.MathNode("mo", [le("⁡", "text")]);
  return r.parentIsSupSub ? new O.MathNode("mrow", [i, m]) : O.newDocumentFragment([i, m]);
};
V({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: x
    } = r, a = e[0];
    return {
      type: "operatorname",
      mode: t.mode,
      body: b0(a),
      alwaysHandleSupSub: x === "\\operatornamewithlimits",
      limits: !1,
      parentIsSupSub: !1
    };
  },
  htmlBuilder: $n,
  mathmlBuilder: p8
});
h("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
Ge({
  type: "ordgroup",
  htmlBuilder(r, e) {
    return r.semisimple ? z.makeFragment(R0(r.body, e, !1)) : z.makeSpan(["mord"], R0(r.body, e, !0), e);
  },
  mathmlBuilder(r, e) {
    return Re(r.body, e, !0);
  }
});
V({
  type: "overline",
  names: ["\\overline"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t
    } = r, x = e[0];
    return {
      type: "overline",
      mode: t.mode,
      body: x
    };
  },
  htmlBuilder(r, e) {
    var t = d0(r.body, e.havingCrampedStyle()), x = z.makeLineSpan("overline-line", e), a = e.fontMetrics().defaultRuleThickness, n = z.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: x
      }, {
        type: "kern",
        size: a
      }]
    }, e);
    return z.makeSpan(["mord", "overline"], [n], e);
  },
  mathmlBuilder(r, e) {
    var t = new O.MathNode("mo", [new O.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var x = new O.MathNode("mover", [B0(r.body, e), t]);
    return x.setAttribute("accent", "true"), x;
  }
});
V({
  type: "phantom",
  names: ["\\phantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, x = e[0];
    return {
      type: "phantom",
      mode: t.mode,
      body: b0(x)
    };
  },
  htmlBuilder: (r, e) => {
    var t = R0(r.body, e.withPhantom(), !1);
    return z.makeFragment(t);
  },
  mathmlBuilder: (r, e) => {
    var t = xe(r.body, e);
    return new O.MathNode("mphantom", t);
  }
});
V({
  type: "hphantom",
  names: ["\\hphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, x = e[0];
    return {
      type: "hphantom",
      mode: t.mode,
      body: x
    };
  },
  htmlBuilder: (r, e) => {
    var t = z.makeSpan([], [d0(r.body, e.withPhantom())]);
    if (t.height = 0, t.depth = 0, t.children)
      for (var x = 0; x < t.children.length; x++)
        t.children[x].height = 0, t.children[x].depth = 0;
    return t = z.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e), z.makeSpan(["mord"], [t], e);
  },
  mathmlBuilder: (r, e) => {
    var t = xe(b0(r.body), e), x = new O.MathNode("mphantom", t), a = new O.MathNode("mpadded", [x]);
    return a.setAttribute("height", "0px"), a.setAttribute("depth", "0px"), a;
  }
});
V({
  type: "vphantom",
  names: ["\\vphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, x = e[0];
    return {
      type: "vphantom",
      mode: t.mode,
      body: x
    };
  },
  htmlBuilder: (r, e) => {
    var t = z.makeSpan(["inner"], [d0(r.body, e.withPhantom())]), x = z.makeSpan(["fix"], []);
    return z.makeSpan(["mord", "rlap"], [t, x], e);
  },
  mathmlBuilder: (r, e) => {
    var t = xe(b0(r.body), e), x = new O.MathNode("mphantom", t), a = new O.MathNode("mpadded", [x]);
    return a.setAttribute("width", "0px"), a;
  }
});
V({
  type: "raisebox",
  names: ["\\raisebox"],
  props: {
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r, x = s0(e[0], "size").value, a = e[1];
    return {
      type: "raisebox",
      mode: t.mode,
      dy: x,
      body: a
    };
  },
  htmlBuilder(r, e) {
    var t = d0(r.body, e), x = p0(r.dy, e);
    return z.makeVList({
      positionType: "shift",
      positionData: -x,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(r, e) {
    var t = new O.MathNode("mpadded", [B0(r.body, e)]), x = r.dy.number + r.dy.unit;
    return t.setAttribute("voffset", x), t;
  }
});
V({
  type: "internal",
  names: ["\\relax"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r) {
    var {
      parser: e
    } = r;
    return {
      type: "internal",
      mode: e.mode
    };
  }
});
V({
  type: "rule",
  names: ["\\rule"],
  props: {
    numArgs: 2,
    numOptionalArgs: 1,
    argTypes: ["size", "size", "size"]
  },
  handler(r, e, t) {
    var {
      parser: x
    } = r, a = t[0], n = s0(e[0], "size"), o = s0(e[1], "size");
    return {
      type: "rule",
      mode: x.mode,
      shift: a && s0(a, "size").value,
      width: n.value,
      height: o.value
    };
  },
  htmlBuilder(r, e) {
    var t = z.makeSpan(["mord", "rule"], [], e), x = p0(r.width, e), a = p0(r.height, e), n = r.shift ? p0(r.shift, e) : 0;
    return t.style.borderRightWidth = U(x), t.style.borderTopWidth = U(a), t.style.bottom = U(n), t.width = x, t.height = a + n, t.depth = -n, t.maxFontSize = a * 1.125 * e.sizeMultiplier, t;
  },
  mathmlBuilder(r, e) {
    var t = p0(r.width, e), x = p0(r.height, e), a = r.shift ? p0(r.shift, e) : 0, n = e.color && e.getColor() || "black", o = new O.MathNode("mspace");
    o.setAttribute("mathbackground", n), o.setAttribute("width", U(t)), o.setAttribute("height", U(x));
    var s = new O.MathNode("mpadded", [o]);
    return a >= 0 ? s.setAttribute("height", U(a)) : (s.setAttribute("height", U(a)), s.setAttribute("depth", U(-a))), s.setAttribute("voffset", U(a)), s;
  }
});
function Wn(r, e, t) {
  for (var x = R0(r, e, !1), a = e.sizeMultiplier / t.sizeMultiplier, n = 0; n < x.length; n++) {
    var o = x[n].classes.indexOf("sizing");
    o < 0 ? Array.prototype.push.apply(x[n].classes, e.sizingClasses(t)) : x[n].classes[o + 1] === "reset-size" + e.size && (x[n].classes[o + 1] = "reset-size" + t.size), x[n].height *= a, x[n].depth *= a;
  }
  return z.makeFragment(x);
}
var pa = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], g8 = (r, e) => {
  var t = e.havingSize(r.size);
  return Wn(r.body, t, e);
};
V({
  type: "sizing",
  names: pa,
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      breakOnTokenText: t,
      funcName: x,
      parser: a
    } = r, n = a.parseExpression(!1, t);
    return {
      type: "sizing",
      mode: a.mode,
      // Figure out what size to use based on the list of functions above
      size: pa.indexOf(x) + 1,
      body: n
    };
  },
  htmlBuilder: g8,
  mathmlBuilder: (r, e) => {
    var t = e.havingSize(r.size), x = xe(r.body, t), a = new O.MathNode("mstyle", x);
    return a.setAttribute("mathsize", U(t.sizeMultiplier)), a;
  }
});
V({
  type: "smash",
  names: ["\\smash"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: !0
  },
  handler: (r, e, t) => {
    var {
      parser: x
    } = r, a = !1, n = !1, o = t[0] && s0(t[0], "ordgroup");
    if (o)
      for (var s = "", i = 0; i < o.body.length; ++i) {
        var m = o.body[i];
        if (s = m.text, s === "t")
          a = !0;
        else if (s === "b")
          n = !0;
        else {
          a = !1, n = !1;
          break;
        }
      }
    else
      a = !0, n = !0;
    var d = e[0];
    return {
      type: "smash",
      mode: x.mode,
      body: d,
      smashHeight: a,
      smashDepth: n
    };
  },
  htmlBuilder: (r, e) => {
    var t = z.makeSpan([], [d0(r.body, e)]);
    if (!r.smashHeight && !r.smashDepth)
      return t;
    if (r.smashHeight && (t.height = 0, t.children))
      for (var x = 0; x < t.children.length; x++)
        t.children[x].height = 0;
    if (r.smashDepth && (t.depth = 0, t.children))
      for (var a = 0; a < t.children.length; a++)
        t.children[a].depth = 0;
    var n = z.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
    return z.makeSpan(["mord"], [n], e);
  },
  mathmlBuilder: (r, e) => {
    var t = new O.MathNode("mpadded", [B0(r.body, e)]);
    return r.smashHeight && t.setAttribute("height", "0px"), r.smashDepth && t.setAttribute("depth", "0px"), t;
  }
});
V({
  type: "sqrt",
  names: ["\\sqrt"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(r, e, t) {
    var {
      parser: x
    } = r, a = t[0], n = e[0];
    return {
      type: "sqrt",
      mode: x.mode,
      body: n,
      index: a
    };
  },
  htmlBuilder(r, e) {
    var t = d0(r.body, e.havingCrampedStyle());
    t.height === 0 && (t.height = e.fontMetrics().xHeight), t = z.wrapFragment(t, e);
    var x = e.fontMetrics(), a = x.defaultRuleThickness, n = a;
    e.style.id < r0.TEXT.id && (n = e.fontMetrics().xHeight);
    var o = a + n / 4, s = t.height + t.depth + o + a, {
      span: i,
      ruleWidth: m,
      advanceWidth: d
    } = ke.sqrtImage(s, e), E = i.height - m;
    E > t.height + t.depth + o && (o = (o + E - t.height - t.depth) / 2);
    var C = i.height - t.height - o - m;
    t.style.paddingLeft = U(d);
    var A = z.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(t.height + C)
      }, {
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: m
      }]
    }, e);
    if (r.index) {
      var b = e.havingStyle(r0.SCRIPTSCRIPT), y = d0(r.index, b, e), w = 0.6 * (A.height - A.depth), P = z.makeVList({
        positionType: "shift",
        positionData: -w,
        children: [{
          type: "elem",
          elem: y
        }]
      }, e), k = z.makeSpan(["root"], [P]);
      return z.makeSpan(["mord", "sqrt"], [k, A], e);
    } else
      return z.makeSpan(["mord", "sqrt"], [A], e);
  },
  mathmlBuilder(r, e) {
    var {
      body: t,
      index: x
    } = r;
    return x ? new O.MathNode("mroot", [B0(t, e), B0(x, e)]) : new O.MathNode("msqrt", [B0(t, e)]);
  }
});
var ga = {
  display: r0.DISPLAY,
  text: r0.TEXT,
  script: r0.SCRIPT,
  scriptscript: r0.SCRIPTSCRIPT
};
V({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r, e) {
    var {
      breakOnTokenText: t,
      funcName: x,
      parser: a
    } = r, n = a.parseExpression(!0, t), o = x.slice(1, x.length - 5);
    return {
      type: "styling",
      mode: a.mode,
      // Figure out what style to use by pulling out the style from
      // the function name
      style: o,
      body: n
    };
  },
  htmlBuilder(r, e) {
    var t = ga[r.style], x = e.havingStyle(t).withFont("");
    return Wn(r.body, x, e);
  },
  mathmlBuilder(r, e) {
    var t = ga[r.style], x = e.havingStyle(t), a = xe(r.body, x), n = new O.MathNode("mstyle", a), o = {
      display: ["0", "true"],
      text: ["0", "false"],
      script: ["1", "false"],
      scriptscript: ["2", "false"]
    }, s = o[r.style];
    return n.setAttribute("scriptlevel", s[0]), n.setAttribute("displaystyle", s[1]), n;
  }
});
var v8 = function(e, t) {
  var x = e.base;
  if (x)
    if (x.type === "op") {
      var a = x.limits && (t.style.size === r0.DISPLAY.size || x.alwaysHandleSupSub);
      return a ? et : null;
    } else if (x.type === "operatorname") {
      var n = x.alwaysHandleSupSub && (t.style.size === r0.DISPLAY.size || x.limits);
      return n ? $n : null;
    } else {
      if (x.type === "accent")
        return t0.isCharacterBox(x.base) ? mr : null;
      if (x.type === "horizBrace") {
        var o = !e.sub;
        return o === x.isOver ? Gn : null;
      } else
        return null;
    }
  else return null;
};
Ge({
  type: "supsub",
  htmlBuilder(r, e) {
    var t = v8(r, e);
    if (t)
      return t(r, e);
    var {
      base: x,
      sup: a,
      sub: n
    } = r, o = d0(x, e), s, i, m = e.fontMetrics(), d = 0, E = 0, C = x && t0.isCharacterBox(x);
    if (a) {
      var A = e.havingStyle(e.style.sup());
      s = d0(a, A, e), C || (d = o.height - A.fontMetrics().supDrop * A.sizeMultiplier / e.sizeMultiplier);
    }
    if (n) {
      var b = e.havingStyle(e.style.sub());
      i = d0(n, b, e), C || (E = o.depth + b.fontMetrics().subDrop * b.sizeMultiplier / e.sizeMultiplier);
    }
    var y;
    e.style === r0.DISPLAY ? y = m.sup1 : e.style.cramped ? y = m.sup3 : y = m.sup2;
    var w = e.sizeMultiplier, P = U(0.5 / m.ptPerEm / w), k = null;
    if (i) {
      var f = r.base && r.base.type === "op" && r.base.name && (r.base.name === "\\oiint" || r.base.name === "\\oiiint");
      (o instanceof Be || f) && (k = U(-o.italic));
    }
    var B;
    if (s && i) {
      d = Math.max(d, y, s.depth + 0.25 * m.xHeight), E = Math.max(E, m.sub2);
      var D = m.defaultRuleThickness, p = 4 * D;
      if (d - s.depth - (i.height - E) < p) {
        E = p - (d - s.depth) + i.height;
        var F = 0.8 * m.xHeight - (d - s.depth);
        F > 0 && (d += F, E -= F);
      }
      var _ = [{
        type: "elem",
        elem: i,
        shift: E,
        marginRight: P,
        marginLeft: k
      }, {
        type: "elem",
        elem: s,
        shift: -d,
        marginRight: P
      }];
      B = z.makeVList({
        positionType: "individualShift",
        children: _
      }, e);
    } else if (i) {
      E = Math.max(E, m.sub1, i.height - 0.8 * m.xHeight);
      var M = [{
        type: "elem",
        elem: i,
        marginLeft: k,
        marginRight: P
      }];
      B = z.makeVList({
        positionType: "shift",
        positionData: E,
        children: M
      }, e);
    } else if (s)
      d = Math.max(d, y, s.depth + 0.25 * m.xHeight), B = z.makeVList({
        positionType: "shift",
        positionData: -d,
        children: [{
          type: "elem",
          elem: s,
          marginRight: P
        }]
      }, e);
    else
      throw new Error("supsub must have either sup or sub.");
    var R = Kx(o, "right") || "mord";
    return z.makeSpan([R], [o, z.makeSpan(["msupsub"], [B])], e);
  },
  mathmlBuilder(r, e) {
    var t = !1, x, a;
    r.base && r.base.type === "horizBrace" && (a = !!r.sup, a === r.base.isOver && (t = !0, x = r.base.isOver)), r.base && (r.base.type === "op" || r.base.type === "operatorname") && (r.base.parentIsSupSub = !0);
    var n = [B0(r.base, e)];
    r.sub && n.push(B0(r.sub, e)), r.sup && n.push(B0(r.sup, e));
    var o;
    if (t)
      o = x ? "mover" : "munder";
    else if (r.sub)
      if (r.sup) {
        var m = r.base;
        m && m.type === "op" && m.limits && e.style === r0.DISPLAY || m && m.type === "operatorname" && m.alwaysHandleSupSub && (e.style === r0.DISPLAY || m.limits) ? o = "munderover" : o = "msubsup";
      } else {
        var i = r.base;
        i && i.type === "op" && i.limits && (e.style === r0.DISPLAY || i.alwaysHandleSupSub) || i && i.type === "operatorname" && i.alwaysHandleSupSub && (i.limits || e.style === r0.DISPLAY) ? o = "munder" : o = "msub";
      }
    else {
      var s = r.base;
      s && s.type === "op" && s.limits && (e.style === r0.DISPLAY || s.alwaysHandleSupSub) || s && s.type === "operatorname" && s.alwaysHandleSupSub && (s.limits || e.style === r0.DISPLAY) ? o = "mover" : o = "msup";
    }
    return new O.MathNode(o, n);
  }
});
Ge({
  type: "atom",
  htmlBuilder(r, e) {
    return z.mathsym(r.text, r.mode, e, ["m" + r.family]);
  },
  mathmlBuilder(r, e) {
    var t = new O.MathNode("mo", [le(r.text, r.mode)]);
    if (r.family === "bin") {
      var x = Er(r, e);
      x === "bold-italic" && t.setAttribute("mathvariant", x);
    } else r.family === "punct" ? t.setAttribute("separator", "true") : (r.family === "open" || r.family === "close") && t.setAttribute("stretchy", "false");
    return t;
  }
});
var jn = {
  mi: "italic",
  mn: "normal",
  mtext: "normal"
};
Ge({
  type: "mathord",
  htmlBuilder(r, e) {
    return z.makeOrd(r, e, "mathord");
  },
  mathmlBuilder(r, e) {
    var t = new O.MathNode("mi", [le(r.text, r.mode, e)]), x = Er(r, e) || "italic";
    return x !== jn[t.type] && t.setAttribute("mathvariant", x), t;
  }
});
Ge({
  type: "textord",
  htmlBuilder(r, e) {
    return z.makeOrd(r, e, "textord");
  },
  mathmlBuilder(r, e) {
    var t = le(r.text, r.mode, e), x = Er(r, e) || "normal", a;
    return r.mode === "text" ? a = new O.MathNode("mtext", [t]) : /[0-9]/.test(r.text) ? a = new O.MathNode("mn", [t]) : r.text === "\\prime" ? a = new O.MathNode("mo", [t]) : a = new O.MathNode("mi", [t]), x !== jn[a.type] && a.setAttribute("mathvariant", x), a;
  }
});
var Tx = {
  "\\nobreak": "nobreak",
  "\\allowbreak": "allowbreak"
}, Mx = {
  " ": {},
  "\\ ": {},
  "~": {
    className: "nobreak"
  },
  "\\space": {},
  "\\nobreakspace": {
    className: "nobreak"
  }
};
Ge({
  type: "spacing",
  htmlBuilder(r, e) {
    if (Mx.hasOwnProperty(r.text)) {
      var t = Mx[r.text].className || "";
      if (r.mode === "text") {
        var x = z.makeOrd(r, e, "textord");
        return x.classes.push(t), x;
      } else
        return z.makeSpan(["mspace", t], [z.mathsym(r.text, r.mode, e)], e);
    } else {
      if (Tx.hasOwnProperty(r.text))
        return z.makeSpan(["mspace", Tx[r.text]], [], e);
      throw new J('Unknown type of space "' + r.text + '"');
    }
  },
  mathmlBuilder(r, e) {
    var t;
    if (Mx.hasOwnProperty(r.text))
      t = new O.MathNode("mtext", [new O.TextNode(" ")]);
    else {
      if (Tx.hasOwnProperty(r.text))
        return new O.MathNode("mspace");
      throw new J('Unknown type of space "' + r.text + '"');
    }
    return t;
  }
});
var va = () => {
  var r = new O.MathNode("mtd", []);
  return r.setAttribute("width", "50%"), r;
};
Ge({
  type: "tag",
  mathmlBuilder(r, e) {
    var t = new O.MathNode("mtable", [new O.MathNode("mtr", [va(), new O.MathNode("mtd", [Re(r.body, e)]), va(), new O.MathNode("mtd", [Re(r.tag, e)])])]);
    return t.setAttribute("width", "100%"), t;
  }
});
var ba = {
  "\\text": void 0,
  "\\textrm": "textrm",
  "\\textsf": "textsf",
  "\\texttt": "texttt",
  "\\textnormal": "textrm"
}, ka = {
  "\\textbf": "textbf",
  "\\textmd": "textmd"
}, b8 = {
  "\\textit": "textit",
  "\\textup": "textup"
}, wa = (r, e) => {
  var t = r.font;
  if (t) {
    if (ba[t])
      return e.withTextFontFamily(ba[t]);
    if (ka[t])
      return e.withTextFontWeight(ka[t]);
    if (t === "\\emph")
      return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
  } else return e;
  return e.withTextFontShape(b8[t]);
};
V({
  type: "text",
  names: [
    // Font families
    "\\text",
    "\\textrm",
    "\\textsf",
    "\\texttt",
    "\\textnormal",
    // Font weights
    "\\textbf",
    "\\textmd",
    // Font Shapes
    "\\textit",
    "\\textup",
    "\\emph"
  ],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: !0,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: x
    } = r, a = e[0];
    return {
      type: "text",
      mode: t.mode,
      body: b0(a),
      font: x
    };
  },
  htmlBuilder(r, e) {
    var t = wa(r, e), x = R0(r.body, t, !0);
    return z.makeSpan(["mord", "text"], x, t);
  },
  mathmlBuilder(r, e) {
    var t = wa(r, e);
    return Re(r.body, t);
  }
});
V({
  type: "underline",
  names: ["\\underline"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "underline",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = d0(r.body, e), x = z.makeLineSpan("underline-line", e), a = e.fontMetrics().defaultRuleThickness, n = z.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: x
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return z.makeSpan(["mord", "underline"], [n], e);
  },
  mathmlBuilder(r, e) {
    var t = new O.MathNode("mo", [new O.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var x = new O.MathNode("munder", [B0(r.body, e), t]);
    return x.setAttribute("accentunder", "true"), x;
  }
});
V({
  type: "vcenter",
  names: ["\\vcenter"],
  props: {
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: !1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "vcenter",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = d0(r.body, e), x = e.fontMetrics().axisHeight, a = 0.5 * (t.height - x - (t.depth + x));
    return z.makeVList({
      positionType: "shift",
      positionData: a,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(r, e) {
    return new O.MathNode("mpadded", [B0(r.body, e)], ["vcenter"]);
  }
});
V({
  type: "verb",
  names: ["\\verb"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r, e, t) {
    throw new J("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(r, e) {
    for (var t = ya(r), x = [], a = e.havingStyle(e.style.text()), n = 0; n < t.length; n++) {
      var o = t[n];
      o === "~" && (o = "\\textasciitilde"), x.push(z.makeSymbol(o, "Typewriter-Regular", r.mode, a, ["mord", "texttt"]));
    }
    return z.makeSpan(["mord", "text"].concat(a.sizingClasses(e)), z.tryCombineChars(x), a);
  },
  mathmlBuilder(r, e) {
    var t = new O.TextNode(ya(r)), x = new O.MathNode("mtext", [t]);
    return x.setAttribute("mathvariant", "monospace"), x;
  }
});
var ya = (r) => r.body.replace(/ /g, r.star ? "␣" : " "), k8 = Dn;
h("\\noexpand", function(r) {
  var e = r.popToken();
  return r.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
    tokens: [e],
    numArgs: 0
  };
});
h("\\expandafter", function(r) {
  var e = r.popToken();
  return r.expandOnce(!0), {
    tokens: [e],
    numArgs: 0
  };
});
h("\\@firstoftwo", function(r) {
  var e = r.consumeArgs(2);
  return {
    tokens: e[0],
    numArgs: 0
  };
});
h("\\@secondoftwo", function(r) {
  var e = r.consumeArgs(2);
  return {
    tokens: e[1],
    numArgs: 0
  };
});
h("\\@ifnextchar", function(r) {
  var e = r.consumeArgs(3);
  r.consumeSpaces();
  var t = r.future();
  return e[0].length === 1 && e[0][0].text === t.text ? {
    tokens: e[1],
    numArgs: 0
  } : {
    tokens: e[2],
    numArgs: 0
  };
});
h("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
h("\\TextOrMath", function(r) {
  var e = r.consumeArgs(2);
  return r.mode === "text" ? {
    tokens: e[0],
    numArgs: 0
  } : {
    tokens: e[1],
    numArgs: 0
  };
});
var Sa = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15
};
h("\\char", function(r) {
  var e = r.popToken(), t, x = "";
  if (e.text === "'")
    t = 8, e = r.popToken();
  else if (e.text === '"')
    t = 16, e = r.popToken();
  else if (e.text === "`")
    if (e = r.popToken(), e.text[0] === "\\")
      x = e.text.charCodeAt(1);
    else {
      if (e.text === "EOF")
        throw new J("\\char` missing argument");
      x = e.text.charCodeAt(0);
    }
  else
    t = 10;
  if (t) {
    if (x = Sa[e.text], x == null || x >= t)
      throw new J("Invalid base-" + t + " digit " + e.text);
    for (var a; (a = Sa[r.future().text]) != null && a < t; )
      x *= t, x += a, r.popToken();
  }
  return "\\@char{" + x + "}";
});
var pr = (r, e, t) => {
  var x = r.consumeArg().tokens;
  if (x.length !== 1)
    throw new J("\\newcommand's first argument must be a macro name");
  var a = x[0].text, n = r.isDefined(a);
  if (n && !e)
    throw new J("\\newcommand{" + a + "} attempting to redefine " + (a + "; use \\renewcommand"));
  if (!n && !t)
    throw new J("\\renewcommand{" + a + "} when command " + a + " does not yet exist; use \\newcommand");
  var o = 0;
  if (x = r.consumeArg().tokens, x.length === 1 && x[0].text === "[") {
    for (var s = "", i = r.expandNextToken(); i.text !== "]" && i.text !== "EOF"; )
      s += i.text, i = r.expandNextToken();
    if (!s.match(/^\s*[0-9]+\s*$/))
      throw new J("Invalid number of arguments: " + s);
    o = parseInt(s), x = r.consumeArg().tokens;
  }
  return r.macros.set(a, {
    tokens: x,
    numArgs: o
  }), "";
};
h("\\newcommand", (r) => pr(r, !1, !0));
h("\\renewcommand", (r) => pr(r, !0, !1));
h("\\providecommand", (r) => pr(r, !0, !0));
h("\\message", (r) => {
  var e = r.consumeArgs(1)[0];
  return console.log(e.reverse().map((t) => t.text).join("")), "";
});
h("\\errmessage", (r) => {
  var e = r.consumeArgs(1)[0];
  return console.error(e.reverse().map((t) => t.text).join("")), "";
});
h("\\show", (r) => {
  var e = r.popToken(), t = e.text;
  return console.log(e, r.macros.get(t), k8[t], k0.math[t], k0.text[t]), "";
});
h("\\bgroup", "{");
h("\\egroup", "}");
h("~", "\\nobreakspace");
h("\\lq", "`");
h("\\rq", "'");
h("\\aa", "\\r a");
h("\\AA", "\\r A");
h("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
h("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
h("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
h("ℬ", "\\mathscr{B}");
h("ℰ", "\\mathscr{E}");
h("ℱ", "\\mathscr{F}");
h("ℋ", "\\mathscr{H}");
h("ℐ", "\\mathscr{I}");
h("ℒ", "\\mathscr{L}");
h("ℳ", "\\mathscr{M}");
h("ℛ", "\\mathscr{R}");
h("ℭ", "\\mathfrak{C}");
h("ℌ", "\\mathfrak{H}");
h("ℨ", "\\mathfrak{Z}");
h("\\Bbbk", "\\Bbb{k}");
h("·", "\\cdotp");
h("\\llap", "\\mathllap{\\textrm{#1}}");
h("\\rlap", "\\mathrlap{\\textrm{#1}}");
h("\\clap", "\\mathclap{\\textrm{#1}}");
h("\\mathstrut", "\\vphantom{(}");
h("\\underbar", "\\underline{\\text{#1}}");
h("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}');
h("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
h("\\ne", "\\neq");
h("≠", "\\neq");
h("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
h("∉", "\\notin");
h("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
h("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
h("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
h("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
h("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
h("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
h("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
h("⟂", "\\perp");
h("‼", "\\mathclose{!\\mkern-0.8mu!}");
h("∌", "\\notni");
h("⌜", "\\ulcorner");
h("⌝", "\\urcorner");
h("⌞", "\\llcorner");
h("⌟", "\\lrcorner");
h("©", "\\copyright");
h("®", "\\textregistered");
h("️", "\\textregistered");
h("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
h("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
h("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
h("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
h("\\vdots", "\\mathord{\\varvdots\\rule{0pt}{15pt}}");
h("⋮", "\\vdots");
h("\\varGamma", "\\mathit{\\Gamma}");
h("\\varDelta", "\\mathit{\\Delta}");
h("\\varTheta", "\\mathit{\\Theta}");
h("\\varLambda", "\\mathit{\\Lambda}");
h("\\varXi", "\\mathit{\\Xi}");
h("\\varPi", "\\mathit{\\Pi}");
h("\\varSigma", "\\mathit{\\Sigma}");
h("\\varUpsilon", "\\mathit{\\Upsilon}");
h("\\varPhi", "\\mathit{\\Phi}");
h("\\varPsi", "\\mathit{\\Psi}");
h("\\varOmega", "\\mathit{\\Omega}");
h("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
h("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
h("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
h("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
h("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
h("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
var Ta = {
  ",": "\\dotsc",
  "\\not": "\\dotsb",
  // \keybin@ checks for the following:
  "+": "\\dotsb",
  "=": "\\dotsb",
  "<": "\\dotsb",
  ">": "\\dotsb",
  "-": "\\dotsb",
  "*": "\\dotsb",
  ":": "\\dotsb",
  // Symbols whose definition starts with \DOTSB:
  "\\DOTSB": "\\dotsb",
  "\\coprod": "\\dotsb",
  "\\bigvee": "\\dotsb",
  "\\bigwedge": "\\dotsb",
  "\\biguplus": "\\dotsb",
  "\\bigcap": "\\dotsb",
  "\\bigcup": "\\dotsb",
  "\\prod": "\\dotsb",
  "\\sum": "\\dotsb",
  "\\bigotimes": "\\dotsb",
  "\\bigoplus": "\\dotsb",
  "\\bigodot": "\\dotsb",
  "\\bigsqcup": "\\dotsb",
  "\\And": "\\dotsb",
  "\\longrightarrow": "\\dotsb",
  "\\Longrightarrow": "\\dotsb",
  "\\longleftarrow": "\\dotsb",
  "\\Longleftarrow": "\\dotsb",
  "\\longleftrightarrow": "\\dotsb",
  "\\Longleftrightarrow": "\\dotsb",
  "\\mapsto": "\\dotsb",
  "\\longmapsto": "\\dotsb",
  "\\hookrightarrow": "\\dotsb",
  "\\doteq": "\\dotsb",
  // Symbols whose definition starts with \mathbin:
  "\\mathbin": "\\dotsb",
  // Symbols whose definition starts with \mathrel:
  "\\mathrel": "\\dotsb",
  "\\relbar": "\\dotsb",
  "\\Relbar": "\\dotsb",
  "\\xrightarrow": "\\dotsb",
  "\\xleftarrow": "\\dotsb",
  // Symbols whose definition starts with \DOTSI:
  "\\DOTSI": "\\dotsi",
  "\\int": "\\dotsi",
  "\\oint": "\\dotsi",
  "\\iint": "\\dotsi",
  "\\iiint": "\\dotsi",
  "\\iiiint": "\\dotsi",
  "\\idotsint": "\\dotsi",
  // Symbols whose definition starts with \DOTSX:
  "\\DOTSX": "\\dotsx"
};
h("\\dots", function(r) {
  var e = "\\dotso", t = r.expandAfterFuture().text;
  return t in Ta ? e = Ta[t] : (t.slice(0, 4) === "\\not" || t in k0.math && t0.contains(["bin", "rel"], k0.math[t].group)) && (e = "\\dotsb"), e;
});
var gr = {
  // \rightdelim@ checks for the following:
  ")": !0,
  "]": !0,
  "\\rbrack": !0,
  "\\}": !0,
  "\\rbrace": !0,
  "\\rangle": !0,
  "\\rceil": !0,
  "\\rfloor": !0,
  "\\rgroup": !0,
  "\\rmoustache": !0,
  "\\right": !0,
  "\\bigr": !0,
  "\\biggr": !0,
  "\\Bigr": !0,
  "\\Biggr": !0,
  // \extra@ also tests for the following:
  $: !0,
  // \extrap@ checks for the following:
  ";": !0,
  ".": !0,
  ",": !0
};
h("\\dotso", function(r) {
  var e = r.future().text;
  return e in gr ? "\\ldots\\," : "\\ldots";
});
h("\\dotsc", function(r) {
  var e = r.future().text;
  return e in gr && e !== "," ? "\\ldots\\," : "\\ldots";
});
h("\\cdots", function(r) {
  var e = r.future().text;
  return e in gr ? "\\@cdots\\," : "\\@cdots";
});
h("\\dotsb", "\\cdots");
h("\\dotsm", "\\cdots");
h("\\dotsi", "\\!\\cdots");
h("\\dotsx", "\\ldots\\,");
h("\\DOTSI", "\\relax");
h("\\DOTSB", "\\relax");
h("\\DOTSX", "\\relax");
h("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
h("\\,", "\\tmspace+{3mu}{.1667em}");
h("\\thinspace", "\\,");
h("\\>", "\\mskip{4mu}");
h("\\:", "\\tmspace+{4mu}{.2222em}");
h("\\medspace", "\\:");
h("\\;", "\\tmspace+{5mu}{.2777em}");
h("\\thickspace", "\\;");
h("\\!", "\\tmspace-{3mu}{.1667em}");
h("\\negthinspace", "\\!");
h("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
h("\\negthickspace", "\\tmspace-{5mu}{.277em}");
h("\\enspace", "\\kern.5em ");
h("\\enskip", "\\hskip.5em\\relax");
h("\\quad", "\\hskip1em\\relax");
h("\\qquad", "\\hskip2em\\relax");
h("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
h("\\tag@paren", "\\tag@literal{({#1})}");
h("\\tag@literal", (r) => {
  if (r.macros.get("\\df@tag"))
    throw new J("Multiple \\tag");
  return "\\gdef\\df@tag{\\text{#1}}";
});
h("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
h("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
h("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
h("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
h("\\newline", "\\\\\\relax");
h("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var Yn = U(ve["Main-Regular"][84][1] - 0.7 * ve["Main-Regular"][65][1]);
h("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + Yn + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
h("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + Yn + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
h("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
h("\\@hspace", "\\hskip #1\\relax");
h("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
h("\\ordinarycolon", ":");
h("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
h("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
h("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
h("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
h("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
h("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
h("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
h("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
h("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
h("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
h("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
h("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
h("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
h("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
h("∷", "\\dblcolon");
h("∹", "\\eqcolon");
h("≔", "\\coloneqq");
h("≕", "\\eqqcolon");
h("⩴", "\\Coloneqq");
h("\\ratio", "\\vcentcolon");
h("\\coloncolon", "\\dblcolon");
h("\\colonequals", "\\coloneqq");
h("\\coloncolonequals", "\\Coloneqq");
h("\\equalscolon", "\\eqqcolon");
h("\\equalscoloncolon", "\\Eqqcolon");
h("\\colonminus", "\\coloneq");
h("\\coloncolonminus", "\\Coloneq");
h("\\minuscolon", "\\eqcolon");
h("\\minuscoloncolon", "\\Eqcolon");
h("\\coloncolonapprox", "\\Colonapprox");
h("\\coloncolonsim", "\\Colonsim");
h("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
h("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
h("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
h("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
h("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
h("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
h("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
h("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
h("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
h("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
h("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
h("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
h("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
h("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}");
h("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}");
h("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}");
h("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}");
h("\\nleqq", "\\html@mathml{\\@nleqq}{≰}");
h("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}");
h("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}");
h("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}");
h("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}");
h("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}");
h("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}");
h("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}");
h("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}");
h("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}");
h("\\imath", "\\html@mathml{\\@imath}{ı}");
h("\\jmath", "\\html@mathml{\\@jmath}{ȷ}");
h("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}");
h("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}");
h("⟦", "\\llbracket");
h("⟧", "\\rrbracket");
h("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}");
h("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}");
h("⦃", "\\lBrace");
h("⦄", "\\rBrace");
h("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}");
h("⦵", "\\minuso");
h("\\darr", "\\downarrow");
h("\\dArr", "\\Downarrow");
h("\\Darr", "\\Downarrow");
h("\\lang", "\\langle");
h("\\rang", "\\rangle");
h("\\uarr", "\\uparrow");
h("\\uArr", "\\Uparrow");
h("\\Uarr", "\\Uparrow");
h("\\N", "\\mathbb{N}");
h("\\R", "\\mathbb{R}");
h("\\Z", "\\mathbb{Z}");
h("\\alef", "\\aleph");
h("\\alefsym", "\\aleph");
h("\\Alpha", "\\mathrm{A}");
h("\\Beta", "\\mathrm{B}");
h("\\bull", "\\bullet");
h("\\Chi", "\\mathrm{X}");
h("\\clubs", "\\clubsuit");
h("\\cnums", "\\mathbb{C}");
h("\\Complex", "\\mathbb{C}");
h("\\Dagger", "\\ddagger");
h("\\diamonds", "\\diamondsuit");
h("\\empty", "\\emptyset");
h("\\Epsilon", "\\mathrm{E}");
h("\\Eta", "\\mathrm{H}");
h("\\exist", "\\exists");
h("\\harr", "\\leftrightarrow");
h("\\hArr", "\\Leftrightarrow");
h("\\Harr", "\\Leftrightarrow");
h("\\hearts", "\\heartsuit");
h("\\image", "\\Im");
h("\\infin", "\\infty");
h("\\Iota", "\\mathrm{I}");
h("\\isin", "\\in");
h("\\Kappa", "\\mathrm{K}");
h("\\larr", "\\leftarrow");
h("\\lArr", "\\Leftarrow");
h("\\Larr", "\\Leftarrow");
h("\\lrarr", "\\leftrightarrow");
h("\\lrArr", "\\Leftrightarrow");
h("\\Lrarr", "\\Leftrightarrow");
h("\\Mu", "\\mathrm{M}");
h("\\natnums", "\\mathbb{N}");
h("\\Nu", "\\mathrm{N}");
h("\\Omicron", "\\mathrm{O}");
h("\\plusmn", "\\pm");
h("\\rarr", "\\rightarrow");
h("\\rArr", "\\Rightarrow");
h("\\Rarr", "\\Rightarrow");
h("\\real", "\\Re");
h("\\reals", "\\mathbb{R}");
h("\\Reals", "\\mathbb{R}");
h("\\Rho", "\\mathrm{P}");
h("\\sdot", "\\cdot");
h("\\sect", "\\S");
h("\\spades", "\\spadesuit");
h("\\sub", "\\subset");
h("\\sube", "\\subseteq");
h("\\supe", "\\supseteq");
h("\\Tau", "\\mathrm{T}");
h("\\thetasym", "\\vartheta");
h("\\weierp", "\\wp");
h("\\Zeta", "\\mathrm{Z}");
h("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
h("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
h("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
h("\\bra", "\\mathinner{\\langle{#1}|}");
h("\\ket", "\\mathinner{|{#1}\\rangle}");
h("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
h("\\Bra", "\\left\\langle#1\\right|");
h("\\Ket", "\\left|#1\\right\\rangle");
var Qn = (r) => (e) => {
  var t = e.consumeArg().tokens, x = e.consumeArg().tokens, a = e.consumeArg().tokens, n = e.consumeArg().tokens, o = e.macros.get("|"), s = e.macros.get("\\|");
  e.macros.beginGroup();
  var i = (E) => (C) => {
    r && (C.macros.set("|", o), a.length && C.macros.set("\\|", s));
    var A = E;
    if (!E && a.length) {
      var b = C.future();
      b.text === "|" && (C.popToken(), A = !0);
    }
    return {
      tokens: A ? a : x,
      numArgs: 0
    };
  };
  e.macros.set("|", i(!1)), a.length && e.macros.set("\\|", i(!0));
  var m = e.consumeArg().tokens, d = e.expandTokens([
    ...n,
    ...m,
    ...t
    // reversed
  ]);
  return e.macros.endGroup(), {
    tokens: d.reverse(),
    numArgs: 0
  };
};
h("\\bra@ket", Qn(!1));
h("\\bra@set", Qn(!0));
h("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
h("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
h("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
h("\\angln", "{\\angl n}");
h("\\blue", "\\textcolor{##6495ed}{#1}");
h("\\orange", "\\textcolor{##ffa500}{#1}");
h("\\pink", "\\textcolor{##ff00af}{#1}");
h("\\red", "\\textcolor{##df0030}{#1}");
h("\\green", "\\textcolor{##28ae7b}{#1}");
h("\\gray", "\\textcolor{gray}{#1}");
h("\\purple", "\\textcolor{##9d38bd}{#1}");
h("\\blueA", "\\textcolor{##ccfaff}{#1}");
h("\\blueB", "\\textcolor{##80f6ff}{#1}");
h("\\blueC", "\\textcolor{##63d9ea}{#1}");
h("\\blueD", "\\textcolor{##11accd}{#1}");
h("\\blueE", "\\textcolor{##0c7f99}{#1}");
h("\\tealA", "\\textcolor{##94fff5}{#1}");
h("\\tealB", "\\textcolor{##26edd5}{#1}");
h("\\tealC", "\\textcolor{##01d1c1}{#1}");
h("\\tealD", "\\textcolor{##01a995}{#1}");
h("\\tealE", "\\textcolor{##208170}{#1}");
h("\\greenA", "\\textcolor{##b6ffb0}{#1}");
h("\\greenB", "\\textcolor{##8af281}{#1}");
h("\\greenC", "\\textcolor{##74cf70}{#1}");
h("\\greenD", "\\textcolor{##1fab54}{#1}");
h("\\greenE", "\\textcolor{##0d923f}{#1}");
h("\\goldA", "\\textcolor{##ffd0a9}{#1}");
h("\\goldB", "\\textcolor{##ffbb71}{#1}");
h("\\goldC", "\\textcolor{##ff9c39}{#1}");
h("\\goldD", "\\textcolor{##e07d10}{#1}");
h("\\goldE", "\\textcolor{##a75a05}{#1}");
h("\\redA", "\\textcolor{##fca9a9}{#1}");
h("\\redB", "\\textcolor{##ff8482}{#1}");
h("\\redC", "\\textcolor{##f9685d}{#1}");
h("\\redD", "\\textcolor{##e84d39}{#1}");
h("\\redE", "\\textcolor{##bc2612}{#1}");
h("\\maroonA", "\\textcolor{##ffbde0}{#1}");
h("\\maroonB", "\\textcolor{##ff92c6}{#1}");
h("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
h("\\maroonD", "\\textcolor{##ca337c}{#1}");
h("\\maroonE", "\\textcolor{##9e034e}{#1}");
h("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
h("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
h("\\purpleC", "\\textcolor{##aa87ff}{#1}");
h("\\purpleD", "\\textcolor{##7854ab}{#1}");
h("\\purpleE", "\\textcolor{##543b78}{#1}");
h("\\mintA", "\\textcolor{##f5f9e8}{#1}");
h("\\mintB", "\\textcolor{##edf2df}{#1}");
h("\\mintC", "\\textcolor{##e0e5cc}{#1}");
h("\\grayA", "\\textcolor{##f6f7f7}{#1}");
h("\\grayB", "\\textcolor{##f0f1f2}{#1}");
h("\\grayC", "\\textcolor{##e3e5e6}{#1}");
h("\\grayD", "\\textcolor{##d6d8da}{#1}");
h("\\grayE", "\\textcolor{##babec2}{#1}");
h("\\grayF", "\\textcolor{##888d93}{#1}");
h("\\grayG", "\\textcolor{##626569}{#1}");
h("\\grayH", "\\textcolor{##3b3e40}{#1}");
h("\\grayI", "\\textcolor{##21242c}{#1}");
h("\\kaBlue", "\\textcolor{##314453}{#1}");
h("\\kaGreen", "\\textcolor{##71B307}{#1}");
typeof document < "u" && document.compatMode !== "CSS1Compat" && typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
function vr() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Ve = vr();
function Zn(r) {
  Ve = r;
}
const Kn = /[&<>"']/, w8 = new RegExp(Kn.source, "g"), Jn = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, y8 = new RegExp(Jn.source, "g"), S8 = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Ma = (r) => S8[r];
function J0(r, e) {
  if (e) {
    if (Kn.test(r))
      return r.replace(w8, Ma);
  } else if (Jn.test(r))
    return r.replace(y8, Ma);
  return r;
}
const T8 = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function M8(r) {
  return r.replace(T8, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const P8 = /(^|[^\[])\^/g;
function f0(r, e) {
  let t = typeof r == "string" ? r : r.source;
  e = e || "";
  const x = {
    replace: (a, n) => {
      let o = typeof n == "string" ? n : n.source;
      return o = o.replace(P8, "$1"), t = t.replace(a, o), x;
    },
    getRegex: () => new RegExp(t, e)
  };
  return x;
}
function Pa(r) {
  try {
    r = encodeURI(r).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return r;
}
const mt = { exec: () => null };
function _a(r, e) {
  const t = r.replace(/\|/g, (n, o, s) => {
    let i = !1, m = o;
    for (; --m >= 0 && s[m] === "\\"; )
      i = !i;
    return i ? "|" : " |";
  }), x = t.split(/ \|/);
  let a = 0;
  if (x[0].trim() || x.shift(), x.length > 0 && !x[x.length - 1].trim() && x.pop(), e)
    if (x.length > e)
      x.splice(e);
    else
      for (; x.length < e; )
        x.push("");
  for (; a < x.length; a++)
    x[a] = x[a].trim().replace(/\\\|/g, "|");
  return x;
}
function zt(r, e, t) {
  const x = r.length;
  if (x === 0)
    return "";
  let a = 0;
  for (; a < x; ) {
    const n = r.charAt(x - a - 1);
    if (n === e && !t)
      a++;
    else if (n !== e && t)
      a++;
    else
      break;
  }
  return r.slice(0, x - a);
}
function _8(r, e) {
  if (r.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let x = 0; x < r.length; x++)
    if (r[x] === "\\")
      x++;
    else if (r[x] === e[0])
      t++;
    else if (r[x] === e[1] && (t--, t < 0))
      return x;
  return -1;
}
function za(r, e, t, x) {
  const a = e.href, n = e.title ? J0(e.title) : null, o = r[1].replace(/\\([\[\]])/g, "$1");
  if (r[0].charAt(0) !== "!") {
    x.state.inLink = !0;
    const s = {
      type: "link",
      raw: t,
      href: a,
      title: n,
      text: o,
      tokens: x.inlineTokens(o)
    };
    return x.state.inLink = !1, s;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: n,
    text: J0(o)
  };
}
function z8(r, e) {
  const t = r.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const x = t[1];
  return e.split(`
`).map((a) => {
    const n = a.match(/^\s+/);
    if (n === null)
      return a;
    const [o] = n;
    return o.length >= x.length ? a.slice(x.length) : a;
  }).join(`
`);
}
class Kt {
  // set by the lexer
  constructor(e) {
    C0(this, "options");
    C0(this, "rules");
    // set by the lexer
    C0(this, "lexer");
    this.options = e || Ve;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const x = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? x : zt(x, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const x = t[0], a = z8(x, t[3] || "");
      return {
        type: "code",
        raw: x,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let x = t[2].trim();
      if (/#$/.test(x)) {
        const a = zt(x, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (x = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: x,
        tokens: this.lexer.inline(x)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let x = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      x = zt(x.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const n = this.lexer.blockTokens(x);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: n,
        text: x
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let x = t[1].trim();
      const a = x.length > 1, n = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +x.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      x = a ? `\\d{1,9}\\${x.slice(-1)}` : `\\${x}`, this.options.pedantic && (x = a ? x : "[*+-]");
      const o = new RegExp(`^( {0,3}${x})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let s = "", i = "", m = !1;
      for (; e; ) {
        let d = !1;
        if (!(t = o.exec(e)) || this.rules.block.hr.test(e))
          break;
        s = t[0], e = e.substring(s.length);
        let E = t[2].split(`
`, 1)[0].replace(/^\t+/, (P) => " ".repeat(3 * P.length)), C = e.split(`
`, 1)[0], A = 0;
        this.options.pedantic ? (A = 2, i = E.trimStart()) : (A = t[2].search(/[^ ]/), A = A > 4 ? 1 : A, i = E.slice(A), A += t[1].length);
        let b = !1;
        if (!E && /^ *$/.test(C) && (s += C + `
`, e = e.substring(C.length + 1), d = !0), !d) {
          const P = new RegExp(`^ {0,${Math.min(3, A - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), k = new RegExp(`^ {0,${Math.min(3, A - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), f = new RegExp(`^ {0,${Math.min(3, A - 1)}}(?:\`\`\`|~~~)`), B = new RegExp(`^ {0,${Math.min(3, A - 1)}}#`);
          for (; e; ) {
            const D = e.split(`
`, 1)[0];
            if (C = D, this.options.pedantic && (C = C.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), f.test(C) || B.test(C) || P.test(C) || k.test(e))
              break;
            if (C.search(/[^ ]/) >= A || !C.trim())
              i += `
` + C.slice(A);
            else {
              if (b || E.search(/[^ ]/) >= 4 || f.test(E) || B.test(E) || k.test(E))
                break;
              i += `
` + C;
            }
            !b && !C.trim() && (b = !0), s += D + `
`, e = e.substring(D.length + 1), E = C.slice(A);
          }
        }
        n.loose || (m ? n.loose = !0 : /\n *\n *$/.test(s) && (m = !0));
        let y = null, w;
        this.options.gfm && (y = /^\[[ xX]\] /.exec(i), y && (w = y[0] !== "[ ] ", i = i.replace(/^\[[ xX]\] +/, ""))), n.items.push({
          type: "list_item",
          raw: s,
          task: !!y,
          checked: w,
          loose: !1,
          text: i,
          tokens: []
        }), n.raw += s;
      }
      n.items[n.items.length - 1].raw = s.trimEnd(), n.items[n.items.length - 1].text = i.trimEnd(), n.raw = n.raw.trimEnd();
      for (let d = 0; d < n.items.length; d++)
        if (this.lexer.state.top = !1, n.items[d].tokens = this.lexer.blockTokens(n.items[d].text, []), !n.loose) {
          const E = n.items[d].tokens.filter((A) => A.type === "space"), C = E.length > 0 && E.some((A) => /\n.*\n/.test(A.raw));
          n.loose = C;
        }
      if (n.loose)
        for (let d = 0; d < n.items.length; d++)
          n.items[d].loose = !0;
      return n;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const x = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", n = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: x,
        raw: t[0],
        href: a,
        title: n
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const x = _a(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), n = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], o = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (x.length === a.length) {
      for (const s of a)
        /^ *-+: *$/.test(s) ? o.align.push("right") : /^ *:-+: *$/.test(s) ? o.align.push("center") : /^ *:-+ *$/.test(s) ? o.align.push("left") : o.align.push(null);
      for (const s of x)
        o.header.push({
          text: s,
          tokens: this.lexer.inline(s)
        });
      for (const s of n)
        o.rows.push(_a(s, o.header.length).map((i) => ({
          text: i,
          tokens: this.lexer.inline(i)
        })));
      return o;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const x = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: x,
        tokens: this.lexer.inline(x)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: J0(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const x = t[2].trim();
      if (!this.options.pedantic && /^</.test(x)) {
        if (!/>$/.test(x))
          return;
        const o = zt(x.slice(0, -1), "\\");
        if ((x.length - o.length) % 2 === 0)
          return;
      } else {
        const o = _8(t[2], "()");
        if (o > -1) {
          const i = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + o;
          t[2] = t[2].substring(0, o), t[0] = t[0].substring(0, i).trim(), t[3] = "";
        }
      }
      let a = t[2], n = "";
      if (this.options.pedantic) {
        const o = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        o && (a = o[1], n = o[3]);
      } else
        n = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(x) ? a = a.slice(1) : a = a.slice(1, -1)), za(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: n && n.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let x;
    if ((x = this.rules.inline.reflink.exec(e)) || (x = this.rules.inline.nolink.exec(e))) {
      const a = (x[2] || x[1]).replace(/\s+/g, " "), n = t[a.toLowerCase()];
      if (!n) {
        const o = x[0].charAt(0);
        return {
          type: "text",
          raw: o,
          text: o
        };
      }
      return za(x, n, x[0], this.lexer);
    }
  }
  emStrong(e, t, x = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && x.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !x || this.rules.inline.punctuation.exec(x)) {
      const o = [...a[0]].length - 1;
      let s, i, m = o, d = 0;
      const E = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (E.lastIndex = 0, t = t.slice(-1 * e.length + o); (a = E.exec(t)) != null; ) {
        if (s = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !s)
          continue;
        if (i = [...s].length, a[3] || a[4]) {
          m += i;
          continue;
        } else if ((a[5] || a[6]) && o % 3 && !((o + i) % 3)) {
          d += i;
          continue;
        }
        if (m -= i, m > 0)
          continue;
        i = Math.min(i, i + m + d);
        const C = [...a[0]][0].length, A = e.slice(0, o + a.index + C + i);
        if (Math.min(o, i) % 2) {
          const y = A.slice(1, -1);
          return {
            type: "em",
            raw: A,
            text: y,
            tokens: this.lexer.inlineTokens(y)
          };
        }
        const b = A.slice(2, -2);
        return {
          type: "strong",
          raw: A,
          text: b,
          tokens: this.lexer.inlineTokens(b)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let x = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(x), n = /^ /.test(x) && / $/.test(x);
      return a && n && (x = x.substring(1, x.length - 1)), x = J0(x, !0), {
        type: "codespan",
        raw: t[0],
        text: x
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let x, a;
      return t[2] === "@" ? (x = J0(t[1]), a = "mailto:" + x) : (x = J0(t[1]), a = x), {
        type: "link",
        raw: t[0],
        text: x,
        href: a,
        tokens: [
          {
            type: "text",
            raw: x,
            text: x
          }
        ]
      };
    }
  }
  url(e) {
    var x;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, n;
      if (t[2] === "@")
        a = J0(t[0]), n = "mailto:" + a;
      else {
        let o;
        do
          o = t[0], t[0] = ((x = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : x[0]) ?? "";
        while (o !== t[0]);
        a = J0(t[0]), t[1] === "www." ? n = "http://" + t[0] : n = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: n,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let x;
      return this.lexer.state.inRawBlock ? x = t[0] : x = J0(t[0]), {
        type: "text",
        raw: t[0],
        text: x
      };
    }
  }
}
const R8 = /^(?: *(?:\n|$))+/, N8 = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, L8 = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Dt = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, I8 = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, e1 = /(?:[*+-]|\d{1,9}[.)])/, t1 = f0(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, e1).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), br = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, O8 = /^[^\n]+/, kr = /(?!\s*\])(?:\\.|[^\[\]\\])+/, q8 = f0(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", kr).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), H8 = f0(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, e1).getRegex(), ix = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", wr = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, U8 = f0("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", wr).replace("tag", ix).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), x1 = f0(br).replace("hr", Dt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ix).getRegex(), G8 = f0(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", x1).getRegex(), yr = {
  blockquote: G8,
  code: N8,
  def: q8,
  fences: L8,
  heading: I8,
  hr: Dt,
  html: U8,
  lheading: t1,
  list: H8,
  newline: R8,
  paragraph: x1,
  table: mt,
  text: O8
}, Ra = f0("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Dt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ix).getRegex(), V8 = {
  ...yr,
  table: Ra,
  paragraph: f0(br).replace("hr", Dt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Ra).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ix).getRegex()
}, X8 = {
  ...yr,
  html: f0(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", wr).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: mt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: f0(br).replace("hr", Dt).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", t1).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, r1 = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, $8 = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, a1 = /^( {2,}|\\)\n(?!\s*$)/, W8 = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Ft = "\\p{P}\\p{S}", j8 = f0(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Ft).getRegex(), Y8 = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Q8 = f0(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Ft).getRegex(), Z8 = f0("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Ft).getRegex(), K8 = f0("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Ft).getRegex(), J8 = f0(/\\([punct])/, "gu").replace(/punct/g, Ft).getRegex(), eo = f0(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), to = f0(wr).replace("(?:-->|$)", "-->").getRegex(), xo = f0("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", to).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Jt = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, ro = f0(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Jt).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), n1 = f0(/^!?\[(label)\]\[(ref)\]/).replace("label", Jt).replace("ref", kr).getRegex(), o1 = f0(/^!?\[(ref)\](?:\[\])?/).replace("ref", kr).getRegex(), ao = f0("reflink|nolink(?!\\()", "g").replace("reflink", n1).replace("nolink", o1).getRegex(), Sr = {
  _backpedal: mt,
  // only used for GFM url
  anyPunctuation: J8,
  autolink: eo,
  blockSkip: Y8,
  br: a1,
  code: $8,
  del: mt,
  emStrongLDelim: Q8,
  emStrongRDelimAst: Z8,
  emStrongRDelimUnd: K8,
  escape: r1,
  link: ro,
  nolink: o1,
  punctuation: j8,
  reflink: n1,
  reflinkSearch: ao,
  tag: xo,
  text: W8,
  url: mt
}, no = {
  ...Sr,
  link: f0(/^!?\[(label)\]\((.*?)\)/).replace("label", Jt).getRegex(),
  reflink: f0(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Jt).getRegex()
}, tr = {
  ...Sr,
  escape: f0(r1).replace("])", "~|])").getRegex(),
  url: f0(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, oo = {
  ...tr,
  br: f0(a1).replace("{2,}", "*").getRegex(),
  text: f0(tr.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Rt = {
  normal: yr,
  gfm: V8,
  pedantic: X8
}, at = {
  normal: Sr,
  gfm: tr,
  breaks: oo,
  pedantic: no
};
class he {
  constructor(e) {
    C0(this, "tokens");
    C0(this, "options");
    C0(this, "state");
    C0(this, "tokenizer");
    C0(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Ve, this.options.tokenizer = this.options.tokenizer || new Kt(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Rt.normal,
      inline: at.normal
    };
    this.options.pedantic ? (t.block = Rt.pedantic, t.inline = at.pedantic) : this.options.gfm && (t.block = Rt.gfm, this.options.breaks ? t.inline = at.breaks : t.inline = at.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Rt,
      inline: at
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new he(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new he(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const x = this.inlineQueue[t];
      this.inlineTokens(x.src, x.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (s, i, m) => i + "    ".repeat(m.length));
    let x, a, n, o;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((s) => (x = s.call({ lexer: this }, e, t)) ? (e = e.substring(x.raw.length), t.push(x), !0) : !1))) {
        if (x = this.tokenizer.space(e)) {
          e = e.substring(x.raw.length), x.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(x);
          continue;
        }
        if (x = this.tokenizer.code(e)) {
          e = e.substring(x.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + x.raw, a.text += `
` + x.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(x);
          continue;
        }
        if (x = this.tokenizer.fences(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.heading(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.hr(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.blockquote(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.list(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.html(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.def(e)) {
          e = e.substring(x.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + x.raw, a.text += `
` + x.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[x.tag] || (this.tokens.links[x.tag] = {
            href: x.href,
            title: x.title
          });
          continue;
        }
        if (x = this.tokenizer.table(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.lheading(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (n = e, this.options.extensions && this.options.extensions.startBlock) {
          let s = 1 / 0;
          const i = e.slice(1);
          let m;
          this.options.extensions.startBlock.forEach((d) => {
            m = d.call({ lexer: this }, i), typeof m == "number" && m >= 0 && (s = Math.min(s, m));
          }), s < 1 / 0 && s >= 0 && (n = e.substring(0, s + 1));
        }
        if (this.state.top && (x = this.tokenizer.paragraph(n))) {
          a = t[t.length - 1], o && a.type === "paragraph" ? (a.raw += `
` + x.raw, a.text += `
` + x.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(x), o = n.length !== e.length, e = e.substring(x.raw.length);
          continue;
        }
        if (x = this.tokenizer.text(e)) {
          e = e.substring(x.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + x.raw, a.text += `
` + x.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(x);
          continue;
        }
        if (e) {
          const s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let x, a, n, o = e, s, i, m;
    if (this.tokens.links) {
      const d = Object.keys(this.tokens.links);
      if (d.length > 0)
        for (; (s = this.tokenizer.rules.inline.reflinkSearch.exec(o)) != null; )
          d.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (o = o.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (s = this.tokenizer.rules.inline.blockSkip.exec(o)) != null; )
      o = o.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (s = this.tokenizer.rules.inline.anyPunctuation.exec(o)) != null; )
      o = o.slice(0, s.index) + "++" + o.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (i || (m = ""), i = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((d) => (x = d.call({ lexer: this }, e, t)) ? (e = e.substring(x.raw.length), t.push(x), !0) : !1))) {
        if (x = this.tokenizer.escape(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.tag(e)) {
          e = e.substring(x.raw.length), a = t[t.length - 1], a && x.type === "text" && a.type === "text" ? (a.raw += x.raw, a.text += x.text) : t.push(x);
          continue;
        }
        if (x = this.tokenizer.link(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(x.raw.length), a = t[t.length - 1], a && x.type === "text" && a.type === "text" ? (a.raw += x.raw, a.text += x.text) : t.push(x);
          continue;
        }
        if (x = this.tokenizer.emStrong(e, o, m)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.codespan(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.br(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.del(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (x = this.tokenizer.autolink(e)) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (!this.state.inLink && (x = this.tokenizer.url(e))) {
          e = e.substring(x.raw.length), t.push(x);
          continue;
        }
        if (n = e, this.options.extensions && this.options.extensions.startInline) {
          let d = 1 / 0;
          const E = e.slice(1);
          let C;
          this.options.extensions.startInline.forEach((A) => {
            C = A.call({ lexer: this }, E), typeof C == "number" && C >= 0 && (d = Math.min(d, C));
          }), d < 1 / 0 && d >= 0 && (n = e.substring(0, d + 1));
        }
        if (x = this.tokenizer.inlineText(n)) {
          e = e.substring(x.raw.length), x.raw.slice(-1) !== "_" && (m = x.raw.slice(-1)), i = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += x.raw, a.text += x.text) : t.push(x);
          continue;
        }
        if (e) {
          const d = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(d);
            break;
          } else
            throw new Error(d);
        }
      }
    return t;
  }
}
class ex {
  constructor(e) {
    C0(this, "options");
    this.options = e || Ve;
  }
  code(e, t, x) {
    var n;
    const a = (n = (t || "").match(/^\S*/)) == null ? void 0 : n[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + J0(a) + '">' + (x ? e : J0(e, !0)) + `</code></pre>
` : "<pre><code>" + (x ? e : J0(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, x) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, x) {
    const a = t ? "ol" : "ul", n = t && x !== 1 ? ' start="' + x + '"' : "";
    return "<" + a + n + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, x) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const x = t.header ? "th" : "td";
    return (t.align ? `<${x} align="${t.align}">` : `<${x}>`) + e + `</${x}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, x) {
    const a = Pa(e);
    if (a === null)
      return x;
    e = a;
    let n = '<a href="' + e + '"';
    return t && (n += ' title="' + t + '"'), n += ">" + x + "</a>", n;
  }
  image(e, t, x) {
    const a = Pa(e);
    if (a === null)
      return x;
    e = a;
    let n = `<img src="${e}" alt="${x}"`;
    return t && (n += ` title="${t}"`), n += ">", n;
  }
  text(e) {
    return e;
  }
}
class Tr {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, x) {
    return "" + x;
  }
  image(e, t, x) {
    return "" + x;
  }
  br() {
    return "";
  }
}
class fe {
  constructor(e) {
    C0(this, "options");
    C0(this, "renderer");
    C0(this, "textRenderer");
    this.options = e || Ve, this.options.renderer = this.options.renderer || new ex(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Tr();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new fe(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new fe(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let x = "";
    for (let a = 0; a < e.length; a++) {
      const n = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[n.type]) {
        const o = n, s = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (s !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(o.type)) {
          x += s || "";
          continue;
        }
      }
      switch (n.type) {
        case "space":
          continue;
        case "hr": {
          x += this.renderer.hr();
          continue;
        }
        case "heading": {
          const o = n;
          x += this.renderer.heading(this.parseInline(o.tokens), o.depth, M8(this.parseInline(o.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const o = n;
          x += this.renderer.code(o.text, o.lang, !!o.escaped);
          continue;
        }
        case "table": {
          const o = n;
          let s = "", i = "";
          for (let d = 0; d < o.header.length; d++)
            i += this.renderer.tablecell(this.parseInline(o.header[d].tokens), { header: !0, align: o.align[d] });
          s += this.renderer.tablerow(i);
          let m = "";
          for (let d = 0; d < o.rows.length; d++) {
            const E = o.rows[d];
            i = "";
            for (let C = 0; C < E.length; C++)
              i += this.renderer.tablecell(this.parseInline(E[C].tokens), { header: !1, align: o.align[C] });
            m += this.renderer.tablerow(i);
          }
          x += this.renderer.table(s, m);
          continue;
        }
        case "blockquote": {
          const o = n, s = this.parse(o.tokens);
          x += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          const o = n, s = o.ordered, i = o.start, m = o.loose;
          let d = "";
          for (let E = 0; E < o.items.length; E++) {
            const C = o.items[E], A = C.checked, b = C.task;
            let y = "";
            if (C.task) {
              const w = this.renderer.checkbox(!!A);
              m ? C.tokens.length > 0 && C.tokens[0].type === "paragraph" ? (C.tokens[0].text = w + " " + C.tokens[0].text, C.tokens[0].tokens && C.tokens[0].tokens.length > 0 && C.tokens[0].tokens[0].type === "text" && (C.tokens[0].tokens[0].text = w + " " + C.tokens[0].tokens[0].text)) : C.tokens.unshift({
                type: "text",
                text: w + " "
              }) : y += w + " ";
            }
            y += this.parse(C.tokens, m), d += this.renderer.listitem(y, b, !!A);
          }
          x += this.renderer.list(d, s, i);
          continue;
        }
        case "html": {
          const o = n;
          x += this.renderer.html(o.text, o.block);
          continue;
        }
        case "paragraph": {
          const o = n;
          x += this.renderer.paragraph(this.parseInline(o.tokens));
          continue;
        }
        case "text": {
          let o = n, s = o.tokens ? this.parseInline(o.tokens) : o.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            o = e[++a], s += `
` + (o.tokens ? this.parseInline(o.tokens) : o.text);
          x += t ? this.renderer.paragraph(s) : s;
          continue;
        }
        default: {
          const o = 'Token with "' + n.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return x;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let x = "";
    for (let a = 0; a < e.length; a++) {
      const n = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[n.type]) {
        const o = this.options.extensions.renderers[n.type].call({ parser: this }, n);
        if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(n.type)) {
          x += o || "";
          continue;
        }
      }
      switch (n.type) {
        case "escape": {
          const o = n;
          x += t.text(o.text);
          break;
        }
        case "html": {
          const o = n;
          x += t.html(o.text);
          break;
        }
        case "link": {
          const o = n;
          x += t.link(o.href, o.title, this.parseInline(o.tokens, t));
          break;
        }
        case "image": {
          const o = n;
          x += t.image(o.href, o.title, o.text);
          break;
        }
        case "strong": {
          const o = n;
          x += t.strong(this.parseInline(o.tokens, t));
          break;
        }
        case "em": {
          const o = n;
          x += t.em(this.parseInline(o.tokens, t));
          break;
        }
        case "codespan": {
          const o = n;
          x += t.codespan(o.text);
          break;
        }
        case "br": {
          x += t.br();
          break;
        }
        case "del": {
          const o = n;
          x += t.del(this.parseInline(o.tokens, t));
          break;
        }
        case "text": {
          const o = n;
          x += t.text(o.text);
          break;
        }
        default: {
          const o = 'Token with "' + n.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return x;
  }
}
class ht {
  constructor(e) {
    C0(this, "options");
    this.options = e || Ve;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
C0(ht, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Ue, xr, l1;
class lo {
  constructor(...e) {
    Zr(this, Ue);
    C0(this, "defaults", vr());
    C0(this, "options", this.setOptions);
    C0(this, "parse", wt(this, Ue, xr).call(this, he.lex, fe.parse));
    C0(this, "parseInline", wt(this, Ue, xr).call(this, he.lexInline, fe.parseInline));
    C0(this, "Parser", fe);
    C0(this, "Renderer", ex);
    C0(this, "TextRenderer", Tr);
    C0(this, "Lexer", he);
    C0(this, "Tokenizer", Kt);
    C0(this, "Hooks", ht);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, n;
    let x = [];
    for (const o of e)
      switch (x = x.concat(t.call(this, o)), o.type) {
        case "table": {
          const s = o;
          for (const i of s.header)
            x = x.concat(this.walkTokens(i.tokens, t));
          for (const i of s.rows)
            for (const m of i)
              x = x.concat(this.walkTokens(m.tokens, t));
          break;
        }
        case "list": {
          const s = o;
          x = x.concat(this.walkTokens(s.items, t));
          break;
        }
        default: {
          const s = o;
          (n = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && n[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((i) => {
            const m = s[i].flat(1 / 0);
            x = x.concat(this.walkTokens(m, t));
          }) : s.tokens && (x = x.concat(this.walkTokens(s.tokens, t)));
        }
      }
    return x;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((x) => {
      const a = { ...x };
      if (a.async = this.defaults.async || a.async || !1, x.extensions && (x.extensions.forEach((n) => {
        if (!n.name)
          throw new Error("extension name required");
        if ("renderer" in n) {
          const o = t.renderers[n.name];
          o ? t.renderers[n.name] = function(...s) {
            let i = n.renderer.apply(this, s);
            return i === !1 && (i = o.apply(this, s)), i;
          } : t.renderers[n.name] = n.renderer;
        }
        if ("tokenizer" in n) {
          if (!n.level || n.level !== "block" && n.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const o = t[n.level];
          o ? o.unshift(n.tokenizer) : t[n.level] = [n.tokenizer], n.start && (n.level === "block" ? t.startBlock ? t.startBlock.push(n.start) : t.startBlock = [n.start] : n.level === "inline" && (t.startInline ? t.startInline.push(n.start) : t.startInline = [n.start]));
        }
        "childTokens" in n && n.childTokens && (t.childTokens[n.name] = n.childTokens);
      }), a.extensions = t), x.renderer) {
        const n = this.defaults.renderer || new ex(this.defaults);
        for (const o in x.renderer) {
          if (!(o in n))
            throw new Error(`renderer '${o}' does not exist`);
          if (o === "options")
            continue;
          const s = o, i = x.renderer[s], m = n[s];
          n[s] = (...d) => {
            let E = i.apply(n, d);
            return E === !1 && (E = m.apply(n, d)), E || "";
          };
        }
        a.renderer = n;
      }
      if (x.tokenizer) {
        const n = this.defaults.tokenizer || new Kt(this.defaults);
        for (const o in x.tokenizer) {
          if (!(o in n))
            throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o))
            continue;
          const s = o, i = x.tokenizer[s], m = n[s];
          n[s] = (...d) => {
            let E = i.apply(n, d);
            return E === !1 && (E = m.apply(n, d)), E;
          };
        }
        a.tokenizer = n;
      }
      if (x.hooks) {
        const n = this.defaults.hooks || new ht();
        for (const o in x.hooks) {
          if (!(o in n))
            throw new Error(`hook '${o}' does not exist`);
          if (o === "options")
            continue;
          const s = o, i = x.hooks[s], m = n[s];
          ht.passThroughHooks.has(o) ? n[s] = (d) => {
            if (this.defaults.async)
              return Promise.resolve(i.call(n, d)).then((C) => m.call(n, C));
            const E = i.call(n, d);
            return m.call(n, E);
          } : n[s] = (...d) => {
            let E = i.apply(n, d);
            return E === !1 && (E = m.apply(n, d)), E;
          };
        }
        a.hooks = n;
      }
      if (x.walkTokens) {
        const n = this.defaults.walkTokens, o = x.walkTokens;
        a.walkTokens = function(s) {
          let i = [];
          return i.push(o.call(this, s)), n && (i = i.concat(n.call(this, s))), i;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return he.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return fe.parse(e, t ?? this.defaults);
  }
}
Ue = new WeakSet(), xr = function(e, t) {
  return (x, a) => {
    const n = { ...a }, o = { ...this.defaults, ...n };
    this.defaults.async === !0 && n.async === !1 && (o.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), o.async = !0);
    const s = wt(this, Ue, l1).call(this, !!o.silent, !!o.async);
    if (typeof x > "u" || x === null)
      return s(new Error("marked(): input parameter is undefined or null"));
    if (typeof x != "string")
      return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(x) + ", string expected"));
    if (o.hooks && (o.hooks.options = o), o.async)
      return Promise.resolve(o.hooks ? o.hooks.preprocess(x) : x).then((i) => e(i, o)).then((i) => o.hooks ? o.hooks.processAllTokens(i) : i).then((i) => o.walkTokens ? Promise.all(this.walkTokens(i, o.walkTokens)).then(() => i) : i).then((i) => t(i, o)).then((i) => o.hooks ? o.hooks.postprocess(i) : i).catch(s);
    try {
      o.hooks && (x = o.hooks.preprocess(x));
      let i = e(x, o);
      o.hooks && (i = o.hooks.processAllTokens(i)), o.walkTokens && this.walkTokens(i, o.walkTokens);
      let m = t(i, o);
      return o.hooks && (m = o.hooks.postprocess(m)), m;
    } catch (i) {
      return s(i);
    }
  };
}, l1 = function(e, t) {
  return (x) => {
    if (x.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + J0(x.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(x);
    throw x;
  };
};
const He = new lo();
function h0(r, e) {
  return He.parse(r, e);
}
h0.options = h0.setOptions = function(r) {
  return He.setOptions(r), h0.defaults = He.defaults, Zn(h0.defaults), h0;
};
h0.getDefaults = vr;
h0.defaults = Ve;
h0.use = function(...r) {
  return He.use(...r), h0.defaults = He.defaults, Zn(h0.defaults), h0;
};
h0.walkTokens = function(r, e) {
  return He.walkTokens(r, e);
};
h0.parseInline = He.parseInline;
h0.Parser = fe;
h0.parser = fe.parse;
h0.Renderer = ex;
h0.TextRenderer = Tr;
h0.Lexer = he;
h0.lexer = he.lex;
h0.Tokenizer = Kt;
h0.Hooks = ht;
h0.parse = h0;
h0.options;
h0.setOptions;
h0.use;
h0.walkTokens;
h0.parseInline;
fe.parse;
he.lex;
const io = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, so = Object.hasOwnProperty;
class Mr {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const x = this;
    let a = uo(e, t === !0);
    const n = a;
    for (; so.call(x.occurrences, a); )
      x.occurrences[n]++, a = n + "-" + x.occurrences[n];
    return x.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function uo(r, e) {
  return typeof r != "string" ? "" : (e || (r = r.toLowerCase()), r.replace(io, "").replace(/ /g, "-"));
}
new Mr();
var rr = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function co(r) {
  return r && r.__esModule && Object.prototype.hasOwnProperty.call(r, "default") ? r.default : r;
}
var Eo = { exports: {} };
(function(r) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(x) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, n = 0, o = {}, s = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: x.Prism && x.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: x.Prism && x.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function k(f) {
          return f instanceof i ? new i(f.type, k(f.content), f.alias) : Array.isArray(f) ? f.map(k) : f.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(k) {
          return Object.prototype.toString.call(k).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(k) {
          return k.__id || Object.defineProperty(k, "__id", { value: ++n }), k.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function k(f, B) {
          B = B || {};
          var D, p;
          switch (s.util.type(f)) {
            case "Object":
              if (p = s.util.objId(f), B[p])
                return B[p];
              D = /** @type {Record<string, any>} */
              {}, B[p] = D;
              for (var F in f)
                f.hasOwnProperty(F) && (D[F] = k(f[F], B));
              return (
                /** @type {any} */
                D
              );
            case "Array":
              return p = s.util.objId(f), B[p] ? B[p] : (D = [], B[p] = D, /** @type {Array} */
              /** @type {any} */
              f.forEach(function(_, M) {
                D[M] = k(_, B);
              }), /** @type {any} */
              D);
            default:
              return f;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(k) {
          for (; k; ) {
            var f = a.exec(k.className);
            if (f)
              return f[1].toLowerCase();
            k = k.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(k, f) {
          k.className = k.className.replace(RegExp(a, "gi"), ""), k.classList.add("language-" + f);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (D) {
            var k = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(D.stack) || [])[1];
            if (k) {
              var f = document.getElementsByTagName("script");
              for (var B in f)
                if (f[B].src == k)
                  return f[B];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(k, f, B) {
          for (var D = "no-" + f; k; ) {
            var p = k.classList;
            if (p.contains(f))
              return !0;
            if (p.contains(D))
              return !1;
            k = k.parentElement;
          }
          return !!B;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: o,
        plaintext: o,
        text: o,
        txt: o,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(k, f) {
          var B = s.util.clone(s.languages[k]);
          for (var D in f)
            B[D] = f[D];
          return B;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(k, f, B, D) {
          D = D || /** @type {any} */
          s.languages;
          var p = D[k], F = {};
          for (var _ in p)
            if (p.hasOwnProperty(_)) {
              if (_ == f)
                for (var M in B)
                  B.hasOwnProperty(M) && (F[M] = B[M]);
              B.hasOwnProperty(_) || (F[_] = p[_]);
            }
          var R = D[k];
          return D[k] = F, s.languages.DFS(s.languages, function(N, I) {
            I === R && N != k && (this[N] = F);
          }), F;
        },
        // Traverse a language definition with Depth First Search
        DFS: function k(f, B, D, p) {
          p = p || {};
          var F = s.util.objId;
          for (var _ in f)
            if (f.hasOwnProperty(_)) {
              B.call(f, _, f[_], D || _);
              var M = f[_], R = s.util.type(M);
              R === "Object" && !p[F(M)] ? (p[F(M)] = !0, k(M, B, null, p)) : R === "Array" && !p[F(M)] && (p[F(M)] = !0, k(M, B, _, p));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(k, f) {
        s.highlightAllUnder(document, k, f);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(k, f, B) {
        var D = {
          callback: B,
          container: k,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        s.hooks.run("before-highlightall", D), D.elements = Array.prototype.slice.apply(D.container.querySelectorAll(D.selector)), s.hooks.run("before-all-elements-highlight", D);
        for (var p = 0, F; F = D.elements[p++]; )
          s.highlightElement(F, f === !0, D.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(k, f, B) {
        var D = s.util.getLanguage(k), p = s.languages[D];
        s.util.setLanguage(k, D);
        var F = k.parentElement;
        F && F.nodeName.toLowerCase() === "pre" && s.util.setLanguage(F, D);
        var _ = k.textContent, M = {
          element: k,
          language: D,
          grammar: p,
          code: _
        };
        function R(I) {
          M.highlightedCode = I, s.hooks.run("before-insert", M), M.element.innerHTML = M.highlightedCode, s.hooks.run("after-highlight", M), s.hooks.run("complete", M), B && B.call(M.element);
        }
        if (s.hooks.run("before-sanity-check", M), F = M.element.parentElement, F && F.nodeName.toLowerCase() === "pre" && !F.hasAttribute("tabindex") && F.setAttribute("tabindex", "0"), !M.code) {
          s.hooks.run("complete", M), B && B.call(M.element);
          return;
        }
        if (s.hooks.run("before-highlight", M), !M.grammar) {
          R(s.util.encode(M.code));
          return;
        }
        if (f && x.Worker) {
          var N = new Worker(s.filename);
          N.onmessage = function(I) {
            R(I.data);
          }, N.postMessage(JSON.stringify({
            language: M.language,
            code: M.code,
            immediateClose: !0
          }));
        } else
          R(s.highlight(M.code, M.grammar, M.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(k, f, B) {
        var D = {
          code: k,
          grammar: f,
          language: B
        };
        if (s.hooks.run("before-tokenize", D), !D.grammar)
          throw new Error('The language "' + D.language + '" has no grammar.');
        return D.tokens = s.tokenize(D.code, D.grammar), s.hooks.run("after-tokenize", D), i.stringify(s.util.encode(D.tokens), D.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(k, f) {
        var B = f.rest;
        if (B) {
          for (var D in B)
            f[D] = B[D];
          delete f.rest;
        }
        var p = new E();
        return C(p, p.head, k), d(k, p, f, p.head, 0), b(p);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(k, f) {
          var B = s.hooks.all;
          B[k] = B[k] || [], B[k].push(f);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(k, f) {
          var B = s.hooks.all[k];
          if (!(!B || !B.length))
            for (var D = 0, p; p = B[D++]; )
              p(f);
        }
      },
      Token: i
    };
    x.Prism = s;
    function i(k, f, B, D) {
      this.type = k, this.content = f, this.alias = B, this.length = (D || "").length | 0;
    }
    i.stringify = function k(f, B) {
      if (typeof f == "string")
        return f;
      if (Array.isArray(f)) {
        var D = "";
        return f.forEach(function(R) {
          D += k(R, B);
        }), D;
      }
      var p = {
        type: f.type,
        content: k(f.content, B),
        tag: "span",
        classes: ["token", f.type],
        attributes: {},
        language: B
      }, F = f.alias;
      F && (Array.isArray(F) ? Array.prototype.push.apply(p.classes, F) : p.classes.push(F)), s.hooks.run("wrap", p);
      var _ = "";
      for (var M in p.attributes)
        _ += " " + M + '="' + (p.attributes[M] || "").replace(/"/g, "&quot;") + '"';
      return "<" + p.tag + ' class="' + p.classes.join(" ") + '"' + _ + ">" + p.content + "</" + p.tag + ">";
    };
    function m(k, f, B, D) {
      k.lastIndex = f;
      var p = k.exec(B);
      if (p && D && p[1]) {
        var F = p[1].length;
        p.index += F, p[0] = p[0].slice(F);
      }
      return p;
    }
    function d(k, f, B, D, p, F) {
      for (var _ in B)
        if (!(!B.hasOwnProperty(_) || !B[_])) {
          var M = B[_];
          M = Array.isArray(M) ? M : [M];
          for (var R = 0; R < M.length; ++R) {
            if (F && F.cause == _ + "," + R)
              return;
            var N = M[R], I = N.inside, $ = !!N.lookbehind, G = !!N.greedy, W = N.alias;
            if (G && !N.pattern.global) {
              var a0 = N.pattern.toString().match(/[imsuy]*$/)[0];
              N.pattern = RegExp(N.pattern.source, a0 + "g");
            }
            for (var j = N.pattern || N, K = D.next, i0 = p; K !== f.tail && !(F && i0 >= F.reach); i0 += K.value.length, K = K.next) {
              var o0 = K.value;
              if (f.length > k.length)
                return;
              if (!(o0 instanceof i)) {
                var H = 1, x0;
                if (G) {
                  if (x0 = m(j, i0, k, $), !x0 || x0.index >= k.length)
                    break;
                  var m0 = x0.index, l0 = x0.index + x0[0].length, Z = i0;
                  for (Z += K.value.length; m0 >= Z; )
                    K = K.next, Z += K.value.length;
                  if (Z -= K.value.length, i0 = Z, K.value instanceof i)
                    continue;
                  for (var u0 = K; u0 !== f.tail && (Z < l0 || typeof u0.value == "string"); u0 = u0.next)
                    H++, Z += u0.value.length;
                  H--, o0 = k.slice(i0, Z), x0.index -= i0;
                } else if (x0 = m(j, 0, o0, $), !x0)
                  continue;
                var m0 = x0.index, E0 = x0[0], T0 = o0.slice(0, m0), g0 = o0.slice(m0 + E0.length), Z0 = i0 + o0.length;
                F && Z0 > F.reach && (F.reach = Z0);
                var N0 = K.prev;
                T0 && (N0 = C(f, N0, T0), i0 += T0.length), A(f, N0, H);
                var re = new i(_, I ? s.tokenize(E0, I) : E0, W, E0);
                if (K = C(f, N0, re), g0 && C(f, K, g0), H > 1) {
                  var W0 = {
                    cause: _ + "," + R,
                    reach: Z0
                  };
                  d(k, f, B, K.prev, i0, W0), F && W0.reach > F.reach && (F.reach = W0.reach);
                }
              }
            }
          }
        }
    }
    function E() {
      var k = { value: null, prev: null, next: null }, f = { value: null, prev: k, next: null };
      k.next = f, this.head = k, this.tail = f, this.length = 0;
    }
    function C(k, f, B) {
      var D = f.next, p = { value: B, prev: f, next: D };
      return f.next = p, D.prev = p, k.length++, p;
    }
    function A(k, f, B) {
      for (var D = f.next, p = 0; p < B && D !== k.tail; p++)
        D = D.next;
      f.next = D, D.prev = f, k.length -= p;
    }
    function b(k) {
      for (var f = [], B = k.head.next; B !== k.tail; )
        f.push(B.value), B = B.next;
      return f;
    }
    if (!x.document)
      return x.addEventListener && (s.disableWorkerMessageHandler || x.addEventListener("message", function(k) {
        var f = JSON.parse(k.data), B = f.language, D = f.code, p = f.immediateClose;
        x.postMessage(s.highlight(D, s.languages[B], B)), p && x.close();
      }, !1)), s;
    var y = s.util.currentScript();
    y && (s.filename = y.src, y.hasAttribute("data-manual") && (s.manual = !0));
    function w() {
      s.manual || s.highlightAll();
    }
    if (!s.manual) {
      var P = document.readyState;
      P === "loading" || P === "interactive" && y && y.defer ? document.addEventListener("DOMContentLoaded", w) : window.requestAnimationFrame ? window.requestAnimationFrame(w) : window.setTimeout(w, 16);
    }
    return s;
  }(e);
  r.exports && (r.exports = t), typeof rr < "u" && (rr.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(x) {
    x.type === "entity" && (x.attributes.title = x.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, n) {
      var o = {};
      o["language-" + n] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[n]
      }, o.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var s = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: o
        }
      };
      s["language-" + n] = {
        pattern: /[\s\S]+/,
        inside: t.languages[n]
      };
      var i = {};
      i[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: s
      }, t.languages.insertBefore("markup", "cdata", i);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(x, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + x + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(x) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    x.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, x.languages.css.atrule.inside.rest = x.languages.css;
    var n = x.languages.markup;
    n && (n.tag.addInlined("style", "css"), n.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var x = "Loading…", a = function(y, w) {
      return "✖ Error " + y + " while fetching file: " + w;
    }, n = "✖ Error: File does not exist or is empty", o = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, s = "data-src-status", i = "loading", m = "loaded", d = "failed", E = "pre[data-src]:not([" + s + '="' + m + '"]):not([' + s + '="' + i + '"])';
    function C(y, w, P) {
      var k = new XMLHttpRequest();
      k.open("GET", y, !0), k.onreadystatechange = function() {
        k.readyState == 4 && (k.status < 400 && k.responseText ? w(k.responseText) : k.status >= 400 ? P(a(k.status, k.statusText)) : P(n));
      }, k.send(null);
    }
    function A(y) {
      var w = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(y || "");
      if (w) {
        var P = Number(w[1]), k = w[2], f = w[3];
        return k ? f ? [P, Number(f)] : [P, void 0] : [P, P];
      }
    }
    t.hooks.add("before-highlightall", function(y) {
      y.selector += ", " + E;
    }), t.hooks.add("before-sanity-check", function(y) {
      var w = (
        /** @type {HTMLPreElement} */
        y.element
      );
      if (w.matches(E)) {
        y.code = "", w.setAttribute(s, i);
        var P = w.appendChild(document.createElement("CODE"));
        P.textContent = x;
        var k = w.getAttribute("data-src"), f = y.language;
        if (f === "none") {
          var B = (/\.(\w+)$/.exec(k) || [, "none"])[1];
          f = o[B] || B;
        }
        t.util.setLanguage(P, f), t.util.setLanguage(w, f);
        var D = t.plugins.autoloader;
        D && D.loadLanguages(f), C(
          k,
          function(p) {
            w.setAttribute(s, m);
            var F = A(w.getAttribute("data-range"));
            if (F) {
              var _ = p.split(/\r\n?|\n/g), M = F[0], R = F[1] == null ? _.length : F[1];
              M < 0 && (M += _.length), M = Math.max(0, Math.min(M - 1, _.length)), R < 0 && (R += _.length), R = Math.max(0, Math.min(R, _.length)), p = _.slice(M, R).join(`
`), w.hasAttribute("data-start") || w.setAttribute("data-start", String(M + 1));
            }
            P.textContent = p, t.highlightElement(P);
          },
          function(p) {
            w.setAttribute(s, d), P.textContent = p;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(w) {
        for (var P = (w || document).querySelectorAll(E), k = 0, f; f = P[k++]; )
          t.highlightElement(f);
      }
    };
    var b = !1;
    t.fileHighlight = function() {
      b || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), b = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Eo);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(r) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  r.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, r.languages.tex = r.languages.latex, r.languages.context = r.languages.latex;
})(Prism);
(function(r) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, x = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  r.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: x
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: x
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: x.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: x.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = r.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], n = x.variable[1].inside, o = 0; o < a.length; o++)
    n[a[o]] = r.languages.bash[a[o]];
  r.languages.sh = r.languages.bash, r.languages.shell = r.languages.bash;
})(Prism);
new Mr();
const mo = (r) => {
  const e = {};
  for (let t = 0, x = r.length; t < x; t++) {
    const a = r[t];
    for (const n in a)
      e[n] ? e[n] = e[n].concat(a[n]) : e[n] = a[n];
  }
  return e;
}, ho = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], fo = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], Bo = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], Co = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Ao = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Do = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
[
  ...ho,
  ...fo.map((r) => `svg:${r}`),
  ...Bo.map((r) => `math:${r}`)
], mo([
  Object.fromEntries(Co.map((r) => [r, ["*"]])),
  Object.fromEntries(Ao.map((r) => [r, ["svg:*"]])),
  Object.fromEntries(Do.map((r) => [r, ["math:*"]]))
]);
new Mr();
/*! @license DOMPurify 3.2.0 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.0/LICENSE */
const {
  entries: i1,
  setPrototypeOf: Na,
  isFrozen: Fo,
  getPrototypeOf: po,
  getOwnPropertyDescriptor: go
} = Object;
let {
  freeze: X0,
  seal: ie,
  create: s1
} = Object, {
  apply: ar,
  construct: nr
} = typeof Reflect < "u" && Reflect;
X0 || (X0 = function(e) {
  return e;
});
ie || (ie = function(e) {
  return e;
});
ar || (ar = function(e, t, x) {
  return e.apply(t, x);
});
nr || (nr = function(e, t) {
  return new e(...t);
});
const Nt = ee(Array.prototype.forEach), La = ee(Array.prototype.pop), nt = ee(Array.prototype.push), $t = ee(String.prototype.toLowerCase), Px = ee(String.prototype.toString), Ia = ee(String.prototype.match), ot = ee(String.prototype.replace), vo = ee(String.prototype.indexOf), bo = ee(String.prototype.trim), se = ee(Object.prototype.hasOwnProperty), U0 = ee(RegExp.prototype.test), lt = ko(TypeError);
function ee(r) {
  return function(e) {
    for (var t = arguments.length, x = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      x[a - 1] = arguments[a];
    return ar(r, e, x);
  };
}
function ko(r) {
  return function() {
    for (var e = arguments.length, t = new Array(e), x = 0; x < e; x++)
      t[x] = arguments[x];
    return nr(r, t);
  };
}
function c0(r, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : $t;
  Na && Na(r, null);
  let x = e.length;
  for (; x--; ) {
    let a = e[x];
    if (typeof a == "string") {
      const n = t(a);
      n !== a && (Fo(e) || (e[x] = n), a = n);
    }
    r[a] = !0;
  }
  return r;
}
function wo(r) {
  for (let e = 0; e < r.length; e++)
    se(r, e) || (r[e] = null);
  return r;
}
function Oe(r) {
  const e = s1(null);
  for (const [t, x] of i1(r))
    se(r, t) && (Array.isArray(x) ? e[t] = wo(x) : x && typeof x == "object" && x.constructor === Object ? e[t] = Oe(x) : e[t] = x);
  return e;
}
function it(r, e) {
  for (; r !== null; ) {
    const x = go(r, e);
    if (x) {
      if (x.get)
        return ee(x.get);
      if (typeof x.value == "function")
        return ee(x.value);
    }
    r = po(r);
  }
  function t() {
    return null;
  }
  return t;
}
const Oa = X0(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), _x = X0(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), zx = X0(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), yo = X0(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Rx = X0(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), So = X0(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), qa = X0(["#text"]), Ha = X0(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Nx = X0(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Ua = X0(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Lt = X0(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), To = ie(/\{\{[\w\W]*|[\w\W]*\}\}/gm), Mo = ie(/<%[\w\W]*|[\w\W]*%>/gm), Po = ie(/\${[\w\W]*}/gm), _o = ie(/^data-[\-\w.\u00B7-\uFFFF]/), zo = ie(/^aria-[\-\w]+$/), u1 = ie(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Ro = ie(/^(?:\w+script|data):/i), No = ie(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), c1 = ie(/^html$/i), Lo = ie(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Ga = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: zo,
  ATTR_WHITESPACE: No,
  CUSTOM_ELEMENT: Lo,
  DATA_ATTR: _o,
  DOCTYPE_NAME: c1,
  ERB_EXPR: Mo,
  IS_ALLOWED_URI: u1,
  IS_SCRIPT_OR_DATA: Ro,
  MUSTACHE_EXPR: To,
  TMPLIT_EXPR: Po
});
const st = {
  element: 1,
  attribute: 2,
  text: 3,
  cdataSection: 4,
  entityReference: 5,
  // Deprecated
  entityNode: 6,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9,
  documentType: 10,
  documentFragment: 11,
  notation: 12
  // Deprecated
}, Io = function() {
  return typeof window > "u" ? null : window;
}, Oo = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let x = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (x = t.getAttribute(a));
  const n = "dompurify" + (x ? "#" + x : "");
  try {
    return e.createPolicy(n, {
      createHTML(o) {
        return o;
      },
      createScriptURL(o) {
        return o;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + n + " could not be created."), null;
  }
};
function E1() {
  let r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Io();
  const e = (Q) => E1(Q);
  if (e.version = "3.2.0", e.removed = [], !r || !r.document || r.document.nodeType !== st.document)
    return e.isSupported = !1, e;
  let {
    document: t
  } = r;
  const x = t, a = x.currentScript, {
    DocumentFragment: n,
    HTMLTemplateElement: o,
    Node: s,
    Element: i,
    NodeFilter: m,
    NamedNodeMap: d = r.NamedNodeMap || r.MozNamedAttrMap,
    HTMLFormElement: E,
    DOMParser: C,
    trustedTypes: A
  } = r, b = i.prototype, y = it(b, "cloneNode"), w = it(b, "remove"), P = it(b, "nextSibling"), k = it(b, "childNodes"), f = it(b, "parentNode");
  if (typeof o == "function") {
    const Q = t.createElement("template");
    Q.content && Q.content.ownerDocument && (t = Q.content.ownerDocument);
  }
  let B, D = "";
  const {
    implementation: p,
    createNodeIterator: F,
    createDocumentFragment: _,
    getElementsByTagName: M
  } = t, {
    importNode: R
  } = x;
  let N = {};
  e.isSupported = typeof i1 == "function" && typeof f == "function" && p && p.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: I,
    ERB_EXPR: $,
    TMPLIT_EXPR: G,
    DATA_ATTR: W,
    ARIA_ATTR: a0,
    IS_SCRIPT_OR_DATA: j,
    ATTR_WHITESPACE: K,
    CUSTOM_ELEMENT: i0
  } = Ga;
  let {
    IS_ALLOWED_URI: o0
  } = Ga, H = null;
  const x0 = c0({}, [...Oa, ..._x, ...zx, ...Rx, ...qa]);
  let l0 = null;
  const Z = c0({}, [...Ha, ...Nx, ...Ua, ...Lt]);
  let u0 = Object.seal(s1(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), m0 = null, E0 = null, T0 = !0, g0 = !0, Z0 = !1, N0 = !0, re = !1, W0 = !0, P0 = !1, j0 = !1, ae = !1, I0 = !1, O0 = !1, w0 = !1, Pr = !0, K0 = !1;
  const f1 = "user-content-";
  let hx = !0, tt = !1, Xe = {}, $e = null;
  const _r = c0({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let zr = null;
  const Rr = c0({}, ["audio", "video", "img", "source", "image", "track"]);
  let fx = null;
  const Nr = c0({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), pt = "http://www.w3.org/1998/Math/MathML", gt = "http://www.w3.org/2000/svg", Fe = "http://www.w3.org/1999/xhtml";
  let We = Fe, Bx = !1, Cx = null;
  const B1 = c0({}, [pt, gt, Fe], Px);
  let vt = c0({}, ["mi", "mo", "mn", "ms", "mtext"]), bt = c0({}, ["annotation-xml"]);
  const C1 = c0({}, ["title", "style", "font", "a", "script"]);
  let xt = null;
  const A1 = ["application/xhtml+xml", "text/html"], D1 = "text/html";
  let M0 = null, je = null;
  const F1 = t.createElement("form"), Lr = function(T) {
    return T instanceof RegExp || T instanceof Function;
  }, Ax = function() {
    let T = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(je && je === T)) {
      if ((!T || typeof T != "object") && (T = {}), T = Oe(T), xt = // eslint-disable-next-line unicorn/prefer-includes
      A1.indexOf(T.PARSER_MEDIA_TYPE) === -1 ? D1 : T.PARSER_MEDIA_TYPE, M0 = xt === "application/xhtml+xml" ? Px : $t, H = se(T, "ALLOWED_TAGS") ? c0({}, T.ALLOWED_TAGS, M0) : x0, l0 = se(T, "ALLOWED_ATTR") ? c0({}, T.ALLOWED_ATTR, M0) : Z, Cx = se(T, "ALLOWED_NAMESPACES") ? c0({}, T.ALLOWED_NAMESPACES, Px) : B1, fx = se(T, "ADD_URI_SAFE_ATTR") ? c0(Oe(Nr), T.ADD_URI_SAFE_ATTR, M0) : Nr, zr = se(T, "ADD_DATA_URI_TAGS") ? c0(Oe(Rr), T.ADD_DATA_URI_TAGS, M0) : Rr, $e = se(T, "FORBID_CONTENTS") ? c0({}, T.FORBID_CONTENTS, M0) : _r, m0 = se(T, "FORBID_TAGS") ? c0({}, T.FORBID_TAGS, M0) : {}, E0 = se(T, "FORBID_ATTR") ? c0({}, T.FORBID_ATTR, M0) : {}, Xe = se(T, "USE_PROFILES") ? T.USE_PROFILES : !1, T0 = T.ALLOW_ARIA_ATTR !== !1, g0 = T.ALLOW_DATA_ATTR !== !1, Z0 = T.ALLOW_UNKNOWN_PROTOCOLS || !1, N0 = T.ALLOW_SELF_CLOSE_IN_ATTR !== !1, re = T.SAFE_FOR_TEMPLATES || !1, W0 = T.SAFE_FOR_XML !== !1, P0 = T.WHOLE_DOCUMENT || !1, I0 = T.RETURN_DOM || !1, O0 = T.RETURN_DOM_FRAGMENT || !1, w0 = T.RETURN_TRUSTED_TYPE || !1, ae = T.FORCE_BODY || !1, Pr = T.SANITIZE_DOM !== !1, K0 = T.SANITIZE_NAMED_PROPS || !1, hx = T.KEEP_CONTENT !== !1, tt = T.IN_PLACE || !1, o0 = T.ALLOWED_URI_REGEXP || u1, We = T.NAMESPACE || Fe, vt = T.MATHML_TEXT_INTEGRATION_POINTS || vt, bt = T.HTML_INTEGRATION_POINTS || bt, u0 = T.CUSTOM_ELEMENT_HANDLING || {}, T.CUSTOM_ELEMENT_HANDLING && Lr(T.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (u0.tagNameCheck = T.CUSTOM_ELEMENT_HANDLING.tagNameCheck), T.CUSTOM_ELEMENT_HANDLING && Lr(T.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (u0.attributeNameCheck = T.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), T.CUSTOM_ELEMENT_HANDLING && typeof T.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (u0.allowCustomizedBuiltInElements = T.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), re && (g0 = !1), O0 && (I0 = !0), Xe && (H = c0({}, qa), l0 = [], Xe.html === !0 && (c0(H, Oa), c0(l0, Ha)), Xe.svg === !0 && (c0(H, _x), c0(l0, Nx), c0(l0, Lt)), Xe.svgFilters === !0 && (c0(H, zx), c0(l0, Nx), c0(l0, Lt)), Xe.mathMl === !0 && (c0(H, Rx), c0(l0, Ua), c0(l0, Lt))), T.ADD_TAGS && (H === x0 && (H = Oe(H)), c0(H, T.ADD_TAGS, M0)), T.ADD_ATTR && (l0 === Z && (l0 = Oe(l0)), c0(l0, T.ADD_ATTR, M0)), T.ADD_URI_SAFE_ATTR && c0(fx, T.ADD_URI_SAFE_ATTR, M0), T.FORBID_CONTENTS && ($e === _r && ($e = Oe($e)), c0($e, T.FORBID_CONTENTS, M0)), hx && (H["#text"] = !0), P0 && c0(H, ["html", "head", "body"]), H.table && (c0(H, ["tbody"]), delete m0.tbody), T.TRUSTED_TYPES_POLICY) {
        if (typeof T.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw lt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof T.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw lt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        B = T.TRUSTED_TYPES_POLICY, D = B.createHTML("");
      } else
        B === void 0 && (B = Oo(A, a)), B !== null && typeof D == "string" && (D = B.createHTML(""));
      X0 && X0(T), je = T;
    }
  }, Ir = c0({}, [..._x, ...zx, ...yo]), Or = c0({}, [...Rx, ...So]), p1 = function(T) {
    let q = f(T);
    (!q || !q.tagName) && (q = {
      namespaceURI: We,
      tagName: "template"
    });
    const Y = $t(T.tagName), A0 = $t(q.tagName);
    return Cx[T.namespaceURI] ? T.namespaceURI === gt ? q.namespaceURI === Fe ? Y === "svg" : q.namespaceURI === pt ? Y === "svg" && (A0 === "annotation-xml" || vt[A0]) : !!Ir[Y] : T.namespaceURI === pt ? q.namespaceURI === Fe ? Y === "math" : q.namespaceURI === gt ? Y === "math" && bt[A0] : !!Or[Y] : T.namespaceURI === Fe ? q.namespaceURI === gt && !bt[A0] || q.namespaceURI === pt && !vt[A0] ? !1 : !Or[Y] && (C1[Y] || !Ir[Y]) : !!(xt === "application/xhtml+xml" && Cx[T.namespaceURI]) : !1;
  }, Ee = function(T) {
    nt(e.removed, {
      element: T
    });
    try {
      f(T).removeChild(T);
    } catch {
      w(T);
    }
  }, kt = function(T, q) {
    try {
      nt(e.removed, {
        attribute: q.getAttributeNode(T),
        from: q
      });
    } catch {
      nt(e.removed, {
        attribute: null,
        from: q
      });
    }
    if (q.removeAttribute(T), T === "is" && !l0[T])
      if (I0 || O0)
        try {
          Ee(q);
        } catch {
        }
      else
        try {
          q.setAttribute(T, "");
        } catch {
        }
  }, qr = function(T) {
    let q = null, Y = null;
    if (ae)
      T = "<remove></remove>" + T;
    else {
      const _0 = Ia(T, /^[\r\n\t ]+/);
      Y = _0 && _0[0];
    }
    xt === "application/xhtml+xml" && We === Fe && (T = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + T + "</body></html>");
    const A0 = B ? B.createHTML(T) : T;
    if (We === Fe)
      try {
        q = new C().parseFromString(A0, xt);
      } catch {
      }
    if (!q || !q.documentElement) {
      q = p.createDocument(We, "template", null);
      try {
        q.documentElement.innerHTML = Bx ? D : A0;
      } catch {
      }
    }
    const L0 = q.body || q.documentElement;
    return T && Y && L0.insertBefore(t.createTextNode(Y), L0.childNodes[0] || null), We === Fe ? M.call(q, P0 ? "html" : "body")[0] : P0 ? q.documentElement : L0;
  }, Hr = function(T) {
    return F.call(
      T.ownerDocument || T,
      T,
      // eslint-disable-next-line no-bitwise
      m.SHOW_ELEMENT | m.SHOW_COMMENT | m.SHOW_TEXT | m.SHOW_PROCESSING_INSTRUCTION | m.SHOW_CDATA_SECTION,
      null
    );
  }, Ur = function(T) {
    return T instanceof E && (typeof T.nodeName != "string" || typeof T.textContent != "string" || typeof T.removeChild != "function" || !(T.attributes instanceof d) || typeof T.removeAttribute != "function" || typeof T.setAttribute != "function" || typeof T.namespaceURI != "string" || typeof T.insertBefore != "function" || typeof T.hasChildNodes != "function");
  }, Gr = function(T) {
    return typeof s == "function" && T instanceof s;
  };
  function pe(Q, T, q) {
    N[Q] && Nt(N[Q], (Y) => {
      Y.call(e, T, q, je);
    });
  }
  const Vr = function(T) {
    let q = null;
    if (pe("beforeSanitizeElements", T, null), Ur(T))
      return Ee(T), !0;
    const Y = M0(T.nodeName);
    if (pe("uponSanitizeElement", T, {
      tagName: Y,
      allowedTags: H
    }), T.hasChildNodes() && !Gr(T.firstElementChild) && U0(/<[/\w]/g, T.innerHTML) && U0(/<[/\w]/g, T.textContent) || T.nodeType === st.progressingInstruction || W0 && T.nodeType === st.comment && U0(/<[/\w]/g, T.data))
      return Ee(T), !0;
    if (!H[Y] || m0[Y]) {
      if (!m0[Y] && $r(Y) && (u0.tagNameCheck instanceof RegExp && U0(u0.tagNameCheck, Y) || u0.tagNameCheck instanceof Function && u0.tagNameCheck(Y)))
        return !1;
      if (hx && !$e[Y]) {
        const A0 = f(T) || T.parentNode, L0 = k(T) || T.childNodes;
        if (L0 && A0) {
          const _0 = L0.length;
          for (let Y0 = _0 - 1; Y0 >= 0; --Y0) {
            const de = y(L0[Y0], !0);
            de.__removalCount = (T.__removalCount || 0) + 1, A0.insertBefore(de, P(T));
          }
        }
      }
      return Ee(T), !0;
    }
    return T instanceof i && !p1(T) || (Y === "noscript" || Y === "noembed" || Y === "noframes") && U0(/<\/no(script|embed|frames)/i, T.innerHTML) ? (Ee(T), !0) : (re && T.nodeType === st.text && (q = T.textContent, Nt([I, $, G], (A0) => {
      q = ot(q, A0, " ");
    }), T.textContent !== q && (nt(e.removed, {
      element: T.cloneNode()
    }), T.textContent = q)), pe("afterSanitizeElements", T, null), !1);
  }, Xr = function(T, q, Y) {
    if (Pr && (q === "id" || q === "name") && (Y in t || Y in F1))
      return !1;
    if (!(g0 && !E0[q] && U0(W, q))) {
      if (!(T0 && U0(a0, q))) {
        if (!l0[q] || E0[q]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !($r(T) && (u0.tagNameCheck instanceof RegExp && U0(u0.tagNameCheck, T) || u0.tagNameCheck instanceof Function && u0.tagNameCheck(T)) && (u0.attributeNameCheck instanceof RegExp && U0(u0.attributeNameCheck, q) || u0.attributeNameCheck instanceof Function && u0.attributeNameCheck(q)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            q === "is" && u0.allowCustomizedBuiltInElements && (u0.tagNameCheck instanceof RegExp && U0(u0.tagNameCheck, Y) || u0.tagNameCheck instanceof Function && u0.tagNameCheck(Y)))
          ) return !1;
        } else if (!fx[q]) {
          if (!U0(o0, ot(Y, K, ""))) {
            if (!((q === "src" || q === "xlink:href" || q === "href") && T !== "script" && vo(Y, "data:") === 0 && zr[T])) {
              if (!(Z0 && !U0(j, ot(Y, K, "")))) {
                if (Y)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, $r = function(T) {
    return T !== "annotation-xml" && Ia(T, i0);
  }, Wr = function(T) {
    pe("beforeSanitizeAttributes", T, null);
    const {
      attributes: q
    } = T;
    if (!q)
      return;
    const Y = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: l0,
      forceKeepAttr: void 0
    };
    let A0 = q.length;
    for (; A0--; ) {
      const L0 = q[A0], {
        name: _0,
        namespaceURI: Y0,
        value: de
      } = L0, rt = M0(_0);
      let q0 = _0 === "value" ? de : bo(de);
      if (Y.attrName = rt, Y.attrValue = q0, Y.keepAttr = !0, Y.forceKeepAttr = void 0, pe("uponSanitizeAttribute", T, Y), q0 = Y.attrValue, K0 && (rt === "id" || rt === "name") && (kt(_0, T), q0 = f1 + q0), W0 && U0(/((--!?|])>)|<\/(style|title)/i, q0)) {
        kt(_0, T);
        continue;
      }
      if (Y.forceKeepAttr || (kt(_0, T), !Y.keepAttr))
        continue;
      if (!N0 && U0(/\/>/i, q0)) {
        kt(_0, T);
        continue;
      }
      re && Nt([I, $, G], (Yr) => {
        q0 = ot(q0, Yr, " ");
      });
      const jr = M0(T.nodeName);
      if (Xr(jr, rt, q0)) {
        if (B && typeof A == "object" && typeof A.getAttributeType == "function" && !Y0)
          switch (A.getAttributeType(jr, rt)) {
            case "TrustedHTML": {
              q0 = B.createHTML(q0);
              break;
            }
            case "TrustedScriptURL": {
              q0 = B.createScriptURL(q0);
              break;
            }
          }
        try {
          Y0 ? T.setAttributeNS(Y0, _0, q0) : T.setAttribute(_0, q0), Ur(T) ? Ee(T) : La(e.removed);
        } catch {
        }
      }
    }
    pe("afterSanitizeAttributes", T, null);
  }, g1 = function Q(T) {
    let q = null;
    const Y = Hr(T);
    for (pe("beforeSanitizeShadowDOM", T, null); q = Y.nextNode(); )
      pe("uponSanitizeShadowNode", q, null), !Vr(q) && (q.content instanceof n && Q(q.content), Wr(q));
    pe("afterSanitizeShadowDOM", T, null);
  };
  return e.sanitize = function(Q) {
    let T = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, q = null, Y = null, A0 = null, L0 = null;
    if (Bx = !Q, Bx && (Q = "<!-->"), typeof Q != "string" && !Gr(Q))
      if (typeof Q.toString == "function") {
        if (Q = Q.toString(), typeof Q != "string")
          throw lt("dirty is not a string, aborting");
      } else
        throw lt("toString is not a function");
    if (!e.isSupported)
      return Q;
    if (j0 || Ax(T), e.removed = [], typeof Q == "string" && (tt = !1), tt) {
      if (Q.nodeName) {
        const de = M0(Q.nodeName);
        if (!H[de] || m0[de])
          throw lt("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (Q instanceof s)
      q = qr("<!---->"), Y = q.ownerDocument.importNode(Q, !0), Y.nodeType === st.element && Y.nodeName === "BODY" || Y.nodeName === "HTML" ? q = Y : q.appendChild(Y);
    else {
      if (!I0 && !re && !P0 && // eslint-disable-next-line unicorn/prefer-includes
      Q.indexOf("<") === -1)
        return B && w0 ? B.createHTML(Q) : Q;
      if (q = qr(Q), !q)
        return I0 ? null : w0 ? D : "";
    }
    q && ae && Ee(q.firstChild);
    const _0 = Hr(tt ? Q : q);
    for (; A0 = _0.nextNode(); )
      Vr(A0) || (A0.content instanceof n && g1(A0.content), Wr(A0));
    if (tt)
      return Q;
    if (I0) {
      if (O0)
        for (L0 = _.call(q.ownerDocument); q.firstChild; )
          L0.appendChild(q.firstChild);
      else
        L0 = q;
      return (l0.shadowroot || l0.shadowrootmode) && (L0 = R.call(x, L0, !0)), L0;
    }
    let Y0 = P0 ? q.outerHTML : q.innerHTML;
    return P0 && H["!doctype"] && q.ownerDocument && q.ownerDocument.doctype && q.ownerDocument.doctype.name && U0(c1, q.ownerDocument.doctype.name) && (Y0 = "<!DOCTYPE " + q.ownerDocument.doctype.name + `>
` + Y0), re && Nt([I, $, G], (de) => {
      Y0 = ot(Y0, de, " ");
    }), B && w0 ? B.createHTML(Y0) : Y0;
  }, e.setConfig = function() {
    let Q = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Ax(Q), j0 = !0;
  }, e.clearConfig = function() {
    je = null, j0 = !1;
  }, e.isValidAttribute = function(Q, T, q) {
    je || Ax({});
    const Y = M0(Q), A0 = M0(T);
    return Xr(Y, A0, q);
  }, e.addHook = function(Q, T) {
    typeof T == "function" && (N[Q] = N[Q] || [], nt(N[Q], T));
  }, e.removeHook = function(Q) {
    if (N[Q])
      return La(N[Q]);
  }, e.removeHooks = function(Q) {
    N[Q] && (N[Q] = []);
  }, e.removeAllHooks = function() {
    N = {};
  }, e;
}
E1();
const {
  SvelteComponent: qo,
  append_hydration: Lx,
  attr: It,
  children: Va,
  claim_component: Ho,
  claim_element: Xa,
  claim_space: Uo,
  claim_text: Go,
  create_component: Vo,
  destroy_component: Xo,
  detach: Ix,
  element: $a,
  init: $o,
  insert_hydration: Wo,
  mount_component: jo,
  safe_not_equal: Yo,
  set_data: Qo,
  space: Zo,
  text: Ko,
  toggle_class: Me,
  transition_in: Jo,
  transition_out: el
} = window.__gradio__svelte__internal;
function tl(r) {
  let e, t, x, a, n, o;
  return x = new /*Icon*/
  r[1]({}), {
    c() {
      e = $a("label"), t = $a("span"), Vo(x.$$.fragment), a = Zo(), n = Ko(
        /*label*/
        r[0]
      ), this.h();
    },
    l(s) {
      e = Xa(s, "LABEL", {
        for: !0,
        "data-testid": !0,
        class: !0
      });
      var i = Va(e);
      t = Xa(i, "SPAN", { class: !0 });
      var m = Va(t);
      Ho(x.$$.fragment, m), m.forEach(Ix), a = Uo(i), n = Go(
        i,
        /*label*/
        r[0]
      ), i.forEach(Ix), this.h();
    },
    h() {
      It(t, "class", "svelte-168uj4v"), It(e, "for", ""), It(e, "data-testid", "block-label"), It(e, "class", "svelte-168uj4v"), Me(e, "hide", !/*show_label*/
      r[2]), Me(e, "sr-only", !/*show_label*/
      r[2]), Me(
        e,
        "float",
        /*float*/
        r[4]
      ), Me(
        e,
        "hide-label",
        /*disable*/
        r[3]
      );
    },
    m(s, i) {
      Wo(s, e, i), Lx(e, t), jo(x, t, null), Lx(e, a), Lx(e, n), o = !0;
    },
    p(s, [i]) {
      (!o || i & /*label*/
      1) && Qo(
        n,
        /*label*/
        s[0]
      ), (!o || i & /*show_label*/
      4) && Me(e, "hide", !/*show_label*/
      s[2]), (!o || i & /*show_label*/
      4) && Me(e, "sr-only", !/*show_label*/
      s[2]), (!o || i & /*float*/
      16) && Me(
        e,
        "float",
        /*float*/
        s[4]
      ), (!o || i & /*disable*/
      8) && Me(
        e,
        "hide-label",
        /*disable*/
        s[3]
      );
    },
    i(s) {
      o || (Jo(x.$$.fragment, s), o = !0);
    },
    o(s) {
      el(x.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Ix(e), Xo(x);
    }
  };
}
function xl(r, e, t) {
  let { label: x = null } = e, { Icon: a } = e, { show_label: n = !0 } = e, { disable: o = !1 } = e, { float: s = !0 } = e;
  return r.$$set = (i) => {
    "label" in i && t(0, x = i.label), "Icon" in i && t(1, a = i.Icon), "show_label" in i && t(2, n = i.show_label), "disable" in i && t(3, o = i.disable), "float" in i && t(4, s = i.float);
  }, [x, a, n, o, s];
}
class rl extends qo {
  constructor(e) {
    super(), $o(this, e, xl, tl, Yo, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: al,
  append_hydration: nl,
  attr: Ox,
  binding_callbacks: ol,
  children: Wa,
  claim_element: ja,
  create_slot: ll,
  detach: qx,
  element: Ya,
  get_all_dirty_from_scope: il,
  get_slot_changes: sl,
  init: ul,
  insert_hydration: cl,
  safe_not_equal: El,
  toggle_class: Pe,
  transition_in: dl,
  transition_out: ml,
  update_slot_base: hl
} = window.__gradio__svelte__internal;
function fl(r) {
  let e, t, x;
  const a = (
    /*#slots*/
    r[5].default
  ), n = ll(
    a,
    r,
    /*$$scope*/
    r[4],
    null
  );
  return {
    c() {
      e = Ya("div"), t = Ya("div"), n && n.c(), this.h();
    },
    l(o) {
      e = ja(o, "DIV", { class: !0, "aria-label": !0 });
      var s = Wa(e);
      t = ja(s, "DIV", { class: !0 });
      var i = Wa(t);
      n && n.l(i), i.forEach(qx), s.forEach(qx), this.h();
    },
    h() {
      Ox(t, "class", "icon svelte-3w3rth"), Ox(e, "class", "empty svelte-3w3rth"), Ox(e, "aria-label", "Empty value"), Pe(
        e,
        "small",
        /*size*/
        r[0] === "small"
      ), Pe(
        e,
        "large",
        /*size*/
        r[0] === "large"
      ), Pe(
        e,
        "unpadded_box",
        /*unpadded_box*/
        r[1]
      ), Pe(
        e,
        "small_parent",
        /*parent_height*/
        r[3]
      );
    },
    m(o, s) {
      cl(o, e, s), nl(e, t), n && n.m(t, null), r[6](e), x = !0;
    },
    p(o, [s]) {
      n && n.p && (!x || s & /*$$scope*/
      16) && hl(
        n,
        a,
        o,
        /*$$scope*/
        o[4],
        x ? sl(
          a,
          /*$$scope*/
          o[4],
          s,
          null
        ) : il(
          /*$$scope*/
          o[4]
        ),
        null
      ), (!x || s & /*size*/
      1) && Pe(
        e,
        "small",
        /*size*/
        o[0] === "small"
      ), (!x || s & /*size*/
      1) && Pe(
        e,
        "large",
        /*size*/
        o[0] === "large"
      ), (!x || s & /*unpadded_box*/
      2) && Pe(
        e,
        "unpadded_box",
        /*unpadded_box*/
        o[1]
      ), (!x || s & /*parent_height*/
      8) && Pe(
        e,
        "small_parent",
        /*parent_height*/
        o[3]
      );
    },
    i(o) {
      x || (dl(n, o), x = !0);
    },
    o(o) {
      ml(n, o), x = !1;
    },
    d(o) {
      o && qx(e), n && n.d(o), r[6](null);
    }
  };
}
function Bl(r, e, t) {
  let x, { $$slots: a = {}, $$scope: n } = e, { size: o = "small" } = e, { unpadded_box: s = !1 } = e, i;
  function m(E) {
    var C;
    if (!E) return !1;
    const { height: A } = E.getBoundingClientRect(), { height: b } = ((C = E.parentElement) === null || C === void 0 ? void 0 : C.getBoundingClientRect()) || { height: A };
    return A > b + 2;
  }
  function d(E) {
    ol[E ? "unshift" : "push"](() => {
      i = E, t(2, i);
    });
  }
  return r.$$set = (E) => {
    "size" in E && t(0, o = E.size), "unpadded_box" in E && t(1, s = E.unpadded_box), "$$scope" in E && t(4, n = E.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty & /*el*/
    4 && t(3, x = m(i));
  }, [o, s, i, x, n, a, d];
}
class Cl extends al {
  constructor(e) {
    super(), ul(this, e, Bl, fl, El, { size: 0, unpadded_box: 1 });
  }
}
const {
  SvelteComponent: Al,
  append_hydration: Hx,
  attr: y0,
  children: Ot,
  claim_svg_element: qt,
  detach: ut,
  init: Dl,
  insert_hydration: Fl,
  noop: Ux,
  safe_not_equal: pl,
  svg_element: Ht
} = window.__gradio__svelte__internal;
function gl(r) {
  let e, t, x, a;
  return {
    c() {
      e = Ht("svg"), t = Ht("rect"), x = Ht("circle"), a = Ht("polyline"), this.h();
    },
    l(n) {
      e = qt(n, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var o = Ot(e);
      t = qt(o, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), Ot(t).forEach(ut), x = qt(o, "circle", { cx: !0, cy: !0, r: !0 }), Ot(x).forEach(ut), a = qt(o, "polyline", { points: !0 }), Ot(a).forEach(ut), o.forEach(ut), this.h();
    },
    h() {
      y0(t, "x", "3"), y0(t, "y", "3"), y0(t, "width", "18"), y0(t, "height", "18"), y0(t, "rx", "2"), y0(t, "ry", "2"), y0(x, "cx", "8.5"), y0(x, "cy", "8.5"), y0(x, "r", "1.5"), y0(a, "points", "21 15 16 10 5 21"), y0(e, "xmlns", "http://www.w3.org/2000/svg"), y0(e, "width", "100%"), y0(e, "height", "100%"), y0(e, "viewBox", "0 0 24 24"), y0(e, "fill", "none"), y0(e, "stroke", "currentColor"), y0(e, "stroke-width", "1.5"), y0(e, "stroke-linecap", "round"), y0(e, "stroke-linejoin", "round"), y0(e, "class", "feather feather-image");
    },
    m(n, o) {
      Fl(n, e, o), Hx(e, t), Hx(e, x), Hx(e, a);
    },
    p: Ux,
    i: Ux,
    o: Ux,
    d(n) {
      n && ut(e);
    }
  };
}
class d1 extends Al {
  constructor(e) {
    super(), Dl(this, e, null, gl, pl, {});
  }
}
var m1 = { exports: {} };
(function(r, e) {
  (function(x, a) {
    r.exports = a();
  })(typeof self < "u" ? self : rr, function() {
    return (
      /******/
      function(t) {
        var x = {};
        function a(n) {
          if (x[n])
            return x[n].exports;
          var o = x[n] = {
            /******/
            i: n,
            /******/
            l: !1,
            /******/
            exports: {}
            /******/
          };
          return t[n].call(o.exports, o, o.exports, a), o.l = !0, o.exports;
        }
        return a.m = t, a.c = x, a.d = function(n, o, s) {
          a.o(n, o) || Object.defineProperty(n, o, {
            /******/
            configurable: !1,
            /******/
            enumerable: !0,
            /******/
            get: s
            /******/
          });
        }, a.n = function(n) {
          var o = n && n.__esModule ? (
            /******/
            function() {
              return n.default;
            }
          ) : (
            /******/
            function() {
              return n;
            }
          );
          return a.d(o, "a", o), o;
        }, a.o = function(n, o) {
          return Object.prototype.hasOwnProperty.call(n, o);
        }, a.p = "", a(a.s = 3);
      }([
        /* 0 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = (
            /** @class */
            function() {
              function o(s, i) {
                this.width = i, this.height = s.length / i, this.data = s;
              }
              return o.createEmpty = function(s, i) {
                return new o(new Uint8ClampedArray(s * i), s);
              }, o.prototype.get = function(s, i) {
                return s < 0 || s >= this.width || i < 0 || i >= this.height ? !1 : !!this.data[i * this.width + s];
              }, o.prototype.set = function(s, i, m) {
                this.data[i * this.width + s] = m ? 1 : 0;
              }, o.prototype.setRegion = function(s, i, m, d, E) {
                for (var C = i; C < i + d; C++)
                  for (var A = s; A < s + m; A++)
                    this.set(A, C, !!E);
              }, o;
            }()
          );
          x.BitMatrix = n;
        },
        /* 1 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = a(2);
          function o(i, m) {
            return i ^ m;
          }
          x.addOrSubtractGF = o;
          var s = (
            /** @class */
            function() {
              function i(m, d, E) {
                this.primitive = m, this.size = d, this.generatorBase = E, this.expTable = new Array(this.size), this.logTable = new Array(this.size);
                for (var C = 1, A = 0; A < this.size; A++)
                  this.expTable[A] = C, C = C * 2, C >= this.size && (C = (C ^ this.primitive) & this.size - 1);
                for (var A = 0; A < this.size - 1; A++)
                  this.logTable[this.expTable[A]] = A;
                this.zero = new n.default(this, Uint8ClampedArray.from([0])), this.one = new n.default(this, Uint8ClampedArray.from([1]));
              }
              return i.prototype.multiply = function(m, d) {
                return m === 0 || d === 0 ? 0 : this.expTable[(this.logTable[m] + this.logTable[d]) % (this.size - 1)];
              }, i.prototype.inverse = function(m) {
                if (m === 0)
                  throw new Error("Can't invert 0");
                return this.expTable[this.size - this.logTable[m] - 1];
              }, i.prototype.buildMonomial = function(m, d) {
                if (m < 0)
                  throw new Error("Invalid monomial degree less than 0");
                if (d === 0)
                  return this.zero;
                var E = new Uint8ClampedArray(m + 1);
                return E[0] = d, new n.default(this, E);
              }, i.prototype.log = function(m) {
                if (m === 0)
                  throw new Error("Can't take log(0)");
                return this.logTable[m];
              }, i.prototype.exp = function(m) {
                return this.expTable[m];
              }, i;
            }()
          );
          x.default = s;
        },
        /* 2 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = a(1), o = (
            /** @class */
            function() {
              function s(i, m) {
                if (m.length === 0)
                  throw new Error("No coefficients.");
                this.field = i;
                var d = m.length;
                if (d > 1 && m[0] === 0) {
                  for (var E = 1; E < d && m[E] === 0; )
                    E++;
                  if (E === d)
                    this.coefficients = i.zero.coefficients;
                  else {
                    this.coefficients = new Uint8ClampedArray(d - E);
                    for (var C = 0; C < this.coefficients.length; C++)
                      this.coefficients[C] = m[E + C];
                  }
                } else
                  this.coefficients = m;
              }
              return s.prototype.degree = function() {
                return this.coefficients.length - 1;
              }, s.prototype.isZero = function() {
                return this.coefficients[0] === 0;
              }, s.prototype.getCoefficient = function(i) {
                return this.coefficients[this.coefficients.length - 1 - i];
              }, s.prototype.addOrSubtract = function(i) {
                var m;
                if (this.isZero())
                  return i;
                if (i.isZero())
                  return this;
                var d = this.coefficients, E = i.coefficients;
                d.length > E.length && (m = [E, d], d = m[0], E = m[1]);
                for (var C = new Uint8ClampedArray(E.length), A = E.length - d.length, b = 0; b < A; b++)
                  C[b] = E[b];
                for (var b = A; b < E.length; b++)
                  C[b] = n.addOrSubtractGF(d[b - A], E[b]);
                return new s(this.field, C);
              }, s.prototype.multiply = function(i) {
                if (i === 0)
                  return this.field.zero;
                if (i === 1)
                  return this;
                for (var m = this.coefficients.length, d = new Uint8ClampedArray(m), E = 0; E < m; E++)
                  d[E] = this.field.multiply(this.coefficients[E], i);
                return new s(this.field, d);
              }, s.prototype.multiplyPoly = function(i) {
                if (this.isZero() || i.isZero())
                  return this.field.zero;
                for (var m = this.coefficients, d = m.length, E = i.coefficients, C = E.length, A = new Uint8ClampedArray(d + C - 1), b = 0; b < d; b++)
                  for (var y = m[b], w = 0; w < C; w++)
                    A[b + w] = n.addOrSubtractGF(A[b + w], this.field.multiply(y, E[w]));
                return new s(this.field, A);
              }, s.prototype.multiplyByMonomial = function(i, m) {
                if (i < 0)
                  throw new Error("Invalid degree less than 0");
                if (m === 0)
                  return this.field.zero;
                for (var d = this.coefficients.length, E = new Uint8ClampedArray(d + i), C = 0; C < d; C++)
                  E[C] = this.field.multiply(this.coefficients[C], m);
                return new s(this.field, E);
              }, s.prototype.evaluateAt = function(i) {
                var m = 0;
                if (i === 0)
                  return this.getCoefficient(0);
                var d = this.coefficients.length;
                if (i === 1)
                  return this.coefficients.forEach(function(C) {
                    m = n.addOrSubtractGF(m, C);
                  }), m;
                m = this.coefficients[0];
                for (var E = 1; E < d; E++)
                  m = n.addOrSubtractGF(this.field.multiply(i, m), this.coefficients[E]);
                return m;
              }, s;
            }()
          );
          x.default = o;
        },
        /* 3 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = a(4), o = a(5), s = a(11), i = a(12);
          function m(C) {
            var A = i.locate(C);
            if (!A)
              return null;
            for (var b = 0, y = A; b < y.length; b++) {
              var w = y[b], P = s.extract(C, w), k = o.decode(P.matrix);
              if (k)
                return {
                  binaryData: k.bytes,
                  data: k.text,
                  chunks: k.chunks,
                  version: k.version,
                  location: {
                    topRightCorner: P.mappingFunction(w.dimension, 0),
                    topLeftCorner: P.mappingFunction(0, 0),
                    bottomRightCorner: P.mappingFunction(w.dimension, w.dimension),
                    bottomLeftCorner: P.mappingFunction(0, w.dimension),
                    topRightFinderPattern: w.topRight,
                    topLeftFinderPattern: w.topLeft,
                    bottomLeftFinderPattern: w.bottomLeft,
                    bottomRightAlignmentPattern: w.alignmentPattern
                  }
                };
            }
            return null;
          }
          var d = {
            inversionAttempts: "attemptBoth"
          };
          function E(C, A, b, y) {
            y === void 0 && (y = {});
            var w = d;
            Object.keys(w || {}).forEach(function(F) {
              w[F] = y[F] || w[F];
            });
            var P = w.inversionAttempts === "attemptBoth" || w.inversionAttempts === "invertFirst", k = w.inversionAttempts === "onlyInvert" || w.inversionAttempts === "invertFirst", f = n.binarize(C, A, b, P), B = f.binarized, D = f.inverted, p = m(k ? D : B);
            return !p && (w.inversionAttempts === "attemptBoth" || w.inversionAttempts === "invertFirst") && (p = m(k ? B : D)), p;
          }
          E.default = E, x.default = E;
        },
        /* 4 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = a(0), o = 8, s = 24;
          function i(E, C, A) {
            return E < C ? C : E > A ? A : E;
          }
          var m = (
            /** @class */
            function() {
              function E(C, A) {
                this.width = C, this.data = new Uint8ClampedArray(C * A);
              }
              return E.prototype.get = function(C, A) {
                return this.data[A * this.width + C];
              }, E.prototype.set = function(C, A, b) {
                this.data[A * this.width + C] = b;
              }, E;
            }()
          );
          function d(E, C, A, b) {
            if (E.length !== C * A * 4)
              throw new Error("Malformed data passed to binarizer.");
            for (var y = new m(C, A), w = 0; w < C; w++)
              for (var P = 0; P < A; P++) {
                var k = E[(P * C + w) * 4 + 0], f = E[(P * C + w) * 4 + 1], B = E[(P * C + w) * 4 + 2];
                y.set(w, P, 0.2126 * k + 0.7152 * f + 0.0722 * B);
              }
            for (var D = Math.ceil(C / o), p = Math.ceil(A / o), F = new m(D, p), _ = 0; _ < p; _++)
              for (var M = 0; M < D; M++) {
                for (var R = 0, N = 1 / 0, I = 0, P = 0; P < o; P++)
                  for (var w = 0; w < o; w++) {
                    var $ = y.get(M * o + w, _ * o + P);
                    R += $, N = Math.min(N, $), I = Math.max(I, $);
                  }
                var G = R / Math.pow(o, 2);
                if (I - N <= s && (G = N / 2, _ > 0 && M > 0)) {
                  var W = (F.get(M, _ - 1) + 2 * F.get(M - 1, _) + F.get(M - 1, _ - 1)) / 4;
                  N < W && (G = W);
                }
                F.set(M, _, G);
              }
            var a0 = n.BitMatrix.createEmpty(C, A), j = null;
            b && (j = n.BitMatrix.createEmpty(C, A));
            for (var _ = 0; _ < p; _++)
              for (var M = 0; M < D; M++) {
                for (var K = i(M, 2, D - 3), i0 = i(_, 2, p - 3), R = 0, o0 = -2; o0 <= 2; o0++)
                  for (var H = -2; H <= 2; H++)
                    R += F.get(K + o0, i0 + H);
                for (var x0 = R / 25, o0 = 0; o0 < o; o0++)
                  for (var H = 0; H < o; H++) {
                    var w = M * o + o0, P = _ * o + H, l0 = y.get(w, P);
                    a0.set(w, P, l0 <= x0), b && j.set(w, P, !(l0 <= x0));
                  }
              }
            return b ? { binarized: a0, inverted: j } : { binarized: a0 };
          }
          x.binarize = d;
        },
        /* 5 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = a(0), o = a(6), s = a(9), i = a(10);
          function m(B, D) {
            for (var p = B ^ D, F = 0; p; )
              F++, p &= p - 1;
            return F;
          }
          function d(B, D) {
            return D << 1 | B;
          }
          var E = [
            { bits: 21522, formatInfo: { errorCorrectionLevel: 1, dataMask: 0 } },
            { bits: 20773, formatInfo: { errorCorrectionLevel: 1, dataMask: 1 } },
            { bits: 24188, formatInfo: { errorCorrectionLevel: 1, dataMask: 2 } },
            { bits: 23371, formatInfo: { errorCorrectionLevel: 1, dataMask: 3 } },
            { bits: 17913, formatInfo: { errorCorrectionLevel: 1, dataMask: 4 } },
            { bits: 16590, formatInfo: { errorCorrectionLevel: 1, dataMask: 5 } },
            { bits: 20375, formatInfo: { errorCorrectionLevel: 1, dataMask: 6 } },
            { bits: 19104, formatInfo: { errorCorrectionLevel: 1, dataMask: 7 } },
            { bits: 30660, formatInfo: { errorCorrectionLevel: 0, dataMask: 0 } },
            { bits: 29427, formatInfo: { errorCorrectionLevel: 0, dataMask: 1 } },
            { bits: 32170, formatInfo: { errorCorrectionLevel: 0, dataMask: 2 } },
            { bits: 30877, formatInfo: { errorCorrectionLevel: 0, dataMask: 3 } },
            { bits: 26159, formatInfo: { errorCorrectionLevel: 0, dataMask: 4 } },
            { bits: 25368, formatInfo: { errorCorrectionLevel: 0, dataMask: 5 } },
            { bits: 27713, formatInfo: { errorCorrectionLevel: 0, dataMask: 6 } },
            { bits: 26998, formatInfo: { errorCorrectionLevel: 0, dataMask: 7 } },
            { bits: 5769, formatInfo: { errorCorrectionLevel: 3, dataMask: 0 } },
            { bits: 5054, formatInfo: { errorCorrectionLevel: 3, dataMask: 1 } },
            { bits: 7399, formatInfo: { errorCorrectionLevel: 3, dataMask: 2 } },
            { bits: 6608, formatInfo: { errorCorrectionLevel: 3, dataMask: 3 } },
            { bits: 1890, formatInfo: { errorCorrectionLevel: 3, dataMask: 4 } },
            { bits: 597, formatInfo: { errorCorrectionLevel: 3, dataMask: 5 } },
            { bits: 3340, formatInfo: { errorCorrectionLevel: 3, dataMask: 6 } },
            { bits: 2107, formatInfo: { errorCorrectionLevel: 3, dataMask: 7 } },
            { bits: 13663, formatInfo: { errorCorrectionLevel: 2, dataMask: 0 } },
            { bits: 12392, formatInfo: { errorCorrectionLevel: 2, dataMask: 1 } },
            { bits: 16177, formatInfo: { errorCorrectionLevel: 2, dataMask: 2 } },
            { bits: 14854, formatInfo: { errorCorrectionLevel: 2, dataMask: 3 } },
            { bits: 9396, formatInfo: { errorCorrectionLevel: 2, dataMask: 4 } },
            { bits: 8579, formatInfo: { errorCorrectionLevel: 2, dataMask: 5 } },
            { bits: 11994, formatInfo: { errorCorrectionLevel: 2, dataMask: 6 } },
            { bits: 11245, formatInfo: { errorCorrectionLevel: 2, dataMask: 7 } }
          ], C = [
            function(B) {
              return (B.y + B.x) % 2 === 0;
            },
            function(B) {
              return B.y % 2 === 0;
            },
            function(B) {
              return B.x % 3 === 0;
            },
            function(B) {
              return (B.y + B.x) % 3 === 0;
            },
            function(B) {
              return (Math.floor(B.y / 2) + Math.floor(B.x / 3)) % 2 === 0;
            },
            function(B) {
              return B.x * B.y % 2 + B.x * B.y % 3 === 0;
            },
            function(B) {
              return (B.y * B.x % 2 + B.y * B.x % 3) % 2 === 0;
            },
            function(B) {
              return ((B.y + B.x) % 2 + B.y * B.x % 3) % 2 === 0;
            }
          ];
          function A(B) {
            var D = 17 + 4 * B.versionNumber, p = n.BitMatrix.createEmpty(D, D);
            p.setRegion(0, 0, 9, 9, !0), p.setRegion(D - 8, 0, 8, 9, !0), p.setRegion(0, D - 8, 9, 8, !0);
            for (var F = 0, _ = B.alignmentPatternCenters; F < _.length; F++)
              for (var M = _[F], R = 0, N = B.alignmentPatternCenters; R < N.length; R++) {
                var I = N[R];
                M === 6 && I === 6 || M === 6 && I === D - 7 || M === D - 7 && I === 6 || p.setRegion(M - 2, I - 2, 5, 5, !0);
              }
            return p.setRegion(6, 9, 1, D - 17, !0), p.setRegion(9, 6, D - 17, 1, !0), B.versionNumber > 6 && (p.setRegion(D - 11, 0, 3, 6, !0), p.setRegion(0, D - 11, 6, 3, !0)), p;
          }
          function b(B, D, p) {
            for (var F = C[p.dataMask], _ = B.height, M = A(D), R = [], N = 0, I = 0, $ = !0, G = _ - 1; G > 0; G -= 2) {
              G === 6 && G--;
              for (var W = 0; W < _; W++)
                for (var a0 = $ ? _ - 1 - W : W, j = 0; j < 2; j++) {
                  var K = G - j;
                  if (!M.get(K, a0)) {
                    I++;
                    var i0 = B.get(K, a0);
                    F({ y: a0, x: K }) && (i0 = !i0), N = d(i0, N), I === 8 && (R.push(N), I = 0, N = 0);
                  }
                }
              $ = !$;
            }
            return R;
          }
          function y(B) {
            var D = B.height, p = Math.floor((D - 17) / 4);
            if (p <= 6)
              return i.VERSIONS[p - 1];
            for (var F = 0, _ = 5; _ >= 0; _--)
              for (var M = D - 9; M >= D - 11; M--)
                F = d(B.get(M, _), F);
            for (var R = 0, M = 5; M >= 0; M--)
              for (var _ = D - 9; _ >= D - 11; _--)
                R = d(B.get(M, _), R);
            for (var N = 1 / 0, I, $ = 0, G = i.VERSIONS; $ < G.length; $++) {
              var W = G[$];
              if (W.infoBits === F || W.infoBits === R)
                return W;
              var a0 = m(F, W.infoBits);
              a0 < N && (I = W, N = a0), a0 = m(R, W.infoBits), a0 < N && (I = W, N = a0);
            }
            if (N <= 3)
              return I;
          }
          function w(B) {
            for (var D = 0, p = 0; p <= 8; p++)
              p !== 6 && (D = d(B.get(p, 8), D));
            for (var F = 7; F >= 0; F--)
              F !== 6 && (D = d(B.get(8, F), D));
            for (var _ = B.height, M = 0, F = _ - 1; F >= _ - 7; F--)
              M = d(B.get(8, F), M);
            for (var p = _ - 8; p < _; p++)
              M = d(B.get(p, 8), M);
            for (var R = 1 / 0, N = null, I = 0, $ = E; I < $.length; I++) {
              var G = $[I], W = G.bits, a0 = G.formatInfo;
              if (W === D || W === M)
                return a0;
              var j = m(D, W);
              j < R && (N = a0, R = j), D !== M && (j = m(M, W), j < R && (N = a0, R = j));
            }
            return R <= 3 ? N : null;
          }
          function P(B, D, p) {
            var F = D.errorCorrectionLevels[p], _ = [], M = 0;
            if (F.ecBlocks.forEach(function(i0) {
              for (var o0 = 0; o0 < i0.numBlocks; o0++)
                _.push({ numDataCodewords: i0.dataCodewordsPerBlock, codewords: [] }), M += i0.dataCodewordsPerBlock + F.ecCodewordsPerBlock;
            }), B.length < M)
              return null;
            B = B.slice(0, M);
            for (var R = F.ecBlocks[0].dataCodewordsPerBlock, N = 0; N < R; N++)
              for (var I = 0, $ = _; I < $.length; I++) {
                var G = $[I];
                G.codewords.push(B.shift());
              }
            if (F.ecBlocks.length > 1)
              for (var W = F.ecBlocks[0].numBlocks, a0 = F.ecBlocks[1].numBlocks, N = 0; N < a0; N++)
                _[W + N].codewords.push(B.shift());
            for (; B.length > 0; )
              for (var j = 0, K = _; j < K.length; j++) {
                var G = K[j];
                G.codewords.push(B.shift());
              }
            return _;
          }
          function k(B) {
            var D = y(B);
            if (!D)
              return null;
            var p = w(B);
            if (!p)
              return null;
            var F = b(B, D, p), _ = P(F, D, p.errorCorrectionLevel);
            if (!_)
              return null;
            for (var M = _.reduce(function(j, K) {
              return j + K.numDataCodewords;
            }, 0), R = new Uint8ClampedArray(M), N = 0, I = 0, $ = _; I < $.length; I++) {
              var G = $[I], W = s.decode(G.codewords, G.codewords.length - G.numDataCodewords);
              if (!W)
                return null;
              for (var a0 = 0; a0 < G.numDataCodewords; a0++)
                R[N++] = W[a0];
            }
            try {
              return o.decode(R, D.versionNumber);
            } catch {
              return null;
            }
          }
          function f(B) {
            if (B == null)
              return null;
            var D = k(B);
            if (D)
              return D;
            for (var p = 0; p < B.width; p++)
              for (var F = p + 1; F < B.height; F++)
                B.get(p, F) !== B.get(F, p) && (B.set(p, F, !B.get(p, F)), B.set(F, p, !B.get(F, p)));
            return k(B);
          }
          x.decode = f;
        },
        /* 6 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = a(7), o = a(8), s;
          (function(y) {
            y.Numeric = "numeric", y.Alphanumeric = "alphanumeric", y.Byte = "byte", y.Kanji = "kanji", y.ECI = "eci";
          })(s = x.Mode || (x.Mode = {}));
          var i;
          (function(y) {
            y[y.Terminator = 0] = "Terminator", y[y.Numeric = 1] = "Numeric", y[y.Alphanumeric = 2] = "Alphanumeric", y[y.Byte = 4] = "Byte", y[y.Kanji = 8] = "Kanji", y[y.ECI = 7] = "ECI";
          })(i || (i = {}));
          function m(y, w) {
            for (var P = [], k = "", f = [10, 12, 14][w], B = y.readBits(f); B >= 3; ) {
              var D = y.readBits(10);
              if (D >= 1e3)
                throw new Error("Invalid numeric value above 999");
              var p = Math.floor(D / 100), F = Math.floor(D / 10) % 10, _ = D % 10;
              P.push(48 + p, 48 + F, 48 + _), k += p.toString() + F.toString() + _.toString(), B -= 3;
            }
            if (B === 2) {
              var D = y.readBits(7);
              if (D >= 100)
                throw new Error("Invalid numeric value above 99");
              var p = Math.floor(D / 10), F = D % 10;
              P.push(48 + p, 48 + F), k += p.toString() + F.toString();
            } else if (B === 1) {
              var D = y.readBits(4);
              if (D >= 10)
                throw new Error("Invalid numeric value above 9");
              P.push(48 + D), k += D.toString();
            }
            return { bytes: P, text: k };
          }
          var d = [
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            " ",
            "$",
            "%",
            "*",
            "+",
            "-",
            ".",
            "/",
            ":"
          ];
          function E(y, w) {
            for (var P = [], k = "", f = [9, 11, 13][w], B = y.readBits(f); B >= 2; ) {
              var D = y.readBits(11), p = Math.floor(D / 45), F = D % 45;
              P.push(d[p].charCodeAt(0), d[F].charCodeAt(0)), k += d[p] + d[F], B -= 2;
            }
            if (B === 1) {
              var p = y.readBits(6);
              P.push(d[p].charCodeAt(0)), k += d[p];
            }
            return { bytes: P, text: k };
          }
          function C(y, w) {
            for (var P = [], k = "", f = [8, 16, 16][w], B = y.readBits(f), D = 0; D < B; D++) {
              var p = y.readBits(8);
              P.push(p);
            }
            try {
              k += decodeURIComponent(P.map(function(F) {
                return "%" + ("0" + F.toString(16)).substr(-2);
              }).join(""));
            } catch {
            }
            return { bytes: P, text: k };
          }
          function A(y, w) {
            for (var P = [], k = "", f = [8, 10, 12][w], B = y.readBits(f), D = 0; D < B; D++) {
              var p = y.readBits(13), F = Math.floor(p / 192) << 8 | p % 192;
              F < 7936 ? F += 33088 : F += 49472, P.push(F >> 8, F & 255), k += String.fromCharCode(o.shiftJISTable[F]);
            }
            return { bytes: P, text: k };
          }
          function b(y, w) {
            for (var P, k, f, B, D = new n.BitStream(y), p = w <= 9 ? 0 : w <= 26 ? 1 : 2, F = {
              text: "",
              bytes: [],
              chunks: [],
              version: w
            }; D.available() >= 4; ) {
              var _ = D.readBits(4);
              if (_ === i.Terminator)
                return F;
              if (_ === i.ECI)
                D.readBits(1) === 0 ? F.chunks.push({
                  type: s.ECI,
                  assignmentNumber: D.readBits(7)
                }) : D.readBits(1) === 0 ? F.chunks.push({
                  type: s.ECI,
                  assignmentNumber: D.readBits(14)
                }) : D.readBits(1) === 0 ? F.chunks.push({
                  type: s.ECI,
                  assignmentNumber: D.readBits(21)
                }) : F.chunks.push({
                  type: s.ECI,
                  assignmentNumber: -1
                });
              else if (_ === i.Numeric) {
                var M = m(D, p);
                F.text += M.text, (P = F.bytes).push.apply(P, M.bytes), F.chunks.push({
                  type: s.Numeric,
                  text: M.text
                });
              } else if (_ === i.Alphanumeric) {
                var R = E(D, p);
                F.text += R.text, (k = F.bytes).push.apply(k, R.bytes), F.chunks.push({
                  type: s.Alphanumeric,
                  text: R.text
                });
              } else if (_ === i.Byte) {
                var N = C(D, p);
                F.text += N.text, (f = F.bytes).push.apply(f, N.bytes), F.chunks.push({
                  type: s.Byte,
                  bytes: N.bytes,
                  text: N.text
                });
              } else if (_ === i.Kanji) {
                var I = A(D, p);
                F.text += I.text, (B = F.bytes).push.apply(B, I.bytes), F.chunks.push({
                  type: s.Kanji,
                  bytes: I.bytes,
                  text: I.text
                });
              }
            }
            if (D.available() === 0 || D.readBits(D.available()) === 0)
              return F;
          }
          x.decode = b;
        },
        /* 7 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = (
            /** @class */
            function() {
              function o(s) {
                this.byteOffset = 0, this.bitOffset = 0, this.bytes = s;
              }
              return o.prototype.readBits = function(s) {
                if (s < 1 || s > 32 || s > this.available())
                  throw new Error("Cannot read " + s.toString() + " bits");
                var i = 0;
                if (this.bitOffset > 0) {
                  var m = 8 - this.bitOffset, d = s < m ? s : m, E = m - d, C = 255 >> 8 - d << E;
                  i = (this.bytes[this.byteOffset] & C) >> E, s -= d, this.bitOffset += d, this.bitOffset === 8 && (this.bitOffset = 0, this.byteOffset++);
                }
                if (s > 0) {
                  for (; s >= 8; )
                    i = i << 8 | this.bytes[this.byteOffset] & 255, this.byteOffset++, s -= 8;
                  if (s > 0) {
                    var E = 8 - s, C = 255 >> E << E;
                    i = i << s | (this.bytes[this.byteOffset] & C) >> E, this.bitOffset += s;
                  }
                }
                return i;
              }, o.prototype.available = function() {
                return 8 * (this.bytes.length - this.byteOffset) - this.bitOffset;
              }, o;
            }()
          );
          x.BitStream = n;
        },
        /* 8 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 }), x.shiftJISTable = {
            32: 32,
            33: 33,
            34: 34,
            35: 35,
            36: 36,
            37: 37,
            38: 38,
            39: 39,
            40: 40,
            41: 41,
            42: 42,
            43: 43,
            44: 44,
            45: 45,
            46: 46,
            47: 47,
            48: 48,
            49: 49,
            50: 50,
            51: 51,
            52: 52,
            53: 53,
            54: 54,
            55: 55,
            56: 56,
            57: 57,
            58: 58,
            59: 59,
            60: 60,
            61: 61,
            62: 62,
            63: 63,
            64: 64,
            65: 65,
            66: 66,
            67: 67,
            68: 68,
            69: 69,
            70: 70,
            71: 71,
            72: 72,
            73: 73,
            74: 74,
            75: 75,
            76: 76,
            77: 77,
            78: 78,
            79: 79,
            80: 80,
            81: 81,
            82: 82,
            83: 83,
            84: 84,
            85: 85,
            86: 86,
            87: 87,
            88: 88,
            89: 89,
            90: 90,
            91: 91,
            92: 165,
            93: 93,
            94: 94,
            95: 95,
            96: 96,
            97: 97,
            98: 98,
            99: 99,
            100: 100,
            101: 101,
            102: 102,
            103: 103,
            104: 104,
            105: 105,
            106: 106,
            107: 107,
            108: 108,
            109: 109,
            110: 110,
            111: 111,
            112: 112,
            113: 113,
            114: 114,
            115: 115,
            116: 116,
            117: 117,
            118: 118,
            119: 119,
            120: 120,
            121: 121,
            122: 122,
            123: 123,
            124: 124,
            125: 125,
            126: 8254,
            33088: 12288,
            33089: 12289,
            33090: 12290,
            33091: 65292,
            33092: 65294,
            33093: 12539,
            33094: 65306,
            33095: 65307,
            33096: 65311,
            33097: 65281,
            33098: 12443,
            33099: 12444,
            33100: 180,
            33101: 65344,
            33102: 168,
            33103: 65342,
            33104: 65507,
            33105: 65343,
            33106: 12541,
            33107: 12542,
            33108: 12445,
            33109: 12446,
            33110: 12291,
            33111: 20189,
            33112: 12293,
            33113: 12294,
            33114: 12295,
            33115: 12540,
            33116: 8213,
            33117: 8208,
            33118: 65295,
            33119: 92,
            33120: 12316,
            33121: 8214,
            33122: 65372,
            33123: 8230,
            33124: 8229,
            33125: 8216,
            33126: 8217,
            33127: 8220,
            33128: 8221,
            33129: 65288,
            33130: 65289,
            33131: 12308,
            33132: 12309,
            33133: 65339,
            33134: 65341,
            33135: 65371,
            33136: 65373,
            33137: 12296,
            33138: 12297,
            33139: 12298,
            33140: 12299,
            33141: 12300,
            33142: 12301,
            33143: 12302,
            33144: 12303,
            33145: 12304,
            33146: 12305,
            33147: 65291,
            33148: 8722,
            33149: 177,
            33150: 215,
            33152: 247,
            33153: 65309,
            33154: 8800,
            33155: 65308,
            33156: 65310,
            33157: 8806,
            33158: 8807,
            33159: 8734,
            33160: 8756,
            33161: 9794,
            33162: 9792,
            33163: 176,
            33164: 8242,
            33165: 8243,
            33166: 8451,
            33167: 65509,
            33168: 65284,
            33169: 162,
            33170: 163,
            33171: 65285,
            33172: 65283,
            33173: 65286,
            33174: 65290,
            33175: 65312,
            33176: 167,
            33177: 9734,
            33178: 9733,
            33179: 9675,
            33180: 9679,
            33181: 9678,
            33182: 9671,
            33183: 9670,
            33184: 9633,
            33185: 9632,
            33186: 9651,
            33187: 9650,
            33188: 9661,
            33189: 9660,
            33190: 8251,
            33191: 12306,
            33192: 8594,
            33193: 8592,
            33194: 8593,
            33195: 8595,
            33196: 12307,
            33208: 8712,
            33209: 8715,
            33210: 8838,
            33211: 8839,
            33212: 8834,
            33213: 8835,
            33214: 8746,
            33215: 8745,
            33224: 8743,
            33225: 8744,
            33226: 172,
            33227: 8658,
            33228: 8660,
            33229: 8704,
            33230: 8707,
            33242: 8736,
            33243: 8869,
            33244: 8978,
            33245: 8706,
            33246: 8711,
            33247: 8801,
            33248: 8786,
            33249: 8810,
            33250: 8811,
            33251: 8730,
            33252: 8765,
            33253: 8733,
            33254: 8757,
            33255: 8747,
            33256: 8748,
            33264: 8491,
            33265: 8240,
            33266: 9839,
            33267: 9837,
            33268: 9834,
            33269: 8224,
            33270: 8225,
            33271: 182,
            33276: 9711,
            33359: 65296,
            33360: 65297,
            33361: 65298,
            33362: 65299,
            33363: 65300,
            33364: 65301,
            33365: 65302,
            33366: 65303,
            33367: 65304,
            33368: 65305,
            33376: 65313,
            33377: 65314,
            33378: 65315,
            33379: 65316,
            33380: 65317,
            33381: 65318,
            33382: 65319,
            33383: 65320,
            33384: 65321,
            33385: 65322,
            33386: 65323,
            33387: 65324,
            33388: 65325,
            33389: 65326,
            33390: 65327,
            33391: 65328,
            33392: 65329,
            33393: 65330,
            33394: 65331,
            33395: 65332,
            33396: 65333,
            33397: 65334,
            33398: 65335,
            33399: 65336,
            33400: 65337,
            33401: 65338,
            33409: 65345,
            33410: 65346,
            33411: 65347,
            33412: 65348,
            33413: 65349,
            33414: 65350,
            33415: 65351,
            33416: 65352,
            33417: 65353,
            33418: 65354,
            33419: 65355,
            33420: 65356,
            33421: 65357,
            33422: 65358,
            33423: 65359,
            33424: 65360,
            33425: 65361,
            33426: 65362,
            33427: 65363,
            33428: 65364,
            33429: 65365,
            33430: 65366,
            33431: 65367,
            33432: 65368,
            33433: 65369,
            33434: 65370,
            33439: 12353,
            33440: 12354,
            33441: 12355,
            33442: 12356,
            33443: 12357,
            33444: 12358,
            33445: 12359,
            33446: 12360,
            33447: 12361,
            33448: 12362,
            33449: 12363,
            33450: 12364,
            33451: 12365,
            33452: 12366,
            33453: 12367,
            33454: 12368,
            33455: 12369,
            33456: 12370,
            33457: 12371,
            33458: 12372,
            33459: 12373,
            33460: 12374,
            33461: 12375,
            33462: 12376,
            33463: 12377,
            33464: 12378,
            33465: 12379,
            33466: 12380,
            33467: 12381,
            33468: 12382,
            33469: 12383,
            33470: 12384,
            33471: 12385,
            33472: 12386,
            33473: 12387,
            33474: 12388,
            33475: 12389,
            33476: 12390,
            33477: 12391,
            33478: 12392,
            33479: 12393,
            33480: 12394,
            33481: 12395,
            33482: 12396,
            33483: 12397,
            33484: 12398,
            33485: 12399,
            33486: 12400,
            33487: 12401,
            33488: 12402,
            33489: 12403,
            33490: 12404,
            33491: 12405,
            33492: 12406,
            33493: 12407,
            33494: 12408,
            33495: 12409,
            33496: 12410,
            33497: 12411,
            33498: 12412,
            33499: 12413,
            33500: 12414,
            33501: 12415,
            33502: 12416,
            33503: 12417,
            33504: 12418,
            33505: 12419,
            33506: 12420,
            33507: 12421,
            33508: 12422,
            33509: 12423,
            33510: 12424,
            33511: 12425,
            33512: 12426,
            33513: 12427,
            33514: 12428,
            33515: 12429,
            33516: 12430,
            33517: 12431,
            33518: 12432,
            33519: 12433,
            33520: 12434,
            33521: 12435,
            33600: 12449,
            33601: 12450,
            33602: 12451,
            33603: 12452,
            33604: 12453,
            33605: 12454,
            33606: 12455,
            33607: 12456,
            33608: 12457,
            33609: 12458,
            33610: 12459,
            33611: 12460,
            33612: 12461,
            33613: 12462,
            33614: 12463,
            33615: 12464,
            33616: 12465,
            33617: 12466,
            33618: 12467,
            33619: 12468,
            33620: 12469,
            33621: 12470,
            33622: 12471,
            33623: 12472,
            33624: 12473,
            33625: 12474,
            33626: 12475,
            33627: 12476,
            33628: 12477,
            33629: 12478,
            33630: 12479,
            33631: 12480,
            33632: 12481,
            33633: 12482,
            33634: 12483,
            33635: 12484,
            33636: 12485,
            33637: 12486,
            33638: 12487,
            33639: 12488,
            33640: 12489,
            33641: 12490,
            33642: 12491,
            33643: 12492,
            33644: 12493,
            33645: 12494,
            33646: 12495,
            33647: 12496,
            33648: 12497,
            33649: 12498,
            33650: 12499,
            33651: 12500,
            33652: 12501,
            33653: 12502,
            33654: 12503,
            33655: 12504,
            33656: 12505,
            33657: 12506,
            33658: 12507,
            33659: 12508,
            33660: 12509,
            33661: 12510,
            33662: 12511,
            33664: 12512,
            33665: 12513,
            33666: 12514,
            33667: 12515,
            33668: 12516,
            33669: 12517,
            33670: 12518,
            33671: 12519,
            33672: 12520,
            33673: 12521,
            33674: 12522,
            33675: 12523,
            33676: 12524,
            33677: 12525,
            33678: 12526,
            33679: 12527,
            33680: 12528,
            33681: 12529,
            33682: 12530,
            33683: 12531,
            33684: 12532,
            33685: 12533,
            33686: 12534,
            33695: 913,
            33696: 914,
            33697: 915,
            33698: 916,
            33699: 917,
            33700: 918,
            33701: 919,
            33702: 920,
            33703: 921,
            33704: 922,
            33705: 923,
            33706: 924,
            33707: 925,
            33708: 926,
            33709: 927,
            33710: 928,
            33711: 929,
            33712: 931,
            33713: 932,
            33714: 933,
            33715: 934,
            33716: 935,
            33717: 936,
            33718: 937,
            33727: 945,
            33728: 946,
            33729: 947,
            33730: 948,
            33731: 949,
            33732: 950,
            33733: 951,
            33734: 952,
            33735: 953,
            33736: 954,
            33737: 955,
            33738: 956,
            33739: 957,
            33740: 958,
            33741: 959,
            33742: 960,
            33743: 961,
            33744: 963,
            33745: 964,
            33746: 965,
            33747: 966,
            33748: 967,
            33749: 968,
            33750: 969,
            33856: 1040,
            33857: 1041,
            33858: 1042,
            33859: 1043,
            33860: 1044,
            33861: 1045,
            33862: 1025,
            33863: 1046,
            33864: 1047,
            33865: 1048,
            33866: 1049,
            33867: 1050,
            33868: 1051,
            33869: 1052,
            33870: 1053,
            33871: 1054,
            33872: 1055,
            33873: 1056,
            33874: 1057,
            33875: 1058,
            33876: 1059,
            33877: 1060,
            33878: 1061,
            33879: 1062,
            33880: 1063,
            33881: 1064,
            33882: 1065,
            33883: 1066,
            33884: 1067,
            33885: 1068,
            33886: 1069,
            33887: 1070,
            33888: 1071,
            33904: 1072,
            33905: 1073,
            33906: 1074,
            33907: 1075,
            33908: 1076,
            33909: 1077,
            33910: 1105,
            33911: 1078,
            33912: 1079,
            33913: 1080,
            33914: 1081,
            33915: 1082,
            33916: 1083,
            33917: 1084,
            33918: 1085,
            33920: 1086,
            33921: 1087,
            33922: 1088,
            33923: 1089,
            33924: 1090,
            33925: 1091,
            33926: 1092,
            33927: 1093,
            33928: 1094,
            33929: 1095,
            33930: 1096,
            33931: 1097,
            33932: 1098,
            33933: 1099,
            33934: 1100,
            33935: 1101,
            33936: 1102,
            33937: 1103,
            33951: 9472,
            33952: 9474,
            33953: 9484,
            33954: 9488,
            33955: 9496,
            33956: 9492,
            33957: 9500,
            33958: 9516,
            33959: 9508,
            33960: 9524,
            33961: 9532,
            33962: 9473,
            33963: 9475,
            33964: 9487,
            33965: 9491,
            33966: 9499,
            33967: 9495,
            33968: 9507,
            33969: 9523,
            33970: 9515,
            33971: 9531,
            33972: 9547,
            33973: 9504,
            33974: 9519,
            33975: 9512,
            33976: 9527,
            33977: 9535,
            33978: 9501,
            33979: 9520,
            33980: 9509,
            33981: 9528,
            33982: 9538,
            34975: 20124,
            34976: 21782,
            34977: 23043,
            34978: 38463,
            34979: 21696,
            34980: 24859,
            34981: 25384,
            34982: 23030,
            34983: 36898,
            34984: 33909,
            34985: 33564,
            34986: 31312,
            34987: 24746,
            34988: 25569,
            34989: 28197,
            34990: 26093,
            34991: 33894,
            34992: 33446,
            34993: 39925,
            34994: 26771,
            34995: 22311,
            34996: 26017,
            34997: 25201,
            34998: 23451,
            34999: 22992,
            35e3: 34427,
            35001: 39156,
            35002: 32098,
            35003: 32190,
            35004: 39822,
            35005: 25110,
            35006: 31903,
            35007: 34999,
            35008: 23433,
            35009: 24245,
            35010: 25353,
            35011: 26263,
            35012: 26696,
            35013: 38343,
            35014: 38797,
            35015: 26447,
            35016: 20197,
            35017: 20234,
            35018: 20301,
            35019: 20381,
            35020: 20553,
            35021: 22258,
            35022: 22839,
            35023: 22996,
            35024: 23041,
            35025: 23561,
            35026: 24799,
            35027: 24847,
            35028: 24944,
            35029: 26131,
            35030: 26885,
            35031: 28858,
            35032: 30031,
            35033: 30064,
            35034: 31227,
            35035: 32173,
            35036: 32239,
            35037: 32963,
            35038: 33806,
            35039: 34915,
            35040: 35586,
            35041: 36949,
            35042: 36986,
            35043: 21307,
            35044: 20117,
            35045: 20133,
            35046: 22495,
            35047: 32946,
            35048: 37057,
            35049: 30959,
            35050: 19968,
            35051: 22769,
            35052: 28322,
            35053: 36920,
            35054: 31282,
            35055: 33576,
            35056: 33419,
            35057: 39983,
            35058: 20801,
            35059: 21360,
            35060: 21693,
            35061: 21729,
            35062: 22240,
            35063: 23035,
            35064: 24341,
            35065: 39154,
            35066: 28139,
            35067: 32996,
            35068: 34093,
            35136: 38498,
            35137: 38512,
            35138: 38560,
            35139: 38907,
            35140: 21515,
            35141: 21491,
            35142: 23431,
            35143: 28879,
            35144: 32701,
            35145: 36802,
            35146: 38632,
            35147: 21359,
            35148: 40284,
            35149: 31418,
            35150: 19985,
            35151: 30867,
            35152: 33276,
            35153: 28198,
            35154: 22040,
            35155: 21764,
            35156: 27421,
            35157: 34074,
            35158: 39995,
            35159: 23013,
            35160: 21417,
            35161: 28006,
            35162: 29916,
            35163: 38287,
            35164: 22082,
            35165: 20113,
            35166: 36939,
            35167: 38642,
            35168: 33615,
            35169: 39180,
            35170: 21473,
            35171: 21942,
            35172: 23344,
            35173: 24433,
            35174: 26144,
            35175: 26355,
            35176: 26628,
            35177: 27704,
            35178: 27891,
            35179: 27945,
            35180: 29787,
            35181: 30408,
            35182: 31310,
            35183: 38964,
            35184: 33521,
            35185: 34907,
            35186: 35424,
            35187: 37613,
            35188: 28082,
            35189: 30123,
            35190: 30410,
            35191: 39365,
            35192: 24742,
            35193: 35585,
            35194: 36234,
            35195: 38322,
            35196: 27022,
            35197: 21421,
            35198: 20870,
            35200: 22290,
            35201: 22576,
            35202: 22852,
            35203: 23476,
            35204: 24310,
            35205: 24616,
            35206: 25513,
            35207: 25588,
            35208: 27839,
            35209: 28436,
            35210: 28814,
            35211: 28948,
            35212: 29017,
            35213: 29141,
            35214: 29503,
            35215: 32257,
            35216: 33398,
            35217: 33489,
            35218: 34199,
            35219: 36960,
            35220: 37467,
            35221: 40219,
            35222: 22633,
            35223: 26044,
            35224: 27738,
            35225: 29989,
            35226: 20985,
            35227: 22830,
            35228: 22885,
            35229: 24448,
            35230: 24540,
            35231: 25276,
            35232: 26106,
            35233: 27178,
            35234: 27431,
            35235: 27572,
            35236: 29579,
            35237: 32705,
            35238: 35158,
            35239: 40236,
            35240: 40206,
            35241: 40644,
            35242: 23713,
            35243: 27798,
            35244: 33659,
            35245: 20740,
            35246: 23627,
            35247: 25014,
            35248: 33222,
            35249: 26742,
            35250: 29281,
            35251: 20057,
            35252: 20474,
            35253: 21368,
            35254: 24681,
            35255: 28201,
            35256: 31311,
            35257: 38899,
            35258: 19979,
            35259: 21270,
            35260: 20206,
            35261: 20309,
            35262: 20285,
            35263: 20385,
            35264: 20339,
            35265: 21152,
            35266: 21487,
            35267: 22025,
            35268: 22799,
            35269: 23233,
            35270: 23478,
            35271: 23521,
            35272: 31185,
            35273: 26247,
            35274: 26524,
            35275: 26550,
            35276: 27468,
            35277: 27827,
            35278: 28779,
            35279: 29634,
            35280: 31117,
            35281: 31166,
            35282: 31292,
            35283: 31623,
            35284: 33457,
            35285: 33499,
            35286: 33540,
            35287: 33655,
            35288: 33775,
            35289: 33747,
            35290: 34662,
            35291: 35506,
            35292: 22057,
            35293: 36008,
            35294: 36838,
            35295: 36942,
            35296: 38686,
            35297: 34442,
            35298: 20420,
            35299: 23784,
            35300: 25105,
            35301: 29273,
            35302: 30011,
            35303: 33253,
            35304: 33469,
            35305: 34558,
            35306: 36032,
            35307: 38597,
            35308: 39187,
            35309: 39381,
            35310: 20171,
            35311: 20250,
            35312: 35299,
            35313: 22238,
            35314: 22602,
            35315: 22730,
            35316: 24315,
            35317: 24555,
            35318: 24618,
            35319: 24724,
            35320: 24674,
            35321: 25040,
            35322: 25106,
            35323: 25296,
            35324: 25913,
            35392: 39745,
            35393: 26214,
            35394: 26800,
            35395: 28023,
            35396: 28784,
            35397: 30028,
            35398: 30342,
            35399: 32117,
            35400: 33445,
            35401: 34809,
            35402: 38283,
            35403: 38542,
            35404: 35997,
            35405: 20977,
            35406: 21182,
            35407: 22806,
            35408: 21683,
            35409: 23475,
            35410: 23830,
            35411: 24936,
            35412: 27010,
            35413: 28079,
            35414: 30861,
            35415: 33995,
            35416: 34903,
            35417: 35442,
            35418: 37799,
            35419: 39608,
            35420: 28012,
            35421: 39336,
            35422: 34521,
            35423: 22435,
            35424: 26623,
            35425: 34510,
            35426: 37390,
            35427: 21123,
            35428: 22151,
            35429: 21508,
            35430: 24275,
            35431: 25313,
            35432: 25785,
            35433: 26684,
            35434: 26680,
            35435: 27579,
            35436: 29554,
            35437: 30906,
            35438: 31339,
            35439: 35226,
            35440: 35282,
            35441: 36203,
            35442: 36611,
            35443: 37101,
            35444: 38307,
            35445: 38548,
            35446: 38761,
            35447: 23398,
            35448: 23731,
            35449: 27005,
            35450: 38989,
            35451: 38990,
            35452: 25499,
            35453: 31520,
            35454: 27179,
            35456: 27263,
            35457: 26806,
            35458: 39949,
            35459: 28511,
            35460: 21106,
            35461: 21917,
            35462: 24688,
            35463: 25324,
            35464: 27963,
            35465: 28167,
            35466: 28369,
            35467: 33883,
            35468: 35088,
            35469: 36676,
            35470: 19988,
            35471: 39993,
            35472: 21494,
            35473: 26907,
            35474: 27194,
            35475: 38788,
            35476: 26666,
            35477: 20828,
            35478: 31427,
            35479: 33970,
            35480: 37340,
            35481: 37772,
            35482: 22107,
            35483: 40232,
            35484: 26658,
            35485: 33541,
            35486: 33841,
            35487: 31909,
            35488: 21e3,
            35489: 33477,
            35490: 29926,
            35491: 20094,
            35492: 20355,
            35493: 20896,
            35494: 23506,
            35495: 21002,
            35496: 21208,
            35497: 21223,
            35498: 24059,
            35499: 21914,
            35500: 22570,
            35501: 23014,
            35502: 23436,
            35503: 23448,
            35504: 23515,
            35505: 24178,
            35506: 24185,
            35507: 24739,
            35508: 24863,
            35509: 24931,
            35510: 25022,
            35511: 25563,
            35512: 25954,
            35513: 26577,
            35514: 26707,
            35515: 26874,
            35516: 27454,
            35517: 27475,
            35518: 27735,
            35519: 28450,
            35520: 28567,
            35521: 28485,
            35522: 29872,
            35523: 29976,
            35524: 30435,
            35525: 30475,
            35526: 31487,
            35527: 31649,
            35528: 31777,
            35529: 32233,
            35530: 32566,
            35531: 32752,
            35532: 32925,
            35533: 33382,
            35534: 33694,
            35535: 35251,
            35536: 35532,
            35537: 36011,
            35538: 36996,
            35539: 37969,
            35540: 38291,
            35541: 38289,
            35542: 38306,
            35543: 38501,
            35544: 38867,
            35545: 39208,
            35546: 33304,
            35547: 20024,
            35548: 21547,
            35549: 23736,
            35550: 24012,
            35551: 29609,
            35552: 30284,
            35553: 30524,
            35554: 23721,
            35555: 32747,
            35556: 36107,
            35557: 38593,
            35558: 38929,
            35559: 38996,
            35560: 39e3,
            35561: 20225,
            35562: 20238,
            35563: 21361,
            35564: 21916,
            35565: 22120,
            35566: 22522,
            35567: 22855,
            35568: 23305,
            35569: 23492,
            35570: 23696,
            35571: 24076,
            35572: 24190,
            35573: 24524,
            35574: 25582,
            35575: 26426,
            35576: 26071,
            35577: 26082,
            35578: 26399,
            35579: 26827,
            35580: 26820,
            35648: 27231,
            35649: 24112,
            35650: 27589,
            35651: 27671,
            35652: 27773,
            35653: 30079,
            35654: 31048,
            35655: 23395,
            35656: 31232,
            35657: 32e3,
            35658: 24509,
            35659: 35215,
            35660: 35352,
            35661: 36020,
            35662: 36215,
            35663: 36556,
            35664: 36637,
            35665: 39138,
            35666: 39438,
            35667: 39740,
            35668: 20096,
            35669: 20605,
            35670: 20736,
            35671: 22931,
            35672: 23452,
            35673: 25135,
            35674: 25216,
            35675: 25836,
            35676: 27450,
            35677: 29344,
            35678: 30097,
            35679: 31047,
            35680: 32681,
            35681: 34811,
            35682: 35516,
            35683: 35696,
            35684: 25516,
            35685: 33738,
            35686: 38816,
            35687: 21513,
            35688: 21507,
            35689: 21931,
            35690: 26708,
            35691: 27224,
            35692: 35440,
            35693: 30759,
            35694: 26485,
            35695: 40653,
            35696: 21364,
            35697: 23458,
            35698: 33050,
            35699: 34384,
            35700: 36870,
            35701: 19992,
            35702: 20037,
            35703: 20167,
            35704: 20241,
            35705: 21450,
            35706: 21560,
            35707: 23470,
            35708: 24339,
            35709: 24613,
            35710: 25937,
            35712: 26429,
            35713: 27714,
            35714: 27762,
            35715: 27875,
            35716: 28792,
            35717: 29699,
            35718: 31350,
            35719: 31406,
            35720: 31496,
            35721: 32026,
            35722: 31998,
            35723: 32102,
            35724: 26087,
            35725: 29275,
            35726: 21435,
            35727: 23621,
            35728: 24040,
            35729: 25298,
            35730: 25312,
            35731: 25369,
            35732: 28192,
            35733: 34394,
            35734: 35377,
            35735: 36317,
            35736: 37624,
            35737: 28417,
            35738: 31142,
            35739: 39770,
            35740: 20136,
            35741: 20139,
            35742: 20140,
            35743: 20379,
            35744: 20384,
            35745: 20689,
            35746: 20807,
            35747: 31478,
            35748: 20849,
            35749: 20982,
            35750: 21332,
            35751: 21281,
            35752: 21375,
            35753: 21483,
            35754: 21932,
            35755: 22659,
            35756: 23777,
            35757: 24375,
            35758: 24394,
            35759: 24623,
            35760: 24656,
            35761: 24685,
            35762: 25375,
            35763: 25945,
            35764: 27211,
            35765: 27841,
            35766: 29378,
            35767: 29421,
            35768: 30703,
            35769: 33016,
            35770: 33029,
            35771: 33288,
            35772: 34126,
            35773: 37111,
            35774: 37857,
            35775: 38911,
            35776: 39255,
            35777: 39514,
            35778: 20208,
            35779: 20957,
            35780: 23597,
            35781: 26241,
            35782: 26989,
            35783: 23616,
            35784: 26354,
            35785: 26997,
            35786: 29577,
            35787: 26704,
            35788: 31873,
            35789: 20677,
            35790: 21220,
            35791: 22343,
            35792: 24062,
            35793: 37670,
            35794: 26020,
            35795: 27427,
            35796: 27453,
            35797: 29748,
            35798: 31105,
            35799: 31165,
            35800: 31563,
            35801: 32202,
            35802: 33465,
            35803: 33740,
            35804: 34943,
            35805: 35167,
            35806: 35641,
            35807: 36817,
            35808: 37329,
            35809: 21535,
            35810: 37504,
            35811: 20061,
            35812: 20534,
            35813: 21477,
            35814: 21306,
            35815: 29399,
            35816: 29590,
            35817: 30697,
            35818: 33510,
            35819: 36527,
            35820: 39366,
            35821: 39368,
            35822: 39378,
            35823: 20855,
            35824: 24858,
            35825: 34398,
            35826: 21936,
            35827: 31354,
            35828: 20598,
            35829: 23507,
            35830: 36935,
            35831: 38533,
            35832: 20018,
            35833: 27355,
            35834: 37351,
            35835: 23633,
            35836: 23624,
            35904: 25496,
            35905: 31391,
            35906: 27795,
            35907: 38772,
            35908: 36705,
            35909: 31402,
            35910: 29066,
            35911: 38536,
            35912: 31874,
            35913: 26647,
            35914: 32368,
            35915: 26705,
            35916: 37740,
            35917: 21234,
            35918: 21531,
            35919: 34219,
            35920: 35347,
            35921: 32676,
            35922: 36557,
            35923: 37089,
            35924: 21350,
            35925: 34952,
            35926: 31041,
            35927: 20418,
            35928: 20670,
            35929: 21009,
            35930: 20804,
            35931: 21843,
            35932: 22317,
            35933: 29674,
            35934: 22411,
            35935: 22865,
            35936: 24418,
            35937: 24452,
            35938: 24693,
            35939: 24950,
            35940: 24935,
            35941: 25001,
            35942: 25522,
            35943: 25658,
            35944: 25964,
            35945: 26223,
            35946: 26690,
            35947: 28179,
            35948: 30054,
            35949: 31293,
            35950: 31995,
            35951: 32076,
            35952: 32153,
            35953: 32331,
            35954: 32619,
            35955: 33550,
            35956: 33610,
            35957: 34509,
            35958: 35336,
            35959: 35427,
            35960: 35686,
            35961: 36605,
            35962: 38938,
            35963: 40335,
            35964: 33464,
            35965: 36814,
            35966: 39912,
            35968: 21127,
            35969: 25119,
            35970: 25731,
            35971: 28608,
            35972: 38553,
            35973: 26689,
            35974: 20625,
            35975: 27424,
            35976: 27770,
            35977: 28500,
            35978: 31348,
            35979: 32080,
            35980: 34880,
            35981: 35363,
            35982: 26376,
            35983: 20214,
            35984: 20537,
            35985: 20518,
            35986: 20581,
            35987: 20860,
            35988: 21048,
            35989: 21091,
            35990: 21927,
            35991: 22287,
            35992: 22533,
            35993: 23244,
            35994: 24314,
            35995: 25010,
            35996: 25080,
            35997: 25331,
            35998: 25458,
            35999: 26908,
            36e3: 27177,
            36001: 29309,
            36002: 29356,
            36003: 29486,
            36004: 30740,
            36005: 30831,
            36006: 32121,
            36007: 30476,
            36008: 32937,
            36009: 35211,
            36010: 35609,
            36011: 36066,
            36012: 36562,
            36013: 36963,
            36014: 37749,
            36015: 38522,
            36016: 38997,
            36017: 39443,
            36018: 40568,
            36019: 20803,
            36020: 21407,
            36021: 21427,
            36022: 24187,
            36023: 24358,
            36024: 28187,
            36025: 28304,
            36026: 29572,
            36027: 29694,
            36028: 32067,
            36029: 33335,
            36030: 35328,
            36031: 35578,
            36032: 38480,
            36033: 20046,
            36034: 20491,
            36035: 21476,
            36036: 21628,
            36037: 22266,
            36038: 22993,
            36039: 23396,
            36040: 24049,
            36041: 24235,
            36042: 24359,
            36043: 25144,
            36044: 25925,
            36045: 26543,
            36046: 28246,
            36047: 29392,
            36048: 31946,
            36049: 34996,
            36050: 32929,
            36051: 32993,
            36052: 33776,
            36053: 34382,
            36054: 35463,
            36055: 36328,
            36056: 37431,
            36057: 38599,
            36058: 39015,
            36059: 40723,
            36060: 20116,
            36061: 20114,
            36062: 20237,
            36063: 21320,
            36064: 21577,
            36065: 21566,
            36066: 23087,
            36067: 24460,
            36068: 24481,
            36069: 24735,
            36070: 26791,
            36071: 27278,
            36072: 29786,
            36073: 30849,
            36074: 35486,
            36075: 35492,
            36076: 35703,
            36077: 37264,
            36078: 20062,
            36079: 39881,
            36080: 20132,
            36081: 20348,
            36082: 20399,
            36083: 20505,
            36084: 20502,
            36085: 20809,
            36086: 20844,
            36087: 21151,
            36088: 21177,
            36089: 21246,
            36090: 21402,
            36091: 21475,
            36092: 21521,
            36160: 21518,
            36161: 21897,
            36162: 22353,
            36163: 22434,
            36164: 22909,
            36165: 23380,
            36166: 23389,
            36167: 23439,
            36168: 24037,
            36169: 24039,
            36170: 24055,
            36171: 24184,
            36172: 24195,
            36173: 24218,
            36174: 24247,
            36175: 24344,
            36176: 24658,
            36177: 24908,
            36178: 25239,
            36179: 25304,
            36180: 25511,
            36181: 25915,
            36182: 26114,
            36183: 26179,
            36184: 26356,
            36185: 26477,
            36186: 26657,
            36187: 26775,
            36188: 27083,
            36189: 27743,
            36190: 27946,
            36191: 28009,
            36192: 28207,
            36193: 28317,
            36194: 30002,
            36195: 30343,
            36196: 30828,
            36197: 31295,
            36198: 31968,
            36199: 32005,
            36200: 32024,
            36201: 32094,
            36202: 32177,
            36203: 32789,
            36204: 32771,
            36205: 32943,
            36206: 32945,
            36207: 33108,
            36208: 33167,
            36209: 33322,
            36210: 33618,
            36211: 34892,
            36212: 34913,
            36213: 35611,
            36214: 36002,
            36215: 36092,
            36216: 37066,
            36217: 37237,
            36218: 37489,
            36219: 30783,
            36220: 37628,
            36221: 38308,
            36222: 38477,
            36224: 38917,
            36225: 39321,
            36226: 39640,
            36227: 40251,
            36228: 21083,
            36229: 21163,
            36230: 21495,
            36231: 21512,
            36232: 22741,
            36233: 25335,
            36234: 28640,
            36235: 35946,
            36236: 36703,
            36237: 40633,
            36238: 20811,
            36239: 21051,
            36240: 21578,
            36241: 22269,
            36242: 31296,
            36243: 37239,
            36244: 40288,
            36245: 40658,
            36246: 29508,
            36247: 28425,
            36248: 33136,
            36249: 29969,
            36250: 24573,
            36251: 24794,
            36252: 39592,
            36253: 29403,
            36254: 36796,
            36255: 27492,
            36256: 38915,
            36257: 20170,
            36258: 22256,
            36259: 22372,
            36260: 22718,
            36261: 23130,
            36262: 24680,
            36263: 25031,
            36264: 26127,
            36265: 26118,
            36266: 26681,
            36267: 26801,
            36268: 28151,
            36269: 30165,
            36270: 32058,
            36271: 33390,
            36272: 39746,
            36273: 20123,
            36274: 20304,
            36275: 21449,
            36276: 21766,
            36277: 23919,
            36278: 24038,
            36279: 24046,
            36280: 26619,
            36281: 27801,
            36282: 29811,
            36283: 30722,
            36284: 35408,
            36285: 37782,
            36286: 35039,
            36287: 22352,
            36288: 24231,
            36289: 25387,
            36290: 20661,
            36291: 20652,
            36292: 20877,
            36293: 26368,
            36294: 21705,
            36295: 22622,
            36296: 22971,
            36297: 23472,
            36298: 24425,
            36299: 25165,
            36300: 25505,
            36301: 26685,
            36302: 27507,
            36303: 28168,
            36304: 28797,
            36305: 37319,
            36306: 29312,
            36307: 30741,
            36308: 30758,
            36309: 31085,
            36310: 25998,
            36311: 32048,
            36312: 33756,
            36313: 35009,
            36314: 36617,
            36315: 38555,
            36316: 21092,
            36317: 22312,
            36318: 26448,
            36319: 32618,
            36320: 36001,
            36321: 20916,
            36322: 22338,
            36323: 38442,
            36324: 22586,
            36325: 27018,
            36326: 32948,
            36327: 21682,
            36328: 23822,
            36329: 22524,
            36330: 30869,
            36331: 40442,
            36332: 20316,
            36333: 21066,
            36334: 21643,
            36335: 25662,
            36336: 26152,
            36337: 26388,
            36338: 26613,
            36339: 31364,
            36340: 31574,
            36341: 32034,
            36342: 37679,
            36343: 26716,
            36344: 39853,
            36345: 31545,
            36346: 21273,
            36347: 20874,
            36348: 21047,
            36416: 23519,
            36417: 25334,
            36418: 25774,
            36419: 25830,
            36420: 26413,
            36421: 27578,
            36422: 34217,
            36423: 38609,
            36424: 30352,
            36425: 39894,
            36426: 25420,
            36427: 37638,
            36428: 39851,
            36429: 30399,
            36430: 26194,
            36431: 19977,
            36432: 20632,
            36433: 21442,
            36434: 23665,
            36435: 24808,
            36436: 25746,
            36437: 25955,
            36438: 26719,
            36439: 29158,
            36440: 29642,
            36441: 29987,
            36442: 31639,
            36443: 32386,
            36444: 34453,
            36445: 35715,
            36446: 36059,
            36447: 37240,
            36448: 39184,
            36449: 26028,
            36450: 26283,
            36451: 27531,
            36452: 20181,
            36453: 20180,
            36454: 20282,
            36455: 20351,
            36456: 21050,
            36457: 21496,
            36458: 21490,
            36459: 21987,
            36460: 22235,
            36461: 22763,
            36462: 22987,
            36463: 22985,
            36464: 23039,
            36465: 23376,
            36466: 23629,
            36467: 24066,
            36468: 24107,
            36469: 24535,
            36470: 24605,
            36471: 25351,
            36472: 25903,
            36473: 23388,
            36474: 26031,
            36475: 26045,
            36476: 26088,
            36477: 26525,
            36478: 27490,
            36480: 27515,
            36481: 27663,
            36482: 29509,
            36483: 31049,
            36484: 31169,
            36485: 31992,
            36486: 32025,
            36487: 32043,
            36488: 32930,
            36489: 33026,
            36490: 33267,
            36491: 35222,
            36492: 35422,
            36493: 35433,
            36494: 35430,
            36495: 35468,
            36496: 35566,
            36497: 36039,
            36498: 36060,
            36499: 38604,
            36500: 39164,
            36501: 27503,
            36502: 20107,
            36503: 20284,
            36504: 20365,
            36505: 20816,
            36506: 23383,
            36507: 23546,
            36508: 24904,
            36509: 25345,
            36510: 26178,
            36511: 27425,
            36512: 28363,
            36513: 27835,
            36514: 29246,
            36515: 29885,
            36516: 30164,
            36517: 30913,
            36518: 31034,
            36519: 32780,
            36520: 32819,
            36521: 33258,
            36522: 33940,
            36523: 36766,
            36524: 27728,
            36525: 40575,
            36526: 24335,
            36527: 35672,
            36528: 40235,
            36529: 31482,
            36530: 36600,
            36531: 23437,
            36532: 38635,
            36533: 19971,
            36534: 21489,
            36535: 22519,
            36536: 22833,
            36537: 23241,
            36538: 23460,
            36539: 24713,
            36540: 28287,
            36541: 28422,
            36542: 30142,
            36543: 36074,
            36544: 23455,
            36545: 34048,
            36546: 31712,
            36547: 20594,
            36548: 26612,
            36549: 33437,
            36550: 23649,
            36551: 34122,
            36552: 32286,
            36553: 33294,
            36554: 20889,
            36555: 23556,
            36556: 25448,
            36557: 36198,
            36558: 26012,
            36559: 29038,
            36560: 31038,
            36561: 32023,
            36562: 32773,
            36563: 35613,
            36564: 36554,
            36565: 36974,
            36566: 34503,
            36567: 37034,
            36568: 20511,
            36569: 21242,
            36570: 23610,
            36571: 26451,
            36572: 28796,
            36573: 29237,
            36574: 37196,
            36575: 37320,
            36576: 37675,
            36577: 33509,
            36578: 23490,
            36579: 24369,
            36580: 24825,
            36581: 20027,
            36582: 21462,
            36583: 23432,
            36584: 25163,
            36585: 26417,
            36586: 27530,
            36587: 29417,
            36588: 29664,
            36589: 31278,
            36590: 33131,
            36591: 36259,
            36592: 37202,
            36593: 39318,
            36594: 20754,
            36595: 21463,
            36596: 21610,
            36597: 23551,
            36598: 25480,
            36599: 27193,
            36600: 32172,
            36601: 38656,
            36602: 22234,
            36603: 21454,
            36604: 21608,
            36672: 23447,
            36673: 23601,
            36674: 24030,
            36675: 20462,
            36676: 24833,
            36677: 25342,
            36678: 27954,
            36679: 31168,
            36680: 31179,
            36681: 32066,
            36682: 32333,
            36683: 32722,
            36684: 33261,
            36685: 33311,
            36686: 33936,
            36687: 34886,
            36688: 35186,
            36689: 35728,
            36690: 36468,
            36691: 36655,
            36692: 36913,
            36693: 37195,
            36694: 37228,
            36695: 38598,
            36696: 37276,
            36697: 20160,
            36698: 20303,
            36699: 20805,
            36700: 21313,
            36701: 24467,
            36702: 25102,
            36703: 26580,
            36704: 27713,
            36705: 28171,
            36706: 29539,
            36707: 32294,
            36708: 37325,
            36709: 37507,
            36710: 21460,
            36711: 22809,
            36712: 23487,
            36713: 28113,
            36714: 31069,
            36715: 32302,
            36716: 31899,
            36717: 22654,
            36718: 29087,
            36719: 20986,
            36720: 34899,
            36721: 36848,
            36722: 20426,
            36723: 23803,
            36724: 26149,
            36725: 30636,
            36726: 31459,
            36727: 33308,
            36728: 39423,
            36729: 20934,
            36730: 24490,
            36731: 26092,
            36732: 26991,
            36733: 27529,
            36734: 28147,
            36736: 28310,
            36737: 28516,
            36738: 30462,
            36739: 32020,
            36740: 24033,
            36741: 36981,
            36742: 37255,
            36743: 38918,
            36744: 20966,
            36745: 21021,
            36746: 25152,
            36747: 26257,
            36748: 26329,
            36749: 28186,
            36750: 24246,
            36751: 32210,
            36752: 32626,
            36753: 26360,
            36754: 34223,
            36755: 34295,
            36756: 35576,
            36757: 21161,
            36758: 21465,
            36759: 22899,
            36760: 24207,
            36761: 24464,
            36762: 24661,
            36763: 37604,
            36764: 38500,
            36765: 20663,
            36766: 20767,
            36767: 21213,
            36768: 21280,
            36769: 21319,
            36770: 21484,
            36771: 21736,
            36772: 21830,
            36773: 21809,
            36774: 22039,
            36775: 22888,
            36776: 22974,
            36777: 23100,
            36778: 23477,
            36779: 23558,
            36780: 23567,
            36781: 23569,
            36782: 23578,
            36783: 24196,
            36784: 24202,
            36785: 24288,
            36786: 24432,
            36787: 25215,
            36788: 25220,
            36789: 25307,
            36790: 25484,
            36791: 25463,
            36792: 26119,
            36793: 26124,
            36794: 26157,
            36795: 26230,
            36796: 26494,
            36797: 26786,
            36798: 27167,
            36799: 27189,
            36800: 27836,
            36801: 28040,
            36802: 28169,
            36803: 28248,
            36804: 28988,
            36805: 28966,
            36806: 29031,
            36807: 30151,
            36808: 30465,
            36809: 30813,
            36810: 30977,
            36811: 31077,
            36812: 31216,
            36813: 31456,
            36814: 31505,
            36815: 31911,
            36816: 32057,
            36817: 32918,
            36818: 33750,
            36819: 33931,
            36820: 34121,
            36821: 34909,
            36822: 35059,
            36823: 35359,
            36824: 35388,
            36825: 35412,
            36826: 35443,
            36827: 35937,
            36828: 36062,
            36829: 37284,
            36830: 37478,
            36831: 37758,
            36832: 37912,
            36833: 38556,
            36834: 38808,
            36835: 19978,
            36836: 19976,
            36837: 19998,
            36838: 20055,
            36839: 20887,
            36840: 21104,
            36841: 22478,
            36842: 22580,
            36843: 22732,
            36844: 23330,
            36845: 24120,
            36846: 24773,
            36847: 25854,
            36848: 26465,
            36849: 26454,
            36850: 27972,
            36851: 29366,
            36852: 30067,
            36853: 31331,
            36854: 33976,
            36855: 35698,
            36856: 37304,
            36857: 37664,
            36858: 22065,
            36859: 22516,
            36860: 39166,
            36928: 25325,
            36929: 26893,
            36930: 27542,
            36931: 29165,
            36932: 32340,
            36933: 32887,
            36934: 33394,
            36935: 35302,
            36936: 39135,
            36937: 34645,
            36938: 36785,
            36939: 23611,
            36940: 20280,
            36941: 20449,
            36942: 20405,
            36943: 21767,
            36944: 23072,
            36945: 23517,
            36946: 23529,
            36947: 24515,
            36948: 24910,
            36949: 25391,
            36950: 26032,
            36951: 26187,
            36952: 26862,
            36953: 27035,
            36954: 28024,
            36955: 28145,
            36956: 30003,
            36957: 30137,
            36958: 30495,
            36959: 31070,
            36960: 31206,
            36961: 32051,
            36962: 33251,
            36963: 33455,
            36964: 34218,
            36965: 35242,
            36966: 35386,
            36967: 36523,
            36968: 36763,
            36969: 36914,
            36970: 37341,
            36971: 38663,
            36972: 20154,
            36973: 20161,
            36974: 20995,
            36975: 22645,
            36976: 22764,
            36977: 23563,
            36978: 29978,
            36979: 23613,
            36980: 33102,
            36981: 35338,
            36982: 36805,
            36983: 38499,
            36984: 38765,
            36985: 31525,
            36986: 35535,
            36987: 38920,
            36988: 37218,
            36989: 22259,
            36990: 21416,
            36992: 36887,
            36993: 21561,
            36994: 22402,
            36995: 24101,
            36996: 25512,
            36997: 27700,
            36998: 28810,
            36999: 30561,
            37e3: 31883,
            37001: 32736,
            37002: 34928,
            37003: 36930,
            37004: 37204,
            37005: 37648,
            37006: 37656,
            37007: 38543,
            37008: 29790,
            37009: 39620,
            37010: 23815,
            37011: 23913,
            37012: 25968,
            37013: 26530,
            37014: 36264,
            37015: 38619,
            37016: 25454,
            37017: 26441,
            37018: 26905,
            37019: 33733,
            37020: 38935,
            37021: 38592,
            37022: 35070,
            37023: 28548,
            37024: 25722,
            37025: 23544,
            37026: 19990,
            37027: 28716,
            37028: 30045,
            37029: 26159,
            37030: 20932,
            37031: 21046,
            37032: 21218,
            37033: 22995,
            37034: 24449,
            37035: 24615,
            37036: 25104,
            37037: 25919,
            37038: 25972,
            37039: 26143,
            37040: 26228,
            37041: 26866,
            37042: 26646,
            37043: 27491,
            37044: 28165,
            37045: 29298,
            37046: 29983,
            37047: 30427,
            37048: 31934,
            37049: 32854,
            37050: 22768,
            37051: 35069,
            37052: 35199,
            37053: 35488,
            37054: 35475,
            37055: 35531,
            37056: 36893,
            37057: 37266,
            37058: 38738,
            37059: 38745,
            37060: 25993,
            37061: 31246,
            37062: 33030,
            37063: 38587,
            37064: 24109,
            37065: 24796,
            37066: 25114,
            37067: 26021,
            37068: 26132,
            37069: 26512,
            37070: 30707,
            37071: 31309,
            37072: 31821,
            37073: 32318,
            37074: 33034,
            37075: 36012,
            37076: 36196,
            37077: 36321,
            37078: 36447,
            37079: 30889,
            37080: 20999,
            37081: 25305,
            37082: 25509,
            37083: 25666,
            37084: 25240,
            37085: 35373,
            37086: 31363,
            37087: 31680,
            37088: 35500,
            37089: 38634,
            37090: 32118,
            37091: 33292,
            37092: 34633,
            37093: 20185,
            37094: 20808,
            37095: 21315,
            37096: 21344,
            37097: 23459,
            37098: 23554,
            37099: 23574,
            37100: 24029,
            37101: 25126,
            37102: 25159,
            37103: 25776,
            37104: 26643,
            37105: 26676,
            37106: 27849,
            37107: 27973,
            37108: 27927,
            37109: 26579,
            37110: 28508,
            37111: 29006,
            37112: 29053,
            37113: 26059,
            37114: 31359,
            37115: 31661,
            37116: 32218,
            37184: 32330,
            37185: 32680,
            37186: 33146,
            37187: 33307,
            37188: 33337,
            37189: 34214,
            37190: 35438,
            37191: 36046,
            37192: 36341,
            37193: 36984,
            37194: 36983,
            37195: 37549,
            37196: 37521,
            37197: 38275,
            37198: 39854,
            37199: 21069,
            37200: 21892,
            37201: 28472,
            37202: 28982,
            37203: 20840,
            37204: 31109,
            37205: 32341,
            37206: 33203,
            37207: 31950,
            37208: 22092,
            37209: 22609,
            37210: 23720,
            37211: 25514,
            37212: 26366,
            37213: 26365,
            37214: 26970,
            37215: 29401,
            37216: 30095,
            37217: 30094,
            37218: 30990,
            37219: 31062,
            37220: 31199,
            37221: 31895,
            37222: 32032,
            37223: 32068,
            37224: 34311,
            37225: 35380,
            37226: 38459,
            37227: 36961,
            37228: 40736,
            37229: 20711,
            37230: 21109,
            37231: 21452,
            37232: 21474,
            37233: 20489,
            37234: 21930,
            37235: 22766,
            37236: 22863,
            37237: 29245,
            37238: 23435,
            37239: 23652,
            37240: 21277,
            37241: 24803,
            37242: 24819,
            37243: 25436,
            37244: 25475,
            37245: 25407,
            37246: 25531,
            37248: 25805,
            37249: 26089,
            37250: 26361,
            37251: 24035,
            37252: 27085,
            37253: 27133,
            37254: 28437,
            37255: 29157,
            37256: 20105,
            37257: 30185,
            37258: 30456,
            37259: 31379,
            37260: 31967,
            37261: 32207,
            37262: 32156,
            37263: 32865,
            37264: 33609,
            37265: 33624,
            37266: 33900,
            37267: 33980,
            37268: 34299,
            37269: 35013,
            37270: 36208,
            37271: 36865,
            37272: 36973,
            37273: 37783,
            37274: 38684,
            37275: 39442,
            37276: 20687,
            37277: 22679,
            37278: 24974,
            37279: 33235,
            37280: 34101,
            37281: 36104,
            37282: 36896,
            37283: 20419,
            37284: 20596,
            37285: 21063,
            37286: 21363,
            37287: 24687,
            37288: 25417,
            37289: 26463,
            37290: 28204,
            37291: 36275,
            37292: 36895,
            37293: 20439,
            37294: 23646,
            37295: 36042,
            37296: 26063,
            37297: 32154,
            37298: 21330,
            37299: 34966,
            37300: 20854,
            37301: 25539,
            37302: 23384,
            37303: 23403,
            37304: 23562,
            37305: 25613,
            37306: 26449,
            37307: 36956,
            37308: 20182,
            37309: 22810,
            37310: 22826,
            37311: 27760,
            37312: 35409,
            37313: 21822,
            37314: 22549,
            37315: 22949,
            37316: 24816,
            37317: 25171,
            37318: 26561,
            37319: 33333,
            37320: 26965,
            37321: 38464,
            37322: 39364,
            37323: 39464,
            37324: 20307,
            37325: 22534,
            37326: 23550,
            37327: 32784,
            37328: 23729,
            37329: 24111,
            37330: 24453,
            37331: 24608,
            37332: 24907,
            37333: 25140,
            37334: 26367,
            37335: 27888,
            37336: 28382,
            37337: 32974,
            37338: 33151,
            37339: 33492,
            37340: 34955,
            37341: 36024,
            37342: 36864,
            37343: 36910,
            37344: 38538,
            37345: 40667,
            37346: 39899,
            37347: 20195,
            37348: 21488,
            37349: 22823,
            37350: 31532,
            37351: 37261,
            37352: 38988,
            37353: 40441,
            37354: 28381,
            37355: 28711,
            37356: 21331,
            37357: 21828,
            37358: 23429,
            37359: 25176,
            37360: 25246,
            37361: 25299,
            37362: 27810,
            37363: 28655,
            37364: 29730,
            37365: 35351,
            37366: 37944,
            37367: 28609,
            37368: 35582,
            37369: 33592,
            37370: 20967,
            37371: 34552,
            37372: 21482,
            37440: 21481,
            37441: 20294,
            37442: 36948,
            37443: 36784,
            37444: 22890,
            37445: 33073,
            37446: 24061,
            37447: 31466,
            37448: 36799,
            37449: 26842,
            37450: 35895,
            37451: 29432,
            37452: 40008,
            37453: 27197,
            37454: 35504,
            37455: 20025,
            37456: 21336,
            37457: 22022,
            37458: 22374,
            37459: 25285,
            37460: 25506,
            37461: 26086,
            37462: 27470,
            37463: 28129,
            37464: 28251,
            37465: 28845,
            37466: 30701,
            37467: 31471,
            37468: 31658,
            37469: 32187,
            37470: 32829,
            37471: 32966,
            37472: 34507,
            37473: 35477,
            37474: 37723,
            37475: 22243,
            37476: 22727,
            37477: 24382,
            37478: 26029,
            37479: 26262,
            37480: 27264,
            37481: 27573,
            37482: 30007,
            37483: 35527,
            37484: 20516,
            37485: 30693,
            37486: 22320,
            37487: 24347,
            37488: 24677,
            37489: 26234,
            37490: 27744,
            37491: 30196,
            37492: 31258,
            37493: 32622,
            37494: 33268,
            37495: 34584,
            37496: 36933,
            37497: 39347,
            37498: 31689,
            37499: 30044,
            37500: 31481,
            37501: 31569,
            37502: 33988,
            37504: 36880,
            37505: 31209,
            37506: 31378,
            37507: 33590,
            37508: 23265,
            37509: 30528,
            37510: 20013,
            37511: 20210,
            37512: 23449,
            37513: 24544,
            37514: 25277,
            37515: 26172,
            37516: 26609,
            37517: 27880,
            37518: 34411,
            37519: 34935,
            37520: 35387,
            37521: 37198,
            37522: 37619,
            37523: 39376,
            37524: 27159,
            37525: 28710,
            37526: 29482,
            37527: 33511,
            37528: 33879,
            37529: 36015,
            37530: 19969,
            37531: 20806,
            37532: 20939,
            37533: 21899,
            37534: 23541,
            37535: 24086,
            37536: 24115,
            37537: 24193,
            37538: 24340,
            37539: 24373,
            37540: 24427,
            37541: 24500,
            37542: 25074,
            37543: 25361,
            37544: 26274,
            37545: 26397,
            37546: 28526,
            37547: 29266,
            37548: 30010,
            37549: 30522,
            37550: 32884,
            37551: 33081,
            37552: 33144,
            37553: 34678,
            37554: 35519,
            37555: 35548,
            37556: 36229,
            37557: 36339,
            37558: 37530,
            37559: 38263,
            37560: 38914,
            37561: 40165,
            37562: 21189,
            37563: 25431,
            37564: 30452,
            37565: 26389,
            37566: 27784,
            37567: 29645,
            37568: 36035,
            37569: 37806,
            37570: 38515,
            37571: 27941,
            37572: 22684,
            37573: 26894,
            37574: 27084,
            37575: 36861,
            37576: 37786,
            37577: 30171,
            37578: 36890,
            37579: 22618,
            37580: 26626,
            37581: 25524,
            37582: 27131,
            37583: 20291,
            37584: 28460,
            37585: 26584,
            37586: 36795,
            37587: 34086,
            37588: 32180,
            37589: 37716,
            37590: 26943,
            37591: 28528,
            37592: 22378,
            37593: 22775,
            37594: 23340,
            37595: 32044,
            37596: 29226,
            37597: 21514,
            37598: 37347,
            37599: 40372,
            37600: 20141,
            37601: 20302,
            37602: 20572,
            37603: 20597,
            37604: 21059,
            37605: 35998,
            37606: 21576,
            37607: 22564,
            37608: 23450,
            37609: 24093,
            37610: 24213,
            37611: 24237,
            37612: 24311,
            37613: 24351,
            37614: 24716,
            37615: 25269,
            37616: 25402,
            37617: 25552,
            37618: 26799,
            37619: 27712,
            37620: 30855,
            37621: 31118,
            37622: 31243,
            37623: 32224,
            37624: 33351,
            37625: 35330,
            37626: 35558,
            37627: 36420,
            37628: 36883,
            37696: 37048,
            37697: 37165,
            37698: 37336,
            37699: 40718,
            37700: 27877,
            37701: 25688,
            37702: 25826,
            37703: 25973,
            37704: 28404,
            37705: 30340,
            37706: 31515,
            37707: 36969,
            37708: 37841,
            37709: 28346,
            37710: 21746,
            37711: 24505,
            37712: 25764,
            37713: 36685,
            37714: 36845,
            37715: 37444,
            37716: 20856,
            37717: 22635,
            37718: 22825,
            37719: 23637,
            37720: 24215,
            37721: 28155,
            37722: 32399,
            37723: 29980,
            37724: 36028,
            37725: 36578,
            37726: 39003,
            37727: 28857,
            37728: 20253,
            37729: 27583,
            37730: 28593,
            37731: 3e4,
            37732: 38651,
            37733: 20814,
            37734: 21520,
            37735: 22581,
            37736: 22615,
            37737: 22956,
            37738: 23648,
            37739: 24466,
            37740: 26007,
            37741: 26460,
            37742: 28193,
            37743: 30331,
            37744: 33759,
            37745: 36077,
            37746: 36884,
            37747: 37117,
            37748: 37709,
            37749: 30757,
            37750: 30778,
            37751: 21162,
            37752: 24230,
            37753: 22303,
            37754: 22900,
            37755: 24594,
            37756: 20498,
            37757: 20826,
            37758: 20908,
            37760: 20941,
            37761: 20992,
            37762: 21776,
            37763: 22612,
            37764: 22616,
            37765: 22871,
            37766: 23445,
            37767: 23798,
            37768: 23947,
            37769: 24764,
            37770: 25237,
            37771: 25645,
            37772: 26481,
            37773: 26691,
            37774: 26812,
            37775: 26847,
            37776: 30423,
            37777: 28120,
            37778: 28271,
            37779: 28059,
            37780: 28783,
            37781: 29128,
            37782: 24403,
            37783: 30168,
            37784: 31095,
            37785: 31561,
            37786: 31572,
            37787: 31570,
            37788: 31958,
            37789: 32113,
            37790: 21040,
            37791: 33891,
            37792: 34153,
            37793: 34276,
            37794: 35342,
            37795: 35588,
            37796: 35910,
            37797: 36367,
            37798: 36867,
            37799: 36879,
            37800: 37913,
            37801: 38518,
            37802: 38957,
            37803: 39472,
            37804: 38360,
            37805: 20685,
            37806: 21205,
            37807: 21516,
            37808: 22530,
            37809: 23566,
            37810: 24999,
            37811: 25758,
            37812: 27934,
            37813: 30643,
            37814: 31461,
            37815: 33012,
            37816: 33796,
            37817: 36947,
            37818: 37509,
            37819: 23776,
            37820: 40199,
            37821: 21311,
            37822: 24471,
            37823: 24499,
            37824: 28060,
            37825: 29305,
            37826: 30563,
            37827: 31167,
            37828: 31716,
            37829: 27602,
            37830: 29420,
            37831: 35501,
            37832: 26627,
            37833: 27233,
            37834: 20984,
            37835: 31361,
            37836: 26932,
            37837: 23626,
            37838: 40182,
            37839: 33515,
            37840: 23493,
            37841: 37193,
            37842: 28702,
            37843: 22136,
            37844: 23663,
            37845: 24775,
            37846: 25958,
            37847: 27788,
            37848: 35930,
            37849: 36929,
            37850: 38931,
            37851: 21585,
            37852: 26311,
            37853: 37389,
            37854: 22856,
            37855: 37027,
            37856: 20869,
            37857: 20045,
            37858: 20970,
            37859: 34201,
            37860: 35598,
            37861: 28760,
            37862: 25466,
            37863: 37707,
            37864: 26978,
            37865: 39348,
            37866: 32260,
            37867: 30071,
            37868: 21335,
            37869: 26976,
            37870: 36575,
            37871: 38627,
            37872: 27741,
            37873: 20108,
            37874: 23612,
            37875: 24336,
            37876: 36841,
            37877: 21250,
            37878: 36049,
            37879: 32905,
            37880: 34425,
            37881: 24319,
            37882: 26085,
            37883: 20083,
            37884: 20837,
            37952: 22914,
            37953: 23615,
            37954: 38894,
            37955: 20219,
            37956: 22922,
            37957: 24525,
            37958: 35469,
            37959: 28641,
            37960: 31152,
            37961: 31074,
            37962: 23527,
            37963: 33905,
            37964: 29483,
            37965: 29105,
            37966: 24180,
            37967: 24565,
            37968: 25467,
            37969: 25754,
            37970: 29123,
            37971: 31896,
            37972: 20035,
            37973: 24316,
            37974: 20043,
            37975: 22492,
            37976: 22178,
            37977: 24745,
            37978: 28611,
            37979: 32013,
            37980: 33021,
            37981: 33075,
            37982: 33215,
            37983: 36786,
            37984: 35223,
            37985: 34468,
            37986: 24052,
            37987: 25226,
            37988: 25773,
            37989: 35207,
            37990: 26487,
            37991: 27874,
            37992: 27966,
            37993: 29750,
            37994: 30772,
            37995: 23110,
            37996: 32629,
            37997: 33453,
            37998: 39340,
            37999: 20467,
            38e3: 24259,
            38001: 25309,
            38002: 25490,
            38003: 25943,
            38004: 26479,
            38005: 30403,
            38006: 29260,
            38007: 32972,
            38008: 32954,
            38009: 36649,
            38010: 37197,
            38011: 20493,
            38012: 22521,
            38013: 23186,
            38014: 26757,
            38016: 26995,
            38017: 29028,
            38018: 29437,
            38019: 36023,
            38020: 22770,
            38021: 36064,
            38022: 38506,
            38023: 36889,
            38024: 34687,
            38025: 31204,
            38026: 30695,
            38027: 33833,
            38028: 20271,
            38029: 21093,
            38030: 21338,
            38031: 25293,
            38032: 26575,
            38033: 27850,
            38034: 30333,
            38035: 31636,
            38036: 31893,
            38037: 33334,
            38038: 34180,
            38039: 36843,
            38040: 26333,
            38041: 28448,
            38042: 29190,
            38043: 32283,
            38044: 33707,
            38045: 39361,
            38046: 40614,
            38047: 20989,
            38048: 31665,
            38049: 30834,
            38050: 31672,
            38051: 32903,
            38052: 31560,
            38053: 27368,
            38054: 24161,
            38055: 32908,
            38056: 30033,
            38057: 30048,
            38058: 20843,
            38059: 37474,
            38060: 28300,
            38061: 30330,
            38062: 37271,
            38063: 39658,
            38064: 20240,
            38065: 32624,
            38066: 25244,
            38067: 31567,
            38068: 38309,
            38069: 40169,
            38070: 22138,
            38071: 22617,
            38072: 34532,
            38073: 38588,
            38074: 20276,
            38075: 21028,
            38076: 21322,
            38077: 21453,
            38078: 21467,
            38079: 24070,
            38080: 25644,
            38081: 26001,
            38082: 26495,
            38083: 27710,
            38084: 27726,
            38085: 29256,
            38086: 29359,
            38087: 29677,
            38088: 30036,
            38089: 32321,
            38090: 33324,
            38091: 34281,
            38092: 36009,
            38093: 31684,
            38094: 37318,
            38095: 29033,
            38096: 38930,
            38097: 39151,
            38098: 25405,
            38099: 26217,
            38100: 30058,
            38101: 30436,
            38102: 30928,
            38103: 34115,
            38104: 34542,
            38105: 21290,
            38106: 21329,
            38107: 21542,
            38108: 22915,
            38109: 24199,
            38110: 24444,
            38111: 24754,
            38112: 25161,
            38113: 25209,
            38114: 25259,
            38115: 26e3,
            38116: 27604,
            38117: 27852,
            38118: 30130,
            38119: 30382,
            38120: 30865,
            38121: 31192,
            38122: 32203,
            38123: 32631,
            38124: 32933,
            38125: 34987,
            38126: 35513,
            38127: 36027,
            38128: 36991,
            38129: 38750,
            38130: 39131,
            38131: 27147,
            38132: 31800,
            38133: 20633,
            38134: 23614,
            38135: 24494,
            38136: 26503,
            38137: 27608,
            38138: 29749,
            38139: 30473,
            38140: 32654,
            38208: 40763,
            38209: 26570,
            38210: 31255,
            38211: 21305,
            38212: 30091,
            38213: 39661,
            38214: 24422,
            38215: 33181,
            38216: 33777,
            38217: 32920,
            38218: 24380,
            38219: 24517,
            38220: 30050,
            38221: 31558,
            38222: 36924,
            38223: 26727,
            38224: 23019,
            38225: 23195,
            38226: 32016,
            38227: 30334,
            38228: 35628,
            38229: 20469,
            38230: 24426,
            38231: 27161,
            38232: 27703,
            38233: 28418,
            38234: 29922,
            38235: 31080,
            38236: 34920,
            38237: 35413,
            38238: 35961,
            38239: 24287,
            38240: 25551,
            38241: 30149,
            38242: 31186,
            38243: 33495,
            38244: 37672,
            38245: 37618,
            38246: 33948,
            38247: 34541,
            38248: 39981,
            38249: 21697,
            38250: 24428,
            38251: 25996,
            38252: 27996,
            38253: 28693,
            38254: 36007,
            38255: 36051,
            38256: 38971,
            38257: 25935,
            38258: 29942,
            38259: 19981,
            38260: 20184,
            38261: 22496,
            38262: 22827,
            38263: 23142,
            38264: 23500,
            38265: 20904,
            38266: 24067,
            38267: 24220,
            38268: 24598,
            38269: 25206,
            38270: 25975,
            38272: 26023,
            38273: 26222,
            38274: 28014,
            38275: 29238,
            38276: 31526,
            38277: 33104,
            38278: 33178,
            38279: 33433,
            38280: 35676,
            38281: 36e3,
            38282: 36070,
            38283: 36212,
            38284: 38428,
            38285: 38468,
            38286: 20398,
            38287: 25771,
            38288: 27494,
            38289: 33310,
            38290: 33889,
            38291: 34154,
            38292: 37096,
            38293: 23553,
            38294: 26963,
            38295: 39080,
            38296: 33914,
            38297: 34135,
            38298: 20239,
            38299: 21103,
            38300: 24489,
            38301: 24133,
            38302: 26381,
            38303: 31119,
            38304: 33145,
            38305: 35079,
            38306: 35206,
            38307: 28149,
            38308: 24343,
            38309: 25173,
            38310: 27832,
            38311: 20175,
            38312: 29289,
            38313: 39826,
            38314: 20998,
            38315: 21563,
            38316: 22132,
            38317: 22707,
            38318: 24996,
            38319: 25198,
            38320: 28954,
            38321: 22894,
            38322: 31881,
            38323: 31966,
            38324: 32027,
            38325: 38640,
            38326: 25991,
            38327: 32862,
            38328: 19993,
            38329: 20341,
            38330: 20853,
            38331: 22592,
            38332: 24163,
            38333: 24179,
            38334: 24330,
            38335: 26564,
            38336: 20006,
            38337: 34109,
            38338: 38281,
            38339: 38491,
            38340: 31859,
            38341: 38913,
            38342: 20731,
            38343: 22721,
            38344: 30294,
            38345: 30887,
            38346: 21029,
            38347: 30629,
            38348: 34065,
            38349: 31622,
            38350: 20559,
            38351: 22793,
            38352: 29255,
            38353: 31687,
            38354: 32232,
            38355: 36794,
            38356: 36820,
            38357: 36941,
            38358: 20415,
            38359: 21193,
            38360: 23081,
            38361: 24321,
            38362: 38829,
            38363: 20445,
            38364: 33303,
            38365: 37610,
            38366: 22275,
            38367: 25429,
            38368: 27497,
            38369: 29995,
            38370: 35036,
            38371: 36628,
            38372: 31298,
            38373: 21215,
            38374: 22675,
            38375: 24917,
            38376: 25098,
            38377: 26286,
            38378: 27597,
            38379: 31807,
            38380: 33769,
            38381: 20515,
            38382: 20472,
            38383: 21253,
            38384: 21574,
            38385: 22577,
            38386: 22857,
            38387: 23453,
            38388: 23792,
            38389: 23791,
            38390: 23849,
            38391: 24214,
            38392: 25265,
            38393: 25447,
            38394: 25918,
            38395: 26041,
            38396: 26379,
            38464: 27861,
            38465: 27873,
            38466: 28921,
            38467: 30770,
            38468: 32299,
            38469: 32990,
            38470: 33459,
            38471: 33804,
            38472: 34028,
            38473: 34562,
            38474: 35090,
            38475: 35370,
            38476: 35914,
            38477: 37030,
            38478: 37586,
            38479: 39165,
            38480: 40179,
            38481: 40300,
            38482: 20047,
            38483: 20129,
            38484: 20621,
            38485: 21078,
            38486: 22346,
            38487: 22952,
            38488: 24125,
            38489: 24536,
            38490: 24537,
            38491: 25151,
            38492: 26292,
            38493: 26395,
            38494: 26576,
            38495: 26834,
            38496: 20882,
            38497: 32033,
            38498: 32938,
            38499: 33192,
            38500: 35584,
            38501: 35980,
            38502: 36031,
            38503: 37502,
            38504: 38450,
            38505: 21536,
            38506: 38956,
            38507: 21271,
            38508: 20693,
            38509: 21340,
            38510: 22696,
            38511: 25778,
            38512: 26420,
            38513: 29287,
            38514: 30566,
            38515: 31302,
            38516: 37350,
            38517: 21187,
            38518: 27809,
            38519: 27526,
            38520: 22528,
            38521: 24140,
            38522: 22868,
            38523: 26412,
            38524: 32763,
            38525: 20961,
            38526: 30406,
            38528: 25705,
            38529: 30952,
            38530: 39764,
            38531: 40635,
            38532: 22475,
            38533: 22969,
            38534: 26151,
            38535: 26522,
            38536: 27598,
            38537: 21737,
            38538: 27097,
            38539: 24149,
            38540: 33180,
            38541: 26517,
            38542: 39850,
            38543: 26622,
            38544: 40018,
            38545: 26717,
            38546: 20134,
            38547: 20451,
            38548: 21448,
            38549: 25273,
            38550: 26411,
            38551: 27819,
            38552: 36804,
            38553: 20397,
            38554: 32365,
            38555: 40639,
            38556: 19975,
            38557: 24930,
            38558: 28288,
            38559: 28459,
            38560: 34067,
            38561: 21619,
            38562: 26410,
            38563: 39749,
            38564: 24051,
            38565: 31637,
            38566: 23724,
            38567: 23494,
            38568: 34588,
            38569: 28234,
            38570: 34001,
            38571: 31252,
            38572: 33032,
            38573: 22937,
            38574: 31885,
            38575: 27665,
            38576: 30496,
            38577: 21209,
            38578: 22818,
            38579: 28961,
            38580: 29279,
            38581: 30683,
            38582: 38695,
            38583: 40289,
            38584: 26891,
            38585: 23167,
            38586: 23064,
            38587: 20901,
            38588: 21517,
            38589: 21629,
            38590: 26126,
            38591: 30431,
            38592: 36855,
            38593: 37528,
            38594: 40180,
            38595: 23018,
            38596: 29277,
            38597: 28357,
            38598: 20813,
            38599: 26825,
            38600: 32191,
            38601: 32236,
            38602: 38754,
            38603: 40634,
            38604: 25720,
            38605: 27169,
            38606: 33538,
            38607: 22916,
            38608: 23391,
            38609: 27611,
            38610: 29467,
            38611: 30450,
            38612: 32178,
            38613: 32791,
            38614: 33945,
            38615: 20786,
            38616: 26408,
            38617: 40665,
            38618: 30446,
            38619: 26466,
            38620: 21247,
            38621: 39173,
            38622: 23588,
            38623: 25147,
            38624: 31870,
            38625: 36016,
            38626: 21839,
            38627: 24758,
            38628: 32011,
            38629: 38272,
            38630: 21249,
            38631: 20063,
            38632: 20918,
            38633: 22812,
            38634: 29242,
            38635: 32822,
            38636: 37326,
            38637: 24357,
            38638: 30690,
            38639: 21380,
            38640: 24441,
            38641: 32004,
            38642: 34220,
            38643: 35379,
            38644: 36493,
            38645: 38742,
            38646: 26611,
            38647: 34222,
            38648: 37971,
            38649: 24841,
            38650: 24840,
            38651: 27833,
            38652: 30290,
            38720: 35565,
            38721: 36664,
            38722: 21807,
            38723: 20305,
            38724: 20778,
            38725: 21191,
            38726: 21451,
            38727: 23461,
            38728: 24189,
            38729: 24736,
            38730: 24962,
            38731: 25558,
            38732: 26377,
            38733: 26586,
            38734: 28263,
            38735: 28044,
            38736: 29494,
            38737: 29495,
            38738: 30001,
            38739: 31056,
            38740: 35029,
            38741: 35480,
            38742: 36938,
            38743: 37009,
            38744: 37109,
            38745: 38596,
            38746: 34701,
            38747: 22805,
            38748: 20104,
            38749: 20313,
            38750: 19982,
            38751: 35465,
            38752: 36671,
            38753: 38928,
            38754: 20653,
            38755: 24188,
            38756: 22934,
            38757: 23481,
            38758: 24248,
            38759: 25562,
            38760: 25594,
            38761: 25793,
            38762: 26332,
            38763: 26954,
            38764: 27096,
            38765: 27915,
            38766: 28342,
            38767: 29076,
            38768: 29992,
            38769: 31407,
            38770: 32650,
            38771: 32768,
            38772: 33865,
            38773: 33993,
            38774: 35201,
            38775: 35617,
            38776: 36362,
            38777: 36965,
            38778: 38525,
            38779: 39178,
            38780: 24958,
            38781: 25233,
            38782: 27442,
            38784: 27779,
            38785: 28020,
            38786: 32716,
            38787: 32764,
            38788: 28096,
            38789: 32645,
            38790: 34746,
            38791: 35064,
            38792: 26469,
            38793: 33713,
            38794: 38972,
            38795: 38647,
            38796: 27931,
            38797: 32097,
            38798: 33853,
            38799: 37226,
            38800: 20081,
            38801: 21365,
            38802: 23888,
            38803: 27396,
            38804: 28651,
            38805: 34253,
            38806: 34349,
            38807: 35239,
            38808: 21033,
            38809: 21519,
            38810: 23653,
            38811: 26446,
            38812: 26792,
            38813: 29702,
            38814: 29827,
            38815: 30178,
            38816: 35023,
            38817: 35041,
            38818: 37324,
            38819: 38626,
            38820: 38520,
            38821: 24459,
            38822: 29575,
            38823: 31435,
            38824: 33870,
            38825: 25504,
            38826: 30053,
            38827: 21129,
            38828: 27969,
            38829: 28316,
            38830: 29705,
            38831: 30041,
            38832: 30827,
            38833: 31890,
            38834: 38534,
            38835: 31452,
            38836: 40845,
            38837: 20406,
            38838: 24942,
            38839: 26053,
            38840: 34396,
            38841: 20102,
            38842: 20142,
            38843: 20698,
            38844: 20001,
            38845: 20940,
            38846: 23534,
            38847: 26009,
            38848: 26753,
            38849: 28092,
            38850: 29471,
            38851: 30274,
            38852: 30637,
            38853: 31260,
            38854: 31975,
            38855: 33391,
            38856: 35538,
            38857: 36988,
            38858: 37327,
            38859: 38517,
            38860: 38936,
            38861: 21147,
            38862: 32209,
            38863: 20523,
            38864: 21400,
            38865: 26519,
            38866: 28107,
            38867: 29136,
            38868: 29747,
            38869: 33256,
            38870: 36650,
            38871: 38563,
            38872: 40023,
            38873: 40607,
            38874: 29792,
            38875: 22593,
            38876: 28057,
            38877: 32047,
            38878: 39006,
            38879: 20196,
            38880: 20278,
            38881: 20363,
            38882: 20919,
            38883: 21169,
            38884: 23994,
            38885: 24604,
            38886: 29618,
            38887: 31036,
            38888: 33491,
            38889: 37428,
            38890: 38583,
            38891: 38646,
            38892: 38666,
            38893: 40599,
            38894: 40802,
            38895: 26278,
            38896: 27508,
            38897: 21015,
            38898: 21155,
            38899: 28872,
            38900: 35010,
            38901: 24265,
            38902: 24651,
            38903: 24976,
            38904: 28451,
            38905: 29001,
            38906: 31806,
            38907: 32244,
            38908: 32879,
            38976: 34030,
            38977: 36899,
            38978: 37676,
            38979: 21570,
            38980: 39791,
            38981: 27347,
            38982: 28809,
            38983: 36034,
            38984: 36335,
            38985: 38706,
            38986: 21172,
            38987: 23105,
            38988: 24266,
            38989: 24324,
            38990: 26391,
            38991: 27004,
            38992: 27028,
            38993: 28010,
            38994: 28431,
            38995: 29282,
            38996: 29436,
            38997: 31725,
            38998: 32769,
            38999: 32894,
            39e3: 34635,
            39001: 37070,
            39002: 20845,
            39003: 40595,
            39004: 31108,
            39005: 32907,
            39006: 37682,
            39007: 35542,
            39008: 20525,
            39009: 21644,
            39010: 35441,
            39011: 27498,
            39012: 36036,
            39013: 33031,
            39014: 24785,
            39015: 26528,
            39016: 40434,
            39017: 20121,
            39018: 20120,
            39019: 39952,
            39020: 35435,
            39021: 34241,
            39022: 34152,
            39023: 26880,
            39024: 28286,
            39025: 30871,
            39026: 33109,
            39071: 24332,
            39072: 19984,
            39073: 19989,
            39074: 20010,
            39075: 20017,
            39076: 20022,
            39077: 20028,
            39078: 20031,
            39079: 20034,
            39080: 20054,
            39081: 20056,
            39082: 20098,
            39083: 20101,
            39084: 35947,
            39085: 20106,
            39086: 33298,
            39087: 24333,
            39088: 20110,
            39089: 20126,
            39090: 20127,
            39091: 20128,
            39092: 20130,
            39093: 20144,
            39094: 20147,
            39095: 20150,
            39096: 20174,
            39097: 20173,
            39098: 20164,
            39099: 20166,
            39100: 20162,
            39101: 20183,
            39102: 20190,
            39103: 20205,
            39104: 20191,
            39105: 20215,
            39106: 20233,
            39107: 20314,
            39108: 20272,
            39109: 20315,
            39110: 20317,
            39111: 20311,
            39112: 20295,
            39113: 20342,
            39114: 20360,
            39115: 20367,
            39116: 20376,
            39117: 20347,
            39118: 20329,
            39119: 20336,
            39120: 20369,
            39121: 20335,
            39122: 20358,
            39123: 20374,
            39124: 20760,
            39125: 20436,
            39126: 20447,
            39127: 20430,
            39128: 20440,
            39129: 20443,
            39130: 20433,
            39131: 20442,
            39132: 20432,
            39133: 20452,
            39134: 20453,
            39135: 20506,
            39136: 20520,
            39137: 20500,
            39138: 20522,
            39139: 20517,
            39140: 20485,
            39141: 20252,
            39142: 20470,
            39143: 20513,
            39144: 20521,
            39145: 20524,
            39146: 20478,
            39147: 20463,
            39148: 20497,
            39149: 20486,
            39150: 20547,
            39151: 20551,
            39152: 26371,
            39153: 20565,
            39154: 20560,
            39155: 20552,
            39156: 20570,
            39157: 20566,
            39158: 20588,
            39159: 20600,
            39160: 20608,
            39161: 20634,
            39162: 20613,
            39163: 20660,
            39164: 20658,
            39232: 20681,
            39233: 20682,
            39234: 20659,
            39235: 20674,
            39236: 20694,
            39237: 20702,
            39238: 20709,
            39239: 20717,
            39240: 20707,
            39241: 20718,
            39242: 20729,
            39243: 20725,
            39244: 20745,
            39245: 20737,
            39246: 20738,
            39247: 20758,
            39248: 20757,
            39249: 20756,
            39250: 20762,
            39251: 20769,
            39252: 20794,
            39253: 20791,
            39254: 20796,
            39255: 20795,
            39256: 20799,
            39257: 20800,
            39258: 20818,
            39259: 20812,
            39260: 20820,
            39261: 20834,
            39262: 31480,
            39263: 20841,
            39264: 20842,
            39265: 20846,
            39266: 20864,
            39267: 20866,
            39268: 22232,
            39269: 20876,
            39270: 20873,
            39271: 20879,
            39272: 20881,
            39273: 20883,
            39274: 20885,
            39275: 20886,
            39276: 20900,
            39277: 20902,
            39278: 20898,
            39279: 20905,
            39280: 20906,
            39281: 20907,
            39282: 20915,
            39283: 20913,
            39284: 20914,
            39285: 20912,
            39286: 20917,
            39287: 20925,
            39288: 20933,
            39289: 20937,
            39290: 20955,
            39291: 20960,
            39292: 34389,
            39293: 20969,
            39294: 20973,
            39296: 20976,
            39297: 20981,
            39298: 20990,
            39299: 20996,
            39300: 21003,
            39301: 21012,
            39302: 21006,
            39303: 21031,
            39304: 21034,
            39305: 21038,
            39306: 21043,
            39307: 21049,
            39308: 21071,
            39309: 21060,
            39310: 21067,
            39311: 21068,
            39312: 21086,
            39313: 21076,
            39314: 21098,
            39315: 21108,
            39316: 21097,
            39317: 21107,
            39318: 21119,
            39319: 21117,
            39320: 21133,
            39321: 21140,
            39322: 21138,
            39323: 21105,
            39324: 21128,
            39325: 21137,
            39326: 36776,
            39327: 36775,
            39328: 21164,
            39329: 21165,
            39330: 21180,
            39331: 21173,
            39332: 21185,
            39333: 21197,
            39334: 21207,
            39335: 21214,
            39336: 21219,
            39337: 21222,
            39338: 39149,
            39339: 21216,
            39340: 21235,
            39341: 21237,
            39342: 21240,
            39343: 21241,
            39344: 21254,
            39345: 21256,
            39346: 30008,
            39347: 21261,
            39348: 21264,
            39349: 21263,
            39350: 21269,
            39351: 21274,
            39352: 21283,
            39353: 21295,
            39354: 21297,
            39355: 21299,
            39356: 21304,
            39357: 21312,
            39358: 21318,
            39359: 21317,
            39360: 19991,
            39361: 21321,
            39362: 21325,
            39363: 20950,
            39364: 21342,
            39365: 21353,
            39366: 21358,
            39367: 22808,
            39368: 21371,
            39369: 21367,
            39370: 21378,
            39371: 21398,
            39372: 21408,
            39373: 21414,
            39374: 21413,
            39375: 21422,
            39376: 21424,
            39377: 21430,
            39378: 21443,
            39379: 31762,
            39380: 38617,
            39381: 21471,
            39382: 26364,
            39383: 29166,
            39384: 21486,
            39385: 21480,
            39386: 21485,
            39387: 21498,
            39388: 21505,
            39389: 21565,
            39390: 21568,
            39391: 21548,
            39392: 21549,
            39393: 21564,
            39394: 21550,
            39395: 21558,
            39396: 21545,
            39397: 21533,
            39398: 21582,
            39399: 21647,
            39400: 21621,
            39401: 21646,
            39402: 21599,
            39403: 21617,
            39404: 21623,
            39405: 21616,
            39406: 21650,
            39407: 21627,
            39408: 21632,
            39409: 21622,
            39410: 21636,
            39411: 21648,
            39412: 21638,
            39413: 21703,
            39414: 21666,
            39415: 21688,
            39416: 21669,
            39417: 21676,
            39418: 21700,
            39419: 21704,
            39420: 21672,
            39488: 21675,
            39489: 21698,
            39490: 21668,
            39491: 21694,
            39492: 21692,
            39493: 21720,
            39494: 21733,
            39495: 21734,
            39496: 21775,
            39497: 21780,
            39498: 21757,
            39499: 21742,
            39500: 21741,
            39501: 21754,
            39502: 21730,
            39503: 21817,
            39504: 21824,
            39505: 21859,
            39506: 21836,
            39507: 21806,
            39508: 21852,
            39509: 21829,
            39510: 21846,
            39511: 21847,
            39512: 21816,
            39513: 21811,
            39514: 21853,
            39515: 21913,
            39516: 21888,
            39517: 21679,
            39518: 21898,
            39519: 21919,
            39520: 21883,
            39521: 21886,
            39522: 21912,
            39523: 21918,
            39524: 21934,
            39525: 21884,
            39526: 21891,
            39527: 21929,
            39528: 21895,
            39529: 21928,
            39530: 21978,
            39531: 21957,
            39532: 21983,
            39533: 21956,
            39534: 21980,
            39535: 21988,
            39536: 21972,
            39537: 22036,
            39538: 22007,
            39539: 22038,
            39540: 22014,
            39541: 22013,
            39542: 22043,
            39543: 22009,
            39544: 22094,
            39545: 22096,
            39546: 29151,
            39547: 22068,
            39548: 22070,
            39549: 22066,
            39550: 22072,
            39552: 22123,
            39553: 22116,
            39554: 22063,
            39555: 22124,
            39556: 22122,
            39557: 22150,
            39558: 22144,
            39559: 22154,
            39560: 22176,
            39561: 22164,
            39562: 22159,
            39563: 22181,
            39564: 22190,
            39565: 22198,
            39566: 22196,
            39567: 22210,
            39568: 22204,
            39569: 22209,
            39570: 22211,
            39571: 22208,
            39572: 22216,
            39573: 22222,
            39574: 22225,
            39575: 22227,
            39576: 22231,
            39577: 22254,
            39578: 22265,
            39579: 22272,
            39580: 22271,
            39581: 22276,
            39582: 22281,
            39583: 22280,
            39584: 22283,
            39585: 22285,
            39586: 22291,
            39587: 22296,
            39588: 22294,
            39589: 21959,
            39590: 22300,
            39591: 22310,
            39592: 22327,
            39593: 22328,
            39594: 22350,
            39595: 22331,
            39596: 22336,
            39597: 22351,
            39598: 22377,
            39599: 22464,
            39600: 22408,
            39601: 22369,
            39602: 22399,
            39603: 22409,
            39604: 22419,
            39605: 22432,
            39606: 22451,
            39607: 22436,
            39608: 22442,
            39609: 22448,
            39610: 22467,
            39611: 22470,
            39612: 22484,
            39613: 22482,
            39614: 22483,
            39615: 22538,
            39616: 22486,
            39617: 22499,
            39618: 22539,
            39619: 22553,
            39620: 22557,
            39621: 22642,
            39622: 22561,
            39623: 22626,
            39624: 22603,
            39625: 22640,
            39626: 27584,
            39627: 22610,
            39628: 22589,
            39629: 22649,
            39630: 22661,
            39631: 22713,
            39632: 22687,
            39633: 22699,
            39634: 22714,
            39635: 22750,
            39636: 22715,
            39637: 22712,
            39638: 22702,
            39639: 22725,
            39640: 22739,
            39641: 22737,
            39642: 22743,
            39643: 22745,
            39644: 22744,
            39645: 22757,
            39646: 22748,
            39647: 22756,
            39648: 22751,
            39649: 22767,
            39650: 22778,
            39651: 22777,
            39652: 22779,
            39653: 22780,
            39654: 22781,
            39655: 22786,
            39656: 22794,
            39657: 22800,
            39658: 22811,
            39659: 26790,
            39660: 22821,
            39661: 22828,
            39662: 22829,
            39663: 22834,
            39664: 22840,
            39665: 22846,
            39666: 31442,
            39667: 22869,
            39668: 22864,
            39669: 22862,
            39670: 22874,
            39671: 22872,
            39672: 22882,
            39673: 22880,
            39674: 22887,
            39675: 22892,
            39676: 22889,
            39744: 22904,
            39745: 22913,
            39746: 22941,
            39747: 20318,
            39748: 20395,
            39749: 22947,
            39750: 22962,
            39751: 22982,
            39752: 23016,
            39753: 23004,
            39754: 22925,
            39755: 23001,
            39756: 23002,
            39757: 23077,
            39758: 23071,
            39759: 23057,
            39760: 23068,
            39761: 23049,
            39762: 23066,
            39763: 23104,
            39764: 23148,
            39765: 23113,
            39766: 23093,
            39767: 23094,
            39768: 23138,
            39769: 23146,
            39770: 23194,
            39771: 23228,
            39772: 23230,
            39773: 23243,
            39774: 23234,
            39775: 23229,
            39776: 23267,
            39777: 23255,
            39778: 23270,
            39779: 23273,
            39780: 23254,
            39781: 23290,
            39782: 23291,
            39783: 23308,
            39784: 23307,
            39785: 23318,
            39786: 23346,
            39787: 23248,
            39788: 23338,
            39789: 23350,
            39790: 23358,
            39791: 23363,
            39792: 23365,
            39793: 23360,
            39794: 23377,
            39795: 23381,
            39796: 23386,
            39797: 23387,
            39798: 23397,
            39799: 23401,
            39800: 23408,
            39801: 23411,
            39802: 23413,
            39803: 23416,
            39804: 25992,
            39805: 23418,
            39806: 23424,
            39808: 23427,
            39809: 23462,
            39810: 23480,
            39811: 23491,
            39812: 23495,
            39813: 23497,
            39814: 23508,
            39815: 23504,
            39816: 23524,
            39817: 23526,
            39818: 23522,
            39819: 23518,
            39820: 23525,
            39821: 23531,
            39822: 23536,
            39823: 23542,
            39824: 23539,
            39825: 23557,
            39826: 23559,
            39827: 23560,
            39828: 23565,
            39829: 23571,
            39830: 23584,
            39831: 23586,
            39832: 23592,
            39833: 23608,
            39834: 23609,
            39835: 23617,
            39836: 23622,
            39837: 23630,
            39838: 23635,
            39839: 23632,
            39840: 23631,
            39841: 23409,
            39842: 23660,
            39843: 23662,
            39844: 20066,
            39845: 23670,
            39846: 23673,
            39847: 23692,
            39848: 23697,
            39849: 23700,
            39850: 22939,
            39851: 23723,
            39852: 23739,
            39853: 23734,
            39854: 23740,
            39855: 23735,
            39856: 23749,
            39857: 23742,
            39858: 23751,
            39859: 23769,
            39860: 23785,
            39861: 23805,
            39862: 23802,
            39863: 23789,
            39864: 23948,
            39865: 23786,
            39866: 23819,
            39867: 23829,
            39868: 23831,
            39869: 23900,
            39870: 23839,
            39871: 23835,
            39872: 23825,
            39873: 23828,
            39874: 23842,
            39875: 23834,
            39876: 23833,
            39877: 23832,
            39878: 23884,
            39879: 23890,
            39880: 23886,
            39881: 23883,
            39882: 23916,
            39883: 23923,
            39884: 23926,
            39885: 23943,
            39886: 23940,
            39887: 23938,
            39888: 23970,
            39889: 23965,
            39890: 23980,
            39891: 23982,
            39892: 23997,
            39893: 23952,
            39894: 23991,
            39895: 23996,
            39896: 24009,
            39897: 24013,
            39898: 24019,
            39899: 24018,
            39900: 24022,
            39901: 24027,
            39902: 24043,
            39903: 24050,
            39904: 24053,
            39905: 24075,
            39906: 24090,
            39907: 24089,
            39908: 24081,
            39909: 24091,
            39910: 24118,
            39911: 24119,
            39912: 24132,
            39913: 24131,
            39914: 24128,
            39915: 24142,
            39916: 24151,
            39917: 24148,
            39918: 24159,
            39919: 24162,
            39920: 24164,
            39921: 24135,
            39922: 24181,
            39923: 24182,
            39924: 24186,
            39925: 40636,
            39926: 24191,
            39927: 24224,
            39928: 24257,
            39929: 24258,
            39930: 24264,
            39931: 24272,
            39932: 24271,
            4e4: 24278,
            40001: 24291,
            40002: 24285,
            40003: 24282,
            40004: 24283,
            40005: 24290,
            40006: 24289,
            40007: 24296,
            40008: 24297,
            40009: 24300,
            40010: 24305,
            40011: 24307,
            40012: 24304,
            40013: 24308,
            40014: 24312,
            40015: 24318,
            40016: 24323,
            40017: 24329,
            40018: 24413,
            40019: 24412,
            40020: 24331,
            40021: 24337,
            40022: 24342,
            40023: 24361,
            40024: 24365,
            40025: 24376,
            40026: 24385,
            40027: 24392,
            40028: 24396,
            40029: 24398,
            40030: 24367,
            40031: 24401,
            40032: 24406,
            40033: 24407,
            40034: 24409,
            40035: 24417,
            40036: 24429,
            40037: 24435,
            40038: 24439,
            40039: 24451,
            40040: 24450,
            40041: 24447,
            40042: 24458,
            40043: 24456,
            40044: 24465,
            40045: 24455,
            40046: 24478,
            40047: 24473,
            40048: 24472,
            40049: 24480,
            40050: 24488,
            40051: 24493,
            40052: 24508,
            40053: 24534,
            40054: 24571,
            40055: 24548,
            40056: 24568,
            40057: 24561,
            40058: 24541,
            40059: 24755,
            40060: 24575,
            40061: 24609,
            40062: 24672,
            40064: 24601,
            40065: 24592,
            40066: 24617,
            40067: 24590,
            40068: 24625,
            40069: 24603,
            40070: 24597,
            40071: 24619,
            40072: 24614,
            40073: 24591,
            40074: 24634,
            40075: 24666,
            40076: 24641,
            40077: 24682,
            40078: 24695,
            40079: 24671,
            40080: 24650,
            40081: 24646,
            40082: 24653,
            40083: 24675,
            40084: 24643,
            40085: 24676,
            40086: 24642,
            40087: 24684,
            40088: 24683,
            40089: 24665,
            40090: 24705,
            40091: 24717,
            40092: 24807,
            40093: 24707,
            40094: 24730,
            40095: 24708,
            40096: 24731,
            40097: 24726,
            40098: 24727,
            40099: 24722,
            40100: 24743,
            40101: 24715,
            40102: 24801,
            40103: 24760,
            40104: 24800,
            40105: 24787,
            40106: 24756,
            40107: 24560,
            40108: 24765,
            40109: 24774,
            40110: 24757,
            40111: 24792,
            40112: 24909,
            40113: 24853,
            40114: 24838,
            40115: 24822,
            40116: 24823,
            40117: 24832,
            40118: 24820,
            40119: 24826,
            40120: 24835,
            40121: 24865,
            40122: 24827,
            40123: 24817,
            40124: 24845,
            40125: 24846,
            40126: 24903,
            40127: 24894,
            40128: 24872,
            40129: 24871,
            40130: 24906,
            40131: 24895,
            40132: 24892,
            40133: 24876,
            40134: 24884,
            40135: 24893,
            40136: 24898,
            40137: 24900,
            40138: 24947,
            40139: 24951,
            40140: 24920,
            40141: 24921,
            40142: 24922,
            40143: 24939,
            40144: 24948,
            40145: 24943,
            40146: 24933,
            40147: 24945,
            40148: 24927,
            40149: 24925,
            40150: 24915,
            40151: 24949,
            40152: 24985,
            40153: 24982,
            40154: 24967,
            40155: 25004,
            40156: 24980,
            40157: 24986,
            40158: 24970,
            40159: 24977,
            40160: 25003,
            40161: 25006,
            40162: 25036,
            40163: 25034,
            40164: 25033,
            40165: 25079,
            40166: 25032,
            40167: 25027,
            40168: 25030,
            40169: 25018,
            40170: 25035,
            40171: 32633,
            40172: 25037,
            40173: 25062,
            40174: 25059,
            40175: 25078,
            40176: 25082,
            40177: 25076,
            40178: 25087,
            40179: 25085,
            40180: 25084,
            40181: 25086,
            40182: 25088,
            40183: 25096,
            40184: 25097,
            40185: 25101,
            40186: 25100,
            40187: 25108,
            40188: 25115,
            40256: 25118,
            40257: 25121,
            40258: 25130,
            40259: 25134,
            40260: 25136,
            40261: 25138,
            40262: 25139,
            40263: 25153,
            40264: 25166,
            40265: 25182,
            40266: 25187,
            40267: 25179,
            40268: 25184,
            40269: 25192,
            40270: 25212,
            40271: 25218,
            40272: 25225,
            40273: 25214,
            40274: 25234,
            40275: 25235,
            40276: 25238,
            40277: 25300,
            40278: 25219,
            40279: 25236,
            40280: 25303,
            40281: 25297,
            40282: 25275,
            40283: 25295,
            40284: 25343,
            40285: 25286,
            40286: 25812,
            40287: 25288,
            40288: 25308,
            40289: 25292,
            40290: 25290,
            40291: 25282,
            40292: 25287,
            40293: 25243,
            40294: 25289,
            40295: 25356,
            40296: 25326,
            40297: 25329,
            40298: 25383,
            40299: 25346,
            40300: 25352,
            40301: 25327,
            40302: 25333,
            40303: 25424,
            40304: 25406,
            40305: 25421,
            40306: 25628,
            40307: 25423,
            40308: 25494,
            40309: 25486,
            40310: 25472,
            40311: 25515,
            40312: 25462,
            40313: 25507,
            40314: 25487,
            40315: 25481,
            40316: 25503,
            40317: 25525,
            40318: 25451,
            40320: 25449,
            40321: 25534,
            40322: 25577,
            40323: 25536,
            40324: 25542,
            40325: 25571,
            40326: 25545,
            40327: 25554,
            40328: 25590,
            40329: 25540,
            40330: 25622,
            40331: 25652,
            40332: 25606,
            40333: 25619,
            40334: 25638,
            40335: 25654,
            40336: 25885,
            40337: 25623,
            40338: 25640,
            40339: 25615,
            40340: 25703,
            40341: 25711,
            40342: 25718,
            40343: 25678,
            40344: 25898,
            40345: 25749,
            40346: 25747,
            40347: 25765,
            40348: 25769,
            40349: 25736,
            40350: 25788,
            40351: 25818,
            40352: 25810,
            40353: 25797,
            40354: 25799,
            40355: 25787,
            40356: 25816,
            40357: 25794,
            40358: 25841,
            40359: 25831,
            40360: 33289,
            40361: 25824,
            40362: 25825,
            40363: 25260,
            40364: 25827,
            40365: 25839,
            40366: 25900,
            40367: 25846,
            40368: 25844,
            40369: 25842,
            40370: 25850,
            40371: 25856,
            40372: 25853,
            40373: 25880,
            40374: 25884,
            40375: 25861,
            40376: 25892,
            40377: 25891,
            40378: 25899,
            40379: 25908,
            40380: 25909,
            40381: 25911,
            40382: 25910,
            40383: 25912,
            40384: 30027,
            40385: 25928,
            40386: 25942,
            40387: 25941,
            40388: 25933,
            40389: 25944,
            40390: 25950,
            40391: 25949,
            40392: 25970,
            40393: 25976,
            40394: 25986,
            40395: 25987,
            40396: 35722,
            40397: 26011,
            40398: 26015,
            40399: 26027,
            40400: 26039,
            40401: 26051,
            40402: 26054,
            40403: 26049,
            40404: 26052,
            40405: 26060,
            40406: 26066,
            40407: 26075,
            40408: 26073,
            40409: 26080,
            40410: 26081,
            40411: 26097,
            40412: 26482,
            40413: 26122,
            40414: 26115,
            40415: 26107,
            40416: 26483,
            40417: 26165,
            40418: 26166,
            40419: 26164,
            40420: 26140,
            40421: 26191,
            40422: 26180,
            40423: 26185,
            40424: 26177,
            40425: 26206,
            40426: 26205,
            40427: 26212,
            40428: 26215,
            40429: 26216,
            40430: 26207,
            40431: 26210,
            40432: 26224,
            40433: 26243,
            40434: 26248,
            40435: 26254,
            40436: 26249,
            40437: 26244,
            40438: 26264,
            40439: 26269,
            40440: 26305,
            40441: 26297,
            40442: 26313,
            40443: 26302,
            40444: 26300,
            40512: 26308,
            40513: 26296,
            40514: 26326,
            40515: 26330,
            40516: 26336,
            40517: 26175,
            40518: 26342,
            40519: 26345,
            40520: 26352,
            40521: 26357,
            40522: 26359,
            40523: 26383,
            40524: 26390,
            40525: 26398,
            40526: 26406,
            40527: 26407,
            40528: 38712,
            40529: 26414,
            40530: 26431,
            40531: 26422,
            40532: 26433,
            40533: 26424,
            40534: 26423,
            40535: 26438,
            40536: 26462,
            40537: 26464,
            40538: 26457,
            40539: 26467,
            40540: 26468,
            40541: 26505,
            40542: 26480,
            40543: 26537,
            40544: 26492,
            40545: 26474,
            40546: 26508,
            40547: 26507,
            40548: 26534,
            40549: 26529,
            40550: 26501,
            40551: 26551,
            40552: 26607,
            40553: 26548,
            40554: 26604,
            40555: 26547,
            40556: 26601,
            40557: 26552,
            40558: 26596,
            40559: 26590,
            40560: 26589,
            40561: 26594,
            40562: 26606,
            40563: 26553,
            40564: 26574,
            40565: 26566,
            40566: 26599,
            40567: 27292,
            40568: 26654,
            40569: 26694,
            40570: 26665,
            40571: 26688,
            40572: 26701,
            40573: 26674,
            40574: 26702,
            40576: 26803,
            40577: 26667,
            40578: 26713,
            40579: 26723,
            40580: 26743,
            40581: 26751,
            40582: 26783,
            40583: 26767,
            40584: 26797,
            40585: 26772,
            40586: 26781,
            40587: 26779,
            40588: 26755,
            40589: 27310,
            40590: 26809,
            40591: 26740,
            40592: 26805,
            40593: 26784,
            40594: 26810,
            40595: 26895,
            40596: 26765,
            40597: 26750,
            40598: 26881,
            40599: 26826,
            40600: 26888,
            40601: 26840,
            40602: 26914,
            40603: 26918,
            40604: 26849,
            40605: 26892,
            40606: 26829,
            40607: 26836,
            40608: 26855,
            40609: 26837,
            40610: 26934,
            40611: 26898,
            40612: 26884,
            40613: 26839,
            40614: 26851,
            40615: 26917,
            40616: 26873,
            40617: 26848,
            40618: 26863,
            40619: 26920,
            40620: 26922,
            40621: 26906,
            40622: 26915,
            40623: 26913,
            40624: 26822,
            40625: 27001,
            40626: 26999,
            40627: 26972,
            40628: 27e3,
            40629: 26987,
            40630: 26964,
            40631: 27006,
            40632: 26990,
            40633: 26937,
            40634: 26996,
            40635: 26941,
            40636: 26969,
            40637: 26928,
            40638: 26977,
            40639: 26974,
            40640: 26973,
            40641: 27009,
            40642: 26986,
            40643: 27058,
            40644: 27054,
            40645: 27088,
            40646: 27071,
            40647: 27073,
            40648: 27091,
            40649: 27070,
            40650: 27086,
            40651: 23528,
            40652: 27082,
            40653: 27101,
            40654: 27067,
            40655: 27075,
            40656: 27047,
            40657: 27182,
            40658: 27025,
            40659: 27040,
            40660: 27036,
            40661: 27029,
            40662: 27060,
            40663: 27102,
            40664: 27112,
            40665: 27138,
            40666: 27163,
            40667: 27135,
            40668: 27402,
            40669: 27129,
            40670: 27122,
            40671: 27111,
            40672: 27141,
            40673: 27057,
            40674: 27166,
            40675: 27117,
            40676: 27156,
            40677: 27115,
            40678: 27146,
            40679: 27154,
            40680: 27329,
            40681: 27171,
            40682: 27155,
            40683: 27204,
            40684: 27148,
            40685: 27250,
            40686: 27190,
            40687: 27256,
            40688: 27207,
            40689: 27234,
            40690: 27225,
            40691: 27238,
            40692: 27208,
            40693: 27192,
            40694: 27170,
            40695: 27280,
            40696: 27277,
            40697: 27296,
            40698: 27268,
            40699: 27298,
            40700: 27299,
            40768: 27287,
            40769: 34327,
            40770: 27323,
            40771: 27331,
            40772: 27330,
            40773: 27320,
            40774: 27315,
            40775: 27308,
            40776: 27358,
            40777: 27345,
            40778: 27359,
            40779: 27306,
            40780: 27354,
            40781: 27370,
            40782: 27387,
            40783: 27397,
            40784: 34326,
            40785: 27386,
            40786: 27410,
            40787: 27414,
            40788: 39729,
            40789: 27423,
            40790: 27448,
            40791: 27447,
            40792: 30428,
            40793: 27449,
            40794: 39150,
            40795: 27463,
            40796: 27459,
            40797: 27465,
            40798: 27472,
            40799: 27481,
            40800: 27476,
            40801: 27483,
            40802: 27487,
            40803: 27489,
            40804: 27512,
            40805: 27513,
            40806: 27519,
            40807: 27520,
            40808: 27524,
            40809: 27523,
            40810: 27533,
            40811: 27544,
            40812: 27541,
            40813: 27550,
            40814: 27556,
            40815: 27562,
            40816: 27563,
            40817: 27567,
            40818: 27570,
            40819: 27569,
            40820: 27571,
            40821: 27575,
            40822: 27580,
            40823: 27590,
            40824: 27595,
            40825: 27603,
            40826: 27615,
            40827: 27628,
            40828: 27627,
            40829: 27635,
            40830: 27631,
            40832: 40638,
            40833: 27656,
            40834: 27667,
            40835: 27668,
            40836: 27675,
            40837: 27684,
            40838: 27683,
            40839: 27742,
            40840: 27733,
            40841: 27746,
            40842: 27754,
            40843: 27778,
            40844: 27789,
            40845: 27802,
            40846: 27777,
            40847: 27803,
            40848: 27774,
            40849: 27752,
            40850: 27763,
            40851: 27794,
            40852: 27792,
            40853: 27844,
            40854: 27889,
            40855: 27859,
            40856: 27837,
            40857: 27863,
            40858: 27845,
            40859: 27869,
            40860: 27822,
            40861: 27825,
            40862: 27838,
            40863: 27834,
            40864: 27867,
            40865: 27887,
            40866: 27865,
            40867: 27882,
            40868: 27935,
            40869: 34893,
            40870: 27958,
            40871: 27947,
            40872: 27965,
            40873: 27960,
            40874: 27929,
            40875: 27957,
            40876: 27955,
            40877: 27922,
            40878: 27916,
            40879: 28003,
            40880: 28051,
            40881: 28004,
            40882: 27994,
            40883: 28025,
            40884: 27993,
            40885: 28046,
            40886: 28053,
            40887: 28644,
            40888: 28037,
            40889: 28153,
            40890: 28181,
            40891: 28170,
            40892: 28085,
            40893: 28103,
            40894: 28134,
            40895: 28088,
            40896: 28102,
            40897: 28140,
            40898: 28126,
            40899: 28108,
            40900: 28136,
            40901: 28114,
            40902: 28101,
            40903: 28154,
            40904: 28121,
            40905: 28132,
            40906: 28117,
            40907: 28138,
            40908: 28142,
            40909: 28205,
            40910: 28270,
            40911: 28206,
            40912: 28185,
            40913: 28274,
            40914: 28255,
            40915: 28222,
            40916: 28195,
            40917: 28267,
            40918: 28203,
            40919: 28278,
            40920: 28237,
            40921: 28191,
            40922: 28227,
            40923: 28218,
            40924: 28238,
            40925: 28196,
            40926: 28415,
            40927: 28189,
            40928: 28216,
            40929: 28290,
            40930: 28330,
            40931: 28312,
            40932: 28361,
            40933: 28343,
            40934: 28371,
            40935: 28349,
            40936: 28335,
            40937: 28356,
            40938: 28338,
            40939: 28372,
            40940: 28373,
            40941: 28303,
            40942: 28325,
            40943: 28354,
            40944: 28319,
            40945: 28481,
            40946: 28433,
            40947: 28748,
            40948: 28396,
            40949: 28408,
            40950: 28414,
            40951: 28479,
            40952: 28402,
            40953: 28465,
            40954: 28399,
            40955: 28466,
            40956: 28364,
            161: 65377,
            162: 65378,
            163: 65379,
            164: 65380,
            165: 65381,
            166: 65382,
            167: 65383,
            168: 65384,
            169: 65385,
            170: 65386,
            171: 65387,
            172: 65388,
            173: 65389,
            174: 65390,
            175: 65391,
            176: 65392,
            177: 65393,
            178: 65394,
            179: 65395,
            180: 65396,
            181: 65397,
            182: 65398,
            183: 65399,
            184: 65400,
            185: 65401,
            186: 65402,
            187: 65403,
            188: 65404,
            189: 65405,
            190: 65406,
            191: 65407,
            192: 65408,
            193: 65409,
            194: 65410,
            195: 65411,
            196: 65412,
            197: 65413,
            198: 65414,
            199: 65415,
            200: 65416,
            201: 65417,
            202: 65418,
            203: 65419,
            204: 65420,
            205: 65421,
            206: 65422,
            207: 65423,
            208: 65424,
            209: 65425,
            210: 65426,
            211: 65427,
            212: 65428,
            213: 65429,
            214: 65430,
            215: 65431,
            216: 65432,
            217: 65433,
            218: 65434,
            219: 65435,
            220: 65436,
            221: 65437,
            222: 65438,
            223: 65439,
            57408: 28478,
            57409: 28435,
            57410: 28407,
            57411: 28550,
            57412: 28538,
            57413: 28536,
            57414: 28545,
            57415: 28544,
            57416: 28527,
            57417: 28507,
            57418: 28659,
            57419: 28525,
            57420: 28546,
            57421: 28540,
            57422: 28504,
            57423: 28558,
            57424: 28561,
            57425: 28610,
            57426: 28518,
            57427: 28595,
            57428: 28579,
            57429: 28577,
            57430: 28580,
            57431: 28601,
            57432: 28614,
            57433: 28586,
            57434: 28639,
            57435: 28629,
            57436: 28652,
            57437: 28628,
            57438: 28632,
            57439: 28657,
            57440: 28654,
            57441: 28635,
            57442: 28681,
            57443: 28683,
            57444: 28666,
            57445: 28689,
            57446: 28673,
            57447: 28687,
            57448: 28670,
            57449: 28699,
            57450: 28698,
            57451: 28532,
            57452: 28701,
            57453: 28696,
            57454: 28703,
            57455: 28720,
            57456: 28734,
            57457: 28722,
            57458: 28753,
            57459: 28771,
            57460: 28825,
            57461: 28818,
            57462: 28847,
            57463: 28913,
            57464: 28844,
            57465: 28856,
            57466: 28851,
            57467: 28846,
            57468: 28895,
            57469: 28875,
            57470: 28893,
            57472: 28889,
            57473: 28937,
            57474: 28925,
            57475: 28956,
            57476: 28953,
            57477: 29029,
            57478: 29013,
            57479: 29064,
            57480: 29030,
            57481: 29026,
            57482: 29004,
            57483: 29014,
            57484: 29036,
            57485: 29071,
            57486: 29179,
            57487: 29060,
            57488: 29077,
            57489: 29096,
            57490: 29100,
            57491: 29143,
            57492: 29113,
            57493: 29118,
            57494: 29138,
            57495: 29129,
            57496: 29140,
            57497: 29134,
            57498: 29152,
            57499: 29164,
            57500: 29159,
            57501: 29173,
            57502: 29180,
            57503: 29177,
            57504: 29183,
            57505: 29197,
            57506: 29200,
            57507: 29211,
            57508: 29224,
            57509: 29229,
            57510: 29228,
            57511: 29232,
            57512: 29234,
            57513: 29243,
            57514: 29244,
            57515: 29247,
            57516: 29248,
            57517: 29254,
            57518: 29259,
            57519: 29272,
            57520: 29300,
            57521: 29310,
            57522: 29314,
            57523: 29313,
            57524: 29319,
            57525: 29330,
            57526: 29334,
            57527: 29346,
            57528: 29351,
            57529: 29369,
            57530: 29362,
            57531: 29379,
            57532: 29382,
            57533: 29380,
            57534: 29390,
            57535: 29394,
            57536: 29410,
            57537: 29408,
            57538: 29409,
            57539: 29433,
            57540: 29431,
            57541: 20495,
            57542: 29463,
            57543: 29450,
            57544: 29468,
            57545: 29462,
            57546: 29469,
            57547: 29492,
            57548: 29487,
            57549: 29481,
            57550: 29477,
            57551: 29502,
            57552: 29518,
            57553: 29519,
            57554: 40664,
            57555: 29527,
            57556: 29546,
            57557: 29544,
            57558: 29552,
            57559: 29560,
            57560: 29557,
            57561: 29563,
            57562: 29562,
            57563: 29640,
            57564: 29619,
            57565: 29646,
            57566: 29627,
            57567: 29632,
            57568: 29669,
            57569: 29678,
            57570: 29662,
            57571: 29858,
            57572: 29701,
            57573: 29807,
            57574: 29733,
            57575: 29688,
            57576: 29746,
            57577: 29754,
            57578: 29781,
            57579: 29759,
            57580: 29791,
            57581: 29785,
            57582: 29761,
            57583: 29788,
            57584: 29801,
            57585: 29808,
            57586: 29795,
            57587: 29802,
            57588: 29814,
            57589: 29822,
            57590: 29835,
            57591: 29854,
            57592: 29863,
            57593: 29898,
            57594: 29903,
            57595: 29908,
            57596: 29681,
            57664: 29920,
            57665: 29923,
            57666: 29927,
            57667: 29929,
            57668: 29934,
            57669: 29938,
            57670: 29936,
            57671: 29937,
            57672: 29944,
            57673: 29943,
            57674: 29956,
            57675: 29955,
            57676: 29957,
            57677: 29964,
            57678: 29966,
            57679: 29965,
            57680: 29973,
            57681: 29971,
            57682: 29982,
            57683: 29990,
            57684: 29996,
            57685: 30012,
            57686: 30020,
            57687: 30029,
            57688: 30026,
            57689: 30025,
            57690: 30043,
            57691: 30022,
            57692: 30042,
            57693: 30057,
            57694: 30052,
            57695: 30055,
            57696: 30059,
            57697: 30061,
            57698: 30072,
            57699: 30070,
            57700: 30086,
            57701: 30087,
            57702: 30068,
            57703: 30090,
            57704: 30089,
            57705: 30082,
            57706: 30100,
            57707: 30106,
            57708: 30109,
            57709: 30117,
            57710: 30115,
            57711: 30146,
            57712: 30131,
            57713: 30147,
            57714: 30133,
            57715: 30141,
            57716: 30136,
            57717: 30140,
            57718: 30129,
            57719: 30157,
            57720: 30154,
            57721: 30162,
            57722: 30169,
            57723: 30179,
            57724: 30174,
            57725: 30206,
            57726: 30207,
            57728: 30204,
            57729: 30209,
            57730: 30192,
            57731: 30202,
            57732: 30194,
            57733: 30195,
            57734: 30219,
            57735: 30221,
            57736: 30217,
            57737: 30239,
            57738: 30247,
            57739: 30240,
            57740: 30241,
            57741: 30242,
            57742: 30244,
            57743: 30260,
            57744: 30256,
            57745: 30267,
            57746: 30279,
            57747: 30280,
            57748: 30278,
            57749: 30300,
            57750: 30296,
            57751: 30305,
            57752: 30306,
            57753: 30312,
            57754: 30313,
            57755: 30314,
            57756: 30311,
            57757: 30316,
            57758: 30320,
            57759: 30322,
            57760: 30326,
            57761: 30328,
            57762: 30332,
            57763: 30336,
            57764: 30339,
            57765: 30344,
            57766: 30347,
            57767: 30350,
            57768: 30358,
            57769: 30355,
            57770: 30361,
            57771: 30362,
            57772: 30384,
            57773: 30388,
            57774: 30392,
            57775: 30393,
            57776: 30394,
            57777: 30402,
            57778: 30413,
            57779: 30422,
            57780: 30418,
            57781: 30430,
            57782: 30433,
            57783: 30437,
            57784: 30439,
            57785: 30442,
            57786: 34351,
            57787: 30459,
            57788: 30472,
            57789: 30471,
            57790: 30468,
            57791: 30505,
            57792: 30500,
            57793: 30494,
            57794: 30501,
            57795: 30502,
            57796: 30491,
            57797: 30519,
            57798: 30520,
            57799: 30535,
            57800: 30554,
            57801: 30568,
            57802: 30571,
            57803: 30555,
            57804: 30565,
            57805: 30591,
            57806: 30590,
            57807: 30585,
            57808: 30606,
            57809: 30603,
            57810: 30609,
            57811: 30624,
            57812: 30622,
            57813: 30640,
            57814: 30646,
            57815: 30649,
            57816: 30655,
            57817: 30652,
            57818: 30653,
            57819: 30651,
            57820: 30663,
            57821: 30669,
            57822: 30679,
            57823: 30682,
            57824: 30684,
            57825: 30691,
            57826: 30702,
            57827: 30716,
            57828: 30732,
            57829: 30738,
            57830: 31014,
            57831: 30752,
            57832: 31018,
            57833: 30789,
            57834: 30862,
            57835: 30836,
            57836: 30854,
            57837: 30844,
            57838: 30874,
            57839: 30860,
            57840: 30883,
            57841: 30901,
            57842: 30890,
            57843: 30895,
            57844: 30929,
            57845: 30918,
            57846: 30923,
            57847: 30932,
            57848: 30910,
            57849: 30908,
            57850: 30917,
            57851: 30922,
            57852: 30956,
            57920: 30951,
            57921: 30938,
            57922: 30973,
            57923: 30964,
            57924: 30983,
            57925: 30994,
            57926: 30993,
            57927: 31001,
            57928: 31020,
            57929: 31019,
            57930: 31040,
            57931: 31072,
            57932: 31063,
            57933: 31071,
            57934: 31066,
            57935: 31061,
            57936: 31059,
            57937: 31098,
            57938: 31103,
            57939: 31114,
            57940: 31133,
            57941: 31143,
            57942: 40779,
            57943: 31146,
            57944: 31150,
            57945: 31155,
            57946: 31161,
            57947: 31162,
            57948: 31177,
            57949: 31189,
            57950: 31207,
            57951: 31212,
            57952: 31201,
            57953: 31203,
            57954: 31240,
            57955: 31245,
            57956: 31256,
            57957: 31257,
            57958: 31264,
            57959: 31263,
            57960: 31104,
            57961: 31281,
            57962: 31291,
            57963: 31294,
            57964: 31287,
            57965: 31299,
            57966: 31319,
            57967: 31305,
            57968: 31329,
            57969: 31330,
            57970: 31337,
            57971: 40861,
            57972: 31344,
            57973: 31353,
            57974: 31357,
            57975: 31368,
            57976: 31383,
            57977: 31381,
            57978: 31384,
            57979: 31382,
            57980: 31401,
            57981: 31432,
            57982: 31408,
            57984: 31414,
            57985: 31429,
            57986: 31428,
            57987: 31423,
            57988: 36995,
            57989: 31431,
            57990: 31434,
            57991: 31437,
            57992: 31439,
            57993: 31445,
            57994: 31443,
            57995: 31449,
            57996: 31450,
            57997: 31453,
            57998: 31457,
            57999: 31458,
            58e3: 31462,
            58001: 31469,
            58002: 31472,
            58003: 31490,
            58004: 31503,
            58005: 31498,
            58006: 31494,
            58007: 31539,
            58008: 31512,
            58009: 31513,
            58010: 31518,
            58011: 31541,
            58012: 31528,
            58013: 31542,
            58014: 31568,
            58015: 31610,
            58016: 31492,
            58017: 31565,
            58018: 31499,
            58019: 31564,
            58020: 31557,
            58021: 31605,
            58022: 31589,
            58023: 31604,
            58024: 31591,
            58025: 31600,
            58026: 31601,
            58027: 31596,
            58028: 31598,
            58029: 31645,
            58030: 31640,
            58031: 31647,
            58032: 31629,
            58033: 31644,
            58034: 31642,
            58035: 31627,
            58036: 31634,
            58037: 31631,
            58038: 31581,
            58039: 31641,
            58040: 31691,
            58041: 31681,
            58042: 31692,
            58043: 31695,
            58044: 31668,
            58045: 31686,
            58046: 31709,
            58047: 31721,
            58048: 31761,
            58049: 31764,
            58050: 31718,
            58051: 31717,
            58052: 31840,
            58053: 31744,
            58054: 31751,
            58055: 31763,
            58056: 31731,
            58057: 31735,
            58058: 31767,
            58059: 31757,
            58060: 31734,
            58061: 31779,
            58062: 31783,
            58063: 31786,
            58064: 31775,
            58065: 31799,
            58066: 31787,
            58067: 31805,
            58068: 31820,
            58069: 31811,
            58070: 31828,
            58071: 31823,
            58072: 31808,
            58073: 31824,
            58074: 31832,
            58075: 31839,
            58076: 31844,
            58077: 31830,
            58078: 31845,
            58079: 31852,
            58080: 31861,
            58081: 31875,
            58082: 31888,
            58083: 31908,
            58084: 31917,
            58085: 31906,
            58086: 31915,
            58087: 31905,
            58088: 31912,
            58089: 31923,
            58090: 31922,
            58091: 31921,
            58092: 31918,
            58093: 31929,
            58094: 31933,
            58095: 31936,
            58096: 31941,
            58097: 31938,
            58098: 31960,
            58099: 31954,
            58100: 31964,
            58101: 31970,
            58102: 39739,
            58103: 31983,
            58104: 31986,
            58105: 31988,
            58106: 31990,
            58107: 31994,
            58108: 32006,
            58176: 32002,
            58177: 32028,
            58178: 32021,
            58179: 32010,
            58180: 32069,
            58181: 32075,
            58182: 32046,
            58183: 32050,
            58184: 32063,
            58185: 32053,
            58186: 32070,
            58187: 32115,
            58188: 32086,
            58189: 32078,
            58190: 32114,
            58191: 32104,
            58192: 32110,
            58193: 32079,
            58194: 32099,
            58195: 32147,
            58196: 32137,
            58197: 32091,
            58198: 32143,
            58199: 32125,
            58200: 32155,
            58201: 32186,
            58202: 32174,
            58203: 32163,
            58204: 32181,
            58205: 32199,
            58206: 32189,
            58207: 32171,
            58208: 32317,
            58209: 32162,
            58210: 32175,
            58211: 32220,
            58212: 32184,
            58213: 32159,
            58214: 32176,
            58215: 32216,
            58216: 32221,
            58217: 32228,
            58218: 32222,
            58219: 32251,
            58220: 32242,
            58221: 32225,
            58222: 32261,
            58223: 32266,
            58224: 32291,
            58225: 32289,
            58226: 32274,
            58227: 32305,
            58228: 32287,
            58229: 32265,
            58230: 32267,
            58231: 32290,
            58232: 32326,
            58233: 32358,
            58234: 32315,
            58235: 32309,
            58236: 32313,
            58237: 32323,
            58238: 32311,
            58240: 32306,
            58241: 32314,
            58242: 32359,
            58243: 32349,
            58244: 32342,
            58245: 32350,
            58246: 32345,
            58247: 32346,
            58248: 32377,
            58249: 32362,
            58250: 32361,
            58251: 32380,
            58252: 32379,
            58253: 32387,
            58254: 32213,
            58255: 32381,
            58256: 36782,
            58257: 32383,
            58258: 32392,
            58259: 32393,
            58260: 32396,
            58261: 32402,
            58262: 32400,
            58263: 32403,
            58264: 32404,
            58265: 32406,
            58266: 32398,
            58267: 32411,
            58268: 32412,
            58269: 32568,
            58270: 32570,
            58271: 32581,
            58272: 32588,
            58273: 32589,
            58274: 32590,
            58275: 32592,
            58276: 32593,
            58277: 32597,
            58278: 32596,
            58279: 32600,
            58280: 32607,
            58281: 32608,
            58282: 32616,
            58283: 32617,
            58284: 32615,
            58285: 32632,
            58286: 32642,
            58287: 32646,
            58288: 32643,
            58289: 32648,
            58290: 32647,
            58291: 32652,
            58292: 32660,
            58293: 32670,
            58294: 32669,
            58295: 32666,
            58296: 32675,
            58297: 32687,
            58298: 32690,
            58299: 32697,
            58300: 32686,
            58301: 32694,
            58302: 32696,
            58303: 35697,
            58304: 32709,
            58305: 32710,
            58306: 32714,
            58307: 32725,
            58308: 32724,
            58309: 32737,
            58310: 32742,
            58311: 32745,
            58312: 32755,
            58313: 32761,
            58314: 39132,
            58315: 32774,
            58316: 32772,
            58317: 32779,
            58318: 32786,
            58319: 32792,
            58320: 32793,
            58321: 32796,
            58322: 32801,
            58323: 32808,
            58324: 32831,
            58325: 32827,
            58326: 32842,
            58327: 32838,
            58328: 32850,
            58329: 32856,
            58330: 32858,
            58331: 32863,
            58332: 32866,
            58333: 32872,
            58334: 32883,
            58335: 32882,
            58336: 32880,
            58337: 32886,
            58338: 32889,
            58339: 32893,
            58340: 32895,
            58341: 32900,
            58342: 32902,
            58343: 32901,
            58344: 32923,
            58345: 32915,
            58346: 32922,
            58347: 32941,
            58348: 20880,
            58349: 32940,
            58350: 32987,
            58351: 32997,
            58352: 32985,
            58353: 32989,
            58354: 32964,
            58355: 32986,
            58356: 32982,
            58357: 33033,
            58358: 33007,
            58359: 33009,
            58360: 33051,
            58361: 33065,
            58362: 33059,
            58363: 33071,
            58364: 33099,
            58432: 38539,
            58433: 33094,
            58434: 33086,
            58435: 33107,
            58436: 33105,
            58437: 33020,
            58438: 33137,
            58439: 33134,
            58440: 33125,
            58441: 33126,
            58442: 33140,
            58443: 33155,
            58444: 33160,
            58445: 33162,
            58446: 33152,
            58447: 33154,
            58448: 33184,
            58449: 33173,
            58450: 33188,
            58451: 33187,
            58452: 33119,
            58453: 33171,
            58454: 33193,
            58455: 33200,
            58456: 33205,
            58457: 33214,
            58458: 33208,
            58459: 33213,
            58460: 33216,
            58461: 33218,
            58462: 33210,
            58463: 33225,
            58464: 33229,
            58465: 33233,
            58466: 33241,
            58467: 33240,
            58468: 33224,
            58469: 33242,
            58470: 33247,
            58471: 33248,
            58472: 33255,
            58473: 33274,
            58474: 33275,
            58475: 33278,
            58476: 33281,
            58477: 33282,
            58478: 33285,
            58479: 33287,
            58480: 33290,
            58481: 33293,
            58482: 33296,
            58483: 33302,
            58484: 33321,
            58485: 33323,
            58486: 33336,
            58487: 33331,
            58488: 33344,
            58489: 33369,
            58490: 33368,
            58491: 33373,
            58492: 33370,
            58493: 33375,
            58494: 33380,
            58496: 33378,
            58497: 33384,
            58498: 33386,
            58499: 33387,
            58500: 33326,
            58501: 33393,
            58502: 33399,
            58503: 33400,
            58504: 33406,
            58505: 33421,
            58506: 33426,
            58507: 33451,
            58508: 33439,
            58509: 33467,
            58510: 33452,
            58511: 33505,
            58512: 33507,
            58513: 33503,
            58514: 33490,
            58515: 33524,
            58516: 33523,
            58517: 33530,
            58518: 33683,
            58519: 33539,
            58520: 33531,
            58521: 33529,
            58522: 33502,
            58523: 33542,
            58524: 33500,
            58525: 33545,
            58526: 33497,
            58527: 33589,
            58528: 33588,
            58529: 33558,
            58530: 33586,
            58531: 33585,
            58532: 33600,
            58533: 33593,
            58534: 33616,
            58535: 33605,
            58536: 33583,
            58537: 33579,
            58538: 33559,
            58539: 33560,
            58540: 33669,
            58541: 33690,
            58542: 33706,
            58543: 33695,
            58544: 33698,
            58545: 33686,
            58546: 33571,
            58547: 33678,
            58548: 33671,
            58549: 33674,
            58550: 33660,
            58551: 33717,
            58552: 33651,
            58553: 33653,
            58554: 33696,
            58555: 33673,
            58556: 33704,
            58557: 33780,
            58558: 33811,
            58559: 33771,
            58560: 33742,
            58561: 33789,
            58562: 33795,
            58563: 33752,
            58564: 33803,
            58565: 33729,
            58566: 33783,
            58567: 33799,
            58568: 33760,
            58569: 33778,
            58570: 33805,
            58571: 33826,
            58572: 33824,
            58573: 33725,
            58574: 33848,
            58575: 34054,
            58576: 33787,
            58577: 33901,
            58578: 33834,
            58579: 33852,
            58580: 34138,
            58581: 33924,
            58582: 33911,
            58583: 33899,
            58584: 33965,
            58585: 33902,
            58586: 33922,
            58587: 33897,
            58588: 33862,
            58589: 33836,
            58590: 33903,
            58591: 33913,
            58592: 33845,
            58593: 33994,
            58594: 33890,
            58595: 33977,
            58596: 33983,
            58597: 33951,
            58598: 34009,
            58599: 33997,
            58600: 33979,
            58601: 34010,
            58602: 34e3,
            58603: 33985,
            58604: 33990,
            58605: 34006,
            58606: 33953,
            58607: 34081,
            58608: 34047,
            58609: 34036,
            58610: 34071,
            58611: 34072,
            58612: 34092,
            58613: 34079,
            58614: 34069,
            58615: 34068,
            58616: 34044,
            58617: 34112,
            58618: 34147,
            58619: 34136,
            58620: 34120,
            58688: 34113,
            58689: 34306,
            58690: 34123,
            58691: 34133,
            58692: 34176,
            58693: 34212,
            58694: 34184,
            58695: 34193,
            58696: 34186,
            58697: 34216,
            58698: 34157,
            58699: 34196,
            58700: 34203,
            58701: 34282,
            58702: 34183,
            58703: 34204,
            58704: 34167,
            58705: 34174,
            58706: 34192,
            58707: 34249,
            58708: 34234,
            58709: 34255,
            58710: 34233,
            58711: 34256,
            58712: 34261,
            58713: 34269,
            58714: 34277,
            58715: 34268,
            58716: 34297,
            58717: 34314,
            58718: 34323,
            58719: 34315,
            58720: 34302,
            58721: 34298,
            58722: 34310,
            58723: 34338,
            58724: 34330,
            58725: 34352,
            58726: 34367,
            58727: 34381,
            58728: 20053,
            58729: 34388,
            58730: 34399,
            58731: 34407,
            58732: 34417,
            58733: 34451,
            58734: 34467,
            58735: 34473,
            58736: 34474,
            58737: 34443,
            58738: 34444,
            58739: 34486,
            58740: 34479,
            58741: 34500,
            58742: 34502,
            58743: 34480,
            58744: 34505,
            58745: 34851,
            58746: 34475,
            58747: 34516,
            58748: 34526,
            58749: 34537,
            58750: 34540,
            58752: 34527,
            58753: 34523,
            58754: 34543,
            58755: 34578,
            58756: 34566,
            58757: 34568,
            58758: 34560,
            58759: 34563,
            58760: 34555,
            58761: 34577,
            58762: 34569,
            58763: 34573,
            58764: 34553,
            58765: 34570,
            58766: 34612,
            58767: 34623,
            58768: 34615,
            58769: 34619,
            58770: 34597,
            58771: 34601,
            58772: 34586,
            58773: 34656,
            58774: 34655,
            58775: 34680,
            58776: 34636,
            58777: 34638,
            58778: 34676,
            58779: 34647,
            58780: 34664,
            58781: 34670,
            58782: 34649,
            58783: 34643,
            58784: 34659,
            58785: 34666,
            58786: 34821,
            58787: 34722,
            58788: 34719,
            58789: 34690,
            58790: 34735,
            58791: 34763,
            58792: 34749,
            58793: 34752,
            58794: 34768,
            58795: 38614,
            58796: 34731,
            58797: 34756,
            58798: 34739,
            58799: 34759,
            58800: 34758,
            58801: 34747,
            58802: 34799,
            58803: 34802,
            58804: 34784,
            58805: 34831,
            58806: 34829,
            58807: 34814,
            58808: 34806,
            58809: 34807,
            58810: 34830,
            58811: 34770,
            58812: 34833,
            58813: 34838,
            58814: 34837,
            58815: 34850,
            58816: 34849,
            58817: 34865,
            58818: 34870,
            58819: 34873,
            58820: 34855,
            58821: 34875,
            58822: 34884,
            58823: 34882,
            58824: 34898,
            58825: 34905,
            58826: 34910,
            58827: 34914,
            58828: 34923,
            58829: 34945,
            58830: 34942,
            58831: 34974,
            58832: 34933,
            58833: 34941,
            58834: 34997,
            58835: 34930,
            58836: 34946,
            58837: 34967,
            58838: 34962,
            58839: 34990,
            58840: 34969,
            58841: 34978,
            58842: 34957,
            58843: 34980,
            58844: 34992,
            58845: 35007,
            58846: 34993,
            58847: 35011,
            58848: 35012,
            58849: 35028,
            58850: 35032,
            58851: 35033,
            58852: 35037,
            58853: 35065,
            58854: 35074,
            58855: 35068,
            58856: 35060,
            58857: 35048,
            58858: 35058,
            58859: 35076,
            58860: 35084,
            58861: 35082,
            58862: 35091,
            58863: 35139,
            58864: 35102,
            58865: 35109,
            58866: 35114,
            58867: 35115,
            58868: 35137,
            58869: 35140,
            58870: 35131,
            58871: 35126,
            58872: 35128,
            58873: 35148,
            58874: 35101,
            58875: 35168,
            58876: 35166,
            58944: 35174,
            58945: 35172,
            58946: 35181,
            58947: 35178,
            58948: 35183,
            58949: 35188,
            58950: 35191,
            58951: 35198,
            58952: 35203,
            58953: 35208,
            58954: 35210,
            58955: 35219,
            58956: 35224,
            58957: 35233,
            58958: 35241,
            58959: 35238,
            58960: 35244,
            58961: 35247,
            58962: 35250,
            58963: 35258,
            58964: 35261,
            58965: 35263,
            58966: 35264,
            58967: 35290,
            58968: 35292,
            58969: 35293,
            58970: 35303,
            58971: 35316,
            58972: 35320,
            58973: 35331,
            58974: 35350,
            58975: 35344,
            58976: 35340,
            58977: 35355,
            58978: 35357,
            58979: 35365,
            58980: 35382,
            58981: 35393,
            58982: 35419,
            58983: 35410,
            58984: 35398,
            58985: 35400,
            58986: 35452,
            58987: 35437,
            58988: 35436,
            58989: 35426,
            58990: 35461,
            58991: 35458,
            58992: 35460,
            58993: 35496,
            58994: 35489,
            58995: 35473,
            58996: 35493,
            58997: 35494,
            58998: 35482,
            58999: 35491,
            59e3: 35524,
            59001: 35533,
            59002: 35522,
            59003: 35546,
            59004: 35563,
            59005: 35571,
            59006: 35559,
            59008: 35556,
            59009: 35569,
            59010: 35604,
            59011: 35552,
            59012: 35554,
            59013: 35575,
            59014: 35550,
            59015: 35547,
            59016: 35596,
            59017: 35591,
            59018: 35610,
            59019: 35553,
            59020: 35606,
            59021: 35600,
            59022: 35607,
            59023: 35616,
            59024: 35635,
            59025: 38827,
            59026: 35622,
            59027: 35627,
            59028: 35646,
            59029: 35624,
            59030: 35649,
            59031: 35660,
            59032: 35663,
            59033: 35662,
            59034: 35657,
            59035: 35670,
            59036: 35675,
            59037: 35674,
            59038: 35691,
            59039: 35679,
            59040: 35692,
            59041: 35695,
            59042: 35700,
            59043: 35709,
            59044: 35712,
            59045: 35724,
            59046: 35726,
            59047: 35730,
            59048: 35731,
            59049: 35734,
            59050: 35737,
            59051: 35738,
            59052: 35898,
            59053: 35905,
            59054: 35903,
            59055: 35912,
            59056: 35916,
            59057: 35918,
            59058: 35920,
            59059: 35925,
            59060: 35938,
            59061: 35948,
            59062: 35960,
            59063: 35962,
            59064: 35970,
            59065: 35977,
            59066: 35973,
            59067: 35978,
            59068: 35981,
            59069: 35982,
            59070: 35988,
            59071: 35964,
            59072: 35992,
            59073: 25117,
            59074: 36013,
            59075: 36010,
            59076: 36029,
            59077: 36018,
            59078: 36019,
            59079: 36014,
            59080: 36022,
            59081: 36040,
            59082: 36033,
            59083: 36068,
            59084: 36067,
            59085: 36058,
            59086: 36093,
            59087: 36090,
            59088: 36091,
            59089: 36100,
            59090: 36101,
            59091: 36106,
            59092: 36103,
            59093: 36111,
            59094: 36109,
            59095: 36112,
            59096: 40782,
            59097: 36115,
            59098: 36045,
            59099: 36116,
            59100: 36118,
            59101: 36199,
            59102: 36205,
            59103: 36209,
            59104: 36211,
            59105: 36225,
            59106: 36249,
            59107: 36290,
            59108: 36286,
            59109: 36282,
            59110: 36303,
            59111: 36314,
            59112: 36310,
            59113: 36300,
            59114: 36315,
            59115: 36299,
            59116: 36330,
            59117: 36331,
            59118: 36319,
            59119: 36323,
            59120: 36348,
            59121: 36360,
            59122: 36361,
            59123: 36351,
            59124: 36381,
            59125: 36382,
            59126: 36368,
            59127: 36383,
            59128: 36418,
            59129: 36405,
            59130: 36400,
            59131: 36404,
            59132: 36426,
            59200: 36423,
            59201: 36425,
            59202: 36428,
            59203: 36432,
            59204: 36424,
            59205: 36441,
            59206: 36452,
            59207: 36448,
            59208: 36394,
            59209: 36451,
            59210: 36437,
            59211: 36470,
            59212: 36466,
            59213: 36476,
            59214: 36481,
            59215: 36487,
            59216: 36485,
            59217: 36484,
            59218: 36491,
            59219: 36490,
            59220: 36499,
            59221: 36497,
            59222: 36500,
            59223: 36505,
            59224: 36522,
            59225: 36513,
            59226: 36524,
            59227: 36528,
            59228: 36550,
            59229: 36529,
            59230: 36542,
            59231: 36549,
            59232: 36552,
            59233: 36555,
            59234: 36571,
            59235: 36579,
            59236: 36604,
            59237: 36603,
            59238: 36587,
            59239: 36606,
            59240: 36618,
            59241: 36613,
            59242: 36629,
            59243: 36626,
            59244: 36633,
            59245: 36627,
            59246: 36636,
            59247: 36639,
            59248: 36635,
            59249: 36620,
            59250: 36646,
            59251: 36659,
            59252: 36667,
            59253: 36665,
            59254: 36677,
            59255: 36674,
            59256: 36670,
            59257: 36684,
            59258: 36681,
            59259: 36678,
            59260: 36686,
            59261: 36695,
            59262: 36700,
            59264: 36706,
            59265: 36707,
            59266: 36708,
            59267: 36764,
            59268: 36767,
            59269: 36771,
            59270: 36781,
            59271: 36783,
            59272: 36791,
            59273: 36826,
            59274: 36837,
            59275: 36834,
            59276: 36842,
            59277: 36847,
            59278: 36999,
            59279: 36852,
            59280: 36869,
            59281: 36857,
            59282: 36858,
            59283: 36881,
            59284: 36885,
            59285: 36897,
            59286: 36877,
            59287: 36894,
            59288: 36886,
            59289: 36875,
            59290: 36903,
            59291: 36918,
            59292: 36917,
            59293: 36921,
            59294: 36856,
            59295: 36943,
            59296: 36944,
            59297: 36945,
            59298: 36946,
            59299: 36878,
            59300: 36937,
            59301: 36926,
            59302: 36950,
            59303: 36952,
            59304: 36958,
            59305: 36968,
            59306: 36975,
            59307: 36982,
            59308: 38568,
            59309: 36978,
            59310: 36994,
            59311: 36989,
            59312: 36993,
            59313: 36992,
            59314: 37002,
            59315: 37001,
            59316: 37007,
            59317: 37032,
            59318: 37039,
            59319: 37041,
            59320: 37045,
            59321: 37090,
            59322: 37092,
            59323: 25160,
            59324: 37083,
            59325: 37122,
            59326: 37138,
            59327: 37145,
            59328: 37170,
            59329: 37168,
            59330: 37194,
            59331: 37206,
            59332: 37208,
            59333: 37219,
            59334: 37221,
            59335: 37225,
            59336: 37235,
            59337: 37234,
            59338: 37259,
            59339: 37257,
            59340: 37250,
            59341: 37282,
            59342: 37291,
            59343: 37295,
            59344: 37290,
            59345: 37301,
            59346: 37300,
            59347: 37306,
            59348: 37312,
            59349: 37313,
            59350: 37321,
            59351: 37323,
            59352: 37328,
            59353: 37334,
            59354: 37343,
            59355: 37345,
            59356: 37339,
            59357: 37372,
            59358: 37365,
            59359: 37366,
            59360: 37406,
            59361: 37375,
            59362: 37396,
            59363: 37420,
            59364: 37397,
            59365: 37393,
            59366: 37470,
            59367: 37463,
            59368: 37445,
            59369: 37449,
            59370: 37476,
            59371: 37448,
            59372: 37525,
            59373: 37439,
            59374: 37451,
            59375: 37456,
            59376: 37532,
            59377: 37526,
            59378: 37523,
            59379: 37531,
            59380: 37466,
            59381: 37583,
            59382: 37561,
            59383: 37559,
            59384: 37609,
            59385: 37647,
            59386: 37626,
            59387: 37700,
            59388: 37678,
            59456: 37657,
            59457: 37666,
            59458: 37658,
            59459: 37667,
            59460: 37690,
            59461: 37685,
            59462: 37691,
            59463: 37724,
            59464: 37728,
            59465: 37756,
            59466: 37742,
            59467: 37718,
            59468: 37808,
            59469: 37804,
            59470: 37805,
            59471: 37780,
            59472: 37817,
            59473: 37846,
            59474: 37847,
            59475: 37864,
            59476: 37861,
            59477: 37848,
            59478: 37827,
            59479: 37853,
            59480: 37840,
            59481: 37832,
            59482: 37860,
            59483: 37914,
            59484: 37908,
            59485: 37907,
            59486: 37891,
            59487: 37895,
            59488: 37904,
            59489: 37942,
            59490: 37931,
            59491: 37941,
            59492: 37921,
            59493: 37946,
            59494: 37953,
            59495: 37970,
            59496: 37956,
            59497: 37979,
            59498: 37984,
            59499: 37986,
            59500: 37982,
            59501: 37994,
            59502: 37417,
            59503: 38e3,
            59504: 38005,
            59505: 38007,
            59506: 38013,
            59507: 37978,
            59508: 38012,
            59509: 38014,
            59510: 38017,
            59511: 38015,
            59512: 38274,
            59513: 38279,
            59514: 38282,
            59515: 38292,
            59516: 38294,
            59517: 38296,
            59518: 38297,
            59520: 38304,
            59521: 38312,
            59522: 38311,
            59523: 38317,
            59524: 38332,
            59525: 38331,
            59526: 38329,
            59527: 38334,
            59528: 38346,
            59529: 28662,
            59530: 38339,
            59531: 38349,
            59532: 38348,
            59533: 38357,
            59534: 38356,
            59535: 38358,
            59536: 38364,
            59537: 38369,
            59538: 38373,
            59539: 38370,
            59540: 38433,
            59541: 38440,
            59542: 38446,
            59543: 38447,
            59544: 38466,
            59545: 38476,
            59546: 38479,
            59547: 38475,
            59548: 38519,
            59549: 38492,
            59550: 38494,
            59551: 38493,
            59552: 38495,
            59553: 38502,
            59554: 38514,
            59555: 38508,
            59556: 38541,
            59557: 38552,
            59558: 38549,
            59559: 38551,
            59560: 38570,
            59561: 38567,
            59562: 38577,
            59563: 38578,
            59564: 38576,
            59565: 38580,
            59566: 38582,
            59567: 38584,
            59568: 38585,
            59569: 38606,
            59570: 38603,
            59571: 38601,
            59572: 38605,
            59573: 35149,
            59574: 38620,
            59575: 38669,
            59576: 38613,
            59577: 38649,
            59578: 38660,
            59579: 38662,
            59580: 38664,
            59581: 38675,
            59582: 38670,
            59583: 38673,
            59584: 38671,
            59585: 38678,
            59586: 38681,
            59587: 38692,
            59588: 38698,
            59589: 38704,
            59590: 38713,
            59591: 38717,
            59592: 38718,
            59593: 38724,
            59594: 38726,
            59595: 38728,
            59596: 38722,
            59597: 38729,
            59598: 38748,
            59599: 38752,
            59600: 38756,
            59601: 38758,
            59602: 38760,
            59603: 21202,
            59604: 38763,
            59605: 38769,
            59606: 38777,
            59607: 38789,
            59608: 38780,
            59609: 38785,
            59610: 38778,
            59611: 38790,
            59612: 38795,
            59613: 38799,
            59614: 38800,
            59615: 38812,
            59616: 38824,
            59617: 38822,
            59618: 38819,
            59619: 38835,
            59620: 38836,
            59621: 38851,
            59622: 38854,
            59623: 38856,
            59624: 38859,
            59625: 38876,
            59626: 38893,
            59627: 40783,
            59628: 38898,
            59629: 31455,
            59630: 38902,
            59631: 38901,
            59632: 38927,
            59633: 38924,
            59634: 38968,
            59635: 38948,
            59636: 38945,
            59637: 38967,
            59638: 38973,
            59639: 38982,
            59640: 38991,
            59641: 38987,
            59642: 39019,
            59643: 39023,
            59644: 39024,
            59712: 39025,
            59713: 39028,
            59714: 39027,
            59715: 39082,
            59716: 39087,
            59717: 39089,
            59718: 39094,
            59719: 39108,
            59720: 39107,
            59721: 39110,
            59722: 39145,
            59723: 39147,
            59724: 39171,
            59725: 39177,
            59726: 39186,
            59727: 39188,
            59728: 39192,
            59729: 39201,
            59730: 39197,
            59731: 39198,
            59732: 39204,
            59733: 39200,
            59734: 39212,
            59735: 39214,
            59736: 39229,
            59737: 39230,
            59738: 39234,
            59739: 39241,
            59740: 39237,
            59741: 39248,
            59742: 39243,
            59743: 39249,
            59744: 39250,
            59745: 39244,
            59746: 39253,
            59747: 39319,
            59748: 39320,
            59749: 39333,
            59750: 39341,
            59751: 39342,
            59752: 39356,
            59753: 39391,
            59754: 39387,
            59755: 39389,
            59756: 39384,
            59757: 39377,
            59758: 39405,
            59759: 39406,
            59760: 39409,
            59761: 39410,
            59762: 39419,
            59763: 39416,
            59764: 39425,
            59765: 39439,
            59766: 39429,
            59767: 39394,
            59768: 39449,
            59769: 39467,
            59770: 39479,
            59771: 39493,
            59772: 39490,
            59773: 39488,
            59774: 39491,
            59776: 39486,
            59777: 39509,
            59778: 39501,
            59779: 39515,
            59780: 39511,
            59781: 39519,
            59782: 39522,
            59783: 39525,
            59784: 39524,
            59785: 39529,
            59786: 39531,
            59787: 39530,
            59788: 39597,
            59789: 39600,
            59790: 39612,
            59791: 39616,
            59792: 39631,
            59793: 39633,
            59794: 39635,
            59795: 39636,
            59796: 39646,
            59797: 39647,
            59798: 39650,
            59799: 39651,
            59800: 39654,
            59801: 39663,
            59802: 39659,
            59803: 39662,
            59804: 39668,
            59805: 39665,
            59806: 39671,
            59807: 39675,
            59808: 39686,
            59809: 39704,
            59810: 39706,
            59811: 39711,
            59812: 39714,
            59813: 39715,
            59814: 39717,
            59815: 39719,
            59816: 39720,
            59817: 39721,
            59818: 39722,
            59819: 39726,
            59820: 39727,
            59821: 39730,
            59822: 39748,
            59823: 39747,
            59824: 39759,
            59825: 39757,
            59826: 39758,
            59827: 39761,
            59828: 39768,
            59829: 39796,
            59830: 39827,
            59831: 39811,
            59832: 39825,
            59833: 39830,
            59834: 39831,
            59835: 39839,
            59836: 39840,
            59837: 39848,
            59838: 39860,
            59839: 39872,
            59840: 39882,
            59841: 39865,
            59842: 39878,
            59843: 39887,
            59844: 39889,
            59845: 39890,
            59846: 39907,
            59847: 39906,
            59848: 39908,
            59849: 39892,
            59850: 39905,
            59851: 39994,
            59852: 39922,
            59853: 39921,
            59854: 39920,
            59855: 39957,
            59856: 39956,
            59857: 39945,
            59858: 39955,
            59859: 39948,
            59860: 39942,
            59861: 39944,
            59862: 39954,
            59863: 39946,
            59864: 39940,
            59865: 39982,
            59866: 39963,
            59867: 39973,
            59868: 39972,
            59869: 39969,
            59870: 39984,
            59871: 40007,
            59872: 39986,
            59873: 40006,
            59874: 39998,
            59875: 40026,
            59876: 40032,
            59877: 40039,
            59878: 40054,
            59879: 40056,
            59880: 40167,
            59881: 40172,
            59882: 40176,
            59883: 40201,
            59884: 40200,
            59885: 40171,
            59886: 40195,
            59887: 40198,
            59888: 40234,
            59889: 40230,
            59890: 40367,
            59891: 40227,
            59892: 40223,
            59893: 40260,
            59894: 40213,
            59895: 40210,
            59896: 40257,
            59897: 40255,
            59898: 40254,
            59899: 40262,
            59900: 40264,
            59968: 40285,
            59969: 40286,
            59970: 40292,
            59971: 40273,
            59972: 40272,
            59973: 40281,
            59974: 40306,
            59975: 40329,
            59976: 40327,
            59977: 40363,
            59978: 40303,
            59979: 40314,
            59980: 40346,
            59981: 40356,
            59982: 40361,
            59983: 40370,
            59984: 40388,
            59985: 40385,
            59986: 40379,
            59987: 40376,
            59988: 40378,
            59989: 40390,
            59990: 40399,
            59991: 40386,
            59992: 40409,
            59993: 40403,
            59994: 40440,
            59995: 40422,
            59996: 40429,
            59997: 40431,
            59998: 40445,
            59999: 40474,
            6e4: 40475,
            60001: 40478,
            60002: 40565,
            60003: 40569,
            60004: 40573,
            60005: 40577,
            60006: 40584,
            60007: 40587,
            60008: 40588,
            60009: 40594,
            60010: 40597,
            60011: 40593,
            60012: 40605,
            60013: 40613,
            60014: 40617,
            60015: 40632,
            60016: 40618,
            60017: 40621,
            60018: 38753,
            60019: 40652,
            60020: 40654,
            60021: 40655,
            60022: 40656,
            60023: 40660,
            60024: 40668,
            60025: 40670,
            60026: 40669,
            60027: 40672,
            60028: 40677,
            60029: 40680,
            60030: 40687,
            60032: 40692,
            60033: 40694,
            60034: 40695,
            60035: 40697,
            60036: 40699,
            60037: 40700,
            60038: 40701,
            60039: 40711,
            60040: 40712,
            60041: 30391,
            60042: 40725,
            60043: 40737,
            60044: 40748,
            60045: 40766,
            60046: 40778,
            60047: 40786,
            60048: 40788,
            60049: 40803,
            60050: 40799,
            60051: 40800,
            60052: 40801,
            60053: 40806,
            60054: 40807,
            60055: 40812,
            60056: 40810,
            60057: 40823,
            60058: 40818,
            60059: 40822,
            60060: 40853,
            60061: 40860,
            60062: 40864,
            60063: 22575,
            60064: 27079,
            60065: 36953,
            60066: 29796,
            60067: 20956,
            60068: 29081
          };
        },
        /* 9 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = a(1), o = a(2);
          function s(E, C, A, b) {
            var y;
            C.degree() < A.degree() && (y = [A, C], C = y[0], A = y[1]);
            for (var w = C, P = A, k = E.zero, f = E.one; P.degree() >= b / 2; ) {
              var B = w, D = k;
              if (w = P, k = f, w.isZero())
                return null;
              P = B;
              for (var p = E.zero, F = w.getCoefficient(w.degree()), _ = E.inverse(F); P.degree() >= w.degree() && !P.isZero(); ) {
                var M = P.degree() - w.degree(), R = E.multiply(P.getCoefficient(P.degree()), _);
                p = p.addOrSubtract(E.buildMonomial(M, R)), P = P.addOrSubtract(w.multiplyByMonomial(M, R));
              }
              if (f = p.multiplyPoly(k).addOrSubtract(D), P.degree() >= w.degree())
                return null;
            }
            var N = f.getCoefficient(0);
            if (N === 0)
              return null;
            var I = E.inverse(N);
            return [f.multiply(I), P.multiply(I)];
          }
          function i(E, C) {
            var A = C.degree();
            if (A === 1)
              return [C.getCoefficient(1)];
            for (var b = new Array(A), y = 0, w = 1; w < E.size && y < A; w++)
              C.evaluateAt(w) === 0 && (b[y] = E.inverse(w), y++);
            return y !== A ? null : b;
          }
          function m(E, C, A) {
            for (var b = A.length, y = new Array(b), w = 0; w < b; w++) {
              for (var P = E.inverse(A[w]), k = 1, f = 0; f < b; f++)
                w !== f && (k = E.multiply(k, n.addOrSubtractGF(1, E.multiply(A[f], P))));
              y[w] = E.multiply(C.evaluateAt(P), E.inverse(k)), E.generatorBase !== 0 && (y[w] = E.multiply(y[w], P));
            }
            return y;
          }
          function d(E, C) {
            var A = new Uint8ClampedArray(E.length);
            A.set(E);
            for (var b = new n.default(285, 256, 0), y = new o.default(b, A), w = new Uint8ClampedArray(C), P = !1, k = 0; k < C; k++) {
              var f = y.evaluateAt(b.exp(k + b.generatorBase));
              w[w.length - 1 - k] = f, f !== 0 && (P = !0);
            }
            if (!P)
              return A;
            var B = new o.default(b, w), D = s(b, b.buildMonomial(C, 1), B, C);
            if (D === null)
              return null;
            var p = i(b, D[0]);
            if (p == null)
              return null;
            for (var F = m(b, D[1], p), _ = 0; _ < p.length; _++) {
              var M = A.length - 1 - b.log(p[_]);
              if (M < 0)
                return null;
              A[M] = n.addOrSubtractGF(A[M], F[_]);
            }
            return A;
          }
          x.decode = d;
        },
        /* 10 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 }), x.VERSIONS = [
            {
              infoBits: null,
              versionNumber: 1,
              alignmentPatternCenters: [],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 7,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 19 }]
                },
                {
                  ecCodewordsPerBlock: 10,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 16 }]
                },
                {
                  ecCodewordsPerBlock: 13,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 13 }]
                },
                {
                  ecCodewordsPerBlock: 17,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 9 }]
                }
              ]
            },
            {
              infoBits: null,
              versionNumber: 2,
              alignmentPatternCenters: [6, 18],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 10,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 34 }]
                },
                {
                  ecCodewordsPerBlock: 16,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 28 }]
                },
                {
                  ecCodewordsPerBlock: 22,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 22 }]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 16 }]
                }
              ]
            },
            {
              infoBits: null,
              versionNumber: 3,
              alignmentPatternCenters: [6, 22],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 15,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 55 }]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 44 }]
                },
                {
                  ecCodewordsPerBlock: 18,
                  ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 17 }]
                },
                {
                  ecCodewordsPerBlock: 22,
                  ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 13 }]
                }
              ]
            },
            {
              infoBits: null,
              versionNumber: 4,
              alignmentPatternCenters: [6, 26],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 20,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 80 }]
                },
                {
                  ecCodewordsPerBlock: 18,
                  ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 32 }]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 24 }]
                },
                {
                  ecCodewordsPerBlock: 16,
                  ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 9 }]
                }
              ]
            },
            {
              infoBits: null,
              versionNumber: 5,
              alignmentPatternCenters: [6, 30],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 108 }]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 43 }]
                },
                {
                  ecCodewordsPerBlock: 18,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 15 },
                    { numBlocks: 2, dataCodewordsPerBlock: 16 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 22,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 11 },
                    { numBlocks: 2, dataCodewordsPerBlock: 12 }
                  ]
                }
              ]
            },
            {
              infoBits: null,
              versionNumber: 6,
              alignmentPatternCenters: [6, 34],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 18,
                  ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 68 }]
                },
                {
                  ecCodewordsPerBlock: 16,
                  ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 27 }]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 19 }]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 15 }]
                }
              ]
            },
            {
              infoBits: 31892,
              versionNumber: 7,
              alignmentPatternCenters: [6, 22, 38],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 20,
                  ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 78 }]
                },
                {
                  ecCodewordsPerBlock: 18,
                  ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 31 }]
                },
                {
                  ecCodewordsPerBlock: 18,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 14 },
                    { numBlocks: 4, dataCodewordsPerBlock: 15 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 13 },
                    { numBlocks: 1, dataCodewordsPerBlock: 14 }
                  ]
                }
              ]
            },
            {
              infoBits: 34236,
              versionNumber: 8,
              alignmentPatternCenters: [6, 24, 42],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 97 }]
                },
                {
                  ecCodewordsPerBlock: 22,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 38 },
                    { numBlocks: 2, dataCodewordsPerBlock: 39 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 22,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 18 },
                    { numBlocks: 2, dataCodewordsPerBlock: 19 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 14 },
                    { numBlocks: 2, dataCodewordsPerBlock: 15 }
                  ]
                }
              ]
            },
            {
              infoBits: 39577,
              versionNumber: 9,
              alignmentPatternCenters: [6, 26, 46],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 116 }]
                },
                {
                  ecCodewordsPerBlock: 22,
                  ecBlocks: [
                    { numBlocks: 3, dataCodewordsPerBlock: 36 },
                    { numBlocks: 2, dataCodewordsPerBlock: 37 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 20,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 16 },
                    { numBlocks: 4, dataCodewordsPerBlock: 17 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 12 },
                    { numBlocks: 4, dataCodewordsPerBlock: 13 }
                  ]
                }
              ]
            },
            {
              infoBits: 42195,
              versionNumber: 10,
              alignmentPatternCenters: [6, 28, 50],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 18,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 68 },
                    { numBlocks: 2, dataCodewordsPerBlock: 69 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 43 },
                    { numBlocks: 1, dataCodewordsPerBlock: 44 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 6, dataCodewordsPerBlock: 19 },
                    { numBlocks: 2, dataCodewordsPerBlock: 20 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 6, dataCodewordsPerBlock: 15 },
                    { numBlocks: 2, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 48118,
              versionNumber: 11,
              alignmentPatternCenters: [6, 30, 54],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 20,
                  ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 81 }]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 1, dataCodewordsPerBlock: 50 },
                    { numBlocks: 4, dataCodewordsPerBlock: 51 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 22 },
                    { numBlocks: 4, dataCodewordsPerBlock: 23 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 3, dataCodewordsPerBlock: 12 },
                    { numBlocks: 8, dataCodewordsPerBlock: 13 }
                  ]
                }
              ]
            },
            {
              infoBits: 51042,
              versionNumber: 12,
              alignmentPatternCenters: [6, 32, 58],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 92 },
                    { numBlocks: 2, dataCodewordsPerBlock: 93 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 22,
                  ecBlocks: [
                    { numBlocks: 6, dataCodewordsPerBlock: 36 },
                    { numBlocks: 2, dataCodewordsPerBlock: 37 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 20 },
                    { numBlocks: 6, dataCodewordsPerBlock: 21 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 7, dataCodewordsPerBlock: 14 },
                    { numBlocks: 4, dataCodewordsPerBlock: 15 }
                  ]
                }
              ]
            },
            {
              infoBits: 55367,
              versionNumber: 13,
              alignmentPatternCenters: [6, 34, 62],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 107 }]
                },
                {
                  ecCodewordsPerBlock: 22,
                  ecBlocks: [
                    { numBlocks: 8, dataCodewordsPerBlock: 37 },
                    { numBlocks: 1, dataCodewordsPerBlock: 38 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 8, dataCodewordsPerBlock: 20 },
                    { numBlocks: 4, dataCodewordsPerBlock: 21 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 22,
                  ecBlocks: [
                    { numBlocks: 12, dataCodewordsPerBlock: 11 },
                    { numBlocks: 4, dataCodewordsPerBlock: 12 }
                  ]
                }
              ]
            },
            {
              infoBits: 58893,
              versionNumber: 14,
              alignmentPatternCenters: [6, 26, 46, 66],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 3, dataCodewordsPerBlock: 115 },
                    { numBlocks: 1, dataCodewordsPerBlock: 116 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 40 },
                    { numBlocks: 5, dataCodewordsPerBlock: 41 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 20,
                  ecBlocks: [
                    { numBlocks: 11, dataCodewordsPerBlock: 16 },
                    { numBlocks: 5, dataCodewordsPerBlock: 17 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 11, dataCodewordsPerBlock: 12 },
                    { numBlocks: 5, dataCodewordsPerBlock: 13 }
                  ]
                }
              ]
            },
            {
              infoBits: 63784,
              versionNumber: 15,
              alignmentPatternCenters: [6, 26, 48, 70],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 22,
                  ecBlocks: [
                    { numBlocks: 5, dataCodewordsPerBlock: 87 },
                    { numBlocks: 1, dataCodewordsPerBlock: 88 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 5, dataCodewordsPerBlock: 41 },
                    { numBlocks: 5, dataCodewordsPerBlock: 42 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 5, dataCodewordsPerBlock: 24 },
                    { numBlocks: 7, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 11, dataCodewordsPerBlock: 12 },
                    { numBlocks: 7, dataCodewordsPerBlock: 13 }
                  ]
                }
              ]
            },
            {
              infoBits: 68472,
              versionNumber: 16,
              alignmentPatternCenters: [6, 26, 50, 74],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 5, dataCodewordsPerBlock: 98 },
                    { numBlocks: 1, dataCodewordsPerBlock: 99 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 7, dataCodewordsPerBlock: 45 },
                    { numBlocks: 3, dataCodewordsPerBlock: 46 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [
                    { numBlocks: 15, dataCodewordsPerBlock: 19 },
                    { numBlocks: 2, dataCodewordsPerBlock: 20 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 3, dataCodewordsPerBlock: 15 },
                    { numBlocks: 13, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 70749,
              versionNumber: 17,
              alignmentPatternCenters: [6, 30, 54, 78],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 1, dataCodewordsPerBlock: 107 },
                    { numBlocks: 5, dataCodewordsPerBlock: 108 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 10, dataCodewordsPerBlock: 46 },
                    { numBlocks: 1, dataCodewordsPerBlock: 47 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 1, dataCodewordsPerBlock: 22 },
                    { numBlocks: 15, dataCodewordsPerBlock: 23 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 14 },
                    { numBlocks: 17, dataCodewordsPerBlock: 15 }
                  ]
                }
              ]
            },
            {
              infoBits: 76311,
              versionNumber: 18,
              alignmentPatternCenters: [6, 30, 56, 82],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 5, dataCodewordsPerBlock: 120 },
                    { numBlocks: 1, dataCodewordsPerBlock: 121 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [
                    { numBlocks: 9, dataCodewordsPerBlock: 43 },
                    { numBlocks: 4, dataCodewordsPerBlock: 44 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 17, dataCodewordsPerBlock: 22 },
                    { numBlocks: 1, dataCodewordsPerBlock: 23 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 14 },
                    { numBlocks: 19, dataCodewordsPerBlock: 15 }
                  ]
                }
              ]
            },
            {
              infoBits: 79154,
              versionNumber: 19,
              alignmentPatternCenters: [6, 30, 58, 86],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 3, dataCodewordsPerBlock: 113 },
                    { numBlocks: 4, dataCodewordsPerBlock: 114 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [
                    { numBlocks: 3, dataCodewordsPerBlock: 44 },
                    { numBlocks: 11, dataCodewordsPerBlock: 45 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [
                    { numBlocks: 17, dataCodewordsPerBlock: 21 },
                    { numBlocks: 4, dataCodewordsPerBlock: 22 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [
                    { numBlocks: 9, dataCodewordsPerBlock: 13 },
                    { numBlocks: 16, dataCodewordsPerBlock: 14 }
                  ]
                }
              ]
            },
            {
              infoBits: 84390,
              versionNumber: 20,
              alignmentPatternCenters: [6, 34, 62, 90],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 3, dataCodewordsPerBlock: 107 },
                    { numBlocks: 5, dataCodewordsPerBlock: 108 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [
                    { numBlocks: 3, dataCodewordsPerBlock: 41 },
                    { numBlocks: 13, dataCodewordsPerBlock: 42 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 15, dataCodewordsPerBlock: 24 },
                    { numBlocks: 5, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 15, dataCodewordsPerBlock: 15 },
                    { numBlocks: 10, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 87683,
              versionNumber: 21,
              alignmentPatternCenters: [6, 28, 50, 72, 94],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 116 },
                    { numBlocks: 4, dataCodewordsPerBlock: 117 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 42 }]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 17, dataCodewordsPerBlock: 22 },
                    { numBlocks: 6, dataCodewordsPerBlock: 23 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 19, dataCodewordsPerBlock: 16 },
                    { numBlocks: 6, dataCodewordsPerBlock: 17 }
                  ]
                }
              ]
            },
            {
              infoBits: 92361,
              versionNumber: 22,
              alignmentPatternCenters: [6, 26, 50, 74, 98],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 111 },
                    { numBlocks: 7, dataCodewordsPerBlock: 112 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 46 }]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 7, dataCodewordsPerBlock: 24 },
                    { numBlocks: 16, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 24,
                  ecBlocks: [{ numBlocks: 34, dataCodewordsPerBlock: 13 }]
                }
              ]
            },
            {
              infoBits: 96236,
              versionNumber: 23,
              alignmentPatternCenters: [6, 30, 54, 74, 102],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 121 },
                    { numBlocks: 5, dataCodewordsPerBlock: 122 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 47 },
                    { numBlocks: 14, dataCodewordsPerBlock: 48 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 11, dataCodewordsPerBlock: 24 },
                    { numBlocks: 14, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 16, dataCodewordsPerBlock: 15 },
                    { numBlocks: 14, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 102084,
              versionNumber: 24,
              alignmentPatternCenters: [6, 28, 54, 80, 106],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 6, dataCodewordsPerBlock: 117 },
                    { numBlocks: 4, dataCodewordsPerBlock: 118 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 6, dataCodewordsPerBlock: 45 },
                    { numBlocks: 14, dataCodewordsPerBlock: 46 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 11, dataCodewordsPerBlock: 24 },
                    { numBlocks: 16, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 30, dataCodewordsPerBlock: 16 },
                    { numBlocks: 2, dataCodewordsPerBlock: 17 }
                  ]
                }
              ]
            },
            {
              infoBits: 102881,
              versionNumber: 25,
              alignmentPatternCenters: [6, 32, 58, 84, 110],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 26,
                  ecBlocks: [
                    { numBlocks: 8, dataCodewordsPerBlock: 106 },
                    { numBlocks: 4, dataCodewordsPerBlock: 107 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 8, dataCodewordsPerBlock: 47 },
                    { numBlocks: 13, dataCodewordsPerBlock: 48 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 7, dataCodewordsPerBlock: 24 },
                    { numBlocks: 22, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 22, dataCodewordsPerBlock: 15 },
                    { numBlocks: 13, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 110507,
              versionNumber: 26,
              alignmentPatternCenters: [6, 30, 58, 86, 114],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 10, dataCodewordsPerBlock: 114 },
                    { numBlocks: 2, dataCodewordsPerBlock: 115 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 19, dataCodewordsPerBlock: 46 },
                    { numBlocks: 4, dataCodewordsPerBlock: 47 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 28, dataCodewordsPerBlock: 22 },
                    { numBlocks: 6, dataCodewordsPerBlock: 23 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 33, dataCodewordsPerBlock: 16 },
                    { numBlocks: 4, dataCodewordsPerBlock: 17 }
                  ]
                }
              ]
            },
            {
              infoBits: 110734,
              versionNumber: 27,
              alignmentPatternCenters: [6, 34, 62, 90, 118],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 8, dataCodewordsPerBlock: 122 },
                    { numBlocks: 4, dataCodewordsPerBlock: 123 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 22, dataCodewordsPerBlock: 45 },
                    { numBlocks: 3, dataCodewordsPerBlock: 46 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 8, dataCodewordsPerBlock: 23 },
                    { numBlocks: 26, dataCodewordsPerBlock: 24 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 12, dataCodewordsPerBlock: 15 },
                    { numBlocks: 28, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 117786,
              versionNumber: 28,
              alignmentPatternCenters: [6, 26, 50, 74, 98, 122],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 3, dataCodewordsPerBlock: 117 },
                    { numBlocks: 10, dataCodewordsPerBlock: 118 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 3, dataCodewordsPerBlock: 45 },
                    { numBlocks: 23, dataCodewordsPerBlock: 46 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 24 },
                    { numBlocks: 31, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 11, dataCodewordsPerBlock: 15 },
                    { numBlocks: 31, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 119615,
              versionNumber: 29,
              alignmentPatternCenters: [6, 30, 54, 78, 102, 126],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 7, dataCodewordsPerBlock: 116 },
                    { numBlocks: 7, dataCodewordsPerBlock: 117 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 21, dataCodewordsPerBlock: 45 },
                    { numBlocks: 7, dataCodewordsPerBlock: 46 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 1, dataCodewordsPerBlock: 23 },
                    { numBlocks: 37, dataCodewordsPerBlock: 24 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 19, dataCodewordsPerBlock: 15 },
                    { numBlocks: 26, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 126325,
              versionNumber: 30,
              alignmentPatternCenters: [6, 26, 52, 78, 104, 130],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 5, dataCodewordsPerBlock: 115 },
                    { numBlocks: 10, dataCodewordsPerBlock: 116 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 19, dataCodewordsPerBlock: 47 },
                    { numBlocks: 10, dataCodewordsPerBlock: 48 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 15, dataCodewordsPerBlock: 24 },
                    { numBlocks: 25, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 23, dataCodewordsPerBlock: 15 },
                    { numBlocks: 25, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 127568,
              versionNumber: 31,
              alignmentPatternCenters: [6, 30, 56, 82, 108, 134],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 13, dataCodewordsPerBlock: 115 },
                    { numBlocks: 3, dataCodewordsPerBlock: 116 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 46 },
                    { numBlocks: 29, dataCodewordsPerBlock: 47 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 42, dataCodewordsPerBlock: 24 },
                    { numBlocks: 1, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 23, dataCodewordsPerBlock: 15 },
                    { numBlocks: 28, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 133589,
              versionNumber: 32,
              alignmentPatternCenters: [6, 34, 60, 86, 112, 138],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 115 }]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 10, dataCodewordsPerBlock: 46 },
                    { numBlocks: 23, dataCodewordsPerBlock: 47 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 10, dataCodewordsPerBlock: 24 },
                    { numBlocks: 35, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 19, dataCodewordsPerBlock: 15 },
                    { numBlocks: 35, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 136944,
              versionNumber: 33,
              alignmentPatternCenters: [6, 30, 58, 86, 114, 142],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 17, dataCodewordsPerBlock: 115 },
                    { numBlocks: 1, dataCodewordsPerBlock: 116 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 14, dataCodewordsPerBlock: 46 },
                    { numBlocks: 21, dataCodewordsPerBlock: 47 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 29, dataCodewordsPerBlock: 24 },
                    { numBlocks: 19, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 11, dataCodewordsPerBlock: 15 },
                    { numBlocks: 46, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 141498,
              versionNumber: 34,
              alignmentPatternCenters: [6, 34, 62, 90, 118, 146],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 13, dataCodewordsPerBlock: 115 },
                    { numBlocks: 6, dataCodewordsPerBlock: 116 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 14, dataCodewordsPerBlock: 46 },
                    { numBlocks: 23, dataCodewordsPerBlock: 47 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 44, dataCodewordsPerBlock: 24 },
                    { numBlocks: 7, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 59, dataCodewordsPerBlock: 16 },
                    { numBlocks: 1, dataCodewordsPerBlock: 17 }
                  ]
                }
              ]
            },
            {
              infoBits: 145311,
              versionNumber: 35,
              alignmentPatternCenters: [6, 30, 54, 78, 102, 126, 150],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 12, dataCodewordsPerBlock: 121 },
                    { numBlocks: 7, dataCodewordsPerBlock: 122 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 12, dataCodewordsPerBlock: 47 },
                    { numBlocks: 26, dataCodewordsPerBlock: 48 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 39, dataCodewordsPerBlock: 24 },
                    { numBlocks: 14, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 22, dataCodewordsPerBlock: 15 },
                    { numBlocks: 41, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 150283,
              versionNumber: 36,
              alignmentPatternCenters: [6, 24, 50, 76, 102, 128, 154],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 6, dataCodewordsPerBlock: 121 },
                    { numBlocks: 14, dataCodewordsPerBlock: 122 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 6, dataCodewordsPerBlock: 47 },
                    { numBlocks: 34, dataCodewordsPerBlock: 48 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 46, dataCodewordsPerBlock: 24 },
                    { numBlocks: 10, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 2, dataCodewordsPerBlock: 15 },
                    { numBlocks: 64, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 152622,
              versionNumber: 37,
              alignmentPatternCenters: [6, 28, 54, 80, 106, 132, 158],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 17, dataCodewordsPerBlock: 122 },
                    { numBlocks: 4, dataCodewordsPerBlock: 123 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 29, dataCodewordsPerBlock: 46 },
                    { numBlocks: 14, dataCodewordsPerBlock: 47 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 49, dataCodewordsPerBlock: 24 },
                    { numBlocks: 10, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 24, dataCodewordsPerBlock: 15 },
                    { numBlocks: 46, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 158308,
              versionNumber: 38,
              alignmentPatternCenters: [6, 32, 58, 84, 110, 136, 162],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 4, dataCodewordsPerBlock: 122 },
                    { numBlocks: 18, dataCodewordsPerBlock: 123 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 13, dataCodewordsPerBlock: 46 },
                    { numBlocks: 32, dataCodewordsPerBlock: 47 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 48, dataCodewordsPerBlock: 24 },
                    { numBlocks: 14, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 42, dataCodewordsPerBlock: 15 },
                    { numBlocks: 32, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 161089,
              versionNumber: 39,
              alignmentPatternCenters: [6, 26, 54, 82, 110, 138, 166],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 20, dataCodewordsPerBlock: 117 },
                    { numBlocks: 4, dataCodewordsPerBlock: 118 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 40, dataCodewordsPerBlock: 47 },
                    { numBlocks: 7, dataCodewordsPerBlock: 48 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 43, dataCodewordsPerBlock: 24 },
                    { numBlocks: 22, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 10, dataCodewordsPerBlock: 15 },
                    { numBlocks: 67, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            },
            {
              infoBits: 167017,
              versionNumber: 40,
              alignmentPatternCenters: [6, 30, 58, 86, 114, 142, 170],
              errorCorrectionLevels: [
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 19, dataCodewordsPerBlock: 118 },
                    { numBlocks: 6, dataCodewordsPerBlock: 119 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 28,
                  ecBlocks: [
                    { numBlocks: 18, dataCodewordsPerBlock: 47 },
                    { numBlocks: 31, dataCodewordsPerBlock: 48 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 34, dataCodewordsPerBlock: 24 },
                    { numBlocks: 34, dataCodewordsPerBlock: 25 }
                  ]
                },
                {
                  ecCodewordsPerBlock: 30,
                  ecBlocks: [
                    { numBlocks: 20, dataCodewordsPerBlock: 15 },
                    { numBlocks: 61, dataCodewordsPerBlock: 16 }
                  ]
                }
              ]
            }
          ];
        },
        /* 11 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = a(0);
          function o(d, E, C, A) {
            var b = d.x - E.x + C.x - A.x, y = d.y - E.y + C.y - A.y;
            if (b === 0 && y === 0)
              return {
                a11: E.x - d.x,
                a12: E.y - d.y,
                a13: 0,
                a21: C.x - E.x,
                a22: C.y - E.y,
                a23: 0,
                a31: d.x,
                a32: d.y,
                a33: 1
              };
            var w = E.x - C.x, P = A.x - C.x, k = E.y - C.y, f = A.y - C.y, B = w * f - P * k, D = (b * f - P * y) / B, p = (w * y - b * k) / B;
            return {
              a11: E.x - d.x + D * E.x,
              a12: E.y - d.y + D * E.y,
              a13: D,
              a21: A.x - d.x + p * A.x,
              a22: A.y - d.y + p * A.y,
              a23: p,
              a31: d.x,
              a32: d.y,
              a33: 1
            };
          }
          function s(d, E, C, A) {
            var b = o(d, E, C, A);
            return {
              a11: b.a22 * b.a33 - b.a23 * b.a32,
              a12: b.a13 * b.a32 - b.a12 * b.a33,
              a13: b.a12 * b.a23 - b.a13 * b.a22,
              a21: b.a23 * b.a31 - b.a21 * b.a33,
              a22: b.a11 * b.a33 - b.a13 * b.a31,
              a23: b.a13 * b.a21 - b.a11 * b.a23,
              a31: b.a21 * b.a32 - b.a22 * b.a31,
              a32: b.a12 * b.a31 - b.a11 * b.a32,
              a33: b.a11 * b.a22 - b.a12 * b.a21
            };
          }
          function i(d, E) {
            return {
              a11: d.a11 * E.a11 + d.a21 * E.a12 + d.a31 * E.a13,
              a12: d.a12 * E.a11 + d.a22 * E.a12 + d.a32 * E.a13,
              a13: d.a13 * E.a11 + d.a23 * E.a12 + d.a33 * E.a13,
              a21: d.a11 * E.a21 + d.a21 * E.a22 + d.a31 * E.a23,
              a22: d.a12 * E.a21 + d.a22 * E.a22 + d.a32 * E.a23,
              a23: d.a13 * E.a21 + d.a23 * E.a22 + d.a33 * E.a23,
              a31: d.a11 * E.a31 + d.a21 * E.a32 + d.a31 * E.a33,
              a32: d.a12 * E.a31 + d.a22 * E.a32 + d.a32 * E.a33,
              a33: d.a13 * E.a31 + d.a23 * E.a32 + d.a33 * E.a33
            };
          }
          function m(d, E) {
            for (var C = s({ x: 3.5, y: 3.5 }, { x: E.dimension - 3.5, y: 3.5 }, { x: E.dimension - 6.5, y: E.dimension - 6.5 }, { x: 3.5, y: E.dimension - 3.5 }), A = o(E.topLeft, E.topRight, E.alignmentPattern, E.bottomLeft), b = i(A, C), y = n.BitMatrix.createEmpty(E.dimension, E.dimension), w = function(p, F) {
              var _ = b.a13 * p + b.a23 * F + b.a33;
              return {
                x: (b.a11 * p + b.a21 * F + b.a31) / _,
                y: (b.a12 * p + b.a22 * F + b.a32) / _
              };
            }, P = 0; P < E.dimension; P++)
              for (var k = 0; k < E.dimension; k++) {
                var f = k + 0.5, B = P + 0.5, D = w(f, B);
                y.set(k, P, d.get(Math.floor(D.x), Math.floor(D.y)));
              }
            return {
              matrix: y,
              mappingFunction: w
            };
          }
          x.extract = m;
        },
        /* 12 */
        /***/
        function(t, x, a) {
          Object.defineProperty(x, "__esModule", { value: !0 });
          var n = 4, o = 0.5, s = 1.5, i = function(f, B) {
            return Math.sqrt(Math.pow(B.x - f.x, 2) + Math.pow(B.y - f.y, 2));
          };
          function m(f) {
            return f.reduce(function(B, D) {
              return B + D;
            });
          }
          function d(f, B, D) {
            var p, F, _, M, R = i(f, B), N = i(B, D), I = i(f, D), $, G, W;
            return N >= R && N >= I ? (p = [B, f, D], $ = p[0], G = p[1], W = p[2]) : I >= N && I >= R ? (F = [f, B, D], $ = F[0], G = F[1], W = F[2]) : (_ = [f, D, B], $ = _[0], G = _[1], W = _[2]), (W.x - G.x) * ($.y - G.y) - (W.y - G.y) * ($.x - G.x) < 0 && (M = [W, $], $ = M[0], W = M[1]), { bottomLeft: $, topLeft: G, topRight: W };
          }
          function E(f, B, D, p) {
            var F = (m(A(f, D, p, 5)) / 7 + // Divide by 7 since the ratio is 1:1:3:1:1
            m(A(f, B, p, 5)) / 7 + m(A(D, f, p, 5)) / 7 + m(A(B, f, p, 5)) / 7) / 4;
            if (F < 1)
              throw new Error("Invalid module size");
            var _ = Math.round(i(f, B) / F), M = Math.round(i(f, D) / F), R = Math.floor((_ + M) / 2) + 7;
            switch (R % 4) {
              case 0:
                R++;
                break;
              case 2:
                R--;
                break;
            }
            return { dimension: R, moduleSize: F };
          }
          function C(f, B, D, p) {
            var F = [{ x: Math.floor(f.x), y: Math.floor(f.y) }], _ = Math.abs(B.y - f.y) > Math.abs(B.x - f.x), M, R, N, I;
            _ ? (M = Math.floor(f.y), R = Math.floor(f.x), N = Math.floor(B.y), I = Math.floor(B.x)) : (M = Math.floor(f.x), R = Math.floor(f.y), N = Math.floor(B.x), I = Math.floor(B.y));
            for (var $ = Math.abs(N - M), G = Math.abs(I - R), W = Math.floor(-$ / 2), a0 = M < N ? 1 : -1, j = R < I ? 1 : -1, K = !0, i0 = M, o0 = R; i0 !== N + a0; i0 += a0) {
              var H = _ ? o0 : i0, x0 = _ ? i0 : o0;
              if (D.get(H, x0) !== K && (K = !K, F.push({ x: H, y: x0 }), F.length === p + 1))
                break;
              if (W += G, W > 0) {
                if (o0 === I)
                  break;
                o0 += j, W -= $;
              }
            }
            for (var l0 = [], Z = 0; Z < p; Z++)
              F[Z] && F[Z + 1] ? l0.push(i(F[Z], F[Z + 1])) : l0.push(0);
            return l0;
          }
          function A(f, B, D, p) {
            var F, _ = B.y - f.y, M = B.x - f.x, R = C(f, B, D, Math.ceil(p / 2)), N = C(f, { x: f.x - M, y: f.y - _ }, D, Math.ceil(p / 2)), I = R.shift() + N.shift() - 1;
            return (F = N.concat(I)).concat.apply(F, R);
          }
          function b(f, B) {
            var D = m(f) / m(B), p = 0;
            return B.forEach(function(F, _) {
              p += Math.pow(f[_] - F * D, 2);
            }), { averageSize: D, error: p };
          }
          function y(f, B, D) {
            try {
              var p = A(f, { x: -1, y: f.y }, D, B.length), F = A(f, { x: f.x, y: -1 }, D, B.length), _ = {
                x: Math.max(0, f.x - f.y) - 1,
                y: Math.max(0, f.y - f.x) - 1
              }, M = A(f, _, D, B.length), R = {
                x: Math.min(D.width, f.x + f.y) + 1,
                y: Math.min(D.height, f.y + f.x) + 1
              }, N = A(f, R, D, B.length), I = b(p, B), $ = b(F, B), G = b(M, B), W = b(N, B), a0 = Math.sqrt(I.error * I.error + $.error * $.error + G.error * G.error + W.error * W.error), j = (I.averageSize + $.averageSize + G.averageSize + W.averageSize) / 4, K = (Math.pow(I.averageSize - j, 2) + Math.pow($.averageSize - j, 2) + Math.pow(G.averageSize - j, 2) + Math.pow(W.averageSize - j, 2)) / j;
              return a0 + K;
            } catch {
              return 1 / 0;
            }
          }
          function w(f, B) {
            for (var D = Math.round(B.x); f.get(D, Math.round(B.y)); )
              D--;
            for (var p = Math.round(B.x); f.get(p, Math.round(B.y)); )
              p++;
            for (var F = (D + p) / 2, _ = Math.round(B.y); f.get(Math.round(F), _); )
              _--;
            for (var M = Math.round(B.y); f.get(Math.round(F), M); )
              M++;
            var R = (_ + M) / 2;
            return { x: F, y: R };
          }
          function P(f) {
            for (var B = [], D = [], p = [], F = [], _ = function(H) {
              for (var x0 = 0, l0 = !1, Z = [0, 0, 0, 0, 0], u0 = function(E0) {
                var T0 = f.get(E0, H);
                if (T0 === l0)
                  x0++;
                else {
                  Z = [Z[1], Z[2], Z[3], Z[4], x0], x0 = 1, l0 = T0;
                  var g0 = m(Z) / 7, Z0 = Math.abs(Z[0] - g0) < g0 && Math.abs(Z[1] - g0) < g0 && Math.abs(Z[2] - 3 * g0) < 3 * g0 && Math.abs(Z[3] - g0) < g0 && Math.abs(Z[4] - g0) < g0 && !T0, N0 = m(Z.slice(-3)) / 3, re = Math.abs(Z[2] - N0) < N0 && Math.abs(Z[3] - N0) < N0 && Math.abs(Z[4] - N0) < N0 && T0;
                  if (Z0) {
                    var W0 = E0 - Z[3] - Z[4], P0 = W0 - Z[2], j0 = { startX: P0, endX: W0, y: H }, ae = D.filter(function(w0) {
                      return P0 >= w0.bottom.startX && P0 <= w0.bottom.endX || W0 >= w0.bottom.startX && P0 <= w0.bottom.endX || P0 <= w0.bottom.startX && W0 >= w0.bottom.endX && Z[2] / (w0.bottom.endX - w0.bottom.startX) < s && Z[2] / (w0.bottom.endX - w0.bottom.startX) > o;
                    });
                    ae.length > 0 ? ae[0].bottom = j0 : D.push({ top: j0, bottom: j0 });
                  }
                  if (re) {
                    var I0 = E0 - Z[4], O0 = I0 - Z[3], j0 = { startX: O0, y: H, endX: I0 }, ae = F.filter(function(K0) {
                      return O0 >= K0.bottom.startX && O0 <= K0.bottom.endX || I0 >= K0.bottom.startX && O0 <= K0.bottom.endX || O0 <= K0.bottom.startX && I0 >= K0.bottom.endX && Z[2] / (K0.bottom.endX - K0.bottom.startX) < s && Z[2] / (K0.bottom.endX - K0.bottom.startX) > o;
                    });
                    ae.length > 0 ? ae[0].bottom = j0 : F.push({ top: j0, bottom: j0 });
                  }
                }
              }, m0 = -1; m0 <= f.width; m0++)
                u0(m0);
              B.push.apply(B, D.filter(function(E0) {
                return E0.bottom.y !== H && E0.bottom.y - E0.top.y >= 2;
              })), D = D.filter(function(E0) {
                return E0.bottom.y === H;
              }), p.push.apply(p, F.filter(function(E0) {
                return E0.bottom.y !== H;
              })), F = F.filter(function(E0) {
                return E0.bottom.y === H;
              });
            }, M = 0; M <= f.height; M++)
              _(M);
            B.push.apply(B, D.filter(function(H) {
              return H.bottom.y - H.top.y >= 2;
            })), p.push.apply(p, F);
            var R = B.filter(function(H) {
              return H.bottom.y - H.top.y >= 2;
            }).map(function(H) {
              var x0 = (H.top.startX + H.top.endX + H.bottom.startX + H.bottom.endX) / 4, l0 = (H.top.y + H.bottom.y + 1) / 2;
              if (f.get(Math.round(x0), Math.round(l0))) {
                var Z = [H.top.endX - H.top.startX, H.bottom.endX - H.bottom.startX, H.bottom.y - H.top.y + 1], u0 = m(Z) / Z.length, m0 = y({ x: Math.round(x0), y: Math.round(l0) }, [1, 1, 3, 1, 1], f);
                return { score: m0, x: x0, y: l0, size: u0 };
              }
            }).filter(function(H) {
              return !!H;
            }).sort(function(H, x0) {
              return H.score - x0.score;
            }).map(function(H, x0, l0) {
              if (x0 > n)
                return null;
              var Z = l0.filter(function(m0, E0) {
                return x0 !== E0;
              }).map(function(m0) {
                return { x: m0.x, y: m0.y, score: m0.score + Math.pow(m0.size - H.size, 2) / H.size, size: m0.size };
              }).sort(function(m0, E0) {
                return m0.score - E0.score;
              });
              if (Z.length < 2)
                return null;
              var u0 = H.score + Z[0].score + Z[1].score;
              return { points: [H].concat(Z.slice(0, 2)), score: u0 };
            }).filter(function(H) {
              return !!H;
            }).sort(function(H, x0) {
              return H.score - x0.score;
            });
            if (R.length === 0)
              return null;
            var N = d(R[0].points[0], R[0].points[1], R[0].points[2]), I = N.topRight, $ = N.topLeft, G = N.bottomLeft, W = k(f, p, I, $, G), a0 = [];
            W && a0.push({
              alignmentPattern: { x: W.alignmentPattern.x, y: W.alignmentPattern.y },
              bottomLeft: { x: G.x, y: G.y },
              dimension: W.dimension,
              topLeft: { x: $.x, y: $.y },
              topRight: { x: I.x, y: I.y }
            });
            var j = w(f, I), K = w(f, $), i0 = w(f, G), o0 = k(f, p, j, K, i0);
            return o0 && a0.push({
              alignmentPattern: { x: o0.alignmentPattern.x, y: o0.alignmentPattern.y },
              bottomLeft: { x: i0.x, y: i0.y },
              topLeft: { x: K.x, y: K.y },
              topRight: { x: j.x, y: j.y },
              dimension: o0.dimension
            }), a0.length === 0 ? null : a0;
          }
          x.locate = P;
          function k(f, B, D, p, F) {
            var _, M, R;
            try {
              _ = E(p, D, F, f), M = _.dimension, R = _.moduleSize;
            } catch {
              return null;
            }
            var N = {
              x: D.x - p.x + F.x,
              y: D.y - p.y + F.y
            }, I = (i(p, F) + i(p, D)) / 2 / R, $ = 1 - 3 / I, G = {
              x: p.x + $ * (N.x - p.x),
              y: p.y + $ * (N.y - p.y)
            }, W = B.map(function(j) {
              var K = (j.top.startX + j.top.endX + j.bottom.startX + j.bottom.endX) / 4, i0 = (j.top.y + j.bottom.y + 1) / 2;
              if (f.get(Math.floor(K), Math.floor(i0))) {
                var o0 = [j.top.endX - j.top.startX, j.bottom.endX - j.bottom.startX, j.bottom.y - j.top.y + 1];
                m(o0) / o0.length;
                var H = y({ x: Math.floor(K), y: Math.floor(i0) }, [1, 1, 1], f), x0 = H + i({ x: K, y: i0 }, G);
                return { x: K, y: i0, score: x0 };
              }
            }).filter(function(j) {
              return !!j;
            }).sort(function(j, K) {
              return j.score - K.score;
            }), a0 = I >= 15 && W.length ? W[0] : G;
            return { alignmentPattern: a0, dimension: M };
          }
        }
        /******/
      ]).default
    );
  });
})(m1);
var vl = m1.exports;
const bl = /* @__PURE__ */ co(vl), {
  SvelteComponent: kl,
  append_hydration: Gx,
  attr: Vx,
  binding_callbacks: Qa,
  children: Xx,
  claim_element: $x,
  claim_space: wl,
  detach: Ut,
  element: Wx,
  init: yl,
  insert_hydration: Sl,
  noop: jx,
  safe_not_equal: Tl,
  space: Ml
} = window.__gradio__svelte__internal, { createEventDispatcher: Pl, onMount: _l, onDestroy: zl } = window.__gradio__svelte__internal;
function Rl(r) {
  let e, t, x, a;
  return {
    c() {
      e = Wx("div"), t = Wx("video"), x = Ml(), a = Wx("canvas"), this.h();
    },
    l(n) {
      e = $x(n, "DIV", { class: !0 });
      var o = Xx(e);
      t = $x(o, "VIDEO", { class: !0 }), Xx(t).forEach(Ut), x = wl(o), a = $x(o, "CANVAS", { class: !0 }), Xx(a).forEach(Ut), o.forEach(Ut), this.h();
    },
    h() {
      Vx(t, "class", "svelte-1sk36xo"), Vx(a, "class", "svelte-1sk36xo"), Vx(e, "class", "container svelte-1sk36xo");
    },
    m(n, o) {
      Sl(n, e, o), Gx(e, t), r[6](t), Gx(e, x), Gx(e, a), r[7](a);
    },
    p: jx,
    i: jx,
    o: jx,
    d(n) {
      n && Ut(e), r[6](null), r[7](null);
    }
  };
}
function Gt(r, e, t, x) {
  r.beginPath(), r.moveTo(e.x, e.y), r.lineTo(t.x, t.y), r.lineWidth = 4, r.strokeStyle = x, r.stroke();
}
function Nl(r, e, t) {
  var x = this && this.__awaiter || function(f, B, D, p) {
    function F(_) {
      return _ instanceof D ? _ : new D(function(M) {
        M(_);
      });
    }
    return new (D || (D = Promise))(function(_, M) {
      function R($) {
        try {
          I(p.next($));
        } catch (G) {
          M(G);
        }
      }
      function N($) {
        try {
          I(p.throw($));
        } catch (G) {
          M(G);
        }
      }
      function I($) {
        $.done ? _($.value) : F($.value).then(R, N);
      }
      I((p = p.apply(f, B || [])).next());
    });
  };
  let a, n, o = null, s = !1, i = null, { value: m } = e, { scanQREnabled: d = !0 } = e, { scanQROnce: E = !0 } = e, { showDetection: C = !0 } = e;
  const A = Pl();
  _l(() => {
    b();
  }), zl(() => {
    w(), o && o.getTracks().forEach((f) => f.stop());
  });
  function b() {
    return x(this, void 0, void 0, function* () {
      try {
        o = yield navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }), t(1, n.srcObject = o, n), n.setAttribute("playsinline", "true"), n.play(), t(
          1,
          n.onloadedmetadata = () => {
            y();
          },
          n
        );
      } catch (f) {
        console.error("Could not access webcam", f);
      }
    });
  }
  function y() {
    if (s) return;
    s = !0, console.log("Starting QR code scanning...");
    function f() {
      if (!n || n.readyState !== 4) {
        i = requestAnimationFrame(f);
        return;
      }
      const B = n.videoWidth, D = n.videoHeight;
      t(0, a.width = B, a), t(0, a.height = D, a);
      const p = a.getContext("2d");
      if (!p) return;
      p.drawImage(n, 0, 0, B, D);
      const F = p.getImageData(0, 0, B, D), _ = bl(F.data, B, D, { inversionAttempts: "dontInvert" });
      if (_) {
        if (console.log("QR Code detected:", m), t(2, m = _.data), A("change"), C) {
          const M = "#FF3B58";
          Gt(p, _.location.topLeftCorner, _.location.topRightCorner, M), Gt(p, _.location.topRightCorner, _.location.bottomRightCorner, M), Gt(p, _.location.bottomRightCorner, _.location.bottomLeftCorner, M), Gt(p, _.location.bottomLeftCorner, _.location.topLeftCorner, M);
        }
        if (E) {
          w();
          return;
        }
      }
      i = requestAnimationFrame(f);
    }
    f();
  }
  function w() {
    console.log("Stopping QR code scanning..."), s = !1, i !== null && (cancelAnimationFrame(i), i = null);
  }
  function P(f) {
    Qa[f ? "unshift" : "push"](() => {
      n = f, t(1, n);
    });
  }
  function k(f) {
    Qa[f ? "unshift" : "push"](() => {
      a = f, t(0, a);
    });
  }
  return r.$$set = (f) => {
    "value" in f && t(2, m = f.value), "scanQREnabled" in f && t(3, d = f.scanQREnabled), "scanQROnce" in f && t(4, E = f.scanQROnce), "showDetection" in f && t(5, C = f.showDetection);
  }, r.$$.update = () => {
    r.$$.dirty & /*scanQREnabled*/
    8 && (d ? y() : w());
  }, [
    a,
    n,
    m,
    d,
    E,
    C,
    P,
    k
  ];
}
class Ll extends kl {
  constructor(e) {
    super(), yl(this, e, Nl, Rl, Tl, {
      value: 2,
      scanQREnabled: 3,
      scanQROnce: 4,
      showDetection: 5
    });
  }
}
const {
  SvelteComponent: Il,
  add_flush_callback: Ol,
  append_hydration: ql,
  attr: Yx,
  bind: Hl,
  binding_callbacks: Ul,
  bubble: Gl,
  children: Za,
  claim_component: Ka,
  claim_element: Ja,
  claim_space: Vl,
  create_component: en,
  destroy_component: tn,
  detach: Vt,
  element: xn,
  init: Xl,
  insert_hydration: rn,
  mount_component: an,
  safe_not_equal: $l,
  set_style: Wl,
  space: jl,
  toggle_class: Yl,
  transition_in: nn,
  transition_out: on
} = window.__gradio__svelte__internal, { createEventDispatcher: Ql } = window.__gradio__svelte__internal;
function Zl(r) {
  let e, t, x, a, n, o, s;
  e = new rl({
    props: {
      show_label: (
        /*show_label*/
        r[2]
      ),
      Icon: d1,
      label: (
        /*label*/
        r[1] || "Image"
      )
    }
  });
  function i(d) {
    r[7](d);
  }
  let m = {
    scanQREnabled: (
      /*scanQREnabled*/
      r[3]
    ),
    scanQROnce: (
      /*scanQROnce*/
      r[4]
    ),
    showDetection: (
      /*showDetection*/
      r[5]
    )
  };
  return (
    /*value*/
    r[0] !== void 0 && (m.value = /*value*/
    r[0]), n = new Ll({ props: m }), Ul.push(() => Hl(n, "value", i)), n.$on(
      "error",
      /*error_handler*/
      r[8]
    ), n.$on(
      "change",
      /*change_handler*/
      r[9]
    ), {
      c() {
        en(e.$$.fragment), t = jl(), x = xn("div"), a = xn("div"), en(n.$$.fragment), this.h();
      },
      l(d) {
        Ka(e.$$.fragment, d), t = Vl(d), x = Ja(d, "DIV", { "data-testid": !0, class: !0 });
        var E = Za(x);
        a = Ja(E, "DIV", { class: !0 });
        var C = Za(a);
        Ka(n.$$.fragment, C), C.forEach(Vt), E.forEach(Vt), this.h();
      },
      h() {
        Yx(a, "class", "upload-container svelte-4w7mzq"), Yl(a, "reduced-height", !0), Wl(a, "width", "auto"), Yx(x, "data-testid", "image"), Yx(x, "class", "image-container svelte-4w7mzq");
      },
      m(d, E) {
        an(e, d, E), rn(d, t, E), rn(d, x, E), ql(x, a), an(n, a, null), s = !0;
      },
      p(d, [E]) {
        const C = {};
        E & /*show_label*/
        4 && (C.show_label = /*show_label*/
        d[2]), E & /*label*/
        2 && (C.label = /*label*/
        d[1] || "Image"), e.$set(C);
        const A = {};
        E & /*scanQREnabled*/
        8 && (A.scanQREnabled = /*scanQREnabled*/
        d[3]), E & /*scanQROnce*/
        16 && (A.scanQROnce = /*scanQROnce*/
        d[4]), E & /*showDetection*/
        32 && (A.showDetection = /*showDetection*/
        d[5]), !o && E & /*value*/
        1 && (o = !0, A.value = /*value*/
        d[0], Ol(() => o = !1)), n.$set(A);
      },
      i(d) {
        s || (nn(e.$$.fragment, d), nn(n.$$.fragment, d), s = !0);
      },
      o(d) {
        on(e.$$.fragment, d), on(n.$$.fragment, d), s = !1;
      },
      d(d) {
        d && (Vt(t), Vt(x)), tn(e, d), tn(n);
      }
    }
  );
}
function Kl(r, e, t) {
  let { value: x = null } = e, { label: a = void 0 } = e, { show_label: n } = e, { scanQREnabled: o } = e, { scanQROnce: s } = e, { showDetection: i } = e;
  const m = Ql();
  function d(A) {
    x = A, t(0, x);
  }
  function E(A) {
    Gl.call(this, r, A);
  }
  const C = () => m("change");
  return r.$$set = (A) => {
    "value" in A && t(0, x = A.value), "label" in A && t(1, a = A.label), "show_label" in A && t(2, n = A.show_label), "scanQREnabled" in A && t(3, o = A.scanQREnabled), "scanQROnce" in A && t(4, s = A.scanQROnce), "showDetection" in A && t(5, i = A.showDetection);
  }, [
    x,
    a,
    n,
    o,
    s,
    i,
    m,
    d,
    E,
    C
  ];
}
class Jl extends Il {
  constructor(e) {
    super(), Xl(this, e, Kl, Zl, $l, {
      value: 0,
      label: 1,
      show_label: 2,
      scanQREnabled: 3,
      scanQROnce: 4,
      showDetection: 5
    });
  }
}
const {
  SvelteComponent: ei,
  add_flush_callback: ti,
  bind: xi,
  binding_callbacks: h1,
  claim_component: sx,
  create_component: ux,
  destroy_component: cx,
  flush: G0,
  init: ri,
  mount_component: Ex,
  safe_not_equal: ai,
  transition_in: dx,
  transition_out: mx
} = window.__gradio__svelte__internal;
function ni(r) {
  let e, t;
  return e = new d1({}), {
    c() {
      ux(e.$$.fragment);
    },
    l(x) {
      sx(e.$$.fragment, x);
    },
    m(x, a) {
      Ex(e, x, a), t = !0;
    },
    i(x) {
      t || (dx(e.$$.fragment, x), t = !0);
    },
    o(x) {
      mx(e.$$.fragment, x), t = !1;
    },
    d(x) {
      cx(e, x);
    }
  };
}
function oi(r) {
  let e, t;
  return e = new Cl({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [ni] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      ux(e.$$.fragment);
    },
    l(x) {
      sx(e.$$.fragment, x);
    },
    m(x, a) {
      Ex(e, x, a), t = !0;
    },
    p(x, a) {
      const n = {};
      a & /*$$scope*/
      1048576 && (n.$$scope = { dirty: a, ctx: x }), e.$set(n);
    },
    i(x) {
      t || (dx(e.$$.fragment, x), t = !0);
    },
    o(x) {
      mx(e.$$.fragment, x), t = !1;
    },
    d(x) {
      cx(e, x);
    }
  };
}
function li(r) {
  let e, t, x;
  function a(o) {
    r[17](o);
  }
  let n = {
    label: (
      /*label*/
      r[4]
    ),
    show_label: (
      /*show_label*/
      r[5]
    ),
    scanQREnabled: (
      /*scan_qr_enabled*/
      r[11]
    ),
    scanQROnce: (
      /*scan_qr_once*/
      r[12]
    ),
    showDetection: (
      /*show_detection*/
      r[13]
    ),
    $$slots: { default: [oi] },
    $$scope: { ctx: r }
  };
  return (
    /*value*/
    r[0] !== void 0 && (n.value = /*value*/
    r[0]), e = new Jl({ props: n }), r[16](e), h1.push(() => xi(e, "value", a)), e.$on(
      "error",
      /*error_handler*/
      r[18]
    ), e.$on(
      "change",
      /*change_handler*/
      r[19]
    ), {
      c() {
        ux(e.$$.fragment);
      },
      l(o) {
        sx(e.$$.fragment, o);
      },
      m(o, s) {
        Ex(e, o, s), x = !0;
      },
      p(o, s) {
        const i = {};
        s & /*label*/
        16 && (i.label = /*label*/
        o[4]), s & /*show_label*/
        32 && (i.show_label = /*show_label*/
        o[5]), s & /*scan_qr_enabled*/
        2048 && (i.scanQREnabled = /*scan_qr_enabled*/
        o[11]), s & /*scan_qr_once*/
        4096 && (i.scanQROnce = /*scan_qr_once*/
        o[12]), s & /*show_detection*/
        8192 && (i.showDetection = /*show_detection*/
        o[13]), s & /*$$scope*/
        1048576 && (i.$$scope = { dirty: s, ctx: o }), !t && s & /*value*/
        1 && (t = !0, i.value = /*value*/
        o[0], ti(() => t = !1)), e.$set(i);
      },
      i(o) {
        x || (dx(e.$$.fragment, o), x = !0);
      },
      o(o) {
        mx(e.$$.fragment, o), x = !1;
      },
      d(o) {
        r[16](null), cx(e, o);
      }
    }
  );
}
function ii(r) {
  let e, t;
  return e = new G1({
    props: {
      visible: (
        /*visible*/
        r[3]
      ),
      variant: "solid",
      border_mode: "base",
      padding: !1,
      elem_id: (
        /*elem_id*/
        r[1]
      ),
      elem_classes: (
        /*elem_classes*/
        r[2]
      ),
      height: (
        /*height*/
        r[6] || void 0
      ),
      width: (
        /*width*/
        r[7]
      ),
      allow_overflow: !1,
      container: (
        /*container*/
        r[8]
      ),
      scale: (
        /*scale*/
        r[9]
      ),
      min_width: (
        /*min_width*/
        r[10]
      ),
      $$slots: { default: [li] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      ux(e.$$.fragment);
    },
    l(x) {
      sx(e.$$.fragment, x);
    },
    m(x, a) {
      Ex(e, x, a), t = !0;
    },
    p(x, [a]) {
      const n = {};
      a & /*visible*/
      8 && (n.visible = /*visible*/
      x[3]), a & /*elem_id*/
      2 && (n.elem_id = /*elem_id*/
      x[1]), a & /*elem_classes*/
      4 && (n.elem_classes = /*elem_classes*/
      x[2]), a & /*height*/
      64 && (n.height = /*height*/
      x[6] || void 0), a & /*width*/
      128 && (n.width = /*width*/
      x[7]), a & /*container*/
      256 && (n.container = /*container*/
      x[8]), a & /*scale*/
      512 && (n.scale = /*scale*/
      x[9]), a & /*min_width*/
      1024 && (n.min_width = /*min_width*/
      x[10]), a & /*$$scope, label, show_label, scan_qr_enabled, scan_qr_once, show_detection, upload_component, value, gradio*/
      1112113 && (n.$$scope = { dirty: a, ctx: x }), e.$set(n);
    },
    i(x) {
      t || (dx(e.$$.fragment, x), t = !0);
    },
    o(x) {
      mx(e.$$.fragment, x), t = !1;
    },
    d(x) {
      cx(e, x);
    }
  };
}
function si(r, e, t) {
  let { elem_id: x = "" } = e, { elem_classes: a = [] } = e, { visible: n = !0 } = e, { value: o = null } = e, { label: s } = e, { show_label: i } = e, { height: m } = e, { width: d } = e, { container: E = !0 } = e, { scale: C = null } = e, { min_width: A = void 0 } = e, { scan_qr_enabled: b } = e, { scan_qr_once: y } = e, { show_detection: w } = e, { gradio: P } = e, k;
  function f(F) {
    h1[F ? "unshift" : "push"](() => {
      k = F, t(15, k);
    });
  }
  function B(F) {
    o = F, t(0, o);
  }
  const D = ({ detail: F }) => P.dispatch("error", F), p = () => P.dispatch("change");
  return r.$$set = (F) => {
    "elem_id" in F && t(1, x = F.elem_id), "elem_classes" in F && t(2, a = F.elem_classes), "visible" in F && t(3, n = F.visible), "value" in F && t(0, o = F.value), "label" in F && t(4, s = F.label), "show_label" in F && t(5, i = F.show_label), "height" in F && t(6, m = F.height), "width" in F && t(7, d = F.width), "container" in F && t(8, E = F.container), "scale" in F && t(9, C = F.scale), "min_width" in F && t(10, A = F.min_width), "scan_qr_enabled" in F && t(11, b = F.scan_qr_enabled), "scan_qr_once" in F && t(12, y = F.scan_qr_once), "show_detection" in F && t(13, w = F.show_detection), "gradio" in F && t(14, P = F.gradio);
  }, [
    o,
    x,
    a,
    n,
    s,
    i,
    m,
    d,
    E,
    C,
    A,
    b,
    y,
    w,
    P,
    k,
    f,
    B,
    D,
    p
  ];
}
class ci extends ei {
  constructor(e) {
    super(), ri(this, e, si, ii, ai, {
      elem_id: 1,
      elem_classes: 2,
      visible: 3,
      value: 0,
      label: 4,
      show_label: 5,
      height: 6,
      width: 7,
      container: 8,
      scale: 9,
      min_width: 10,
      scan_qr_enabled: 11,
      scan_qr_once: 12,
      show_detection: 13,
      gradio: 14
    });
  }
  get elem_id() {
    return this.$$.ctx[1];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), G0();
  }
  get elem_classes() {
    return this.$$.ctx[2];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), G0();
  }
  get visible() {
    return this.$$.ctx[3];
  }
  set visible(e) {
    this.$$set({ visible: e }), G0();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), G0();
  }
  get label() {
    return this.$$.ctx[4];
  }
  set label(e) {
    this.$$set({ label: e }), G0();
  }
  get show_label() {
    return this.$$.ctx[5];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), G0();
  }
  get height() {
    return this.$$.ctx[6];
  }
  set height(e) {
    this.$$set({ height: e }), G0();
  }
  get width() {
    return this.$$.ctx[7];
  }
  set width(e) {
    this.$$set({ width: e }), G0();
  }
  get container() {
    return this.$$.ctx[8];
  }
  set container(e) {
    this.$$set({ container: e }), G0();
  }
  get scale() {
    return this.$$.ctx[9];
  }
  set scale(e) {
    this.$$set({ scale: e }), G0();
  }
  get min_width() {
    return this.$$.ctx[10];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), G0();
  }
  get scan_qr_enabled() {
    return this.$$.ctx[11];
  }
  set scan_qr_enabled(e) {
    this.$$set({ scan_qr_enabled: e }), G0();
  }
  get scan_qr_once() {
    return this.$$.ctx[12];
  }
  set scan_qr_once(e) {
    this.$$set({ scan_qr_once: e }), G0();
  }
  get show_detection() {
    return this.$$.ctx[13];
  }
  set show_detection(e) {
    this.$$set({ show_detection: e }), G0();
  }
  get gradio() {
    return this.$$.ctx[14];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), G0();
  }
}
export {
  ci as default
};
